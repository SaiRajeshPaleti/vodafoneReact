export default {
	id: 'radio_accordion',
	name: 'radioaccordion',
	displayAccordion: true,
	GetClickEvent: function GetClickEvent() {
		console.log('Radio Button click');
	},
	header: {
		type: 'Simple',
		headerData: {
			title: 'Radio Accordion Heading'
		},
		arrowTooltip: 'radio tooltip'
	},

	content: {
		type: 'Radio',

		contentData: [
			{
				id: 'radio1',
				name: 'radio',
				tooltip: 'click here to select',
				displayValue: 'Order',
				onChange: function onChange(event) {
					//Method Implementation goes here
					console.log(' I am in Radio Button data function', event);
				}
			},
			{
				id: 'radio1',
				name: 'radio',
				tooltip: 'click here to select',
				displayValue: 'Quote',
				onChange: function onChange(event) {
					//Method Implementation goes here
					console.log(' I am in Radio Button data function', event);
				}
			}
		]
	}
};
