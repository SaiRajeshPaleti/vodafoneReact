export default {

loggedInUser: "Test User",
	journeyInfo: [{ "key": "incident", "name": "incidents" }, { "key": "serviceRequest", "name": "service requests" }, { "key": "changeRequest", "name": "change requests" }, { "key": "problem", "name": "problems" }],
	journeyData: { "incident": "10", "serviceRequest": "20", "changeRequest": "30", "problem": "40" },
	linkInfo: {
		id: "",
		name: "linkName",
		linkType: "darkbgbodylink",
		url: "#",
		label: ""
		},
	rolesInfo: { "incident":true, "serviceRequest":true, "changeRequest":true, "problem": true  }
	

};

