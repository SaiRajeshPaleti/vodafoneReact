export default {
	activeTabKey: 'Incidents',
	id: 'lamp1',
	name: 'lavaLamp',
	type: 'tabWhiteBG',
	tabs: [
		{
			id: 'tab1',
			name: 'lavaLamp1',
			key: 'Incidents',
			value: 'Incidents'
		},
		{
			id: 'tab2',
			name: 'lavaLamp2',
			key: 'serviceRequests',
			value: 'Service requests'
		},
		{
			id: 'tab3',
			name: 'lavaLamp3',
			key: 'changeRequests',
			value: 'Change requests'
		},
		{
			id: 'tab4',
			name: 'lavaLamp4',
			key: 'problems',
			value: 'Problems'
		},
		{
			id: 'tab5',
			name: 'lavaLamp5',
			key: 'myServices',
			value: 'My services'
		}
	],
	onChange: function onChange(tab) {
		console.log(tab.id);
	}
};
