export default {
	advancedSearchTitle: 'Advanced Search',
	searchButtonLabel: 'Search',
	clearButtonLabel: 'Clear',
	closeTooltip: 'Click here to close the advanced search criteria view',
	clearFn: () => {
		console.log('Cleared!');
	},
	submitHandler: (searchCriteria) => {
		console.log('search query  ' + ' <<url>>' + '<<Default criteria>> ' + JSON.stringify(searchCriteria));
	},
	criteria: { QuoteReferenceNo: '123', StartDate: '2018-08-28T13:26:09.927Z' },

	advancedSearchComponentData: [
		{
			componentType: 'Text',
			id: 'cove-300',
			name: 'cove-300',
			searchAttribute: 'orderRef',
			placeholder: 'Order reference',
			title: '',
			maxLength: 40,
			value: ''
		},
		{
			componentType: 'Text',
			id: 'cove-301',
			name: 'cove-301',
			searchAttribute: 'customerRef',
			placeholder: 'Customer reference',
			title: '',
			maxLength: 40,
			value: ''
		},
		{
			componentType: 'Text',
			id: 'cove-302',
			name: 'cove-302',
			searchAttribute: 'postcode',
			placeholder: 'Post code',
			title: '',
			maxLength: 40,
			value: ''
		},
		{
			componentType: 'DateRange',
			isRangeAttribute: 'true',
			rangeValue: 90,
			rangeAttributes: [
				{
					data: {
						name: 'StartDate',
						title: 'StartDate',
						id: 'cove-200',
						searchAttribute: 'startDate',
						componentType: 'SimpleDate',
						placeholder: 'From Date',
						value: '',
						locale: 'en',
						format: 'DD MMM YYYY',
						//before: 90,
						deriving: true,
						after: 0
					},
					componentType: 'SimpleDate',
					searchAttribute: 'startDate'
				},
				{
					data: {
						name: 'endDate',
						title: 'endDate',
						id: 'cove-201',
						searchAttribute: 'endDate',
						componentType: 'SimpleDate',
						placeholder: 'To Date',
						value: '',
						locale: 'en',
						format: 'DD MMM YYYY',
						//before: 90,
						deriving: false,
						after: 0,
						defaultbefore: 30,
						defaultafter: 5
					},
					componentType: 'SimpleDate',
					searchAttribute: 'endDate'
				}
			]
		}
	]
};
