export default {
    data: {
        name: 'dateTimePicker',
        id: 'date_time_picker',
        title: 'Date Time',
        placeholder: 'Enter Date Time',
        locale: 'en-US',
        value: '05 Jun 2018 05:20 PM',
        before: 0,
        after: 0,
        dateFormat: 'DD MMM YYYY',
        timeFormat: 'hh:mm A',
        timeConstraints: {
            minutes: {
                min: 0,
                max: 59,
                step: 5
            }
        }
    },
    onChange: (data) => {
        console.log(data);
    }
};
