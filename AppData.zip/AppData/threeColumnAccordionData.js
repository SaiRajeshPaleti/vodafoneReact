export default {
	getCharges: function getCharges(params) {
		console.log(params);
		return new Promise((resolve, reject) => {
			let cosPrices = [];
			let standardPrice = {};
			let enhancedPrice = {};
			let premiumPrice = {};
			cosPrices.push(standardPrice);
			cosPrices.push(enhancedPrice);
			cosPrices.push(premiumPrice);
			standardPrice['firstTerm'] = {
				onOffCharge: '20',
				rentalPerAnnumCharge: '20'
			};
			enhancedPrice['firstTerm'] = {
				onOffCharge: '30',
				rentalPerAnnumCharge: '30'
			};
			premiumPrice['firstTerm'] = {
				onOffCharge: '20',
				rentalPerAnnumCharge: '30'
			};

			standardPrice['secondTerm'] = {
				onOffCharge: '30',
				rentalPerAnnumCharge: '40'
			};
			enhancedPrice['secondTerm'] = {
				onOffCharge: '30',
				rentalPerAnnumCharge: '40'
			};
			premiumPrice['secondTerm'] = {
				onOffCharge: '50',
				rentalPerAnnumCharge: '20'
			};
			resolve(cosPrices);
		});
	},
	//alwaysExpanded: true,
	displayAccordion: true,
	header: {
		type: 'ThreeDAccordion',

		headerData: {
			title: 'Show service options',
			headerTitle: 'Class of service',
			terms: {
				firstTerm: {
					onOffCharge: '0',
					rentalPerAnnumCharge: '0'
				},
				secondTerm: {
					onOffCharge: '0',
					rentalPerAnnumCharge: '0'
				}
			}
		}
	},
	content: {
		type: 'ThreeDAccordion',
		contentData: [
			{
				key: 'standard',
				type: 'Standard',
				'input-type': 'text',
				bandwidth: '500',
				actualBandwidth: '500',
				terms: {
					firstTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					},
					secondTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					}
				},
				textfield: {
					componentType: 'Text',
					id: 'standard',
					name: 'standard',
					maxLength: 10,
					placeholder: '',
					disabled: true
				},
				onSaveAddressHandler: function saveAddressHandler(addressDetails) {
					console.log('addressDetails', addressDetails);
				}
			},
			{
				type: 'Enhanced',
				key: 'enhanced',
				'input-type': 'text',
				bandwidth: '0',
				terms: {
					firstTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					},
					secondTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					}
				},
				textfield: {
					componentType: 'Text',
					id: 'enhanced',
					name: 'enhanced',
					maxLength: 10,
					placeholder: ''
				},
				onSaveAddressHandler: function saveAddressHandler(addressDetails) {
					console.log('addressDetails', addressDetails);
				}
			},
			{
				type: 'Premium',
				key: 'premium',
				'input-type': 'text',
				bandwidth: '0',
				terms: {
					firstTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					},
					secondTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					}
				},
				textfield: {
					componentType: 'Text',
					id: 'premium',
					name: 'premium',
					maxLength: 10,
					placeholder: ''
				},
				onSaveAddressHandler: function saveAddressHandler(addressDetails) {
					console.log('New added Address  ', addressDetails);
				}
			}
		]
	},
	footer: {
		type: 'Center',
		title: 'Hide service options'
	}
};
