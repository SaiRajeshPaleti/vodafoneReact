export default {
  contentSearch: {
    selectBoxName: 'form-input',
    selectBoxId: 'selectBox',

    dropdown: [
      {
        itemName: 'INCV',
        itemValue: 'INCV'
      },
      {
        itemName: 'Customer ref',
        itemValue: 'Customer ref'
      }
    ],
    defaultValue: 'Customer ref',
    restrict: 'Customer ref'
  },
  textSearch: {
    searchCriteriaLength: 2,
    textData: {
      id: 'ContextSerach',
      name: 'ContextSerach',
      maxLength: 40,
      placeholder: 'Enter Reference',
      clear: true,
      format: /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/
    },
    buttonData: {
      location: 'search',
      id: 'iconButton',
      name: '',
      type: 'primary',
      buttonType: 'button',
      isIcon: true
    }
  },
  onClick: (a) => {
    console.log('Search function invoked', a);
  },
  searchNote: 'Search for incident reference or customer reference. Enter a minimum of 3 characters'
};
