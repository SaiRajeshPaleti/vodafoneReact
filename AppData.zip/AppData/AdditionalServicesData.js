export default {
	AccordionData: [
		{
			removeAdditionalServices: function removeAdditionalServices(headerData) {
				console.log('remove additional Section', headerData);
			},
			selectQuoteOption: function selectQuoteOption(quoteOption) {
				console.log('Selected Plan', quoteOption);
			},
			getHeaderValue: function getHeaderValue(totalHeaderValue) {
				//Method Implementation goes here when slected Raio button in the header
				console.log(' Selected Header Value is', totalHeaderValue);
			},
			selectButtonClick: function selectButtonClick(id) {
				//Button click both in the header and content
				console.log('i am in select Button click', id);
			},
			routerRequired: function routerRequired(params) {
				console.log(params);
				return new Promise((resolve, reject) => {
					let ports = [
						{
							id: 'AS1237',
							name: 'routerPorts1',
							bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR',
							label: 'AS1237 Cisco 2819 - 10M Eth RTR',
							checked: true,
							terms: {
								firstTerm: {
									onOffCharge: '250.57',
									rentalPerAnnumCharge: '200.67'
								},
								secondTerm: {
									onOffCharge: '150.47',
									rentalPerAnnumCharge: '100.27'
								}
							},
							installation: {
								firstTerm: {
									install: '100',
									rentOrBuy: '200'
								},
								secondTerm: {
									install: '500',
									rentOrBuy: '100'
								}
							}
						},
						{
							id: 'ADVA825',
							name: 'routerPorts1',
							bandwidth: 'ADVA 825 5 Port',
							label: 'ADVA 825 5 Port',
							checked: false,
							className: 'row_wrapper',
							terms: {
								firstTerm: {
									onOffCharge: '',
									rentalPerAnnumCharge: '100'
								},
								secondTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: ''
								}
							},
							installation: {
								firstTerm: {
									install: '200',
									rentOrBuy: ''
								},
								secondTerm: {
									install: '',
									rentOrBuy: '100'
								}
							}
						},
						{
							id: 'ADVA206',
							name: 'routerPorts1',
							bandwidth: 'ADVA 206 6 Port',
							label: 'ADVA 206 6 Port',
							checked: false,
							terms: {
								firstTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: ''
								},
								secondTerm: {
									onOffCharge: '',
									rentalPerAnnumCharge: '100'
								}
							},
							installation: {
								firstTerm: {
									install: '100',
									rentOrBuy: ''
								},
								secondTerm: {
									install: '',
									rentOrBuy: '900'
								}
							}
						}
					];
					resolve(ports);
				});
			},
			rentOrBuyButtonHandler: function rentOrBuyButtonHandler(params) {
				console.log(params);
				return new Promise((resolve, reject) => {
					let ports = [
						{
							id: 'AS1237',
							name: 'routerPorts1',
							bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR',
							label: 'AS1237 Cisco 2819 - 10M Eth RTR',
							checked: true,
							terms: {
								firstTerm: {
									onOffCharge: '250.57',
									rentalPerAnnumCharge: '200.67'
								},
								secondTerm: {
									onOffCharge: '150.47',
									rentalPerAnnumCharge: '100.27'
								}
							},
							installation: {
								firstTerm: {
									install: '100',
									rentOrBuy: '200'
								},
								secondTerm: {
									install: '500',
									rentOrBuy: '100'
								}
							}
						},
						{
							id: 'ADVA825',
							name: 'routerPorts1',
							bandwidth: 'ADVA 825 5 Port',
							label: 'ADVA 825 5 Port',
							checked: false,
							className: 'row_wrapper',
							terms: {
								firstTerm: {
									onOffCharge: '',
									rentalPerAnnumCharge: '100'
								},
								secondTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: ''
								}
							},
							installation: {
								firstTerm: {
									install: '200',
									rentOrBuy: ''
								},
								secondTerm: {
									install: '',
									rentOrBuy: '100'
								}
							}
						},
						{
							id: 'ADVA206',
							name: 'routerPorts1',
							bandwidth: 'ADVA 206 6 Port',
							label: 'ADVA 206 6 Port',
							checked: false,
							terms: {
								firstTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: ''
								},
								secondTerm: {
									onOffCharge: '',
									rentalPerAnnumCharge: '100'
								}
							},
							installation: {
								firstTerm: {
									install: '100',
									rentOrBuy: ''
								},
								secondTerm: {
									install: '',
									rentOrBuy: '900'
								}
							}
						}
					];
					resolve(ports);
				});
			},
			setContentData: function setContentData(contentData) {
				//updated contentData
				//console.log('contentData', contentData);
			},
			setHeaderData: function setHeaderData(headerData) {
				//console.log('headerData', headerData);
			},
			updateOptionCharges: function updateOptionCharges(params) {
				console.log('params:', params);
				let additionalServices = [
					{
						id: 'DNSRegistrationManagement',
						title: 'DNS Registration & Management',
						type: 'input',
						status: false,
						display: true,
						checkBoxContent: {
							id: 'DNSRegistrationManagementMailRelay',
							name: 'DNSRegistrationManagementMailRelay',
							displayValue: 'Mail relay',
							value: 'false',
							onClick: function onClick(selectedPlan) {
								console.log('Selected Plan', selectedPlan);
							}
						},
						domains: [
							{
								id: '.co.uk',
								name: '.co.uk',
								label: '.co.uk',
								charges: {
									firstTerm: {
										onOffCharge: '10.46',
										rentalPerAnnumCharge: '20.45'
									},
									secondTerm: {
										onOffCharge: '20.54',
										rentalPerAnnumCharge: ''
									}
								},
								value: ''
							},
							{
								id: '.com',
								name: '.com',
								label: '.com',
								charges: {
									firstTerm: {
										onOffCharge: '9',
										rentalPerAnnumCharge: '14'
									},
									secondTerm: {
										onOffCharge: '14',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: '.net',
								name: '.net',
								label: '.net',
								charges: {
									firstTerm: {
										onOffCharge: '10',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '15',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: '.org',
								name: '.org',
								label: '.org',
								charges: {
									firstTerm: {
										onOffCharge: '9',
										rentalPerAnnumCharge: '14'
									},
									secondTerm: {
										onOffCharge: '16',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},

							{
								id: 'Mail Relay',
								name: 'Mail Relay',
								label: 'Mail Relay',
								charges: {
									firstTerm: {
										onOffCharge: '9',
										rentalPerAnnumCharge: '14'
									},
									secondTerm: {
										onOffCharge: '16',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							}
						],
						notification: {
							messageTitle: 'Quantity for domains between 0 to 10000',
							messageBody:
								"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
						}
					},
					{
						id: 'DNSTransferManagement',
						title: 'DNS Transfer & Management',
						type: 'input',
						mailRelay: true,
						display: true,
						checkBoxContent: {
							id: 'DNSTransferManagementMailRelay',
							name: 'DNSTransferManagementMailRelay',
							displayValue: 'Mail relay',
							value: 'false'
						},
						status: false,
						domains: [
							{
								id: '.co.uk',
								name: '.co.uk',
								label: '.co.uk',
								charges: {
									firstTerm: {
										onOffCharge: '10',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '15',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: 'Mail Relay',
								name: 'Mail Relay',
								label: 'Mail Relay',
								charges: {
									firstTerm: {
										onOffCharge: '10',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '15',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: '.com',
								name: '.com',
								label: '.com',
								charges: {
									firstTerm: {
										onOffCharge: '9',
										rentalPerAnnumCharge: '14'
									},
									secondTerm: {
										onOffCharge: '14',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: '.net',
								name: '.net',
								label: '.net',
								charges: {
									firstTerm: {
										onOffCharge: '10',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '15',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: '.org',
								name: '.org',
								label: '.org',
								charges: {
									firstTerm: {
										onOffCharge: '9',
										rentalPerAnnumCharge: '14'
									},
									secondTerm: {
										onOffCharge: '16',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							},
							{
								id: '.gov.uk',
								name: '.gov.uk',
								label: '.gov.uk',
								charges: {
									firstTerm: {
										onOffCharge: '12',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '11',
										rentalPerAnnumCharge: '13'
									}
								},
								value: ''
							},
							{
								id: '.ac.uk',
								name: '.ac.uk',
								label: '.ac.uk',
								charges: {
									firstTerm: {
										onOffCharge: '20',
										rentalPerAnnumCharge: '25'
									},
									secondTerm: {
										onOffCharge: '30',
										rentalPerAnnumCharge: '50'
									}
								},
								value: ''
							}
						],
						notification: {
							messageTitle: 'Quantity for domains between 0 to 10000',
							messageBody:
								"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
						}
					},
					{
						id: 'DistributedDenialServiceProtection',
						title: 'Distributed denial of service protection',
						type: 'radio',
						status: false,
						display: true,
						checkBoxContent: {
							id: 'DDServiceProtection',
							name: 'DDServiceProtection',
							displayValue: 'Mail relay',
							value: 'false'
						},
						domains: [
							{
								id: 'ServiceOption1',
								name: 'Service Option1',
								label: 'Service Option1',
								charges: {
									firstTerm: {
										onOffCharge: '950.0',
										rentalPerAnnumCharge: '1457.0'
									},
									secondTerm: {
										onOffCharge: '0',
										rentalPerAnnumCharge: '2250'
									}
								},
								value: ''
							},
							{
								id: 'ServiceOption2',
								name: 'Service Option2',
								label: 'Service Option2',
								checked: true,
								charges: {
									firstTerm: {
										onOffCharge: '1000.0',
										rentalPerAnnumCharge: '1000.0'
									},
									secondTerm: {
										onOffCharge: '0',
										rentalPerAnnumCharge: '2500'
									}
								},
								value: '1'
							}
						]
					},
					{
						id: 'ProviderIndependent',
						title: 'Provider Independent (IP)',
						type: 'input',
						status: false,
						display: false,
						checkBoxContent: {
							id: 'ProviderIndependentMailRealy',
							name: 'ProviderIndependentMailRealy',
							displayValue: 'Mail relay',
							value: 'false'
						},
						domains: [
							{
								id: 'qty',
								name: 'qty',
								label: 'qty',
								charges: {
									firstTerm: {
										onOffCharge: '10',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '15',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							}
						]
					},
					{
						id: 'NonPortableIPAddresses',
						title: 'Non portable IP Addresses',
						type: 'input',
						status: false,
						display: true,
						domains: [
							{
								id: '.co.uk',
								name: '.co.uk',
								label: '.co.uk',
								charges: {
									firstTerm: {
										onOffCharge: '10',
										rentalPerAnnumCharge: '15'
									},
									secondTerm: {
										onOffCharge: '15',
										rentalPerAnnumCharge: '20'
									}
								},
								value: ''
							}
						]
					},
					{
						id: 'PerformanceReporting',
						title: 'Performance reporting',
						type: 'input',
						status: false,
						display: true,
						domains: []
					}
				];
				return new Promise((resolve, reject) => {
					additionalServices.map((service) => {
						if (service.id === params.additionalServiceId) {
							service.domains.map((domain) => {
								if (domain.id === params.optionId) {
									resolve(domain);
								}
								return domain;
							});
						}
						return service;
					});
				});
			},
			id: 'router_required',
			name: 'router_required',
			displayAccordion: true,
			header: {
				type: 'ThreeColumn',
				headerData: {
					additionalData: {
						terms: {
							firstTerm: {
								name: '1 year term',
								onOffCharge: '',
								// apiData1: '@FormData.onOffCharge|firstTerm.installationCharge',
								rentalPerAnnumCharge: ''
								// apiData2:
								// 	'@FormData.rentalPerAnnumCharge|firstTerm.recurringCharge'
							},
							secondTerm: {
								name: '3 years term',
								onOffCharge: '',
								//apiData1: '@FormData.onOffCharge|secondTerm.installationCharge',
								rentalPerAnnumCharge: ''
								//apiData2:
								//'@FormData.rentalPerAnnumCharge|secondTerm.recurringCharge'
							}
						},
						status: true,
						control: ''
					},
					additionalSection: true,
					deleteFlag: true,
					title: 'Show additional services',
					plan: {
						control: 'radio',
						name: 'Fiber Off-Net',
						accessSpeed: '500 Mbps',
						bearerSpeed: '1000 Mbps'
					},
					buttonList: {
						firstTerm: {
							id: 'headerbutton_1',
							name: 'Select',
							type: 'tertiary',
							buttonType: 'button',
							isIcon: false,
							location: 'lefttick',
							uniqueReference: '1234'
						},
						secondTerm: {
							id: 'headerbutton_2',
							name: 'Select',
							type: 'tertiary',
							buttonType: 'button',
							isIcon: false,
							location: 'lefttick',
							uniqueReference: '2345'
						}
					},
					terms: {
						firstTerm: {
							name: '1 Year term',
							onOffCharge: '',
							rentalPerAnnumCharge: ''
						},
						secondTerm: {
							name: '3 Years term',
							onOffCharge: '',
							rentalPerAnnumCharge: ''
						}
					}
				}
			},
			content: {
				type: 'AdditionalServices',
				contentData: {
					additionalServices: [
						{
							id: 'DNSRegistrationManagement',
							title: 'DNS Registration & Management',
							type: 'input',
							status: false,
							display: true,
							checkBoxContent: {
								id: 'DNSRegistrationManagementMailRelay',
								name: 'DNSRegistrationManagementMailRelay',
								displayValue: 'Mail relay',
								value: 'false',
								onClick: function onClick(selectedPlan) {
									console.log('Selected Plan', selectedPlan);
								}
							},

							domains: [
								{
									id: '.co.uk',
									name: '.co.uk',
									label: '.co.uk',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.com',
									name: '.com',
									label: '.com',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.net',
									name: '.net',
									label: '.net',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.org',
									name: '.org',
									label: '.org',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},

								{
									id: 'Mail Relay',
									name: 'Mail Relay',
									label: 'Mail Relay',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								}
							],
							notification: {
								messageTitle: 'Quantity for domains between 0 to 10000',
								messageBody:
									"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
							}
						},
						{
							id: 'DNSTransferManagement',
							title: 'DNS Transfer & Management',
							type: 'input',
							mailRelay: true,
							display: true,
							checkBoxContent: {
								id: 'DNSTransferManagementMailRelay',
								name: 'DNSTransferManagementMailRelay',
								displayValue: 'Mail relay',
								value: 'false'
							},
							status: false,
							domains: [
								{
									id: '.co.uk',
									name: '.co.uk',
									label: '.co.uk',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: 'Mail Relay',
									name: 'Mail Relay',
									label: 'Mail Relay',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.com',
									name: '.com',
									label: '.com',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.net',
									name: '.net',
									label: '.net',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.org',
									name: '.org',
									label: '.org',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.gov.uk',
									name: '.gov.uk',
									label: '.gov.uk',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: '.ac.uk',
									name: '.ac.uk',
									label: '.ac.uk',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								}
							],
							notification: {
								messageTitle: 'Quantity for domains between 0 to 10000',
								messageBody:
									"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
							}
						},
						{
							id: 'DistributedDenialServiceProtection',
							title: 'Distributed denial of service protection',
							type: 'radio',
							status: false,
							display: true,
							checkBoxContent: {
								id: 'DDServiceProtection',
								name: 'DDServiceProtection',
								displayValue: 'Mail relay',
								value: 'false'
							},
							domains: [
								{
									id: 'ServiceOption1',
									name: 'Service Option1',
									label: 'Service Option1',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: 'ServiceOption2',
									name: 'Service Option2',
									label: 'Service Option2',
									checked: false,
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								}
							]
						},
						{
							id: 'ProviderIndependent',
							title: 'Provider Independent (IP)',
							type: 'input',
							status: false,
							display: false,
							checkBoxContent: {
								id: 'ProviderIndependentMailRealy',
								name: 'ProviderIndependentMailRealy',
								displayValue: 'Mail relay',
								value: 'false'
							},
							domains: [
								{
									id: 'qty',
									name: 'qty',
									label: 'qty',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								}
							]
						},
						{
							id: 'NonPortableIPAddresses',
							title: 'Non portable IP Addresses',
							type: 'input',
							status: false,
							display: true,
							domains: [
								{
									id: '.co.uk',
									name: '.co.uk',
									label: '.co.uk',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								}
							]
						},
						{
							id: 'PerformanceReporting',
							title: 'Performance reporting',
							type: 'radio',
							status: false,
							display: true,
							domains: [
								{
									id: 'ServiceOption1',
									name: 'Service Option1',
									label: 'Service Option1',
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: ''
								},
								{
									id: 'ServiceOption2',
									name: 'Service Option2',
									label: 'Service Option2',
									checked: false,
									charges: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										}
									},
									value: '0'
								}
							]
						}
					],
					routerModels: {
						routerLabels: {
							install: 'Install',
							rental: 'Rental/Buy'
						},
						defaultRouterCost: {
							name: 'Default',
							terms: {
								firstTerm: {
									install: '0',
									rentOrBuy: '0'
								},
								secondTerm: {
									install: '0',
									rentOrBuy: '0'
								}
							}
						},
						ports: [
							{
								id: 'AS1237',
								name: 'routerPorts1',
								bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR',
								label: 'AS1237 Cisco 2819 - 10M Eth RTR',
								checked: true,
								terms: {
									firstTerm: {
										onOffCharge: '250.57',
										rentalPerAnnumCharge: '200.67'
									},
									secondTerm: {
										onOffCharge: '150.47',
										rentalPerAnnumCharge: '100.27'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: '200'
									},
									secondTerm: {
										install: '500',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA825',
								name: 'routerPorts1',
								bandwidth: 'ADVA 825 5 Port',
								label: 'ADVA 825 5 Port',
								checked: false,
								className: 'row_wrapper',
								terms: {
									firstTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									},
									secondTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									}
								},
								installation: {
									firstTerm: {
										install: '200',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA206',
								name: 'routerPorts1',
								bandwidth: 'ADVA 206 6 Port',
								label: 'ADVA 206 6 Port',
								checked: false,
								terms: {
									firstTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									},
									secondTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '900'
									}
								}
							}
						],
						checkBoxContent: {
							name: 'RouterRequired',
							id: 'RouterRequired',
							displayValue: 'Router required',
							value: 'false'
						},
						buttons: [
							{
								id: 'rentButton',
								name: 'Rent',
								type: 'secondary',
								buttonType: 'button'
							},
							{
								id: 'buyButton',
								name: 'Buy',
								type: 'tertiary',
								buttonType: 'button'
							}
						]
					},
					dropdownSection: {
						dropDownData: {
							id: 'burstspeed',
							name: 'Please select',
							clickTxt: 'Please select',
							title: 'Please select',
							value: '',
							dropdownValues: [
								{
									optionName: 'Please select',
									optionValue: 'Please select',
									id: 1
								},
								{
									optionName: '100 Mbps',
									optionValue: '100 Mbps',
									id: 2
								}
							]
						},
						alertMessageData: {
							type: 'info',
							name: 'info',
							id: 'l_a',
							lightBackground: true,
							arrowRequired: false,
							messageTitle: 'Information',
							messageBody: 'Adding burst speed with add additional charges to your annual recurring price'
						},
						labelData: {
							id: 'label1',
							type: 'labelDefault',
							htmlFor: '',
							labelname: 'Burst speed'
						}
					},
					heading: 'Additional services'
				}
			},
			footer: {
				type: 'Simple',
				title: 'Hide services options'
			}
		}
		// {
		// 	removeAdditionalServices: function removeAdditionalServices(headerData) {
		// 		console.log('remove additional Section', headerData);
		// 	},
		// 	selectQuoteOption: function selectQuoteOption(quoteOption) {
		// 		console.log('Selected Plan', quoteOption);
		// 	},
		// 	getHeaderValue: function getHeaderValue(totalHeaderValue) {
		// 		//Method Implementation goes here when slected Raio button in the header
		// 		console.log(' Selected Header Value is', totalHeaderValue);
		// 	},
		// 	selectButtonClick: function selectButtonClick(id) {
		// 		//Button click both in the header and content
		// 		console.log('i am in select Button click', id);
		// 	},
		// 	rentOrBuyButtonHandler: function rentOrBuyButtonHandler(selectedButton) {
		// 		console.log('i am in rent Button click', selectedButton);
		// 	},
		// 	setContentData: function setContentData(contentData) {
		// 		//updated contentData
		// 		//console.log('contentData', contentData);
		// 	},
		// 	setHeaderData: function setHeaderData(headerData) {
		// 		//console.log('headerData', headerData);
		// 	},
		// 	id: 'router_required',
		// 	name: 'router_required',
		// 	displayAccordion: true,
		// 	header: {
		// 		type: 'ThreeColumn',
		// 		headerData: {
		// 			// additionalData: {
		// 			// 	terms: {
		// 			// 		firstTerm: {
		// 			// 			name: '1 year term',
		// 			// 			onOffCharge: '12345',
		// 			// 			// apiData1: '@FormData.onOffCharge|firstTerm.installationCharge',
		// 			// 			rentalPerAnnumCharge: '1234'
		// 			// 			// apiData2:
		// 			// 			// 	'@FormData.rentalPerAnnumCharge|firstTerm.recurringCharge'
		// 			// 		},
		// 			// 		secondTerm: {
		// 			// 			name: '3 years term',
		// 			// 			onOffCharge: '123',
		// 			// 			//apiData1: '@FormData.onOffCharge|secondTerm.installationCharge',
		// 			// 			rentalPerAnnumCharge: '154'
		// 			// 			//apiData2:
		// 			// 			//'@FormData.rentalPerAnnumCharge|secondTerm.recurringCharge'
		// 			// 		}
		// 			// 	},
		// 			// 	status: true,
		// 			// 	control: ''
		// 			// },
		// 			// additionalSection: true,
		// 			deleteFlag: true,
		// 			title: 'Show additional services',
		// 			plan: {
		// 				control: 'radio',
		// 				name: 'Fiber Off-Net',
		// 				accessSpeed: '500 Mbps',
		// 				bearerSpeed: '1000 Mbps'
		// 			},
		// 			buttonList: {
		// 				firstTerm: {
		// 					id: 'headerbutton_1',
		// 					name: 'Select',
		// 					type: 'tertiary',
		// 					buttonType: 'button',
		// 					isIcon: false,
		// 					location: 'lefttick',
		// 					uniqueReference: '1234'
		// 				},
		// 				secondTerm: {
		// 					id: 'headerbutton_2',
		// 					name: 'Select',
		// 					type: 'tertiary',
		// 					buttonType: 'button',
		// 					isIcon: false,
		// 					location: 'lefttick',
		// 					uniqueReference: '2345'
		// 				}
		// 			},
		// 			terms: {
		// 				firstTerm: {
		// 					name: '1 Year term',
		// 					onOffCharge: '',
		// 					rentalPerAnnumCharge: ''
		// 				},
		// 				secondTerm: {
		// 					name: '3 Years term',
		// 					onOffCharge: '',
		// 					rentalPerAnnumCharge: ''
		// 				}
		// 			}
		// 		}
		// 	},
		// 	content: {
		// 		type: 'AdditionalServices',
		// 		contentData: {
		// 			additionalServices: [
		// 				{
		// 					id: 'DNSRegistrationManagement',
		// 					title: 'DNS Registration & Management',
		// 					type: 'input',
		// 					mailRelay: true,
		// 					status: false,
		// 					display: true,
		// 					checkBoxContent: {
		// 						id: 'DNSRegistrationManagementMailRelay',
		// 						name: 'DNSRegistrationManagementMailRelay',
		// 						displayValue: 'Mail relay',
		// 						value: 'false',
		// 						onClick: function onClick(selectedPlan) {
		// 							console.log('Selected Plan', selectedPlan);
		// 						}
		// 					},
		// 					domains: [
		// 						{
		// 							id: '.co.uk',
		// 							name: '.co.uk',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '10',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '15',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.com',
		// 							name: '.com',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '9',
		// 									rentalPerAnnumCharge: '14'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '14',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.net',
		// 							name: '.net',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '10',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '15',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.org',
		// 							name: '.org',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '9',
		// 									rentalPerAnnumCharge: '14'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '16',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						}
		// 					],
		// 					notification: {
		// 						messageTitle: 'Quantity for domains between 0 to 10000',
		// 						messageBody:
		// 							"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
		// 					}
		// 				},
		// 				{
		// 					id: 'DNSTransferManagement',
		// 					title: 'DNS Transfer & Management',
		// 					type: 'input',
		// 					mailRelay: true,
		// 					display: false,
		// 					checkBoxContent: {
		// 						id: 'DNSTransferManagementMailRelay',
		// 						name: 'DNSTransferManagementMailRelay',
		// 						displayValue: 'Mail relay',
		// 						value: 'false'
		// 					},
		// 					status: false,
		// 					domains: [
		// 						{
		// 							id: '.co.uk',
		// 							name: '.co.uk',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '10',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '15',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.com',
		// 							name: '.com',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '9',
		// 									rentalPerAnnumCharge: '14'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '14',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.net',
		// 							name: '.net',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '10',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '15',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.org',
		// 							name: '.org',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '9',
		// 									rentalPerAnnumCharge: '14'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '16',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.gov.uk',
		// 							name: '.gov.uk',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '12',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '11',
		// 									rentalPerAnnumCharge: '13'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: '.ac.uk',
		// 							name: '.ac.uk',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '20',
		// 									rentalPerAnnumCharge: '25'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '30',
		// 									rentalPerAnnumCharge: '50'
		// 								}
		// 							},
		// 							value: ''
		// 						}
		// 					],
		// 					notification: {
		// 						messageTitle: 'Quantity for domains between 0 to 10000',
		// 						messageBody:
		// 							"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
		// 					}
		// 				},
		// 				{
		// 					id: 'DistributedDenialServiceProtection',
		// 					title: 'Distributed denial of service protection',
		// 					type: 'radio',
		// 					status: false,
		// 					display: true,
		// 					domains: [
		// 						{
		// 							id: 'ServiceOption1',
		// 							name: 'Service Option1',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '950.0',
		// 									rentalPerAnnumCharge: '1457.0'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '0',
		// 									rentalPerAnnumCharge: '2250'
		// 								}
		// 							},
		// 							value: ''
		// 						},
		// 						{
		// 							id: 'ServiceOption2',
		// 							name: 'Service Option2',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '1000.0',
		// 									rentalPerAnnumCharge: '1000.0'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '0',
		// 									rentalPerAnnumCharge: '2500'
		// 								}
		// 							},
		// 							value: ''
		// 						}
		// 					]
		// 				},
		// 				{
		// 					id: 'ProviderIndependent',
		// 					title: 'Provider Independent (IP)',
		// 					type: 'input',
		// 					status: false,
		// 					display: false,
		// 					domains: [
		// 						{
		// 							id: 'qty',
		// 							name: 'qty',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '10',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '15',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						}
		// 					]
		// 				},
		// 				{
		// 					id: 'NonPortableIPAddresses',
		// 					title: 'Non portable IP Addresses',
		// 					type: 'input',
		// 					status: false,
		// 					display: true,
		// 					domains: [
		// 						{
		// 							id: '.co.uk',
		// 							name: '.co.uk',
		// 							charges: {
		// 								firstTerm: {
		// 									onOffCharge: '10',
		// 									rentalPerAnnumCharge: '15'
		// 								},
		// 								secondTerm: {
		// 									onOffCharge: '15',
		// 									rentalPerAnnumCharge: '20'
		// 								}
		// 							},
		// 							value: ''
		// 						}
		// 					]
		// 				},
		// 				{
		// 					id: 'PerformanceReporting',
		// 					title: 'Performance reporting',
		// 					type: 'input',
		// 					status: false,
		// 					display: true,
		// 					domains: []
		// 				}
		// 			],
		// 			routerModels: {
		// 				defaultRouterCost: {
		// 					name: 'Default',
		// 					terms: {
		// 						firstTerm: {
		// 							install: '',
		// 							rentOrBuy: ''
		// 						},
		// 						secondTerm: {
		// 							install: '',
		// 							rentOrBuy: ''
		// 						}
		// 					}
		// 				},
		// 				ports: [
		// 					{
		// 						id: 'AS1237',
		// 						name: 'routerPorts1',
		// 						bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR',
		// 						checked: true,
		// 						terms: {
		// 							firstTerm: {
		// 								onOffCharge: '',
		// 								rentalPerAnnumCharge: ''
		// 							},
		// 							secondTerm: {
		// 								onOffCharge: '',
		// 								rentalPerAnnumCharge: ''
		// 							}
		// 						},
		// 						installation: {
		// 							firstTerm: {
		// 								install: '',
		// 								rentOrBuy: ''
		// 							},
		// 							secondTerm: {
		// 								install: '',
		// 								rentOrBuy: ''
		// 							}
		// 						}
		// 					},
		// 					{
		// 						id: 'ADVA825',
		// 						name: 'routerPorts1',
		// 						bandwidth: 'ADVA 825 5 Port',
		// 						checked: false,
		// 						className: 'row_wrapper',
		// 						terms: {
		// 							firstTerm: {
		// 								onOffCharge: '',
		// 								rentalPerAnnumCharge: ''
		// 							},
		// 							secondTerm: {
		// 								onOffCharge: '',
		// 								rentalPerAnnumCharge: ''
		// 							}
		// 						},
		// 						installation: {
		// 							firstTerm: {
		// 								install: '',
		// 								rentOrBuy: ''
		// 							},
		// 							secondTerm: {
		// 								install: '',
		// 								rentOrBuy: ''
		// 							}
		// 						}
		// 					},
		// 					{
		// 						id: 'ADVA206',
		// 						name: 'routerPorts1',
		// 						bandwidth: 'ADVA 206 6 Port',
		// 						checked: false,
		// 						terms: {
		// 							firstTerm: {
		// 								onOffCharge: '',
		// 								rentalPerAnnumCharge: ''
		// 							},
		// 							secondTerm: {
		// 								onOffCharge: '',
		// 								rentalPerAnnumCharge: ''
		// 							}
		// 						},
		// 						installation: {
		// 							firstTerm: {
		// 								install: '',
		// 								rentOrBuy: ''
		// 							},
		// 							secondTerm: {
		// 								install: '',
		// 								rentOrBuy: '900'
		// 							}
		// 						}
		// 					}
		// 				],
		// 				checkBoxContent: {
		// 					name: 'RouterRequired',
		// 					id: 'RouterRequired',
		// 					displayValue: 'Router required',
		// 					value: 'false'
		// 				},
		// 				buttons: [
		// 					{
		// 						id: 'rentButton',
		// 						name: 'Rent',
		// 						type: 'secondary',
		// 						buttonType: 'button'
		// 					},
		// 					{
		// 						id: 'buyButton',
		// 						name: 'Buy',
		// 						type: 'tertiary',
		// 						buttonType: 'button'
		// 					}
		// 				]
		// 			},
		// 			dropdownSection: {
		// 				dropDownData: {
		// 					id: 'burstspeed',
		// 					name: 'Please select',
		// 					clickTxt: 'Please select',
		// 					title: 'Please select',
		// 					value: '',
		// 					dropdownValues: [
		// 						{
		// 							optionName: 'Please select',
		// 							optionValue: 'Please select',
		// 							id: 1
		// 						},
		// 						{
		// 							optionName: '100 Mbps',
		// 							optionValue: '100 Mbps',
		// 							id: 2
		// 						}
		// 					]
		// 				},
		// 				alertMessageData: {
		// 					type: 'info',
		// 					name: 'info',
		// 					id: 'l_a',
		// 					lightBackground: true,
		// 					arrowRequired: false,
		// 					messageTitle: 'Information',
		// 					messageBody: 'Adding burst speed with add additional charges to your annual recurring price'
		// 				},
		// 				labelData: {
		// 					id: 'label1',
		// 					type: 'labelDefault',
		// 					htmlFor: '',
		// 					labelname: 'Burst speed'
		// 				}
		// 			},
		// 			heading: 'Additional services'
		// 		}
		// 	},
		// 	footer: {
		// 		type: 'Simple',
		// 		title: 'Hide services options'
		// 	}
		// }
	]
};
