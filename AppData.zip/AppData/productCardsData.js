export default {
	type: 'ProductCarouselList',
	//enableDefaultSelection: true,
	//defaultSelectedProd: 'Ethernet Wireline',
	card4: [
		{
			type: 'card4',
			Id: 'w1',
			url: 'EWL_interconnect',
			name: 'Ethernet Wireline',
			description: 'Ethernet Wireline',
			description1: 'Interconnects',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w11',
			url: 'EWL_pointtopoint',
			name: 'Ethernet Wireless',
			description: 'Ethernet Wireless',
			description1: 'Point to Point',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w12',
			url: 'EWL_MSPbearer',
			name: 'Ethernet Wirelines',
			description: 'Ethernet Wirelines',
			description1: 'Bearer',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w31',
			url: 'EWL_interconnect',
			name: 'Ethernet Publicline',
			description: 'Ethernet Publicline',
			description1: 'Interconnects',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w14',
			url: 'EWL_interconnect',
			name: 'Wholesale',
			description: 'Wholesale',
			description1: 'IPVPN',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w15',
			url: 'EWL_MSPbearer',
			name: 'Retail',
			description: 'Retail',
			description1: 'IPVPNS',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w16',
			url: 'EWL_interconnect',
			name: 'Wholesale privateline',
			description: 'Wholesale privateline',
			description1: 'IPVPN point',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w17',
			url: 'EWL_interconnect',
			name: 'Wholesale publicline',
			description: 'Wholesale publicline',
			description1: 'IPV point',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w18',
			url: 'EWL_interconnect',
			name: 'Entranet Wireline',
			description: 'Entranet Wireline',
			description1: 'IP point',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w19',
			url: 'EWL_interconnect',
			name: 'Interconnects Wireline',
			description: 'Interconnects Wireline',
			description1: 'IN point',
			onClick: () => {}
		},
		{
			type: 'card4',
			Id: 'w10',
			url: 'EWL_interconnect',
			name: 'Interconnects privateline',
			description: 'Interconnects privateline',
			description1: 'INCN point',
			onClick: () => {}
		}
	],
	onClick: (e) => {
		console.log('selected card ' + JSON.stringify(e));
	},
	// onSlide: (e) => {
	// 	console.log('onSlide card ' + JSON.stringify(e));
	// },
	tooltip: 'Click here to access more products',
	displayCards: {
		minimumCards: 5,
		intialIndex: 0,
		singleStep: 5,
		multipleStpes: 5
	}
};
