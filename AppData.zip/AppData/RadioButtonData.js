export default {
	onChange: function onChange(event) {
		//Method Implementation goes here
		console.log(' I am in Radio Button data function', event);
	},
	id: '1',
	name: 'radio',
	tooltip: 'click here to select',
	displayValue: 'Order Something',
};
