export default {
	id: 'compositeaccordion',
	name: 'compositeaccordion',
	displayAccordion: true,
	onChange: function onChange(selectedPlan) {
		console.log('Selected Plan', selectedPlan);
	},
	getAccordionInfo: function getAccordionInfo(totalHeaderValue) {
		//Method Implementation goes here
		console.log(' Selected Header Value is', totalHeaderValue);
	},
	selectButtonClick: function selectButtonClick() {
		console.log('i am in select Button click');
	},
	remove: function remove() {
		console.log('i am in remove button click');
	},

	header: {
		type: 'ThreeColumn',
		headerData: {
			title: 'Show additional services',
			additionalData: {
				terms: {
					firstTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					},
					secondTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: '0'
					}
				}
			},
			additionalSection: false,
			plan: {
				control: 'delete',
				name: 'Fiber Off-Net',
				id: 'multiselection',
				accessSpeed: '500 Mbps',
				bearerSpeed: '1000 Mbps'
			},
			terms: {
				firstTerm: {
					name: '1 Year term',
					onOffCharge: '1050.0',
					rentalPerAnnumCharge: '6156.0'
				},
				secondTerm: {
					name: '3 Years term',
					onOffCharge: '0.0',
					rentalPerAnnumCharge: '6098.2'
				}
			}
		}
	},
	content: {
		type: 'MultiSiteOption',
		contentData: [
			{
				routerRequired: function routerRequired(params) {
					console.log(params);
					return new Promise((resolve, reject) => {
						let ports = [
							{
								id: 'AS1237',
								name: 'routerPorts',
								bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR1',
								label: 'AS1237 Cisco 2819 - 10M Eth RTR',
								checked: true,
								terms: {
									firstTerm: {
										onOffCharge: '250.57',
										rentalPerAnnumCharge: '200.67'
									},
									secondTerm: {
										onOffCharge: '150.47',
										rentalPerAnnumCharge: '100.27'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: '200'
									},
									secondTerm: {
										install: '500',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA825',
								name: 'routerPorts',
								bandwidth: 'ADVA 825 5 Port',
								label: 'ADVA 825 5 Port',
								checked: false,
								className: 'row_wrapper',
								terms: {
									firstTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									},
									secondTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									}
								},
								installation: {
									firstTerm: {
										install: '200',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA206',
								name: 'routerPorts',
								bandwidth: 'ADVA 206 6 Port',
								label: 'ADVA 206 6 Port',
								checked: false,
								terms: {
									firstTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									},
									secondTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '900'
									}
								}
							}
						];
						resolve(ports);
					});
				},
				rentOrBuyButtonHandler: function rentOrBuyButtonHandler(params) {
					console.log(params);
					return new Promise((resolve, reject) => {
						let ports = [
							{
								id: 'AS1237',
								name: 'routerPorts1',
								bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR',
								label: 'AS1237 Cisco 2819 - 10M Eth RTR',
								checked: true,
								terms: {
									firstTerm: {
										onOffCharge: '250.57',
										rentalPerAnnumCharge: '200.67'
									},
									secondTerm: {
										onOffCharge: '150.47',
										rentalPerAnnumCharge: '100.27'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: '200'
									},
									secondTerm: {
										install: '500',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA825',
								name: 'routerPorts1',
								bandwidth: 'ADVA 825 5 Port',
								label: 'ADVA 825 5 Port',
								checked: false,
								className: 'row_wrapper',
								terms: {
									firstTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									},
									secondTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									}
								},
								installation: {
									firstTerm: {
										install: '200',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA206',
								name: 'routerPorts1',
								bandwidth: 'ADVA 206 6 Port',
								label: 'ADVA 206 6 Port',
								checked: false,
								terms: {
									firstTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									},
									secondTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '900'
									}
								}
							}
						];
						resolve(ports);
					});
				},
				selectedService: function selectedService(selectedPlan) {
					console.log('selectedPlan in primary', selectedPlan);
					return new Promise((resolve, reject) => {
						let selectedPLan = {
							id: selectedPlan.id,
							name: selectedPlan.name,
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '300'
								},
								secondTerm: {
									onOffCharge: '400',
									rentalPerAnnumCharge: '500'
								}
							}
						};
						resolve(selectedPLan);
					});
				},
				selectRouter: function selectRouter(selectedRouter) {
					console.log('selectedRouter in primary', selectedRouter);
				},
				selectedPSTNOption: function selectedPSTNOption(selectedVPNOption) {
					console.log('selected VPN Option in primary :', selectedVPNOption);
					return new Promise((resolve, reject) => {
						let selectedPlan = {
							label: selectedVPNOption.label,
							checked: false,
							id: selectedVPNOption.id,
							name: selectedVPNOption.name,
							displayAdditional: true,
							control: '',
							terms: {
								firstTerm: {
									onOffCharge: '100',
									rentalPerAnnumCharge: '100'
								},
								secondTerm: {
									onOffCharge: '100',
									rentalPerAnnumCharge: '100'
								}
							}
						};
						resolve(selectedPlan);
					});
				},
				selectedSpeedOption: function selectedSpeedOption(selectedOption) {
					console.log('selected speedOption in primary is :', selectedOption);
				},
				id: 'primary',
				display: true,
				title: 'Primary access service options',
				routerModels: {
					key: 'primary',
					routerLabels: {
						install: 'Install',
						rental: 'Rental'
					},
					defaultRouterCost: {
						name: 'Default',
						terms: {
							firstTerm: {
								install: '0',
								rentOrBuy: '0'
							},
							secondTerm: {
								install: '0',
								rentOrBuy: '0'
							}
						}
					},
					ports: [],
					checkBoxContent: {
						name: 'RouterRequired1',
						id: 'RouterRequired1',
						displayValue: 'Router required',
						value: 'false'
					},
					buttons: [
						{
							id: 'rentButton1',
							name: 'Rent',
							type: 'secondary',
							buttonType: 'button'
						},
						{
							display: true,
							id: 'buyButton1',
							name: 'Buy',
							type: 'tertiary',
							buttonType: 'button'
						}
					]
				},
				speedoptions: {
					contentData: [
						{
							key: 'primary',
							heading: 'Port speed options',
							plans: [
								{
									bandwidth: '400 Mbps',
									label: '400 Mbps',
									checked: false,
									id: 'speedoptions1',
									name: 'speedoptions1',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '950.0',
											rentalPerAnnumCharge: '5457.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5240.0'
										}
									}
								},
								{
									bandwidth: '450 Mbps',
									label: '450 Mbps',
									id: 'speedoptions2',
									name: 'speedoptions1',
									checked: false,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1000.0',
											rentalPerAnnumCharge: '6000.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5542.0'
										}
									}
								},
								{
									bandwidth: '500 Mbps',
									label: '500 Mbps',
									id: 'speedoptions3',
									name: 'speedoptions1',
									checked: true,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1050.0',
											rentalPerAnnumCharge: '6156.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6098.2'
										}
									}
								},
								{
									bandwidth: '550 Mbps',
									label: '550 Mbps',
									checked: false,
									id: 'speedoptions4',
									name: 'speedoptions1',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1100.0',
											rentalPerAnnumCharge: '7230.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6989.4'
										}
									}
								},
								{
									bandwidth: '600 Mbps',
									label: '600 Mbps',
									checked: false,
									id: 'speedoptions5',
									name: 'speedoptions1',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '1250.0',
											rentalPerAnnumCharge: '7990.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '7840.4'
										}
									}
								}
							]
						}
					]
				},
				classofService: {
					key: 'primary',
					title: 'Class of service options',
					data: [
						{
							id: 'primaryoption1',
							checked: false,
							name: 'option1',
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							}
						},
						{
							id: 'primaryoption2',
							name: 'option1',
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '950',
									rentalPerAnnumCharge: '1000'
								},
								secondTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '300'
								}
							}
						},
						{
							id: 'primaryoption3',
							name: 'option1',
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '300'
								},
								secondTerm: {
									onOffCharge: '400',
									rentalPerAnnumCharge: '500'
								}
							}
						}
					]
				},
				pstnOptions: {
					contentData: [
						{
							key: 'primary',
							heading: 'Multi VPN',
							plans: [
								{
									label: '1',
									checked: false,
									id: '1',
									name: 'pstnoptions1',
									getCharges: true,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										}
									}
								},
								{
									label: '2',
									checked: false,
									id: '2',
									name: 'pstnoptions1',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '3',
									checked: false,
									id: '3',
									name: 'pstnoptions1',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '4',
									checked: false,
									getCharges: true,
									id: '4',
									name: 'pstnoptions1',
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '5',
									checked: false,
									id: '5',
									name: 'pstnoptions1',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '6',
									checked: false,
									id: '6',
									name: 'pstnoptions1',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								}
							]
						}
					]
				},
				AssuranceSpeeds: {
					contentData: [
						{
							heading: 'Assurance rates',
							plans: []
						}
					]
				},
				enhancedOptions: {
					contentData: [
						{
							heading: 'Enhanced care',
							plans: []
						}
					]
				},
				newPstnOptions: {
					contentData: [
						{
							heading: 'New PSTN Line',
							plans: []
						}
					]
				}
			},
			{
				routerRequired: function routerRequired(params) {
					console.log(params);
					return new Promise((resolve, reject) => {
						let ports = [
							{
								id: 'AS1237',
								name: 'routerPorts1',
								bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR1',
								label: 'AS1237 Cisco 2819 - 10M Eth RTR1',
								checked: true,
								terms: {
									firstTerm: {
										onOffCharge: '250.57',
										rentalPerAnnumCharge: '200.67'
									},
									secondTerm: {
										onOffCharge: '150.47',
										rentalPerAnnumCharge: '100.27'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: '200'
									},
									secondTerm: {
										install: '500',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA825',
								name: 'routerPorts1',
								bandwidth: 'ADVA 825 5 Port',
								label: 'ADVA 825 5 Port1',
								checked: false,
								className: 'row_wrapper',
								terms: {
									firstTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									},
									secondTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									}
								},
								installation: {
									firstTerm: {
										install: '200',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA206',
								name: 'routerPorts1',
								bandwidth: 'ADVA 206 6 Port',
								label: 'ADVA 206 6 Port1',
								checked: false,
								terms: {
									firstTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									},
									secondTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '900'
									}
								}
							}
						];
						resolve(ports);
					});
				},
				rentOrBuyButtonHandler: function rentOrBuyButtonHandler(params) {
					console.log(params);
					return new Promise((resolve, reject) => {
						let ports = [
							{
								id: 'AS1237',
								name: 'routerPorts1',
								bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR1',
								label: 'AS1237 Cisco 2819 - 10M Eth RTR1',
								checked: true,
								terms: {
									firstTerm: {
										onOffCharge: '250.57',
										rentalPerAnnumCharge: '200.67'
									},
									secondTerm: {
										onOffCharge: '150.47',
										rentalPerAnnumCharge: '100.27'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: '200'
									},
									secondTerm: {
										install: '500',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA825',
								name: 'routerPorts1',
								bandwidth: 'ADVA 825 5 Port',
								label: 'ADVA 825 5 Port1',
								checked: false,
								className: 'row_wrapper',
								terms: {
									firstTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									},
									secondTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									}
								},
								installation: {
									firstTerm: {
										install: '200',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '100'
									}
								}
							},
							{
								id: 'ADVA206',
								name: 'routerPorts1',
								bandwidth: 'ADVA 206 6 Port',
								label: 'ADVA 206 6 Port1',
								checked: false,
								terms: {
									firstTerm: {
										onOffCharge: '200',
										rentalPerAnnumCharge: ''
									},
									secondTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: '100'
									}
								},
								installation: {
									firstTerm: {
										install: '100',
										rentOrBuy: ''
									},
									secondTerm: {
										install: '',
										rentOrBuy: '900'
									}
								}
							}
						];
						resolve(ports);
					});
				},
				selectedService: function selectedService(selectedPlan) {
					console.log('selectedPlan in primary', selectedPlan);
					return new Promise((resolve, reject) => {
						let selectedPLan = {
							id: selectedPlan.id,
							name: selectedPlan.name,
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '300',
									rentalPerAnnumCharge: '300'
								},
								secondTerm: {
									onOffCharge: '300',
									rentalPerAnnumCharge: '300'
								}
							}
						};
						resolve(selectedPLan);
					});
				},
				selectRouter: function selectRouter(selectedRouter) {
					console.log('selectedRouter in secondary', selectedRouter);
				},
				selectedNewPSTNOption: function selectedNewPSTNOption(selectedNewPSTNOption) {
					console.log('selected New PSTN in primary :', selectedNewPSTNOption);
					return new Promise((resolve, reject) => {
						let selectedPlan = {
							label: selectedNewPSTNOption.label,
							checked: false,
							id: selectedNewPSTNOption.id,
							name: selectedNewPSTNOption.name,
							getCharges: true,
							control: '',
							terms: {
								firstTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '200'
								},
								secondTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '200'
								}
							}
						};
						resolve(selectedPlan);
					});
				},
				selectedSpeedOption: function selectedSpeedOption(selectedOption) {
					console.log('selected speedOption in secondary is :', selectedOption);
				},

				selectedAssuranceOption: function selectedAssuranceOption(selectedOption) {
					console.log('selected Assurance option in secondary is :', selectedOption);
				},
				selectedPSTNOption: function selectedPSTNOption(selectedPSTNOption) {
					console.log('selected VPN Option in primary :', selectedPSTNOption);
					return new Promise((resolve, reject) => {
						let selectedPlan = {
							label: selectedPSTNOption.label,
							checked: false,
							id: selectedPSTNOption.id,
							name: selectedPSTNOption.name,
							getCharges: true,
							control: '',
							terms: {
								firstTerm: {
									onOffCharge: '500',
									rentalPerAnnumCharge: '500'
								},
								secondTerm: {
									onOffCharge: '500',
									rentalPerAnnumCharge: '00'
								}
							}
						};
						resolve(selectedPlan);
					});
				},
				selectedEnhancedOption: function selectedEnhancedOption(selectedEnhancedOption) {
					console.log('selected Enhanced Option in primary :', selectedEnhancedOption);
					return new Promise((resolve, reject) => {
						let selectedPlan = {
							label: selectedEnhancedOption.label,
							checked: false,
							id: selectedEnhancedOption.id,
							name: selectedEnhancedOption.name,
							getCharges: true,
							control: '',
							terms: {
								firstTerm: {
									onOffCharge: '400',
									rentalPerAnnumCharge: '400'
								},
								secondTerm: {
									onOffCharge: '400',
									rentalPerAnnumCharge: '400'
								}
							}
						};
						resolve(selectedPlan);
					});
				},
				title: 'Secondary access service options',
				id: 'secondary',
				display: true,
				speedoptions: {
					contentData: [
						{
							heading: 'Port speed options',
							plans: [
								{
									bandwidth: '400 Mbps',
									label: '400 Mbps',
									checked: false,
									id: 'speedoptions1',
									name: 'speedoptions',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '950.0',
											rentalPerAnnumCharge: '5457.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5240.0'
										}
									}
								},
								{
									bandwidth: '450 Mbps',
									label: '450 Mbps',
									id: 'speedoptions2',
									name: 'speedoptions',
									checked: false,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1000.0',
											rentalPerAnnumCharge: '6000.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5542.0'
										}
									}
								},
								{
									bandwidth: '500 Mbps',
									label: '500 Mbps',
									id: 'speedoptions3',
									name: 'speedoptions',
									checked: true,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1050.0',
											rentalPerAnnumCharge: '6156.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6098.2'
										}
									}
								},
								{
									bandwidth: '550 Mbps',
									label: '550 Mbps',
									checked: false,
									id: 'speedoptions4',
									name: 'speedoptions',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1100.0',
											rentalPerAnnumCharge: '7230.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6989.4'
										}
									}
								},
								{
									bandwidth: '600 Mbps',
									label: '600 Mbps',
									checked: false,
									id: 'speedoptions5',
									name: 'speedoptions',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '1250.0',
											rentalPerAnnumCharge: '7990.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '7840.4'
										}
									}
								}
							]
						}
					]
				},
				routerModels: {
					routerLabels: {
						install: 'Install',
						rental: 'Rental'
					},
					defaultRouterCost: {
						name: 'Default',
						terms: {
							firstTerm: {
								install: '0',
								rentOrBuy: '0'
							},
							secondTerm: {
								install: '0',
								rentOrBuy: '0'
							}
						}
					},
					ports: [],
					checkBoxContent: {
						name: 'RouterRequired1',
						id: 'RouterRequired1',
						displayValue: 'Router required',
						value: 'false'
					},
					buttons: [
						{
							id: 'rentButton',
							name: 'Rent',
							type: 'secondary',
							buttonType: 'button'
						},
						{
							display: true,
							id: 'buyButton',
							name: 'Buy',
							type: 'tertiary',
							buttonType: 'button'
						}
					]
				},
				classofService: {
					title: 'Class of service options',
					data: [
						{
							id: 'option2',
							name: 'CosOption',
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							}
						},
						{
							id: 'option3',
							name: 'CosOption',
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '950',
									rentalPerAnnumCharge: '1000'
								},
								secondTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '300'
								}
							}
						},
						{
							id: 'option4',
							name: 'CosOption',
							checked: false,
							standard: {
								title: 'Standard',
								percentage: '100%',
								speed: '10.0'
							},
							enhanced: {
								title: 'Enhanced',
								percentage: '100%',
								speed: '10.0'
							},
							premium: {
								title: 'Premium',
								percentage: '100%',
								speed: '10.0'
							},
							terms: {
								firstTerm: {
									onOffCharge: '200',
									rentalPerAnnumCharge: '300'
								},
								secondTerm: {
									onOffCharge: '400',
									rentalPerAnnumCharge: '500'
								}
							}
						}
					]
				},
				pstnOptions: {
					contentData: [
						{
							heading: 'Multi VPN',
							plans: [
								{
									label: '1',
									checked: false,
									id: '1',
									name: 'pstnoptions',
									getCharges: true,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										}
									}
								},
								{
									label: '2',
									checked: false,
									id: '2',
									name: 'pstnoptions',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '3',
									checked: false,
									id: '3',
									name: 'pstnoptions',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '4',
									checked: false,
									id: '4',
									name: 'pstnoptions',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '5',
									checked: false,
									id: '5',
									name: 'pstnoptions',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								},
								{
									label: '6',
									checked: false,
									id: '6',
									name: 'pstnoptions',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '2000.0',
											rentalPerAnnumCharge: '3000.0'
										},
										secondTerm: {
											onOffCharge: '100.0',
											rentalPerAnnumCharge: '1642.0'
										}
									}
								}
							]
						}
					]
				},
				AssuranceSpeeds: {
					contentData: [
						{
							heading: 'Assurance rates',
							plans: [
								{
									bandwidth: '400 Mbps',
									label: '400 Mbps',
									checked: false,
									id: 'AssuranceRates1',
									name: 'AssuranceRates',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '950.0',
											rentalPerAnnumCharge: '5457.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5240.0'
										}
									}
								},
								{
									bandwidth: '450 Mbps',
									label: '450 Mbps',
									id: 'AssuranceRates2',
									name: 'AssuranceRates',
									checked: false,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1000.0',
											rentalPerAnnumCharge: '6000.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5542.0'
										}
									}
								},
								{
									bandwidth: '500 Mbps',
									label: '500 Mbps',
									id: 'AssuranceRates3',
									name: 'AssuranceRates',
									checked: true,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1050.0',
											rentalPerAnnumCharge: '6156.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6098.2'
										}
									}
								},
								{
									bandwidth: '550 Mbps',
									label: '550 Mbps',
									checked: false,
									id: 'AssuranceRates4',
									name: 'AssuranceRates',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1100.0',
											rentalPerAnnumCharge: '7230.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6989.4'
										}
									}
								},
								{
									bandwidth: '600 Mbps',
									label: '600 Mbps',
									checked: false,
									id: 'AssuranceRates6',
									name: 'AssuranceRates',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '1250.0',
											rentalPerAnnumCharge: '7990.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '7840.4'
										}
									}
								}
							]
						}
					]
				},
				enhancedOptions: {
					contentData: [
						{
							heading: 'Enhanced care',
							plans: [
								{
									label: 'Yes',
									checked: false,
									id: 'enhancedyes',
									name: 'enhancedCare',
									getCharges: true,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										}
									}
								},
								{
									label: 'No',
									checked: true,
									id: 'enhancedno',
									name: 'enhancedCare',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '',
											rentalPerAnnumCharge: ''
										}
									}
								}
							]
						}
					]
				},
				newPstnOptions: {
					contentData: [
						{
							heading: 'New PSTN Line',
							plans: [
								{
									label: 'Yes',
									checked: false,
									id: 'pstnyes',
									name: 'newPstnOptions',
									getCharges: true,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '0.0'
										}
									}
								},
								{
									label: 'No',
									checked: true,
									id: 'pstnno',
									name: 'newPstnOptions',
									getCharges: true,
									control: 'remove',
									terms: {
										firstTerm: {
											onOffCharge: '0',
											rentalPerAnnumCharge: '0'
										},
										secondTerm: {
											onOffCharge: '',
											rentalPerAnnumCharge: ''
										}
									}
								}
							]
						}
					]
				}
			}
		]
	},
	footer: {
		type: 'Simple',
		title: 'Hide service options'
	},
	tooltip: 'Click here to delete the option from the set '
};
