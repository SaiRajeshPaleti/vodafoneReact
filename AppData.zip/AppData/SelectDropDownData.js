export default {
  selectBoxName: 'form-input',
  selectBoxId: 'selectBox',
  dropdown: [
    {
      itemName: 'INCV',
      itemValue: 'INCV'
    },
    {
      itemName: 'Customer Ref',
      itemValue: 'Customer Ref'
    }
  ],
  defaultValue: 'Customer Ref',
  onChange: (e) => {
    console.log(e);
  }
};
