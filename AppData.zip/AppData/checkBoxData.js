export default {
	onChange: function onChange(val) {
		//Method Implementation goes here
		console.log(' I am in CheckBox data function', val);
	},
	id: '1',
	name: 'checkbox',
	tooltip: 'Click on CheckBox to select',
	displayValue: 'Check Box Text'
};
