export default {
	date: new Date(),
	displayText: 'Last updated',
	title: 'Click to refresh your incidents data',
	id: 'a',
	onClick: () => {
		console.log('refresh');
	}
};
