export default [
    {
        dailType: true,
        id: 'dial1',
        values: {
            text1: '25',
            total: '200',
            text2: 'Priority 1',
            text3: 'still active',
            completionPercentage: '25',
            type: 'Dial',
            circleStyle: 'expired_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with Priority 1 status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial2',
        values: {
            text1: '43',
            total: '200',
            text2: 'Priority 2',
            text3: 'still active',
            completionPercentage: '10',
            type: 'Dial',
            circleStyle: 'expiring_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with Priority 2 status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial3',
        values: {
            text1: '23',
            total: '200',
            text2: 'Priority 3',
            text3: 'still active',
            completionPercentage: '15',
            type: 'Dial',
            circleStyle: 'buddha_gold_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with Priority 3 status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial4',
        values: {
            text1: '97',
            total: '200',
            text2: 'Priority 4',
            text3: 'still active',
            completionPercentage: '21',
            type: 'cricle',
            circleStyle: 'active_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with Priority 4status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial5',
        values: {
            text1: '80',
            total: '200',
            text2: 'Expiring',
            text3: 'in next 7 days',
            completionPercentage: '13',
            type: 'cricle',
            circleStyle: 'expiring_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with Expiring status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial6',
        values: {
            text1: '30',
            total: '200',
            text2: 'Active',
            text3: 'quotes',
            type: 'cricle',
            completionPercentage: '16',
            circleStyle: 'active_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with active status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial7',
        values: {
            text1: '25',
            total: '200',
            text2: 'Priority 1',
            text3: 'still active',
            completionPercentage: '80',
            type: 'cricle',
            circleStyle: 'guardsman_red_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with active status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial8',
        values: {
            text1: '200',
            total: '200',
            text2: 'Priority 2',
            text3: 'still active',
            completionPercentage: '60',
            type: 'cricle',
            circleStyle: 'tangerine_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with active status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial9',
        values: {
            text1: '18',
            total: '200',
            text2: 'Priority 3',
            text3: 'still active',
            completionPercentage: '40',
            type: 'cricle',
            circleStyle: 'buddha_gold_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with active status ');
        },
        tooltip: 'Click here to get the filtered list view'
    },
    {
        dailType: true,
        id: 'dial10',
        values: {
            text1: '25',
            total: '200',
            text2: 'Priority 4',
            text3: 'still active',
            completionPercentage: '80',
            type: 'cricle',
            circleStyle: 'silver_dial'
        },
        action: function submitHandler() {
            console.log('clicked dial with active status ');
        },
        tooltip: 'Click here to get the filtered list view'
    }
];
