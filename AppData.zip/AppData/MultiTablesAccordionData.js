export default {
	id: 'multi_table_accordion',
	name: 'multitableaccordion',
	onChange: function onChange(selectedPlan) {
		console.log('Selected Plan', selectedPlan);
	},
	getHeaderValue: function getHeaderValue(totalHeaderValue) {
		//Method Implementation goes here
		console.log(' Selected Header Value is', totalHeaderValue);
	},
	selectButtonClick: function selectButtonClick() {
		console.log('i am in select Button click');
	},

	displayAccordion: true,
	header: {
		type: 'ThreeColumn',
		headerData: {
			// additionalData: {
			//   terms: {
			//     firstTerm: {
			//       name: "1 year term",
			//       onOffCharge: "12345",
			//       // apiData1: '@FormData.onOffCharge|firstTerm.installationCharge',
			//       rentalPerAnnumCharge: "1234"
			//       // apiData2:
			//       // 	'@FormData.rentalPerAnnumCharge|firstTerm.recurringCharge'
			//     },
			//     secondTerm: {
			//       name: "3 years term",
			//       onOffCharge: "123",
			//       //apiData1: '@FormData.onOffCharge|secondTerm.installationCharge',
			//       rentalPerAnnumCharge: "154"
			//       //apiData2:
			//       //'@FormData.rentalPerAnnumCharge|secondTerm.recurringCharge'
			//     }
			//   },
			//   status: true,
			//   control: ""
			// },
			// additionalSection: true,
			deleteFlag: true,
			title: 'Show additional services',
			plan: {
				control: 'delete',
				name: 'Fiber Off-Net',
				accessSpeed: '500 Mbps',
				bearerSpeed: '1000 Mbps'
			},
			// buttonList: {
			//   firstTerm: {
			//     id: "headerbutton_1",
			//     name: "Select",
			//     type: "tertiary",
			//     buttonType: "button",
			//     isIcon: false,
			//     location: "lefttick",
			//     uniqueReference: "1234"
			//   },
			//   secondTerm: {
			//     id: "headerbutton_2",
			//     name: "Select",
			//     type: "tertiary",
			//     buttonType: "button",
			//     isIcon: false,
			//     location: "lefttick",
			//     uniqueReference: "2345"
			//   }
			// },
			terms: {
				firstTerm: {
					name: '1 Year term',
					onOffCharge: '1050.0',
					rentalPerAnnumCharge: '6156.0'
				},
				secondTerm: {
					name: '3 Years term',
					onOffCharge: '0.0',
					rentalPerAnnumCharge: '6098.2'
				}
			}
		}
	},
	content: {
		type: 'MultiTable',
		contentData: [
			{
				showmore: {
					show: 'See all multi vpn options',
					hide: 'Hide all speed options'
				},
				heading: 'Speed options',
				plans: [
					{
						bandwidth: '400 Mbps',
						label: '700 Mbps',
						checked: false,
						className: 'row_wrapper',
						id: 'speedoptions1',
						name: 'speedoptions',
						tooltip: 'click here to select',
						control: '',
						displayAdditional: null,
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '950.0',
								rentalPerAnnumCharge: '5457.0'
							},
							secondTerm: {
								name: '3 Year term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '5240.0'
							}
						}
					},
					{
						bandwidth: '400 Mbps',
						label: '400 Mbps',
						checked: false,
						className: 'row_wrapper',
						id: 'speedoptions7',
						name: 'speedoptions',
						tooltip: 'click here to select',
						control: '',
						displayAdditional: null,
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '950.0',
								rentalPerAnnumCharge: '5457.0'
							},
							secondTerm: {
								name: '3 Year term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '5240.0'
							}
						}
					},
					{
						bandwidth: '450 Mbps',
						label: '450 Mbps',
						id: 'speedoptions2',
						name: 'speedoptions',
						checked: false,
						className: 'row_wrapper',
						tooltip: 'click here to select',
						displayAdditional: null,
						control: '',
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '1000.0',
								rentalPerAnnumCharge: '6000.0'
							},
							secondTerm: {
								name: '3 Years term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '5542.0'
							}
						}
					},

					{
						bandwidth: '500 Mbps',
						label: '500 Mbps',
						id: 'speedoptions3',
						name: 'speedoptions',
						tooltip: 'click here to select',
						checked: true,
						className: 'row_wrapper',
						displayAdditional: null,
						control: '',
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '1050.0',
								rentalPerAnnumCharge: '6156.0'
							},
							secondTerm: {
								name: '3 Years term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '6098.2'
							}
						}
					},
					{
						bandwidth: '550 Mbps',
						label: '550 Mbps',
						checked: false,
						className: 'row_wrapper',
						id: 'speedoptions4',
						name: 'speedoptions',
						tooltip: 'click here to select',
						displayAdditional: null,
						control: '',
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '1100.0',
								rentalPerAnnumCharge: '7230.0'
							},
							secondTerm: {
								name: '3 Years term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '6989.4'
							}
						}
					},
					{
						bandwidth: '600 Mbps',
						label: '600 Mbps',
						checked: false,
						className: 'row_wrapper item_selected',
						tooltip: 'click here to select',
						id: 'speedoptions5',
						name: 'speedoptions',
						control: '',
						displayAdditional: null,
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '1250.0',
								rentalPerAnnumCharge: '7990.0'
							},
							secondTerm: {
								name: '3 Years term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '7840.4'
							}
						}
					}
				]
			},

			{
				footerTitle: 'Show speed options',
				heading: 'PSTN options',
				plans: [
					{
						bandwidth: 'Existing PSTN',
						label: 'Existing PSTN',
						checked: true,
						className: 'row_wrapper item_selected',
						tooltip: 'click here to select',
						id: 'pstnoptions1',
						name: 'pstnoptions',
						control: '',
						displayAdditional: false,
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '0.0'
							},
							secondTerm: {
								name: '3 Years term',
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '0.0'
							}
						}
					},
					{
						bandwidth: 'New PSTN',
						label: 'New PSTN',
						checked: false,
						className: 'row_wrapper',
						tooltip: 'click here to select',
						id: 'pstnoptions2',
						name: 'pstnoptions',
						control: 'remove',
						displayAdditional: true,
						terms: {
							firstTerm: {
								name: '1 Year term',
								onOffCharge: '2000.0',
								rentalPerAnnumCharge: '3000.0'
							},
							secondTerm: {
								name: '3 Years term',
								onOffCharge: '100.0',
								rentalPerAnnumCharge: '1642.0'
							}
						}
					}
				]
			}
		]
	},
	footer: {
		type: 'Simple',
		title: 'Hide service options'
	}
};
