export default {
	moveDown: (value) => {
        
        console.log(value);
      
	},
	moveUp: (value) => {
        
        console.log(value);
        
	}
};
