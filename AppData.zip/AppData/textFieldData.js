export default {
  id: 'input_id1',
  name: 'txt1',
  title: '',
  placeholder: 'Enter some text',
  value: 'abc',
  // disabled: 'disabled',
  keyCode: 'Enter',
  maxLength: 100,
  helpText: {
    labelname: 'Help text',
    type: 'labelDefault',
    fontSizeType: 'sm'
  },
  labelField: {
    labelname: 'Label Heading',
    type: 'labelDefault',
    fontSizeType: 'sm'
  },
  onChange: (value) => console.log('input value:', value),
  edit: true
};
