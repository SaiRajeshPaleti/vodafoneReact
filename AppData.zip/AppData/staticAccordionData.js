export default {
	id: 'static_accordion',
	name: 'staticaccordion',
	header: {
		type: 'Simple',
		headerData: {
			title: 'Site A details'
		},
		arrowTooltip: ''
	},
	content: {
		type: 'StaticAccordion',
		contentData: [
			{
				labelData: {
					id: 'Interconnect_location',
					isRequired: false,
					htmlFor: 'Interconnect_location',
					type: 'labelDefault',
					labelname: 'Interconnect location:'
				},
				value: ''
			},
			{
				labelData: {
					id: 'Access_type',
					isRequired: false,
					htmlFor: 'Access_type',
					type: 'labelDefault',
					labelname: 'Access type:',
					className: true,
					styling: 'boldClass'
				},
				value: 'Fibre On-Net'
			},

			{
				labelData: {
					id: 'Bearer_speed',
					isRequired: false,
					htmlFor: 'Bearer_speed',
					type: 'labelDefault',
					labelname: 'Bearer speed:',
					className: true,
					styling: 'boldClass'
				},
				value: '1000 Mbps'
			},
			{
				labelData: {
					id: 'post_code',
					isRequired: false,
					htmlFor: 'post_code',
					type: 'labelDefault',
					labelname: 'Post code:',
					className: true,
					styling: 'boldClass'
				},
				value: 'B24 9PT'
			},
			{
				labelData: {
					id: 'Site_address',
					isRequired: false,
					htmlFor: 'Site_address',
					type: 'labelDefault',
					labelname: 'Site address:'
				},
				value: ''
			},
			{
				labelData: {
					id: 'Access_type',
					isRequired: false,
					htmlFor: 'Access_type',
					type: 'labelDefault',
					labelname: 'Access type:',
					className: true,
					styling: 'boldClass'
				},
				value: 'Fibre On-Net'
			},
			{
				labelData: {
					id: 'Bearer_speed',
					isRequired: false,
					htmlFor: 'Bearer_speed',
					type: 'labelDefault',
					labelname: 'Bearer speed:',
					className: true,
					styling: 'boldClass'
				},
				value: '1000 Mbps'
			},
			{
				labelData: {
					id: 'post_code',
					isRequired: false,
					htmlFor: 'post_code',
					type: 'labelDefault',
					labelname: 'Post code:',
					className: true,
					styling: 'boldClass'
				},
				value: 'B24 9PT'
			}
		]
	}
};
