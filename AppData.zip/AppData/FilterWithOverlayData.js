export default {
  clearFilter: () => {
    console.log('clear Filter');
  },
  onClick: (a) => {
    console.log(a);
  },
  noteLabel: 'Note',
  noteText: 'Dates older than 1 month will take longer to process',
  tooltip: 'Click here to open the filter criteria',
  filterText: 'Filters',
  clearFilterText: 'Clear filters',
  PriorityBox: {
    Heading: 'Priority',
    DropDown: {
      id: 'priorityDropdownButton',
      name: 'priorityDropdownButton',
      dropDownButtonType: 'checkbox',
      clickTxt: 'View all types',
      title: 'Click Here',
      checkedElements: (e) => {},
      dropdownButtonValues: [
        {
          id: 'P1',
          name: 'P1',
          displayValue: 'P1'
        },
        {
          id: 'P2',
          name: 'P2',
          displayValue: 'P2'
        },
        {
          id: 'P3',
          name: 'P3',
          displayValue: 'P3'
        },
        {
          id: 'P4',
          name: 'P4',
          displayValue: 'P4'
        }
      ]
    }
  },
  StatusBox: {
    Heading: 'Status',
    DropDown: {
      id: 'statusDropdownButton',
      name: 'statusDropdownButton',
      dropDownButtonType: 'checkbox',
      clickTxt: 'View all statuses',
      title: 'Click Here',
      checkedElements: (e) => {},
      dropdownButtonValues: [
        {
          id: '1',
          name: 'New',
          displayValue: 'New'
        },
        {
          id: '2',
          name: 'InProgress',
          displayValue: 'In progress'
        },
        {
          id: '3',
          name: 'Resolved',
          displayValue: 'Resolved'
        },
        {
          id: '4',
          name: 'AwaitingCustomerInput',
          displayValue: 'Awaiting customer input'
        }
      ]
    }
  },
  EscalationBox: {
    Heading: 'Escalation',
    DropDown: {
      id: 'escalationDropdownButton',
      name: 'escalationDropdownButton',
      dropDownButtonType: 'checkbox',
      clickTxt: 'View all',
      title: 'Click Here',
      checkedElements: (e) => {},
      dropdownButtonValues: [
        {
          id: 'L1',
          name: 'L1',
          displayValue: 'L1'
        },
        {
          id: 'L2',
          name: 'L2',
          displayValue: 'L2'
        },
        {
          id: 'L3',
          name: 'L3',
          displayValue: 'L3'
        },
        {
          id: 'L4',
          name: 'L4',
          displayValue: 'L4'
        }
      ]
    }
  },
  startDatePicker: {
    Title: 'Date Raised From',
    data: {
      name: 'startDatePicker',
      id: 'start_date_picker',
      title: 'StartDate',
      componentType: 'SimpleDate',
      inputId: 'startpicker',
      locale: 'en',
      dateFormat: 'DD MMM YYYY',
      after: 0,
      timeFormat: false,
      timeConstraints: {
        minutes: {
          min: 0,
          max: 59,
          step: 5
        }
      }
    }
    // onChange: (e) => {
    //     console.log(e);
    // }
  },

  endDatePicker: {
    Title: 'Date Raised To',
    data: {
      name: 'endDatePicker',
      id: 'end_date_picker',
      title: 'EndDate',

      componentType: 'SimpleDate',
      inputId: 'endpicker',

      locale: 'en',
      dateFormat: 'DD MMM YYYY',
      after: 0,
      timeFormat: false,
      timeConstraints: {
        minutes: {
          min: 0,
          max: 59,
          step: 5
        }
      }
    }
  },
  buttonData: {
    id: 'primary',
    name: 'Apply filter',
    type: 'primary',
    buttonType: 'button'
  },
  alertData: {
    type: 'info',
    name: 'info',
    id: 'l_w',
    lightBackground: true,
    arrowRequired: false,
    messageTitle: 'Invalid Date',
    messageBody: 'From date cannot be greater than to date'
  },
  timePeriodOptions: {
    timePeriod: [
      {
        displayValue: '24',
        displayText: 'Hours',
        selected: false
      },
      {
        displayValue: '7',
        displayText: 'Days',
        selected: false
      },
      {
        displayValue: '1',
        displayText: 'Month',
        selected: false
      }
    ]
  },
  closeFilter: false
};
