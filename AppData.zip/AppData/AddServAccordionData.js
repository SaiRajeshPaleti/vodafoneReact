export default {
	id: 'addserviceaccordion',
	name: 'addserviceaccordion',
	displayAccordion: true,

	selectedAddSpeedOption: function selectedAddSpeedOption(selectedPlan) {
		console.log('Selected Plan', selectedPlan);
	},
	setAccessOption: function setAccessOption(selectedPlan) {
		console.log('Selected Plan for Check box', selectedPlan);
		return new Promise((resolve, reject) => {
			let plan = {
				bandwidth: selectedPlan.bandwidth,
				label: selectedPlan.label,
				type: 'checkbox',
				checked: false,
				id: 'speedoptions8',
				name: 'speedoptions1',
				control: '',
				displayAdditional: null,
				terms: {
					firstTerm: {
						onOffCharge: '950.0',
						rentalPerAnnumCharge: '5457.0'
					},
					secondTerm: {
						onOffCharge: '0.0',
						rentalPerAnnumCharge: '5240.0'
					}
				}
			};
			resolve(plan);
			return plan;
		});
	},

	updateOptionCharges: function updateOptionCharges(params) {
		console.log('params:', params);
		let additionalServices = [
			{
				id: 'DNSRegistrationManagement',
				title: 'DNS Registration & Management',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'DNSRegistrationManagementMailRelay',
					name: 'DNSRegistrationManagementMailRelay',
					displayValue: 'Mail relay',
					value: 'false',
					onClick: function onClick(selectedPlan) {
						console.log('Selected Plan', selectedPlan);
					}
				},
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10.46',
								rentalPerAnnumCharge: '20.45'
							},
							secondTerm: {
								onOffCharge: '20.54',
								rentalPerAnnumCharge: ''
							}
						},
						value: ''
					},
					{
						id: '.com',
						name: '.com',
						label: '.com',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '14',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.net',
						name: '.net',
						label: '.net',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.org',
						name: '.org',
						label: '.org',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},

					{
						id: 'Mail Relay',
						name: 'Mail Relay',
						label: 'Mail Relay',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				],
				notification: {
					messageTitle: 'Quantity for domains between 0 to 10000',
					messageBody:
						"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
				}
			},
			{
				id: 'DNSTransferManagement',
				title: 'DNS Transfer & Management',
				type: 'input',
				mailRelay: true,
				display: true,
				checkBoxContent: {
					id: 'DNSTransferManagementMailRelay',
					name: 'DNSTransferManagementMailRelay',
					displayValue: 'Mail relay',
					value: 'false'
				},
				status: false,
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: 'Mail Relay',
						name: 'Mail Relay',
						label: 'Mail Relay',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.com',
						name: '.com',
						label: '.com',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '14',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.net',
						name: '.net',
						label: '.net',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.org',
						name: '.org',
						label: '.org',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.gov.uk',
						name: '.gov.uk',
						label: '.gov.uk',
						charges: {
							firstTerm: {
								onOffCharge: '12',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '11',
								rentalPerAnnumCharge: '13'
							}
						},
						value: ''
					},
					{
						id: '.ac.uk',
						name: '.ac.uk',
						label: '.ac.uk',
						charges: {
							firstTerm: {
								onOffCharge: '20',
								rentalPerAnnumCharge: '25'
							},
							secondTerm: {
								onOffCharge: '30',
								rentalPerAnnumCharge: '50'
							}
						},
						value: ''
					}
				],
				notification: {
					messageTitle: 'Quantity for domains between 0 to 10000',
					messageBody:
						"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
				}
			},
			{
				id: 'ProviderIndependent',
				title: 'Provider Independent (IP)',
				type: 'input',
				status: false,
				display: false,
				checkBoxContent: {
					id: 'ProviderIndependentMailRealy',
					name: 'ProviderIndependentMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'NonPortableIPAddresses',
				title: 'Non portable IP Addresses',
				type: 'input',
				status: false,
				display: true,
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'SecureRemoteUserAccess',
				title: 'Secure Remote User Access',
				type: 'input',
				status: false,
				display: true,
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '20'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'CEToCEReporting',
				title: 'CE to CE Reporting (for managed router)',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'CEToCEReportingMailRealy',
					name: 'CEToCEReportingMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'WiresOnlyReporting',
				title: 'Wires Only Reporting (for Non managed router)',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'WiresOnlyReportingMailRealy',
					name: 'WiresOnlyReportingMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			}
		];
		return new Promise((resolve, reject) => {
			additionalServices.map((service) => {
				if (service.id === params.additionalServiceId) {
					service.domains.map((domain) => {
						if (domain.id === params.optionId) {
							domain.value = params.value;
							resolve(domain);
						}
						return domain;
					});
				}
				return service;
			});
		});
	},
	setButtonHandler: function setButtonHandler(params) {
		console.log('params:', params);
		let additionalServices = [
			{
				id: 'DNSRegistrationManagement',
				title: 'DNS Registration & Management',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'DNSRegistrationManagementMailRelay',
					name: 'DNSRegistrationManagementMailRelay',
					displayValue: 'Mail relay',
					value: 'false',
					onClick: function onClick(selectedPlan) {
						console.log('Selected Plan', selectedPlan);
					}
				},
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10.46',
								rentalPerAnnumCharge: '20.45'
							},
							secondTerm: {
								onOffCharge: '20.54',
								rentalPerAnnumCharge: ''
							}
						},
						value: ''
					},
					{
						id: '.com',
						name: '.com',
						label: '.com',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '14',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.net',
						name: '.net',
						label: '.net',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.org',
						name: '.org',
						label: '.org',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},

					{
						id: 'Mail Relay',
						name: 'Mail Relay',
						label: 'Mail Relay',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				],
				notification: {
					messageTitle: 'Quantity for domains between 0 to 10000',
					messageBody:
						"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
				}
			},
			{
				id: 'DNSTransferManagement',
				title: 'DNS Transfer & Management',
				type: 'input',
				mailRelay: true,
				display: true,
				checkBoxContent: {
					id: 'DNSTransferManagementMailRelay',
					name: 'DNSTransferManagementMailRelay',
					displayValue: 'Mail relay',
					value: 'false'
				},
				status: false,
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: 'Mail Relay',
						name: 'Mail Relay',
						label: 'Mail Relay',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.com',
						name: '.com',
						label: '.com',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '14',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.net',
						name: '.net',
						label: '.net',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.org',
						name: '.org',
						label: '.org',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.gov.uk',
						name: '.gov.uk',
						label: '.gov.uk',
						charges: {
							firstTerm: {
								onOffCharge: '12',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '11',
								rentalPerAnnumCharge: '13'
							}
						},
						value: ''
					},
					{
						id: '.ac.uk',
						name: '.ac.uk',
						label: '.ac.uk',
						charges: {
							firstTerm: {
								onOffCharge: '20',
								rentalPerAnnumCharge: '25'
							},
							secondTerm: {
								onOffCharge: '30',
								rentalPerAnnumCharge: '50'
							}
						},
						value: ''
					}
				],
				notification: {
					messageTitle: 'Quantity for domains between 0 to 10000',
					messageBody:
						"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
				}
			},
			{
				id: 'ProviderIndependent',
				title: 'Provider Independent (IP)',
				type: 'input',
				status: false,
				display: false,
				checkBoxContent: {
					id: 'ProviderIndependentMailRealy',
					name: 'ProviderIndependentMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'NonPortableIPAddresses',
				title: 'Non portable IP Addresses',
				type: 'input',
				status: false,
				display: true,
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'SecureRemoteUserAccess',
				title: 'Secure Remote User Access',
				type: 'input',
				status: false,
				display: true,
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '20'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'CEToCEReporting',
				title: 'CE to CE Reporting (for managed router)',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'CEToCEReportingMailRealy',
					name: 'CEToCEReportingMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'WiresOnlyReporting',
				title: 'Wires Only Reporting (for Non managed router)',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'WiresOnlyReportingMailRealy',
					name: 'WiresOnlyReportingMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			}
		];
		return new Promise((resolve, reject) => {
			additionalServices.map((service) => {
				if (service.id === params.additionalServiceId) {
					service.domains.map((domain) => {
						if (domain.id === params.optionId) {
							domain.value = params.value;
							resolve(domain);
						}
						return domain;
					});
				}
				return service;
			});
		});
	},
	selectedAdditionalServices: function selectedAdditionalServices(selectedItem) {
		console.log(' i am in selected additionalServices', selectedItem);
	},
	header: {
		type: 'Simple',
		headerData: {
			title: 'Add additional services'
		}
	},
	content: {
		type: 'AddServAccordion',

		contentData: {
			routerModels: {
				defaultRouterCost: {},
				ports: [],
				checkBoxContent: {
					value: 'false'
				},
				buttons: []
			},
			showNetworkBasedService: true,
			networkBasedInternetData: {
				id: 'NetworkBasedInternetAccess',
				title: 'Network based internet access',
				type: 'radio',
				status: false,
				display: true,
				showNetworkBasedService: true,
				multiTableData: {
					contentData: [
						{
							heading: 'Service Speed',
							plans: [
								{
									bandwidth: '2 Mbps',
									label: '2 Mbps',
									checked: false,
									id: 'speedoptions1',
									name: 'speedoptions',
									type: 'radio',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '950.0',
											rentalPerAnnumCharge: '5457.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5240.0'
										}
									}
								},
								{
									bandwidth: '4 Mbps',
									label: '4 Mbps',
									id: 'speedoptions2',
									name: 'speedoptions',
									checked: false,
									type: 'radio',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1000.0',
											rentalPerAnnumCharge: '6000.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5542.0'
										}
									}
								},

								{
									bandwidth: '6 Mbps',
									label: '6 Mbps',
									id: 'speedoptions3',
									name: 'speedoptions',
									tooltip: 'click here to select',
									checked: true,
									type: 'radio',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1050.0',
											rentalPerAnnumCharge: '6156.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6098.2'
										}
									}
								},
								{
									bandwidth: '8 Mbps',
									label: '8 Mbps',
									checked: false,
									type: 'radio',
									id: 'speedoptions4',
									name: 'speedoptions',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1100.0',
											rentalPerAnnumCharge: '7230.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6989.4'
										}
									}
								},
								{
									bandwidth: '10 Mbps',
									label: '10 Mbps',
									checked: false,
									type: 'radio',
									id: 'speedoptions5',
									name: 'speedoptions',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '1250.0',
											rentalPerAnnumCharge: '7990.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '7840.4'
										}
									}
								},
								{
									bandwidth: '12 Mbps',
									label: '12 Mbps',
									checked: false,
									type: 'radio',
									id: 'speedoptions7',
									name: 'speedoptions',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '1250.0',
											rentalPerAnnumCharge: '7990.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '7840.4'
										}
									}
								}
							]
						},
						{
							heading: '',
							plans: [
								{
									bandwidth: '400 Mbps',
									label: 'Access Standard',
									type: 'checkbox',
									value: true,
									disabled: true,
									id: 'speedoptions8',
									name: 'speedoptions1',
									control: '',
									displayAdditional: null,
									terms: {
										firstTerm: {
											onOffCharge: '950.0',
											rentalPerAnnumCharge: '5457.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5240.0'
										}
									}
								},
								{
									bandwidth: '450 Mbps',
									label: 'Access resilient',
									type: 'checkbox',
									id: 'speedoptions9',
									name: 'speedoptions1',
									value: true,
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											onOffCharge: '1000.0',
											rentalPerAnnumCharge: '6000.0'
										},
										secondTerm: {
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '5542.0'
										}
									}
								},

								{
									bandwidth: '500 Mbps',
									label: 'Firewall standard',
									type: 'checkbox',
									id: 'speedoptions10',
									name: 'speedoptions1',
									tooltip: 'click here to select',
									value: true,
									className: 'row_wrapper',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											name: '1 Year term',
											onOffCharge: '1050.0',
											rentalPerAnnumCharge: '6156.0'
										},
										secondTerm: {
											name: '3 Years term',
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6098.2'
										}
									}
								},
								{
									bandwidth: '550 Mbps',
									label: 'Firewall resilient',
									type: 'checkbox',
									value: false,
									className: 'row_wrapper',
									id: 'speedoptions11',
									name: 'speedoptions1',
									tooltip: 'click here to select',
									displayAdditional: null,
									control: '',
									terms: {
										firstTerm: {
											name: '1 Year term',
											onOffCharge: '1100.0',
											rentalPerAnnumCharge: '7230.0'
										},
										secondTerm: {
											name: '3 Years term',
											onOffCharge: '0.0',
											rentalPerAnnumCharge: '6989.4'
										}
									}
								}
							]
						}
					]
				},
				// checkBoxContent: {
				// 	id: 'NetworkBasedInternetAccessMailRelay',
				// 	name: 'NetworkBasedInternetAccessMailRelay',
				// 	displayValue: 'Mail relay',
				// 	value: 'false',
				// 	onClick: function onClick(selectedPlan) {
				// 		console.log('Selected Plan', selectedPlan);
				// 	}
				// },

				domains: []
			},
			addServiceHeading: 'Additional services',
			heading: '',
			additionalServices: [
				{
					id: 'DNSRegistrationManagement',
					title: 'DNS Registration & Management',
					type: 'input',
					status: false,
					display: true,
					checkBoxContent: {
						id: 'DNSRegistrationManagementMailRelay',
						name: 'DNSRegistrationManagementMailRelay',
						displayValue: 'Mail relay',
						value: 'false',
						onClick: function onClick(selectedPlan) {
							console.log('Selected Plan', selectedPlan);
						}
					},

					domains: [
						{
							id: '.co.uk',
							name: '.co.uk',
							label: '.co.uk',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.com',
							name: '.com',
							label: '.com',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.net',
							name: '.net',
							label: '.net',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.org',
							name: '.org',
							label: '.org',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},

						{
							id: 'Mail Relay',
							name: 'Mail Relay',
							label: 'Mail Relay',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						}
					],
					notification: {
						messageTitle: 'Quantity for domains between 0 to 10000',
						messageBody:
							"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
					}
				},
				{
					id: 'DNSTransferManagement',
					title: 'DNS Transfer & Management',
					type: 'input',
					mailRelay: true,
					display: true,
					checkBoxContent: {
						id: 'DNSTransferManagementMailRelay',
						name: 'DNSTransferManagementMailRelay',
						displayValue: 'Mail relay',
						value: 'false'
					},
					status: false,
					domains: [
						{
							id: '.co.uk',
							name: '.co.uk',
							label: '.co.uk',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: 'Mail Relay',
							name: 'Mail Relay',
							label: 'Mail Relay',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.com',
							name: '.com',
							label: '.com',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.net',
							name: '.net',
							label: '.net',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.org',
							name: '.org',
							label: '.org',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.gov.uk',
							name: '.gov.uk',
							label: '.gov.uk',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: '.ac.uk',
							name: '.ac.uk',
							label: '.ac.uk',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						}
					],
					notification: {
						messageTitle: 'Quantity for domains between 0 to 10000',
						messageBody:
							"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
					}
				},
				{
					id: 'ProviderIndependent',
					title: 'Provider Independent (IP)',
					type: 'input',
					status: false,
					display: true,
					checkBoxContent: {
						id: 'ProviderIndependentMailRealy',
						name: 'ProviderIndependentMailRealy',
						displayValue: 'Mail relay',
						value: 'false'
					},
					domains: [
						{
							id: 'qty',
							name: 'qty',
							label: 'qty',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						}
					]
				},
				{
					id: 'NonPortableIPAddresses',
					title: 'Non portable IP Addresses',
					type: 'input',
					status: false,
					display: true,
					domains: [
						{
							id: '.co.uk',
							name: '.co.uk',
							label: '.co.uk',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						}
					]
				},
				{
					id: 'SecureRemoteUserAccess',
					title: 'Secure Remote User Access',
					type: 'input',
					status: false,
					display: true,

					buttonSection: {
						selectedButton: 'Regular',
						cWHeading: 'C&W authentication',
						showButtons: true,
						buttons: [
							{
								id: 'regular',
								name: 'Regular',
								type: 'secondary',
								buttonType: 'button'
							},
							{
								id: 'strong',
								name: 'Strong',
								type: 'tertiary',
								buttonType: 'button'
							}
						]
					},

					domains: [
						{
							id: 'C&WRegularAuthenticationQty',
							name: 'C&W Regular Authentication Qty',
							label: 'C&W Regular Authentication Qty',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: 'C&WStrongAuthentication Qty',
							name: 'C&W Strong Authentication Qty',
							label: 'C&W Strong Authentication Qty',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						},
						{
							id: 'qty',
							name: 'qty',
							label: 'qty',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: '',
							buttonHandler: function buttonHandler(event) {
								console.log('its coming here', event);
							}
						}
					]
				},
				{
					id: 'CEToCEReporting',
					title: 'CE to CE Reporting (for managed router)',
					type: 'input',
					status: false,
					display: true,
					domains: [
						{
							id: 'qty',
							name: 'qty',
							label: 'qty',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						}
					]
				},
				{
					id: 'WiresOnlyReporting',
					title: 'Wires Only Reporting (for Non managed router)',
					type: 'input',
					status: false,
					display: true,
					domains: [
						{
							id: 'qty',
							name: 'qty',
							label: 'qty',
							charges: {
								firstTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								},
								secondTerm: {
									onOffCharge: '0',
									rentalPerAnnumCharge: '0'
								}
							},
							value: ''
						}
					]
				}
			]
		}
	},
	footer: {
		type: 'Simple',
		title: 'Hide service options'
	}
};
