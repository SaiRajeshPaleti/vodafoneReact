export default {
	id: 'multi_select_accordion',
	name: 'multiselectaccordion',
	displayAccordion: true,
	// onChange: function onChange(selectedPlan) {
	// 	console.log('Selected Plan', selectedPlan);
	// },
	getHeaderValue: function getHeaderValue(totalHeaderValue) {
		//Method Implementation goes here
		console.log(' Selected Header Value is', totalHeaderValue);
	},
	selectButtonClick: function selectButtonClick() {
		console.log('i am in select Button click');
	},
	onClick: function onClick() {
		console.log('i am in select Button click');
	},
	getExtraPlans: function getExtraPlans() {
		console.log('i am in getExtra plans');
	},
	updateOptionCharges: function updateOptionCharges(params) {
		console.log('params:', params);
		let additionalServices = [
			{
				id: 'DNSRegistrationManagement',
				title: 'DNS Registration & Management',
				type: 'input',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'DNSRegistrationManagementMailRelay',
					name: 'DNSRegistrationManagementMailRelay',
					displayValue: 'Mail relay',
					value: 'false',
					onClick: function onClick(selectedPlan) {
						console.log('Selected Plan', selectedPlan);
					}
				},
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10.46',
								rentalPerAnnumCharge: '20.45'
							},
							secondTerm: {
								onOffCharge: '20.54',
								rentalPerAnnumCharge: ''
							}
						},
						value: ''
					},
					{
						id: '.com',
						name: '.com',
						label: '.com',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '14',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.net',
						name: '.net',
						label: '.net',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.org',
						name: '.org',
						label: '.org',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},

					{
						id: 'Mail Relay',
						name: 'Mail Relay',
						label: 'Mail Relay',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				],
				notification: {
					messageTitle: 'Quantity for domains between 0 to 10000',
					messageBody:
						"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
				}
			},
			{
				id: 'DNSTransferManagement',
				title: 'DNS Transfer & Management',
				type: 'input',
				mailRelay: true,
				display: true,
				checkBoxContent: {
					id: 'DNSTransferManagementMailRelay',
					name: 'DNSTransferManagementMailRelay',
					displayValue: 'Mail relay',
					value: 'false'
				},
				status: false,
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: 'Mail Relay',
						name: 'Mail Relay',
						label: 'Mail Relay',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.com',
						name: '.com',
						label: '.com',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '14',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.net',
						name: '.net',
						label: '.net',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.org',
						name: '.org',
						label: '.org',
						charges: {
							firstTerm: {
								onOffCharge: '9',
								rentalPerAnnumCharge: '14'
							},
							secondTerm: {
								onOffCharge: '16',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					},
					{
						id: '.gov.uk',
						name: '.gov.uk',
						label: '.gov.uk',
						charges: {
							firstTerm: {
								onOffCharge: '12',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '11',
								rentalPerAnnumCharge: '13'
							}
						},
						value: ''
					},
					{
						id: '.ac.uk',
						name: '.ac.uk',
						label: '.ac.uk',
						charges: {
							firstTerm: {
								onOffCharge: '20',
								rentalPerAnnumCharge: '25'
							},
							secondTerm: {
								onOffCharge: '30',
								rentalPerAnnumCharge: '50'
							}
						},
						value: ''
					}
				],
				notification: {
					messageTitle: 'Quantity for domains between 0 to 10000',
					messageBody:
						"You should not keep all the domain quantity required as '0'.At least one domain quantity should have non zero value."
				}
			},
			{
				id: 'DistributedDenialServiceProtection',
				title: 'Distributed denial of service protection',
				type: 'radio',
				status: false,
				display: true,
				checkBoxContent: {
					id: 'DDServiceProtection',
					name: 'DDServiceProtection',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'ServiceOption1',
						name: 'Service Option1',
						label: 'Service Option1',
						charges: {
							firstTerm: {
								onOffCharge: '950.0',
								rentalPerAnnumCharge: '1457.0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '2250'
							}
						},
						value: ''
					},
					{
						id: 'ServiceOption2',
						name: 'Service Option2',
						label: 'Service Option2',
						checked: true,
						charges: {
							firstTerm: {
								onOffCharge: '1000.0',
								rentalPerAnnumCharge: '1000.0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '2500'
							}
						},
						value: '1'
					}
				]
			},
			{
				id: 'ProviderIndependent',
				title: 'Provider Independent (IP)',
				type: 'input',
				status: false,
				display: false,
				checkBoxContent: {
					id: 'ProviderIndependentMailRealy',
					name: 'ProviderIndependentMailRealy',
					displayValue: 'Mail relay',
					value: 'false'
				},
				domains: [
					{
						id: 'qty',
						name: 'qty',
						label: 'qty',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'NonPortableIPAddresses',
				title: 'Non portable IP Addresses',
				type: 'input',
				status: false,
				display: true,
				domains: [
					{
						id: '.co.uk',
						name: '.co.uk',
						label: '.co.uk',
						charges: {
							firstTerm: {
								onOffCharge: '10',
								rentalPerAnnumCharge: '15'
							},
							secondTerm: {
								onOffCharge: '15',
								rentalPerAnnumCharge: '20'
							}
						},
						value: ''
					}
				]
			},
			{
				id: 'PerformanceReporting',
				title: 'Performance reporting',
				type: 'input',
				status: false,
				display: true,
				domains: [
					{
						id: 'ServiceOption1',
						name: 'Service Option1',
						label: 'Service Option1',
						charges: {
							firstTerm: {
								onOffCharge: '950.0',
								rentalPerAnnumCharge: '1457.0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '2250'
							}
						},
						value: ''
					},
					{
						id: 'ServiceOption2',
						name: 'Service Option2',
						label: 'Service Option2',
						checked: true,
						charges: {
							firstTerm: {
								onOffCharge: '1000.0',
								rentalPerAnnumCharge: '1000.0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '2500'
							}
						},
						value: '1'
					}
				]
			}
		];
		return new Promise((resolve, reject) => {
			additionalServices.map((service) => {
				if (service.id === params.additionalServiceId) {
					service.domains.map((domain) => {
						if (domain.id === params.optionId) {
							resolve(domain);
						}
						return domain;
					});
				}
				return service;
			});
		});
	},
	selectedOption: function selectedOption() {
		console.log('i am in selectOption options');
	},
	selectedSpeedOption: function selectedSpeedOption() {
		console.log('i am in selectedSpeedOption options');
	},
	selectedPSTNOption: function selectedPSTNOption() {
		console.log('i am in selectedPSTNOption options');
	},
	getServiceOptionCharges: function getServiceOptionCharges(params) {
		console.log('i am in getServiceOptionCharges options', params);
	},
	setBackUpEVC: function setBackUpEVC() {
		console.log('i am in switch Click');
	},
	getCharges: function getCharges(params) {
		console.log(params);
		return new Promise((resolve, reject) => {
			let cosPrices = [];
			let standardPrice = {};
			let enhancedPrice = {};
			let premiumPrice = {};
			cosPrices.push(standardPrice);
			cosPrices.push(enhancedPrice);
			cosPrices.push(premiumPrice);
			standardPrice['firstTerm'] = {
				onOffCharge: '20',
				rentalPerAnnumCharge: '20'
			};
			enhancedPrice['firstTerm'] = {
				onOffCharge: '30',
				rentalPerAnnumCharge: '30'
			};
			premiumPrice['firstTerm'] = {
				onOffCharge: '20',
				rentalPerAnnumCharge: '30'
			};

			standardPrice['secondTerm'] = {
				onOffCharge: '30',
				rentalPerAnnumCharge: '40'
			};
			enhancedPrice['secondTerm'] = {
				onOffCharge: '30',
				rentalPerAnnumCharge: '40'
			};
			premiumPrice['secondTerm'] = {
				onOffCharge: '50',
				rentalPerAnnumCharge: '20'
			};
			resolve(cosPrices);
		});
	},
	header: {
		type: 'ThreeColumn',
		headerData: {
			// additionalData: {
			//   terms: {
			//     firstTerm: {
			//       name: "1 year term",
			//       onOffCharge: "12345",
			//       // apiData1: '@FormData.onOffCharge|firstTerm.installationCharge',
			//       rentalPerAnnumCharge: "1234"
			//       // apiData2:
			//       // 	'@FormData.rentalPerAnnumCharge|firstTerm.recurringCharge'
			//     },
			//     secondTerm: {
			//       name: "3 years term",
			//       onOffCharge: "123",
			//       //apiData1: '@FormData.onOffCharge|secondTerm.installationCharge',
			//       rentalPerAnnumCharge: "154"
			//       //apiData2:
			//       //'@FormData.rentalPerAnnumCharge|secondTerm.recurringCharge'
			//     }
			//   },
			//   status: true,
			//   control: ""
			// },
			// additionalSection: true,
			deleteFlag: true,
			title: 'Show additional services',
			plan: {
				control: 'delete',
				name: 'Fiber Off-Net',
				accessSpeed: '500 Mbps',
				bearerSpeed: '1000 Mbps'
			},
			// buttonList: {
			//   firstTerm: {
			//     id: "headerbutton_1",
			//     name: "Select",
			//     type: "tertiary",
			//     buttonType: "button",
			//     isIcon: false,
			//     location: "lefttick",
			//     uniqueReference: "1234"
			//   },
			//   secondTerm: {
			//     id: "headerbutton_2",
			//     name: "Select",
			//     type: "tertiary",
			//     buttonType: "button",
			//     isIcon: false,
			//     location: "lefttick",
			//     uniqueReference: "2345"
			//   }
			// },
			terms: {
				firstTerm: {
					name: '1 Year term',
					onOffCharge: '1050.0',
					rentalPerAnnumCharge: '6156.0'
				},
				secondTerm: {
					name: '3 Years term',
					onOffCharge: '0.0',
					rentalPerAnnumCharge: '6098.2'
				}
			}
		}
	},
	content: {
		type: 'MultiSelect',
		contentData: {
			speedoptions: {
				contentData: [
					{
						heading: 'Speed options',
						plans: [
							{
								bandwidth: '400 Mbps',
								label: '400 Mbps',
								checked: false,
								className: 'row_wrapper',
								id: 'speedoptions1',
								name: 'speedoptions',
								tooltip: 'click here to select',
								control: '',
								displayAdditional: null,
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '950.0',
										rentalPerAnnumCharge: '5457.0'
									},
									secondTerm: {
										name: '3 Year term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '5240.0'
									}
								}
							},
							{
								bandwidth: '450 Mbps',
								label: '450 Mbps',
								id: 'speedoptions2',
								name: 'speedoptions',
								checked: false,
								className: 'row_wrapper',
								tooltip: 'click here to select',
								displayAdditional: null,
								control: '',
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '1000.0',
										rentalPerAnnumCharge: '6000.0'
									},
									secondTerm: {
										name: '3 Years term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '5542.0'
									}
								}
							},
							{
								bandwidth: '500 Mbps',
								label: '500 Mbps',
								id: 'speedoptions3',
								name: 'speedoptions',
								tooltip: 'click here to select',
								checked: true,
								className: 'row_wrapper',
								displayAdditional: null,
								control: '',
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '1050.0',
										rentalPerAnnumCharge: '6156.0'
									},
									secondTerm: {
										name: '3 Years term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '6098.2'
									}
								}
							},
							{
								bandwidth: '550 Mbps',
								label: '550 Mbps',
								checked: false,
								className: 'row_wrapper',
								id: 'speedoptions4',
								name: 'speedoptions',
								tooltip: 'click here to select',
								displayAdditional: null,
								control: '',
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '1100.0',
										rentalPerAnnumCharge: '7230.0'
									},
									secondTerm: {
										name: '3 Years term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '6989.4'
									}
								}
							},
							{
								bandwidth: '600 Mbps',
								label: '600 Mbps',
								checked: false,
								className: 'row_wrapper item_selected',
								tooltip: 'click here to select',
								id: 'speedoptions5',
								name: 'speedoptions',
								control: '',
								displayAdditional: null,
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '1250.0',
										rentalPerAnnumCharge: '7990.0'
									},
									secondTerm: {
										name: '3 Years term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '7840.4'
									}
								}
							}
						]
					}
				]
			},
			evcData: {
				id: 'backupevc',
				title: 'Back up EVC',
				mainClass: 'add_services_user_roles_list_right',
				name: 'backupevc',
				status: false,
				disabled: false
			},
			classofService: {
				title: 'Class of services',
				contentData: [
					{
						key: 'standard',
						type: 'Standard',
						'input-type': 'text',
						bandwidth: '500',
						actualBandwidth: '500',
						terms: {
							firstTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							}
						},
						textfield: {
							componentType: 'Text',
							id: 'standard',
							name: 'standard',
							maxLength: 10,
							placeholder: '',
							disabled: true
						}
					},
					{
						type: 'Enhanced',
						key: 'enhanced',
						'input-type': 'text',
						bandwidth: '0',
						terms: {
							firstTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							}
						},
						textfield: {
							componentType: 'Text',
							id: 'enhanced',
							name: 'enhanced',
							maxLength: 10,
							placeholder: ''
						}
					},
					{
						type: 'Premium',
						key: 'premium',
						'input-type': 'text',
						bandwidth: '0',
						terms: {
							firstTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							}
						},
						textfield: {
							componentType: 'Text',
							id: 'premium',
							name: 'premium',
							maxLength: 10,
							placeholder: ''
						}
					}
				]
			},
			pstnoptions: {
				display: true,
				contentData: [
					{
						heading: 'PSTN options',
						plans: [
							{
								bandwidth: 'Existing PSTN',
								label: 'Existing PSTN',
								checked: true,
								className: 'row_wrapper item_selected',
								tooltip: 'click here to select',
								id: 'pstnoptions1',
								name: 'pstnoptions',
								control: '',
								displayAdditional: false,
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '0.0'
									},
									secondTerm: {
										name: '3 Years term',
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '0.0'
									}
								}
							},
							{
								bandwidth: 'New PSTN',
								label: 'New PSTN',
								checked: false,
								className: 'row_wrapper',
								tooltip: 'click here to select',
								id: 'pstnoptions2',
								name: 'pstnoptions',
								control: 'remove',
								displayAdditional: true,
								terms: {
									firstTerm: {
										name: '1 Year term',
										onOffCharge: '2000.0',
										rentalPerAnnumCharge: '3000.0'
									},
									secondTerm: {
										name: '3 Years term',
										onOffCharge: '100.0',
										rentalPerAnnumCharge: '1642.0'
									}
								}
							}
						]
					}
				]
			},
			bearerOptions: {
				contentData: {
					plans: {
						standardOptions: true,
						standard: {
							firstTerm: {
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '0.0'
							},
							secondTerm: {
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '0.0'
							}
						},
						extraPlans: [
							{
								bandwidth: 'ADVA 825 5 Port',
								label: 'ADVA 825 5 Port',
								tooltip: 'click here to select',
								checked: false,
								name: 'beaeroptions',
								id: 'extra4',
								control: 'remove',
								terms: {
									firstTerm: {
										onOffCharge: '1000.0',
										rentalPerAnnumCharge: '1000.0'
									},
									secondTerm: {
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '1542.0'
									}
								}
							},
							{
								bandwidth: 'ADVA 206 6 Port',
								tooltip: 'click here to select',
								checked: true,
								label: 'ADVA 206 6 Port',
								className: 'acc_catalogue_list_item selectedplan',
								name: 'beaeroptions',
								id: 'extra5',
								control: 'remove',
								terms: {
									firstTerm: {
										onOffCharge: '1050.0',
										rentalPerAnnumCharge: '1156.0'
									},
									secondTerm: {
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '1098.0'
									}
								}
							},
							{
								bandwidth: 'ADVA 206 10 Port',
								label: 'ADVA 206 10 Port',
								tooltip: 'click here to select',
								checked: false,
								className: 'acc_catalogue_list_item',
								name: 'beaeroptions',
								id: 'extra6',
								control: 'remove',
								terms: {
									firstTerm: {
										onOffCharge: '1100.0',
										rentalPerAnnumCharge: '1230.0'
									},
									secondTerm: {
										onOffCharge: '0.0',
										rentalPerAnnumCharge: '1989.0'
									}
								}
							},
							{
								bandwidth: 'ADVA 206 14 Port',
								label: 'ADVA 206 14 Port',
								tooltip: 'click here to select',
								checked: false,
								className: 'acc_catalogue_list_item',
								name: 'beaeroptions',
								id: 'extra7',
								control: 'remove',
								terms: {
									firstTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: ''
									},
									secondTerm: {
										onOffCharge: '',
										rentalPerAnnumCharge: ''
									}
								}
							}
						]
					},
					buttons: [
						{
							id: 'standardButton',
							name: 'Standard',
							type: 'secondary',
							buttonType: 'button'
						},
						{
							id: 'extraButton',
							name: 'Extra',
							type: 'tertiary',
							buttonType: 'button'
						}
					],
					heading: 'Number of ports required',
					additionalServices: [
						{
							id: '8',
							title: 'Performance reporting',
							type: 'radio',
							display: true,
							apiData: '@FormData.display|8.display',
							status: false,
							apiData3: '@FormData.status|8.status',
							apiData2: '@FormData.domains|8.domains',
							domains: [
								{
									id: 'ServiceOption1',
									name: 'Service Option1',
									label: 'Service Option1',
									charges: {
										firstTerm: {
											onOffCharge: '100',
											rentalPerAnnumCharge: '100'
										},
										secondTerm: {
											onOffCharge: '100',
											rentalPerAnnumCharge: '100'
										}
									},
									value: ''
								},
								{
									id: 'ServiceOption2',
									name: 'Service Option2',
									label: 'Service Option2',
									charges: {
										firstTerm: {
											onOffCharge: '100',
											rentalPerAnnumCharge: '100'
										},
										secondTerm: {
											onOffCharge: '100',
											rentalPerAnnumCharge: '100'
										}
									},
									value: ''
								}
							]
						}
					]
				}
			}
		}
	},
	footer: {
		type: 'Simple',
		title: 'Hide service options'
	},
	tooltip: 'Click here to delete the option from the set '
};
