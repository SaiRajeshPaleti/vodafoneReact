export default {
	data: {
		name: 'datePicker',
		id: 'date_picker',
		title: 'EndDate',
		searchAttribute: 'EndDate',
		componentType: 'SimpleDate',
		inputId: 'cove-200',
		placeholder: 'Enter date',
		value: '',
		locale: 'en',
		format: 'DD MMM YYYY',
		before: 0
		// after: 3
	},
	labelDefault: {
		id: 'label1',
		type: 'labelDefault',
		htmlFor: '',
		labelname: 'If the date selected is less than lead time, it will be assumed as soon as possible'
	},
	onChange: (e) => {
		console.log(e);
	}
};
