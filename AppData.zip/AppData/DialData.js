export default [
	{
		dailType: true,
		id: 'dial1',
		values: {
			text1: '200',
			total: '500',
			text2: 'Priority1',
			text3: 'Expired',
			completionPercentage: '25',
			type: 'DialReverse',
			circleStyle: 'expired_dial'
		},
		action: function submitHandler() {
			console.log('clicked dial with Priority1 status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial2',
		values: {
			text1: '120',
			total: '500',
			text2: 'Priority2',
			text3: 'still active',
			completionPercentage: '10',
			type: 'DialReverse',
			circleStyle: 'expiring_dial'
		},
		action: function submitHandler() {
			console.log('clicked dial with Priority2 status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial3',
		values: {
			text1: '80',
			total: '500',
			text2: 'Priority1',
			text3: 'active & healthy',
			completionPercentage: '15',
			type: 'Dial',
			circleStyle: 'active_dial'
		},
		action: function submitHandler() {
			console.log('clicked dial with Priority1 status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial4',
		values: {
			text1: '50',
			total: '500',
			text2: 'Expired',
			text3: 'Quotes',
			completionPercentage: '21',
			type: 'cricle',
			circleStyle: 'expired_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with expired status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial5',
		values: {
			text1: '10',
			total: '500',
			text2: 'Expiring',
			text3: 'in next 7 days',
			completionPercentage: '13',
			type: 'cricle',
			circleStyle: 'expiring_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with Expiring status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial6',
		values: {
			text1: '350',
			total: '500',
			text2: 'Active',
			text3: 'quotes',
			type: 'cricle',
			completionPercentage: '16',
			circleStyle: 'active_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with active status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial7',
		values: {
			text1: '250',
			total: '500',
			text2: 'Priority 1',
			text3: 'still active',
			completionPercentage: '80',
			type: 'cricle',
			circleStyle: 'guardsman_red_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with active status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial8',
		values: {
			text1: '500',
			total: '500',
			text2: 'Priority 2',
			text3: 'still active',
			completionPercentage: '60',
			type: 'cricle',
			circleStyle: 'tangerine_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with active status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial9',
		values: {
			text1: '180',
			total: '500',
			text2: 'Priority 3',
			text3: 'still active',
			completionPercentage: '40',
			type: 'cricle',
			circleStyle: 'buddha_gold_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with active status ');
		},
		tooltip: 'Click here to get the filtered list view'
	},
	{
		dailType: true,
		id: 'dial10',
		values: {
			text1: '230',
			total: '500',
			text2: 'Priority 4',
			text3: 'still active',
			completionPercentage: '80',
			type: 'cricle',
			circleStyle: 'silver_dial'
		},
		action: function submitHandler() {
			console.log('clicked Quote with active status ');
		},
		tooltip: 'Click here to get the filtered list view'
	}
];
