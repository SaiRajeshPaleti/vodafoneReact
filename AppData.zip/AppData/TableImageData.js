export default [
	{
		controlType: 'image',
		name: 'Actions',
		isSelected: true,
		link: false,
		tooltip: 'Click Here to access Options',
		rowData: [ 'OrderNumber' ],
		ActionData: {
			actionToBePerformed: 'redirect',
			imageType: 'floatIcon',
			IconType: 'icon-more',
			isChoiceAction: true,
			transitionData: {
				transitionName: 'slide',
				transitionAppear: true,
				transitionAppearTimeout: 100,
				transitionEnterTimeout: 300,
				transitionLeaveTimeout: 300
			},
			selectionData: [
				{
					label: 'Approve',
					ActionMethod: 'approveCharges',
					params: [ 'OrderNumber' ]
				},
				{
					label: 'Reject',
					ActionMethod: 'rejectCharges',
					params: [ 'OrderNumber' ]
				}
			],
			imagealt: 'AC actions',
			tooltip: 'Click here to access options'
		},
		sortable: false,
		type: 'control',
		key: 'revalidate',
		onClick: (value) => {
			console.log(value);
		}
	},
	{
		controlType: 'image',
		name: 'Actions',
		isSelected: true,
		link: false,
		rowData: [ 'QuoteReferenceNumber' ],
		ActionData: {
			actionToBePerformed: 'redirect',
			imageType: 'sprite__icon',
			IconType: 'Quote_Refresh',
			isChoiceAction: false,
			ActionMethod: 'revalidateQuote',
			params: [ 'QuoteReferenceNumber' ],
			imagealt: 'revalidate'
		},
		sortable: false,
		type: 'control',
		key: 'revalidate',
		onClick: (value) => {
			console.log(value);
		}
	},
	{
		controlType: 'image',
		name: 'Actions',
		isSelected: true,
		link: false,
		rowData: [ 'QuoteReferenceNumber' ],
		ActionData: {
			actionToBePerformed: 'redirect',
			imageType: 'sprite__icon',
			IconType: 'document-xls',
			isChoiceAction: false,
			ActionMethod: 'revalidateQuote',
			params: [ 'QuoteReferenceNumber' ],
			imagealt: 'revalidate'
		},
		sortable: false,
		type: 'control',
		key: 'revalidate',
		onClick: (value) => {
			console.log(value);
		}
	}
];
