export default {
	buttondata: [
		{
			id: 'primary',
			name: 'Primary button',
			type: 'primary',
			buttonType: 'submit',
			onClick: (id) => {
				console.log('', id);
			}
		},
		{
			id: 'secondary',
			name: 'Secondary button',
			type: 'secondary',
			buttonType: 'reset',
			onClick: () => {}
		},
		{
			id: 'tertiary',
			name: 'Tertiary button',
			type: 'tertiary',
			buttonType: 'button',
			onClick: () => {}
		},
		{
			id: 'transparent',
			name: 'Transparent button',
			type: 'transparent',
			buttonType: 'button',
			onClick: () => {}
		},
		{
			id: 'disabled',
			name: 'Disabled button',
			type: 'primary',
			buttonType: 'button',
			isDisabled: true,
			onClick: () => {}
		}
	],
	buttonWithIconData: [
		{
			location: 'right',
			id: 'rightIconButton',
			name: 'Right icon button',
			type: 'primary',
			buttonType: 'button',
			isIcon: true,
		},
		{
			location: 'left',
			id: 'leftIconButton',
			name: 'Left icon button',
			type: 'tertiary',
			buttonType: 'button',
			isIcon: true
		},
		{
			location: 'lefttick',
			id: 'leftIconButton',
			name: 'Left icon button',
			type: 'tertiary',
			buttonType: 'button',
			isIcon: true
		}
	]
};
