export default {
	timePeriod: [
		{
			displayValue: '24',
			displayText: 'Hours'
		},
		{
			displayValue: '7',
			displayText: 'Days'
		},
		{
			displayValue: '1',
			displayText: 'Month'
		}
	],
	onClick: (data) => {
		console.log('Selected one is: ', data.displayValue, ' ', data.displayText);
	}
};
