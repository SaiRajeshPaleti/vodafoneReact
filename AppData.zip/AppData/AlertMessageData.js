export default {
	messagedata: [
		{
			type: 'warning',
			name: 'warning',
			id: 'd_w',
			lightBackground: false,
			arrowRequired: false,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'warning',
			name: 'warning',
			id: 'd_w_wa',
			lightBackground: false,
			arrowRequired: true,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'warning',
			name: 'warning',
			id: 'l_w',
			lightBackground: true,
			arrowRequired: false,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'warning',
			name: 'warning',
			id: 'l_w_wa',
			lightBackground: true,
			arrowRequired: true,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'warning',
			name: 'warning',
			id: 'l_w',
			lightBackground: true,
			arrowRequired: true,
			messageTitle: 'This is a mandotary field',
			isValidate: true
		},
		{
			type: 'info',
			name: 'info',
			id: 'd_i',
			lightBackground: false,
			arrowRequired: false,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'info',
			name: 'info',
			id: 'd_i_wa',
			lightBackground: false,
			arrowRequired: true,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'info',
			name: 'info',
			id: 'l_i',
			lightBackground: true,
			arrowRequired: false,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'info',
			name: 'info',
			id: 'l_i_wa',
			lightBackground: true,
			arrowRequired: true,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'alert',
			name: 'alert',
			id: 'd_a',
			lightBackground: false,
			arrowRequired: false,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'alert',
			name: 'alert',
			id: 'd_a_wa',
			lightBackground: false,
			arrowRequired: true,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'alert',
			name: 'alert',
			id: 'l_a',
			lightBackground: true,
			arrowRequired: false,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		},
		{
			type: 'alert',
			name: 'alert',
			id: 'l_a_wa',
			lightBackground: true,
			arrowRequired: true,
			messageTitle: 'Minimum role selection required',
			messageBody: 'Please select and add at least one role for the user before proceeding to the next step.'
		}
	]
};
