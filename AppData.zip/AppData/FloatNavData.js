export default {
	id: 'float1',
	name: 'floatIcon',
	iconPrimary: 'more-android',
	hoverTitle: 'Do some Action',
	hoverIcons: [
		{
			id: '1',
			name: 'overView',
			hoverTitle: 'Overview',
			iconName: 'arrow-up',
			targetId: 'body',
			onClick: () => {}
		},
		{
			id: '2',
			name: 'search',
			hoverTitle: 'Search',
			iconName: 'search',
			targetId: 'ContextSearch',
			onClick: (e) => {
				console.log('event clicked', e.target.value);
			}
		}
	],
	onClick: () => {}
};
