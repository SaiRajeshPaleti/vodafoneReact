export default {
  id: 'chatBubble',
  name: 'chatBubble',
  notes: [
    {
      content: 'test Comments',
      commentedBy: 'rest.esb',
      commentedWhen: '2017-03-22T10:35:53'
    },
    {
      content: '<b>Amareswar a</b><p>test Comment</p>',
      commentedBy: 'non.rest.esb',
      commentedWhen: '2017-03-23T10:35:53'
    }
  ]
};
