export default {
    id: 'richtextbox',
    name: 'richtextbox',
    maxLength: '10',
    title: 'Please add any steps taken to resolve the issue',
    placeholder: '',
    onChange: (data) => {
        // console.log('text area data ', data);
    }
};
