export default {
	onChangeHandler: function changeHandler() {
		//method implementation goes here
	},

	searchIconFont: 'p',
	clearIconFont: '3',

	textField: {
		id: 'search-snack-input',
		name: 'txt1',
		title: '',
		placeholder: 'Enter some text',
		maxLength: 40,
		onChange: (value) => console.log('input value:', value)
	},
	buttonWithIconData: [
		{
			location: 'right',
			id: 'rightIconButton',
			name: 'Right icon button',
			type: 'primary',
			buttonType: 'button',
			isIcon: true
		}
	]
};
