export default {
	id: 'link1',
	name: 'linkName',
	linkType: 'bodylink' /*stdlink  or bodylink or darkbglink  or darkbgbodylink*/,
	href: '#',
	label: 'This is link text',
	onClick: (val) => {
		console.log('this is....', val);
	}
};
