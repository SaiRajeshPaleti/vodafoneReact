export default {
	stepTracker: {
		onClick: function onClick(step) {
			// step implementation goes here
			console.log('step clicked', step);
		},
		id: '1',
		name: 'Step Tracker',
		type: 'stepTracker',
		data: [
			{ id: '1', name: 'Site 1 Details', stepNo: '1', isComplete: true, isActive: false },
			{ id: '2', name: 'Site 2 Details', stepNo: '2', isComplete: true, isActive: false },
			{ id: '3', name: 'Site 3 Details', stepNo: '3', isComplete: false, isActive: true },
			{ id: '4', name: 'Site 4 Details', stepNo: '4', isComplete: false, isActive: false },
			{ id: '5', name: 'Site 5 Details', stepNo: '5', isComplete: false, isActive: false },
			{ id: '6', name: 'Site 6 Details', stepNo: '6', isComplete: false, isActive: false }
		]
	},
	orderTracker: {
		onClick: function onClick(step) {
			// step implementation goes here
			console.log('step clicked', step);
		},
		id: '2',
		name: 'Order Step Tracker',
		type: 'orderTracker',
		data: [
			{ id: '1', name: 'Quote Submitted', isComplete: true, isActive: false, icon: 'icon-reports' },
			{ id: '2', name: 'Ordered', isComplete: true, isActive: false, icon: 'shopping-trolley' },
			{ id: '3', name: 'Planning', isComplete: true, isActive: false, icon: 'EPL_interconnect' },
			{ id: '4', name: 'Build', isComplete: false, isActive: true, icon: 'rank-networker' },
			{ id: '5', name: 'Test', isComplete: false, isActive: false, icon: 'diagnostics' },
			{ id: '6', name: 'Ready', isComplete: false, isActive: false, icon: 'completed' }
		]
	}
};
