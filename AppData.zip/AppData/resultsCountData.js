export default {
	id: 'rc1',
	name: 'Result Count',
	labels: {
		label1: 'Showing ',
		label2: ' of ',
		label3: ' results'
	},
	pageIndex: 1,
	noOfResults: 7,
	// totalNumberOfResults: 10,
	noOfResultsPerPage: 10
};
