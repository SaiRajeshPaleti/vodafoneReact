export default {
	show: true,
	index: 0,
	childList: [
		{
			name: 'Reject',
			id: 'Reject',
			type: 'Reject',
			text: 'Rejection reason',
			leftButton: 'cancelBtn',
			rightButton: 'rejectBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'Alert',
					body: {
						type: 'warning',
						name: 'warning',
						id: 'l_i',
						type: 'info',
						lightBackground: true,
						arrowRequired: false,
						messageTitle: 'Please note!',
						messageBody:
							'If you reject this charge your order will be placed on hold under caveat A4. Customer excess charges not agreed, until approval can be agreed. If no approval is agreed with in 15 working days period we will cancel your Vodafone order and our order with the supplier.'
					}
				},
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'Choose reason for rejection.',
						isRequired: true
					}
				},
				{
					type: 'Dropdown',
					body: {
						onChange: function onChange() {
							//Write your logic Here
						},
						isMandatory: true,
						MissingText: 'Please enter the name of the new template',
						arrowText: 'Click on DropDown',
						id: 'dropDown1',
						name: 'DropDown',
						title: 'Please select a category',
						selectedCategoryLabel: 'Selected Category',
						dropdownValues: [
							{
								optionName: 'Select category',
								optionValue: '',
								id: 1,
								selected: true
							},
							{
								optionName: 'Category',
								optionValue: 'Category',
								id: 2
							}
						]
					}
				},
				{
					type: 'TextArea',
					body: {
						id: 'textarea123',
						name: 'Enter Reference',
						rows: 5,
						label: 'Enter Reference',
						maxLength: 4000,
						title: 'Please enter the description',
						placeholder: 'Enter Reference',
						label_header_left: {
							labelname: 'Notes',
							type: 'labelDefault',
							isInline: true,
							fontSizeType: 'lg'
						},
						label_header_right: {
							labelname: 'characters left',
							type: 'labelDefault',
							isInline: true,
							fontSizeType: 'lg'
						},
						label_helper: {
							labelname: 'You can enter  +, (), /, space and – special characters',
							type: 'labelDefault',
							fontSizeType: 'sm'
						},
						onChange: (event) => console.log('teaxtarea value:', event.target.value)
					}
				}
			]
		},
		{
			name: 'Approve',
			id: 'Approve',
			type: 'Approve',
			text: 'Confirmation approval',
			leftButton: 'cancelBtn',
			rightButton: 'approveBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'You are about to approve charge amount of £1322.50 for order number - Q5056781_1.'
					}
				},
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'Are you sure you want to approve this charge?'
					}
				}
			]
		},
		{
			name: 'SaveQuotes',
			id: 'SaveQuotes',
			type: 'Save Quotes',
			text: 'Your quote reference',
			leftButton: 'cancelBtn',
			rightButton: 'saveBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'Alert',
					body: {
						type: 'warning',
						name: 'warning',
						id: 'l_w',
						type: 'warning',
						lightBackground: true,
						arrowRequired: false,
						messageTitle: 'Non editable quote/s',
						messageBody:
							'Your quote/s will be saved and you will not be able to change your selected options once you go to the next step.'
					}
				},

				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'Why not save your quote/s with your own reference number?'
					}
				},
				{
					type: 'TextField',
					body: {
						id: 'overlaytext1',
						name: 'txt1',
						title: '',
						placeholder: 'Enter your incident reference here',
						maxLength: 10,
						onChange: (evt) => console.log('input value:', evt.target.value)
					}
				}
			]
		},
		{
			name: 'ApproveAll',
			id: 'ApproveAll',
			type: 'Approve All',
			text: 'Confirmation approval',
			leftButton: 'cancelBtn',
			rightButton: 'approveBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'You are about to approve all charges.'
					}
				},
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'Are you sure you want to approve all charges?'
					}
				}
			]
		}
	],
	buttondata: {
		deleteBtn: {
			id: 'primary',
			name: 'Delete',
			type: 'primary',
			buttonType: 'button'
		},
		openModal: {
			id: 'primary',
			name: 'Open Modal Box',
			type: 'primary',
			buttonType: 'button'
		},

		cancelBtn: {
			id: 'secondary',
			name: 'Cancel',
			type: 'secondary',
			buttonType: 'reset'
		},
		rejectBtn: {
			id: 'primary',
			name: 'Submit Rejection',
			type: 'primary',
			buttonType: 'button'
		},
		approveBtn: {
			id: 'primary',
			name: 'Approve',
			type: 'primary',
			buttonType: 'button'
		},
		saveBtn: {
			id: 'primary',
			name: 'Save quote/s >',
			type: 'primary',
			buttonType: 'button'
		}
	},
	tooltip: 'Click Here to Close',

	deleteMethod: (value) => {
		console.log(value);
	}
};
