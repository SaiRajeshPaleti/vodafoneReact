export default [
    {
        title: 'Not escalated',
        text: '',
        data: [
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            }
        ]
    },
    {
        title: 'Team Manager',
        text: 'L1',
        data: [
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 1'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Not enough cake'
            }
        ]
    },
    {
        title: 'Operations Manager',
        text: 'L2',
        data: [
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 2'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            }
        ]
    },
    {
        title: 'Senior Operations Manager',
        text: 'L3',
        data: [
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 3'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            }
        ]
    },
    {
        title: 'Global Service Operations Manager',
        text: 'L4',
        color: true,
        level: 4,
        data: [
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 4',
                hightlightTxt: true
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            },
            {
                date: '12.15am 08 September 2017',
                action: 'Escalation requested',
                reason: 'Level 0'
            }
        ]
    }
];
