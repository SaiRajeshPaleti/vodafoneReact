export default {
	card1: [
		{
			FrameworkCard: true,
			type: 'card1',
			name: 'card1',
			id: 'i1',
			reference: 'INC0010691',
			priority: 'P1',
			body: {
				description: 'Lorem ipsum dolor sit amet,  consectetur adipiscing elit...'
			},
			onClick: () => {
				console.log('Function called INC0010691');
			}
		},
		{
			FrameworkCard: true,
			type: 'card1',
			name: 'card1',
			id: 'i2',
			reference: 'INC0010693',
			priority: 'P2',
			body: {
				description: 'Lorem ipsum dolor sit amet,  consectetur adipiscing elit...'
			},
			onClick: () => {
				console.log('Function called INC0010693');
			}
		},
		{
			FrameworkCard: true,
			type: 'card1',
			name: 'card1',
			id: 'i3',
			reference: 'INC0010694',
			priority: 'P3',
			body: {
				description: 'Lorem ipsum dolor sit amet,  consectetur adipiscing elit...'
			},
			onClick: () => {
				console.log('Function called INC0010694');
			}
		},
		{
			FrameworkCard: true,
			type: 'card1',
			name: 'card1',

			id: 'i4',
			reference: 'INC0010695',
			priority: 'P4',
			body: {
				description: 'Lorem ipsum dolor sit amet,  consectetur adipiscing elit...'
			},
			onClick: () => {
				console.log('Function called INC0010695');
			}
		}
	],
	card2: [
		{
			type: 'card2',
			name: 'card2',
			id: 'j1',
			reference: 'VFTOP_75192_180531_376149',
			body: {
				productName: 'Ethernet Wireline - Interconnect',
				description: 'Test Quote 1'
			},
			onClick: () => {}
		},
		{
			type: 'card2',
			name: 'card2',
			id: 'j2',
			reference: 'VFTOP_75192_180427_291517',
			body: {
				productName: 'Ethernet Wireline - Network',
				description: 'Test Quote 2'
			},
			onClick: () => {}
		},
		{
			type: 'card2',
			name: 'card2',
			id: 'j3',
			reference: 'VFTOP_71885_180523_360511',
			body: {
				productName: 'Ethernet Wireline - MSP Bearer',
				description: 'Test Quote 1'
			},
			onClick: () => {}
		},
		{
			type: 'card2',
			name: 'card2',
			id: 'j4',
			reference: 'VFTOP_75192_180417_242771',
			body: {
				productName: 'Ethernet Wireline - Internet Access',
				description: 'Test Quote 1'
			},
			onClick: () => {}
		}
	],
	card3: [
		{
			id: 'card3',
			title: 'Ethernet Wireline - Interconnect',
			additional_title: '500 Mbps',
			displayIcon: true,
			className: 'priority_delete_card',
			type: 'card3',
			onClick: (id) => {
				console.log('i am in card click', id);
			},
			content: {
				body: [
					{
						name: 'Site address:',
						description:
							'Edinburgh - Unit 8, Keyway Business Park, Kingsbury Road, Erdington, Edinburgh, EH3 8AX'
					},
					{
						name: 'Secondary bearer speed:',
						description: 'None'
					},
					{
						name: '',
						description: ''
					},
					{
						name: 'Secondary access type:',
						description: 'Primary backup'
					}
				],
				dataFooter: [
					{
						name: 'Contract term:',
						description: '1 year'
					},
					{
						name: 'Quote date:',
						description: '12 Mar 2018'
					},
					{
						name: 'Quote expiry date:',
						description: '22 May 2018'
					},
					{
						name: 'Quote reference:',
						description: 'VFTOP_71885_180510_324028'
					}
				]
			}
		}
	],
	card4: [
		{
			type: 'card4',
			id: 'w1',
			url: 'EWL_interconnect',
			name: 'Ethernet Wireline',
			description: 'Interconnect',
			onClick: () => {}
		},
		{
			type: 'card4',
			id: 'w2',
			url: 'EWL_pointtopoint',
			name: 'Ethernet Wireline',
			description: 'Point to Point',
			onClick: () => {}
		},
		{
			type: 'card4',
			id: 'w3',
			url: 'EWL_MSPbearer',
			name: 'Ethernet Wireline',
			description: 'Bearer',
			onClick: () => {}
		},
		{
			type: 'card4',
			id: 'w4',
			url: 'EWL_interconnect',
			name: 'Ethernet Privateline',
			description: 'Interconnect',
			onClick: () => {}
		},
		{
			type: 'card4',
			id: 'w5',
			url: 'EWL_interconnect',
			name: 'Wholesale',
			description: 'IPVPN',
			onClick: () => {}
		}
	],
	card5: [
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '300',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '350',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '400',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '450',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '500',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '550',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '600',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '650',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '700',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '750',
			onClick: () => {}
		},
		{
			type: 'card5',
			id: 's1',
			name: 'card5',
			speed: '800',
			onClick: () => {}
		}
	],
	card6: [
		{
			type: 'card6',
			title: 'Vodafone Enterprise',
			address: '123 London street, London - BH3 8AG',
			step_tracker_title: 'Order stage',
			date_data: {
				heading: 'Order date',
				value: '12 Mar 2018'
			},
			order_details: [
				{
					name: 'Quote reference',
					value: 'VFTOP_71885_180523_360511'
				},
				{
					name: 'Product',
					value: 'Ethernet Wireline - Interconnect'
				},
				{
					name: 'Contract term',
					value: '1 Year'
				},
				{
					name: 'Contact number',
					value: '220-3444589'
				}
			],
			stepTrackerData: {
				stepImplementation: function stepImplementation() {
					// step implementation goes here
					console.log('step clicked');
				},
				id: '2',
				name: 'Order Step Tracker',
				type: 'orderTracker',
				data: [
					{ id: '1', name: 'Quote Submitted', isComplete: true, isActive: false, icon: 'icon-reports' },
					{ id: '2', name: 'Ordered', isComplete: true, isActive: false, icon: 'shopping-trolley' },
					{ id: '3', name: 'Planning', isComplete: true, isActive: false, icon: 'EPL_interconnect' },
					{ id: '4', name: 'Build', isComplete: false, isActive: true, icon: 'rank-networker' },
					{ id: '5', name: 'Test', isComplete: false, isActive: false, icon: 'diagnostics' },
					{ id: '6', name: 'Ready', isComplete: false, isActive: false, icon: 'completed' }
				]
			}
		}
	],
	card7: [
		{
			type: 'card7',
			dataList: {
				heading: 'Template One',
				name: 'Ethernet Interconnect',
				url: 'http://www.vodafone.co.uk/',
				item1: true,
				item2: true,
				item3: true,
				item4: false
			},
			card7_mapping: {
				item1: {
					label: 'Customer And Billing Details',
					key: 'CustomerAndBillingDetails'
				},
				item2: {
					label: 'Site A Details',
					key: 'SiteADetails'
				},
				item3: {
					label: 'Site B Details',
					key: 'SiteBDetails'
				},
				item4: {
					label: 'Service Details',
					key: 'ServiceDetails'
				}
			}
		},
		{
			type: 'card7',
			dataList: {
				heading: 'Template Two',
				name: 'Ethernet Interconnect',
				url: 'http://www.vodafone.co.uk/',
				item1: true,
				item2: true,
				item3: true,
				item4: false
			},
			card7_mapping: {
				item1: {
					label: 'Customer And Billing Details',
					key: 'CustomerAndBillingDetails'
				},
				item2: {
					label: 'Site A Details',
					key: 'SiteADetails'
				},
				item3: {
					label: 'Site B Details',
					key: 'SiteBDetails'
				},
				item4: {
					label: 'Service Details',
					key: 'ServiceDetails'
				}
			}
		},
		{
			type: 'card7',
			dataList: {
				heading: 'Template Three',
				name: 'Ethernet Interconnect',
				url: 'http://www.vodafone.co.uk/',
				item1: true,
				item2: true,
				item3: true,
				item4: false
			},
			card7_mapping: {
				item1: {
					label: 'Customer And Billing Details',
					key: 'CustomerAndBillingDetails'
				},
				item2: {
					label: 'Site A Details',
					key: 'SiteADetails'
				},
				item3: {
					label: 'Site B Details',
					key: 'SiteBDetails'
				},
				item4: {
					label: 'Service Details',
					key: 'ServiceDetails'
				}
			}
		},
		{
			type: 'card7',
			dataList: {
				heading: 'Template Four',
				name: 'Ethernet Interconnect',
				url: 'http://www.vodafone.co.uk/',
				item1: true,
				item2: true,
				item3: true,
				item4: false
			},
			card7_mapping: {
				item1: {
					label: 'Customer And Billing Details',
					key: 'CustomerAndBillingDetails'
				},
				item2: {
					label: 'Site A Details',
					key: 'SiteADetails'
				},
				item3: {
					label: 'Site B Details',
					key: 'SiteBDetails'
				},
				item4: {
					label: 'Service Details',
					key: 'ServiceDetails'
				}
			}
		}
	],
	card8: [
		{
			type: 'card8',
			title: 'Leased line',
			content: {
				body: [
					{
						name: 'Company name:',
						description: 'Company_name'
					},
					{
						name: 'Subsidiary name:',
						description: 'Company_name'
					},
					{
						name: 'Contact name:',
						description: 'Company_name'
					},
					{
						name: 'Contact number:',
						description: 'Company_name'
					}
				],
				dataFooter: [
					{
						name: 'Contract term:',
						description: '1 year'
					},
					{
						name: 'Date service required:',
						description: '12 Mar 2018'
					},
					{
						name: 'Billing account no:',
						description: '1342183517'
					},
					{
						name: 'Quote reference:',
						description: 'VFTOP_71885_180510_324028'
					}
				]
			}
		}
	],
	card9: [
		{
			type: 'card9',
			iconName: 'icon-reports',
			noteList: [ { text: 'test notes', date: '12 May 2018' }, { text: 'test notes', date: '12 May 2018' } ]
		}
	],
	card10: [
		{
			type: 'card10',
			title: 'Vodafone Enterprise',
			date_value: '12 Mar 2018',
			product_data: {
				heading: 'Product',
				value: 'Access'
			},
			order_ref: {
				heading: 'Order reference',
				value: '5556777888'
			},
			order_details: [
				{
					name: 'Quote reference',
					value: 'VFTOP_71885_180523_360511'
				},
				{
					name: 'Customer reference',
					value: 'John Doe'
				},
				{
					name: 'Site A address',
					value: 'HAINAULT ROAD, LONDON, GBR'
				},
				{
					name: 'Site B address',
					value: 'HAINAULT ROAD, LONDON, GBR'
				}
			],
			stepTrackerData: {
				stepImplementation: function stepImplementation() {
					// step implementation goes here
					console.log('step clicked');
				},
				id: '2',
				currentActive: 'Build',
				name: 'Order Step Tracker',
				type: 'orderTracker',
				data: [
					{ id: '1', name: 'Quote', icon: 'icon-reports' },
					{ id: '2', name: 'Request', icon: 'icon-reports' },
					{ id: '3', name: 'Order Planning', icon: 'icon-reports' },
					{ id: '4', name: 'Build', icon: 'icon-reports' },
					{ id: '5', name: 'Test', icon: 'icon-reports' },
					{ id: '6', name: 'Ready for Use', icon: 'icon-reports' }
				]
			}
		}
	]
};
