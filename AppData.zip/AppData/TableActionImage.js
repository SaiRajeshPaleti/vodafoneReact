export default {


	controlType: 'image',
	name: 'Actions',
	isSelected: 'true',
	link: 'false',
	tooltip: 'Click Here to access Options',
	actionToBePerformed: 'redirect',
	rowData: { 'OrderNumber': 'OrderNumber' },
	"ActionData": {
		"actionToBePerformed": "redirect",
		"imageType": "floatIcon",
		"IconType": 'icon-more',
		"actionRequired": "selection",
		"selectionData": [
			{
				"label": "Approve",
				"ActionMethod": "approveCharges",
				"params": ["OrderNumber"]
			},
			{
				"label": "Reject",
				"ActionMethod": "rejectCharges",
				"params": ["OrderNumber"]
			}
		],
		"imagealt": "AC actions",
		"tooltip": "Click here to access options"
	},
	sortable: 'false',
	type: 'control',
	key: 'revalidate',
	actionHandler: function actionHandler(value, param) {
		console.log(param, "param");
		console.log(value)


	}
}
