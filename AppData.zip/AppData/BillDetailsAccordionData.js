export default {
	id: 'billdetails_accordion',
	name: 'billdetailsaccordion',
	displayAccordion: true,
	header: {
		type: 'Simple',
		headerData: {
			title: 'Additional Details'
		}
	},
	content: {
		type: 'ExtendedFormAccordion',
		contentData: {
			extendedForm: [
				{
					componentType: 'Label',
					componentData: {
						id: 'quote_reference_dropdown',
						isRequired: true,
						htmlFor: 'quote_reference_dropdown',
						type: 'labelDefault',
						labelname: 'Billing account number'
					}
				},
				{
					componentType: 'DropdownComponent',
					componentData: {
						CategoryName: 'Category',
						title: 'Please select',
						selectedCategoryLabel: 'Please select',
						arrowText: 'Click on DropDown',
						id: 'DropdownComponent',
						name: 'DropdownComponent',
						dropdownValues: [
							{
								optionName: '17/2, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
								optionValue: 'This is an details'
							},
							{
								optionName: '17/3, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
								optionValue: 'This is an details1'
							},
							{
								optionName: '17/4, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
								optionValue: 'This is an details2'
							}
						],
						onChange: function onChange() {
							//Write your logic Here
						}
					}
				}
			],
			link: [
				{
					text: 'Add new billing account address'
				}
			],
			formdata: [
				{
					componentType: 'AddressSelector',
					componentData: {
						dropDownVisibility: false,
						id: 'AddressSelctor1',
						name: 'AddressSelector',
						heading: 'Site A Address',
						DropDownData: {
							arrowText: 'Click on DropDown',
							id: 'dropDown1',
							name: 'DropDown',
							CategoryName: 'Category',
							title: 'Please select',
							selectedCategoryLabel: 'Please select',
							dropdownValues: [
								{
									optionName: '17/2, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
									optionValue: 'This is an details'
								},
								{
									optionName: '17/3, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
									optionValue: 'This is an details1'
								},
								{
									optionName: '17/4, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
									optionValue: 'This is an details2'
								}
							]
						},

						formTextFieldsData: [
							{
								id: 'buildingNumber',
								name: 'txt1',
								title: '',
								placeholder: 'Enter Building Number',
								maxLength: 50,
								labelData: {
									id: 'buildingNumber',
									type: 'labelRequiredDefault',
									htmlFor: '',
									labelname: 'Building Number',
									isRequired: false
								}
							},
							{
								id: 'buildingName',
								name: 'txt2',
								title: '',
								placeholder: 'Enter Building Name',
								maxLength: 50,
								labelData: {
									id: 'buildingName',
									type: 'labelRequiredDefault',
									htmlFor: '',
									labelname: 'Building Name',
									isRequired: false
								}
							},
							{
								id: 'street',
								name: 'txt3',
								title: '',
								placeholder: 'Enter Street',
								maxLength: 50,
								labelData: {
									id: 'street',
									type: 'labelRequiredDefault',
									htmlFor: '',
									labelname: 'Street',
									isRequired: true
								}
							},
							{
								id: 'town',
								name: 'txt4',
								title: '',
								placeholder: 'Enter Town',
								maxLength: 50,
								labelData: {
									id: 'town',
									type: 'labelRequiredDefault',
									htmlFor: '',
									labelname: 'Town/City',
									isRequired: false
								}
							},
							{
								id: 'country',
								name: 'txt5',
								title: '',
								placeholder: 'Enter Country',
								maxLength: 50,
								labelData: {
									id: 'country',
									type: 'labelRequiredDefault',
									htmlFor: '',
									labelname: 'Country',
									isRequired: false
								}
							}
						],
						findButton: {
							id: 'secondary',
							name: 'Find Address',
							type: 'secondary',
							buttonType: 'button'
						},
						manualAddressLabel: {
							id: 'manualaddressentry',
							name: 'Enter Address Manually?'
						},
						addressInputComponentData: {
							id: 'input_id1',
							name: 'txt1',
							title: '',
							placeholder: 'Enter some text',
							maxLength: 50,
							helperText: ''
						},
						postcodeLabel: {
							id: 'postcode',
							type: 'labelRequiredDefault',
							htmlFor: '',
							labelname: 'Site Post Code'
						},
						addressLabel: {
							id: 'postcode',
							type: 'labelRequiredDefault',
							htmlFor: '',
							labelname: 'Please confirm your address'
						},
						addressManualLabel: {
							htmlFor: '',
							styling: '',
							labelname: 'Enter Address Manually?'
						}
					}
				}
			]
		}
	},
	showAccordion: true
};
