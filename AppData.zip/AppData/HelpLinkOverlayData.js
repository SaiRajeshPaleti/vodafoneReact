export default {
	OverlayData: {
		show: true,
		index: 0,
		childList: [
			{
				name: 'WhatTypeToRaise',
				id: 'TypeToRaise',
				type: 'What Type To Raise',
				text: 'Unsure about the type?',
				leftButton: 'incidentButton',
				rightButton: 'serviceButton',
				data: [
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelHeadingCenter',
							labelname: 'Raise incident'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Raise an incident if you are experiencing an error, service outage or degraded service.'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'For example:'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Cannot access email'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Hardware problems'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Line test failure errors'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Diagnostic test issues'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Logging faults'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelHeadingCenter',
							labelname: 'Raise service request'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Log a service request if you require a new service of facility'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'For example:'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Require a change to access privileges'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Get access to new services'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Change to existing services'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Change network and site details'
						}
					},
					{
						type: 'Label',
						body: {
							id: 'label1',
							type: 'labelCenter',
							labelname: 'Circuit termination details'
						}
					}
				]
			}
		],
		buttondata: {
			incidentButton: {
				id: 'tertiary',
				name: 'Raise incident',
				type: 'tertiary',
				buttonType: 'button',
				onClick: (data) => {
					console.log('data is..', data);
				}
			},
			serviceButton: {
				id: 'tertiary',
				name: 'Raise service request',
				type: 'tertiary',
				buttonType: 'button',
				onClick: (data) => {
					console.log('data is..', data);
				}
			}
		},
		tooltip: 'Click Here to Close'
	}
};
