export default {
	noCountIcon: 'icon-info', //Consumer can change the ICON as per the requirement
	noRecordsTxt: 'No service/site currently added.'
	
};
