export default {
	getCurrentPage: (value) => {
		console.log(value);
	},
	pagenumber: 1,
	totalPages: 5
};
