export default {
	id: 'float1',
	name: 'floatIcon',
	iconPrimary: 'more-android',
	hoverTitle: 'Do some Action',
	hoverIcons: [
		{
			id: 'scrollTop',
			name: 'overView',
			hoverTitle: 'Go to top',
			iconName: 'arrow-up-icon'
		},
		{
			id: 'searchIcon',
			name: 'search',
			hoverTitle: 'Search',
			iconName: 'search-icon'
		}
	],
	onClick: () => {
		console.log('handle click');
	}
};
