export default {
	noCountIcon: 'icon-info', //Consumer can change the ICON as per the requirement
	noRecordsTxt: '0 records found',
	noQuotesTxt: 'You have no quotes to display at present'
};
