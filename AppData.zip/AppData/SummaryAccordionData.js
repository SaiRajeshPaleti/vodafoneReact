export default {
	displayAccordion: true,
	getTab: '',
	CreateHandler: 'highlightPrice|getTab',
	id: 'installationcost',
	name: 'installationcost',
	getTabValue: function getTabValue(tabValue) {
		console.log('Selected Tab', tabValue);
	},
	header: {
		type: 'Summary',
		headerData: {
			title: 'Installation cost',
			terms: [
				{
					id: 'oneOffTotal',
					cost: '',
					apiData: '@FormData.cost|generalInfo.summaryInstallationTotal',
					isActive: true
				},
				{
					id: 'monthlyTotal',
					cost: '',
					apiData: '@FormData.cost|generalInfo.amortisedTotal',
					isActive: false
				}
			],

			lavalampdata: {
				activeTabKey: 'One-off cost',
				id: 'lamp1',
				name: 'lavaLamp1',
				type: 'tabWhiteBG',
				tabs: [
					{
						id: 'oneOffTotal',
						name: 'One-off cost',
						key: 'One-off cost',
						value: 'One-off cost'
					},
					{
						id: 'monthlyTotal',
						name: 'Monthly',
						key: 'Monthly',
						value: 'Monthly'
					}
				]
			},
			arrowTooltip: 'Summary Accordion Header tooltip'
		}
		// headerData: {
		// 	title: 'Installation cost',
		// 	terms: [
		// 		{
		// 			name: 'monthTotal',
		// 			cost: 1,
		// 			isActive: true
		// 		},
		// 		{
		// 			name: 'yearTotal',
		// 			cost: 1,
		// 			isActive: false
		// 		}
		// 	],

		// 	lavalampdata: {
		// 		activeTabKey: 'Monthly',
		// 		id: 'lamp1',
		// 		name: 'lavaLamp1',
		// 		type: 'tabWhiteBG',
		// 		tabs: [
		// 			{
		// 				id: 'monthTotal',
		// 				name: 'monthly',
		// 				key: 'Monthly',
		// 				value: 'Monthly'
		// 			},
		// 			{
		// 				id: 'yearTotal',
		// 				name: 'yearly',
		// 				key: 'Yearly',
		// 				value: 'Yearly'
		// 			}
		// 		]
		// 	},
		// 	arrowTooltip: 'Summary Accordion Header tooltip'
		// }
	},
	content: {
		type: 'SummaryContent',
		contentData: [
			{
				title: 'Interconnect: Site installation charge',
				terms: [
					{
						id: 'oneOffTotal',
						cost: 1235,
						isActive: true
					},
					{
						id: 'monthlyTotal',
						cost: 2346,
						isActive: false
					}
				]
			},
			{
				title: 'Site installation charge',
				terms: [
					{
						id: 'oneOffTotal',
						cost: 1425.0,
						isActive: true
					},
					{
						id: 'monthlyTotal',
						cost: 123.62,
						isActive: false
					}
				]
			}
		]
	}
};

// export default {
// 	id: 'summary_accordion',
// 	name: 'summary_accordion',
// 	displayAccordion: true,

// 	//alwaysExpanded: true,
// 	getTabValue: function getTabValue(tabValue) {
// 		console.log('Selected Tab', tabValue);
// 	},
// 	header: {
// 		type: 'Summary',

// 		headerData: {
// 			title: 'Installation cost',
// 			terms: [
// 				{
// 					name: 'monthly',
// 					cost: '0',
// 					isActive: true
// 				},
// 				{
// 					name: 'yearly',
// 					cost: '0',
// 					isActive: false
// 				}
// 			],

// 			lavalampdata: {
// 				activeTabKey: 'Monthly',
// 				id: 'lamp1',
// 				name: 'lavaLamp',
// 				type: 'tabWhiteBG',
// 				tabs: [
// 					{
// 						id: 'monthly',
// 						name: 'monthly',
// 						key: 'Monthly',
// 						value: 'Monthly'
// 					},
// 					{
// 						id: 'yearly',
// 						name: 'yearly',
// 						key: 'Yearly',
// 						value: 'Yearly'
// 					}
// 				]
// 			},
// 			arrowTooltip: 'Summary Accordion Header tooltip'
// 		}
// 	},
// 	content: {
// 		type: 'SummaryContent',
// 		contentData: [
// 			{
// 				title: 'CoS Standard(20 Mbps):',
// 				terms: [
// 					{
// 						name: 'monthly',
// 						cost: '2271.04',
// 						isActive: true
// 					},
// 					{
// 						name: 'yearly',
// 						cost: '9121.03',
// 						isActive: false
// 					}
// 				]
// 			},
// 			{
// 				title: 'CoS Standard(20 Mbps):',
// 				terms: [
// 					{
// 						name: 'monthly',
// 						cost: '2071.04',
// 						isActive: true
// 					},
// 					{
// 						name: 'yearly',
// 						cost: '9820.03',
// 						isActive: false
// 					}
// 				]
// 			},
// 			{
// 				title: 'CoS Standard(20 Mbps):',
// 				terms: [
// 					{
// 						name: 'monthly',
// 						cost: '2371.04',
// 						isActive: true
// 					},
// 					{
// 						name: 'yearly',
// 						cost: '9621.03',
// 						isActive: false
// 					}
// 				]
// 			}
// 			// {
// 			// 	title: 'CoS Standard(20 Mbps):',
// 			// 	monthly_value: '$271.04',
// 			// 	quarterly_value: '$821.03'
// 			// },
// 			// {
// 			// 	title: 'CoS Enhanced(0 Mbps):',
// 			// 	monthly_value: '$0.0',
// 			// 	quarterly_value: '$0.0'
// 			// }
// 		]
// 	}
// };
