export default {
	columns: [
		{
			id: 'data1',
			name: 'SelectAll',
			key: 'SelectAll',
			type: 'control',
			controlType: 'checkbox',
			isSelected: true,
			sortable: 'false',
			link: 'false'
		},
		{
			id: 'data2',	
			name: 'Reference',
			key: 'reference',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: true
		},
		{
			id: 'data3',	
			name: 'Summary',
			key: 'summary',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data4',	
			name: 'Status',
			key: 'status',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data5',
			name: 'Assigned To',
			key: 'assignedTo',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data5',
			name: 'Last Updated',
			key: 'lastUpdated',
			type: 'date',
			isSelected: true,
			sortable: false,
			link: true
		},
		{
			id: 'data6',	
			name: 'Priority',
			key: 'priority',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data7',
			name: 'Customer Reference',
			key: 'customerReference',
			type: 'string',
			isSelected: false,
			sortable: false,
			link: 'false'
		}
	],
	chooseColumnProps: {
		chooseLabel: 'Choose',
		columnLabel: 'columns',
		defaultBtn: {
			id: 'transparent',
			name: 'Default View',
			type: 'transparent',
			buttonType: 'button',
			onClick: (value) => { console.log("Button Clicked", value); }
		}
	},
	chooseColumnMethod: (value) => { console.log("Checkbox Clicked", value); }, 
	tooltip: 'Click here to expand or collpse',
	chooseColumn: (value) => {
		console.log(value);
	},
	defaultView: (value) => {
		console.log(value);
	},
	moveDown: (value) => {
		console.log(value);
	},
	moveUp: (value) => {
		console.log(value);
	}
};
