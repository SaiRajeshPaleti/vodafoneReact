export default {
  id: 'attachments',
  name: 'attachments',
  list: [
    {
      name: 'PRBV00040916.pdf',
      url: 'https://vodafonetest.service-now.com/api/now/attachment/faad6e57db2172408b49fcb6ae961923/file'
    },
    {
      name: 'PRBV00041300.pdf',
      url: 'https://vodafonetest.service-now.com/api/now/attachment/3fadaedbdb2172408b49fcb6ae96190e/file'
    }
  ]
};
