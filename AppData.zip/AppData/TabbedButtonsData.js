export default {
	activeButton: 'ad',
	buttons: [{
			id: 'ad',
			label: 'Additional Details'
		},
		{
			id: 'rc',
			label: 'Request closure'
		},
		{
			id: 're',
			label: 'Request escalation'
		}
	],
	onClick: (dataPassed) => console.log('Button ID', dataPassed)
};