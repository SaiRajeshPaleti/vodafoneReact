export default {
	displayAccordion: true,
	id: 'INC1234567890',
	name: 'INC1234567890',
	status: false,
	header: {
		type: 'ToggleTable',
		headerData: {
			handleSelection: (e) => {
				console.log(e);
			},
			title: 'INC1234567890',
			lastUpdate: 'Last updated: 29 Aug 2018 13:29',
			status: 'Pending',
			dueTime: '1 Hours',
			priority: 'P1',
			control: 'checkbox'
		}
	},
	content: {
		type: 'StaticAccordion',
		id: 'INC1234567890',
		contentData: [
			{
				labelData: {
					id: 'Interconnect_location',
					isRequired: false,
					htmlFor: 'Interconnect_location',
					type: 'labelDefault',
					labelname: 'Summary'
				},
				value: 'Summary content'
			},
			{
				labelData: {
					id: 'Access_type',
					isRequired: false,
					htmlFor: 'Access_type',
					type: 'labelDefault',
					labelname: 'Service',
					// className: true,
					styling: 'boldClass'
				},
				value: 'Internet Of Things'
			}
		]
	},
	footer: {
		type: 'Table',
		btnName: 'View summary',
		method: (e) => {
			console.log(e);
		}
	}
};
