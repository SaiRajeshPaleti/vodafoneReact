export default {
	id: 'switch1',
	status: false,
	name: 'switch',
	mainClass: '',
	onClick: (data) =>  {
		console.log("button status ", data);
	}
};
