const EscalationMatrixData = [
    {
        id: 0,
        caption: 'This business service has 5 levels',
        arrow: true
    },
    {
        id: 5,
        text: 'L5',
        caption: 'Head of Group Enterprise Operations'
    },
    {
        id: 4,
        text: 'L4',
        caption: 'Global Service Operations Manager'
    },
    {
        id: 3,
        text: 'L3',
        caption: 'Senior Operations Manager'
    },
    {
        id: 2,
        text: 'L2',
        caption: 'Operations managers'
    },
    {
        id: 1,
        text: 'L1',
        caption: 'Team manager'
    }
]

export default EscalationMatrixData;