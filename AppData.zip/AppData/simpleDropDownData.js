export default {
  onChange: function onChange(val) {
    //Write your logic Here
    console.log('this is val', val);
  },
  id: 'dropDown1',
  name: 'Select a category',
  clickTxt: 'Select a category',
  title: 'Functionality',
  // disabled: true,
  value: 'Service Management',
  helpText: {
    labelname: 'Label text',
    type: 'labelDefault',
    fontSizeType: 'sm'
  },
  label: {
    labelname: 'sample text',
    type: 'labelDefault',
    fontSizeType: 'sm'
  },
  dropdownValues: [
    {
      optionName: 'Functionality',
      optionValue: 'Functionality',
      id: 6
    },
    {
      optionName: 'Security-Policy',
      optionValue: 'Security-Policy',
      id: 7,
      selected: true
    },
    {
      optionName: 'Ordering',
      optionValue: 'Ordering',
      id: 8
    },
    {
      optionName: 'View Invoice',
      optionValue: 'View Invoice',
      id: 9
    },
    {
      optionName: 'Service Management',
      optionValue: 'Service Management',
      id: 10
    }
  ]
};
