export default {
	applyFilter: (selectedData) => {
		console.log('selectedData', selectedData);
	},
	selectedCount: 0,
	filterDropdownData: [
		{
			id: 'filter_accordion',
			name: 'filterAccordion',
			header: {
				type: 'Simple',
				headerData: {
					title: 'Products'
				}
			},
			content: {
				type: 'Radio',
				contentData: [
					{
						id: 'EthernetWirelinePoint',
						name: 'products',
						tooltip: 'click here to select',
						displayValue: 'Ethernet Wireline - Point to Point',
						checked: true
					},
					{
						id: 'EthernetWirelineMSP',
						name: 'products',
						tooltip: 'click here to select',
						displayValue: 'Ethernet Wireline - MSP Bearer'
					}
				]
			}
		},
		{
			id: 'filter_accordion',
			name: 'filterAccordion',
			header: {
				type: 'Simple',
				headerData: {
					title: 'Quote type'
				}
			},
			content: {
				type: 'Radio',
				contentData: [
					{
						id: 'Standard',
						name: 'quote',
						tooltip: 'click here to select',
						displayValue: 'Standard'
						//,checked: true
					},
					{
						id: 'B2BStandarad',
						name: 'quote',
						tooltip: 'click here to select',
						displayValue: 'B2B Standarad'
						// checked: false
					}
				]
			}
		}
	],
	tooltip: 'Click here to open the filter criteria'
};
