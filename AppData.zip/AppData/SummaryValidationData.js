export default {
        messageTitle: 'Sorry, some errors were found',
        messageBody: [
            {
                id: 'input1',
                label: 'Order contact first name is mandotary'
            },
            {
                id: 'input2',
                label: 'Order contact last name is mandotary'
            },
            {
                id: 'input3',
                label: 'Order contact telephone no. is mandotary'
            }
        ]
}