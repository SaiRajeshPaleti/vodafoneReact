export default {
	tileData: [
		{
			id: 'linktile1',
			title: 'Raise incident',
			description: 'Allows you to raise an issue with your Business Service',
			icon: 'warning',
			onClick: (id, title) => {
				console.log('Clicked by ' + id + ' with the title ' + title)
			},
			highlightText: 'raise'
		},
		{
			id: 'linktile2',
			title: 'Raise service request',
			description: 'Allows you to raise an issue with your Business Service',
			icon: 'settings',
			onClick: (id, title) => { 				
				console.log('Clicked by ' + id + ' with the title ' + title) 			
			},
			highlightText: 'raise'
		},
		{
			id: 'linktile3',
			title: 'Raise order',
			description: 'Allows you to raise an issue with your Business Service',
			icon: 'icon-shopping-trolley',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			},
			highlightText: 'raise'
		},
		{
			id: 'linktile4',
			title: 'Raise quote',
			description: 'Allows you to raise an issue with your Business Service',
			icon: 'icon-report',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			},
			highlightText: 'raise'
		},
		{
			id: 'linktile5',
			title: 'Raise bulk quote',
			description: 'Allows you to raise an issue with your Business Service',
			icon: 'icon-reports',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile6',
			title: 'Raise API incident',
			description: 'Raise incident for API issues',
			icon: 'warning',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile7',
			title: 'Raise data incident',
			description: 'Raise incident for data issues',
			icon: 'icon-data',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile8',
			title: 'Raise incident',
			description: 'Allows you to raise an issue with your Business Service',
			icon: 'warning',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile9',
			title: 'Raise other incident',
			description: 'Raise incident for other network related issues',
			icon: 'warning',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile10',
			title: 'Raise platform portal incident',
			description: 'Raise incident for platform portal',
			icon: 'warning',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile11',
			title: 'Raise reporting incident',
			description: 'Raise incident for reporting issues',
			icon: 'warning',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile12',
			title: 'Raise service request',
			description: 'Allows you to raise a Service Request for this Business Service',
			icon: 'settings',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile13',
			title: 'Raise SMS incident',
			description: 'Raise incident for SMS issues',
			icon: 'sms',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		},
		{
			id: 'linktile14',
			title: 'Raise voice incident',
			description: 'Raise incident for voice issues',
			icon: 'icon-report',
			onClick: (id, title) => { 				
				console.log('Clicked by ', id) 			
			}
		}
	]
}
