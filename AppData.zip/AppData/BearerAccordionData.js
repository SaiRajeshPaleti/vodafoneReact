export default {
	id: 'bearer_accordion',
	name: 'beareraccordion',
	displayAccordion: true,
	onChange: function onChange(selectedPlan) {
		console.log('Selected Plan', selectedPlan);
	},
	getHeaderValue: function getHeaderValue(totalHeaderValue) {
		//Method Implementation goes here
		console.log(' Selected Header Value is', totalHeaderValue);
	},
	selectButtonClick: function selectButtonClick() {
		console.log('i am in select Button click');
	},
	getExtraPlans: function getExtraPlans(buttonId) {
		console.log('Selected Button id is :', buttonId);
		console.log(buttonId);
		return new Promise((resolve, reject) => {
			let ports = [
				{
					id: 'AS1237',
					name: 'routerPorts1',
					bandwidth: 'AS1237 Cisco 2819 - 10M Eth RTR',
					label: 'AS1237 Cisco 2819 - 10M Eth RTR',
					checked: true,
					terms: {
						firstTerm: {
							onOffCharge: '250.57',
							rentalPerAnnumCharge: '200.67'
						},
						secondTerm: {
							onOffCharge: '150.47',
							rentalPerAnnumCharge: '100.27'
						}
					},
					installation: {
						firstTerm: {
							install: '100',
							rentOrBuy: '200'
						},
						secondTerm: {
							install: '500',
							rentOrBuy: '100'
						}
					}
				},
				{
					id: 'ADVA825',
					name: 'routerPorts1',
					bandwidth: 'ADVA 825 5 Port',
					label: 'ADVA 825 5 Port',
					checked: false,
					className: 'row_wrapper',
					terms: {
						firstTerm: {
							onOffCharge: '',
							rentalPerAnnumCharge: '100'
						},
						secondTerm: {
							onOffCharge: '200',
							rentalPerAnnumCharge: ''
						}
					},
					installation: {
						firstTerm: {
							install: '200',
							rentOrBuy: ''
						},
						secondTerm: {
							install: '',
							rentOrBuy: '100'
						}
					}
				},
				{
					id: 'ADVA206',
					name: 'routerPorts1',
					bandwidth: 'ADVA 206 6 Port',
					label: 'ADVA 206 6 Port',
					checked: false,
					terms: {
						firstTerm: {
							onOffCharge: '200',
							rentalPerAnnumCharge: ''
						},
						secondTerm: {
							onOffCharge: '',
							rentalPerAnnumCharge: '100'
						}
					},
					installation: {
						firstTerm: {
							install: '100',
							rentOrBuy: ''
						},
						secondTerm: {
							install: '',
							rentOrBuy: '900'
						}
					}
				}
			];
			resolve(ports);
		});
	},
	selectedOption: function selectedOption(selectedPlan) {
		console.log('selectedPlan is :', selectedPlan);
	},
	header: {
		type: 'ThreeColumn',
		headerData: {
			deleteFlag: true,
			title: 'Show additional services',
			plan: {
				control: 'delete',
				name: 'Fiber Off-Net',
				accessSpeed: '500 Mbps',
				bearerSpeed: '1000 Mbps'
			},
			buttonList: {
				firstTerm: {
					id: 'headerbutton_1',
					name: 'Select',
					type: 'tertiary',
					buttonType: 'button',
					isIcon: false,
					location: 'lefttick',
					uniqueReference: '1234'
				},
				secondTerm: {
					id: 'headerbutton_2',
					name: 'Select',
					type: 'tertiary',
					buttonType: 'button',
					isIcon: false,
					location: 'lefttick',
					uniqueReference: '2345'
				}
			},
			terms: {
				firstTerm: {
					name: '1 Year term',
					onOffCharge: '',
					rentalPerAnnumCharge: ''
				},
				secondTerm: {
					name: '3 Years term',
					onOffCharge: '',
					rentalPerAnnumCharge: ''
				}
			}
		}
	},
	content: {
		type: 'BearerAccordion',
		contentData: {
			plans: {
				standardOptions: true,
				standard: {
					firstTerm: {
						onOffCharge: '0.0',
						rentalPerAnnumCharge: '0.0'
					},
					secondTerm: {
						onOffCharge: '0.0',
						rentalPerAnnumCharge: '0.0'
					}
				},
				extraPlans: [
					{
						bandwidth: 'ADVA 825 5 Port',
						label: 'ADVA 825 5 Port',
						tooltip: 'click here to select',
						checked: false,
						name: 'beaeroptions',
						id: 'extra4',
						control: 'remove',
						terms: {
							firstTerm: {
								onOffCharge: '1000.0',
								rentalPerAnnumCharge: '1000.0'
							},
							secondTerm: {
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '1542.0'
							}
						}
					},
					{
						bandwidth: 'ADVA 206 6 Port',
						label: 'ADVA 206 6 Port',
						tooltip: 'click here to select',
						checked: true,
						name: 'beaeroptions',
						id: 'extra5',
						control: 'remove',
						terms: {
							firstTerm: {
								onOffCharge: '1050.0',
								rentalPerAnnumCharge: '1156.0'
							},
							secondTerm: {
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '1098.0'
							}
						}
					},
					{
						bandwidth: 'ADVA 206 10 Port',
						label: 'ADVA 206 10 Port',
						tooltip: 'click here to select',
						checked: false,
						name: 'beaeroptions',
						id: 'extra6',
						control: 'remove',
						terms: {
							firstTerm: {
								onOffCharge: '1100.0',
								rentalPerAnnumCharge: '1230.0'
							},
							secondTerm: {
								onOffCharge: '0.0',
								rentalPerAnnumCharge: '1989.0'
							}
						}
					},
					{
						bandwidth: 'ADVA 206 14 Port',
						label: 'ADVA 206 14 Port',
						tooltip: 'click here to select',
						checked: false,
						name: 'beaeroptions',
						id: 'extra7',
						control: 'remove',
						terms: {
							firstTerm: {
								onOffCharge: '',
								rentalPerAnnumCharge: ''
							},
							secondTerm: {
								onOffCharge: '',
								rentalPerAnnumCharge: ''
							}
						}
					}
				]
			},
			buttons: [
				{
					id: 'standardButton',
					name: 'Standard',
					type: 'secondary',
					buttonType: 'button'
				},
				{
					id: 'extraButton',
					name: 'Extra',
					type: 'tertiary',
					buttonType: 'button'
				}
			],
			heading: 'Number of ports required',
			additionalServices: [
				{
					id: '8',
					title: 'Performance reporting',
					type: 'radio',
					display: true,
					apiData: '@FormData.display|8.display',
					status: false,
					apiData3: '@FormData.status|8.status',
					apiData2: '@FormData.domains|8.domains',
					domains: [
						{
							id: 'ServiceOption1',
							name: 'Service Option1',
							label: 'service option1',
							charges: {
								firstTerm: {
									onOffCharge: '',
									rentalPerAnnumCharge: ''
								},
								secondTerm: {
									onOffCharge: '',
									rentalPerAnnumCharge: ''
								}
							},
							value: ''
						},
						{
							id: 'ServiceOption2',
							name: 'Service Option2',
							label: 'service option2',
							charges: {
								firstTerm: {
									onOffCharge: '100',
									rentalPerAnnumCharge: '100'
								},
								secondTerm: {
									onOffCharge: '100',
									rentalPerAnnumCharge: '100'
								}
							},
							value: ''
						}
					]
				}
			]
		}
	},
	footer: {
		type: 'Simple',
		title: 'Hide service options'
	}
};
