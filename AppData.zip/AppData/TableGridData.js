export default {
  getSummary: (value) => {
    console.log('', value);
  },
  sortHandler: (sortData) => {
    console.log('sort data check', sortData);
  },
  selectedData: (SelectAllData) => {
    console.log('Select all data', SelectAllData);
  },
  sortKey: {
    key: 'refer',
    type: 'ASC'
  },

  columns: [
    {
      name: 'SelectAll',
      key: 'SelectAll',
      type: 'control',
      controlType: 'checkbox',
      isSelected: true,
      sortable: false,
      link: false
    },
    {
      name: 'Reference',
      key: 'reference',
      type: 'string',
      isSelected: true,
      sortable: true,
      link: true
    },
    {
      name: 'Summary',
      key: 'summary',
      type: 'string',
      isSelected: true,
      sortable: true,
      link: false
    },
    {
      name: 'Status',
      key: 'status',
      type: 'string',
      isSelected: true,
      sortable: true,
      link: false
    },
    {
      name: 'Assigned To',
      key: 'assignedTo',
      type: 'string',
      isSelected: true,
      sortable: true,
      link: false
    },
    {
      name: 'Last Updated',
      key: 'lastUpdated',
      type: 'date',
      isSelected: true,
      sortable: true,
      link: false
    },
    {
      name: 'Priority',
      key: 'priority',
      type: 'string',
      isSelected: true,
      sortable: true,
      link: false
    },
    {
      name: 'Customer Reference',
      key: 'customerReference',
      type: 'string',
      isSelected: false,
      sortable: true,
      link: false
    }
  ],

  tabledata: [
    {
      reference: 'INC0014',
      summary: 'Summary',
      status: 'PENDING',
      assignedTo: 'George',
      lastUpdated: '10-Feb-1980',
      lastUpdatedTime: '13:45',
      priority: 'P1',
      customerReference: '315467',
      Validity: 1
    },
    {
      reference: 'INC1045',
      summary: 'QuoteSummary',
      status: 'PENDING',
      assignedTo: 'Anson',
      lastUpdated: '10-Jan-1991',
      lastUpdatedTime: '13:45',
      priority: 'P2',
      customerReference: '312312',
      Validity: 1
    },
    {
      reference: 'INC8077',
      summary: 'OrderSummary',
      status: 'IN PROGRESS',
      assignedTo: 'John',
      lastUpdated: '15-June-1989',
      lastUpdatedTime: '13:45',
      priority: 'P1',
      customerReference: '123312',
      Validity: 1
    },
    {
      reference: 'INC4076',
      summary: 'SummaryQuote',
      status: 'CLOSED',
      assignedTo: 'Mothy',
      lastUpdated: '17-DEC-1967',
      lastUpdatedTime: '13:45',
      priority: 'P3',
      customerReference: '123122',
      Validity: 1,
      checked: true
    },
    {
      summary: 'BTCharges',
      reference: 'INC3056',
      status: 'PENDING',
      assignedTo: 'EveryOne',
      lastUpdated: '17-DEC-1967',
      lastUpdatedTime: '13:45',
      priority: 'P4',
      customerReference: '12312',
      Validity: 1
    }
  ],
  recordsPerPage: 20,
  totalcount: 100,
  selectAllData: (status) => {
    console.log('Select pop data.....', status);
  },
  isAllSelected: true,
  uniqueColumn: 'reference'
};
