export default {
	id: 'dropdownButton',
	name: 'dropdownButton',
	dropDownButtonType: 'checkbox',
	clickTxt: 'Click me',
	title: 'Click Here',
	checkedElements: (e) => {
		console.log(e);
	},
	dropdownButtonValues: [
		{
			id: '1',
			name: 'checkbox1',
			tooltip: 'Click on CheckBox to select',
			displayValue: 'Sample 1'
		},
		{
			id: '2',
			name: 'checkbox2',
			tooltip: 'Click on CheckBox to select',
			displayValue: 'Sample 2'
		},
		{
			id: '3',
			name: 'checkbox3',
			tooltip: 'Click on CheckBox to select',
			displayValue: 'Sample 3'
		},
		{
			id: '4',
			name: 'checkbox4',
			tooltip: 'Click on CheckBox to select',
			displayValue: 'Sample 4'
		}
	]
};
