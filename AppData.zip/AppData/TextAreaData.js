export default {
	id: 'textarea1',
	name: 'Description',
	rows: 5,
	label: 'Notes',
	//maxLength: 20,
	//value: 'sss',
	title: 'Please enter the description',
	placeholder: 'Enter Some Text',
	label_header_left: {
		labelname: 'Notes',
		isRequired: true,
		type: 'labelDefault',
		isInline: true,
		fontSizeType: 'lg'
	},
	label_header_right: {
		labelname: '',
		type: 'labelDefault',
		isInline: true,
		fontSizeType: 'lg'
	},
	label_helper: {
		labelname: 'You can enter  +, (), /, space and – special characters',
		type: 'labelDefault',
		fontSizeType: 'sm'
	},
	onChange: (value) => console.log('teaxtarea value:', value)
};
