export default {
    Heading: 'Priority',
    DropDown: {
        id: 'priorityDropdownButton',
        name: 'priorityDropdownButton',
        dropDownButtonType: 'checkbox',
        clickTxt: 'View all types',
        title: 'Click Here',
        checkedElements: (e) => {},
        dropdownButtonValues: [
            {
                id: 'P1',
                name: 'P1',
                displayValue: 'P1'
            },
            {
                id: 'P2',
                name: 'P2',
                displayValue: 'P2'
            },
            {
                id: 'P3',
                name: 'P3',
                displayValue: 'P3'
            },
            {
                id: 'P4',
                name: 'P4',
                displayValue: 'P4'
            }
        ]
    }
};
