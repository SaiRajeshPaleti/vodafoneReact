export default {
	id: 'backupEvc_accordion',
	name: 'backupEvc_accordion',
	displayAccordion: true,
	//alwaysExpanded: true,
	header: {
		type: 'Simple',
		arrowTooltip: 'click here to expand',
		headerData: {
			title: 'Show back up EVC for service speed'
		}
	},
	content: {
		type: 'BackupEVC',
		contentData: {
			switchProps: {
				id: 'backupevc',
				title: 'Back up EVC',
				mainClass: 'add_services_user_roles_list_right',
				name: 'backupevc',
				checked: true,
				onClick: (data) => {
					console.log('button status ', data);
				}
			},
			backupCharges: {
				title: 'Back up core charges',
				terms: {
					firstTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: 120
					},
					secondTerm: {
						onOffCharge: '0',
						rentalPerAnnumCharge: 120
					}
				}
			},
			classofService: {
				title: 'Class of services',
				contentData: [
					{
						key: 'standard',
						type: 'Standard',
						'input-type': 'text',
						bandwidth: '500',
						actualBandwidth: '500',
						terms: {
							firstTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							}
						},
						textfield: {
							componentType: 'Text',
							id: 'standard',
							name: 'standard',
							maxLength: 10,
							placeholder: '',
							disabled: true
						}
					},
					{
						type: 'Enhanced',
						key: 'enhanced',
						'input-type': 'text',
						bandwidth: '0',
						terms: {
							firstTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							}
						},
						textfield: {
							componentType: 'Text',
							id: 'enhanced',
							name: 'enhanced',
							maxLength: 10,
							placeholder: ''
						}
					},
					{
						type: 'Premium',
						key: 'premium',
						'input-type': 'text',
						bandwidth: '0',
						terms: {
							firstTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							},
							secondTerm: {
								onOffCharge: '0',
								rentalPerAnnumCharge: '0'
							}
						},
						textfield: {
							componentType: 'Text',
							id: 'premium',
							name: 'premium',
							maxLength: 10,
							placeholder: ''
						}
					}
				]
			}
		}
	}
};
