export default {
  placeholder: 'Select a Value',
  onClick: (data) => {
    console.log('Selected one is: ', data);
  },
  title: {
    labelname: 'Business service',
    type: 'labelDefault'
  },
  helpText: {
    labelname: 'Please select the service on which you are raising the incident',
    type: 'labelHelperLightSM'
  },
  default: null,
  values: [
    '1 Dropdown Value',
    '1 hello Value',
    '2 Dropdown Value',
    '2 world Value',
    '3 Dropdown Value',
    '3 fo foo',
    '3 me'
  ]
};
