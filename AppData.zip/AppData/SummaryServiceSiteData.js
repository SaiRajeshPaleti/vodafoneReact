export default {
	//  deleteSite()
	deleteSite: function deleteSite() {
		//Button click both in the header and content
		console.log('i am in delete Button click');
	},
	editSite: function editSite() {
		console.log('i am in edit Button click');
	},
	bearerSpeed: {
		title: 'DualPOP',
		speed: '100 Mbps'
	},
	accessType: {
		title: 'DualPOP',
		type: '100 Mbps'
	},
	siteAddress: {
		title: 'Site address:',
		address: 'Flat A, 7, Tavistock Road, London, Greater London W11 1AT'
	}
};
