export default {
	show: true,
	orderInfoIcon: 'icon-info',
	closeIcon: 'close',
	orderConfirmTxt: 'Your Order is Confirmed',
	orderReferenceTxt: 'Your order reference is',
	orderReferenceNumber: ' order reference number ',
	orderDetailsTxt: 'click the button to view order details',
	buttondata: {
		id: 'primary',
		name: 'View Order',
		type: 'primary',
		buttonType: 'submit',
		onClick: (id) => {
			console.log('', id);
		}
	}
};
