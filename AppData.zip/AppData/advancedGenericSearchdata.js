// import AdvSearchComponentType from './searchComponentTypes';
export default {
	id: '1',
	name: 'advanced Generic',
	helpText: 'Search for quote reference. Enter a minimum of 3 characters',
	searchPlaceHolder: 'Enter Quote reference',
	tooltip: 'Click Here to Search Advance Search Criteria',
	searchTooltip: 'Click here to initiate the search',
	closeTooltip: 'Click here to close the advanced search criteria view',
	clear: 'clear',
	textFieldData: {
		id: 'input_id1',
		name: 'txt1',
		title: '',
		placeholder: 'Enter some text',
		value: '',
		maxLength: 10
	},
	searchMethod: (value) => {
		console.log(value);
	}
};
