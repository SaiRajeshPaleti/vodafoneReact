export default [
  {
    // sliderTitle: 'Without toolitip and custom marks and without default value',
    id: 'incidentImpact',
    min: 0,
    max: 100,
    step: 25,
    // defaultValue: 7,
    marks: true,

    customMarks: {
      25: 'Up to 25% of users',
      50: '25-75% of users Entire site impacted',
      75: '>75% of users Multiple / critical sites impacted'
    }
    // tooltip: true
  },
  {
    labelname: 'With default tooltip and default marks',

    id: 'discount',
    min: 0,
    max: 5,
    step: 0.5,
    defaultValue: 0,
    marks: true,
    tooltip: true,
    showTooltipByDefault: true
  },
  {
    labelname: 'With dots and default value',
    id: 'contract',
    min: 12,
    max: 36,
    step: 6,
    defaultValue: 24,
    dots: true
  },
  {
    labelname: 'Without dots and default value',
    id: 'contract1',
    min: 12,
    max: 36,
    step: 6,
    defaultValue: 24
  },
  {
    labelname: 'With hover toolitip and default marks and default value',
    id: 'swapStock',
    min: 2.5,
    max: 10,
    step: 0.5,
    defaultValue: 7,
    marks: true,
    tooltip: true
  }
];
