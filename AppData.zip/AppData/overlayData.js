export default {
	show: true,
	index: 0,
	childList: [
		{
			id: 'Generic',
			name: 'Generic',
			type: 'Generic',
			text: 'Are you sure?',
			leftButton: 'cancelBtn',
			rightButton: 'deleteBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'You are about to permanently delete this message.'
					}
				},
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'Do you want to continue?'
					}
				}
			]
		}
	],
	buttondata: {
		deleteBtn: {
			id: 'primary',
			name: 'Delete',
			type: 'primary',
			buttonType: 'button'
		},
		openModal: {
			id: 'primary',
			name: 'Open Modal Box',
			type: 'primary',
			buttonType: 'button'
		},

		cancelBtn: {
			id: 'secondary',
			name: 'Cancel',
			type: 'secondary',
			buttonType: 'reset'
		}
	},
	tooltip: 'Click Here to Close',

	deleteMethod: (value) => {
		console.log(value);
	}
};
