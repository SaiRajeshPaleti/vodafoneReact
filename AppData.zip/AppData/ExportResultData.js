export default {
	data: [
		{
			reference: 'VF_TOP_8822_196301_402',
			summary: 'Ethernet-2ZSM',
			status: 'completed',
			assignedTo: 'Finance',
			lastUpdated: '14-08-2018',
			priority: 'low',
			isSelected: false
		},
		{
			reference: 'VF_TOP_8822_196301_403',
			summary: 'Ethernet-3ZSM',

			assignedTo: 'Finance',
			lastUpdated: '15-08-2018',
			priority: 'low',
			status: 'completed',
			isSelected: false
		}
	],
	label: 'Export results',
	columns: [
		{
			id: 'data2',
			name: 'Reference',
			key: 'reference',
			type: 'string',
			isSelected: true,
			isDisabled: true,
			sortable: false,
			link: true
		},
		{
			id: 'data3',
			name: 'Summary',
			key: 'summary',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data4',
			name: 'Status',
			key: 'status',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data5',
			name: 'Assigned To',
			key: 'assignedTo',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		},
		{
			id: 'data6',
			name: 'Last Updated',
			key: 'lastUpdated',
			type: 'date',
			isSelected: true,
			sortable: false,
			link: true
		},
		{
			id: 'data7',
			name: 'Priority',
			key: 'priority',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: 'false'
		}
	],
	fileName: 'Bulkquotelist.xlsx',
	sheetName: 'Bulkquotes',
	otherExportsFlag: true,
	otherExports: [
		{
			name: 'Save as Excel',
			onClick: () => {}
		},
		{
			name: 'Save as PDF',
			onClick: () => {}
		}
	],
	type: 'type1'
};
