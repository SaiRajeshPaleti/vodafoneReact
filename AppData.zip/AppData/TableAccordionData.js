export const tableAccType1 = {
	id: 'table_accordion',
	name: 'tableaccordion',
	displayAccordion: true,
	header: {
		type: 'Table',
		headerData: {
			id: 't1',
			//	isSelected: true,
			//	isSelectHidden: false,
			content: [
				{
					title: 'Quote reference',
					value: 'VFTOP_75192_180424_267316',
					key: 'QuoteReference',
					isHidden: true
				},
				{
					title: 'Product',
					value: 'Ethernet Wireline - Point to Point',
					key: 'Product'
				},
				{
					title: 'Site A details',
					value: false,
					key: 'SiteADetails'
				},
				{
					title: 'Validity',
					value: 'Active',
					key: 'Validity'
				},
				{
					title: 'Quote type',
					value: 'Standard',
					key: 'QuoteType'
				},
				{
					title: 'Site B details',
					value: 'UB4 8HP',
					key: 'SiteBDetails'
				}
			],
			statusKey: 'Validity',
			isBody: true,
			tableActionData: {
				controlType: 'image',
				name: 'Actions',
				isSelected: true,
				link: false,
				tooltip: 'Click Here to access Options',
				rowData: [ 'OrderNumber' ],
				ActionData: {
					actionToBePerformed: 'redirect',
					imageType: 'floatIcon',
					IconType: 'icon-more',
					isChoiceAction: true,
					transitionData: {
						transitionName: 'slide',
						transitionAppear: true,
						transitionAppearTimeout: 100,
						transitionEnterTimeout: 300,
						transitionLeaveTimeout: 300
					},
					selectionData: [
						{
							label: 'Refresh',
							ActionMethod: 'approveCharges',
							params: [ 'OrderNumber' ]
						}
					],
					imagealt: 'AC actions',
					tooltip: 'Click here to access options'
				},
				sortable: false,
				type: 'control',
				key: 'revalidate',
				onClick: (value) => {
					console.log(value);
				}
			}
		}
	},
	content: {
		type: 'StaticAccordion',
		contentData: [
			{
				labelData: {
					type: 'labelDefault',
					labelname: ' Quote date:',
					styling: 'boldClass'
				},
				value: '06 Jul 2018'
			},
			{
				labelData: {
					type: 'labelDefault',
					labelname: 'Customer reference:',
					styling: 'boldClass'
				},
				value: 'Cust_12340987'
			}
		]
	},
	footer: {
		type: 'Table',
		buttonData: {
			id: 'secondary',
			name: 'View summary',
			type: 'secondary',
			buttonType: 'button',
			onClick: () => {}
		}
	},
	selectButtonClick: (e) => {
		console.log(e);
	}
};

export const tableAccType2 = {
	id: 'table_accordion',
	name: 'tableaccordion',
	header: {
		type: 'Table',
		headerData: {
			content: [
				{
					title: 'Quote reference',
					value: 'VFTOP_75192_180424_267316'
				},
				{
					title: 'Product',
					value: 'Ethernet Wireline - Point to Point'
				},
				{
					title: 'Site A details',
					value: false
				},
				{
					title: 'Validity',
					value: 'Active'
				},
				{
					title: 'Quote type',
					value: 'Standard'
				},
				{
					title: 'Site B details',
					value: 'UB4 8HPX'
				}
			],
			headerActionData: {
				url: '/',
				methodName: 'approveCharges',
				headerParams: [ 'uuid' ],
				actionHandler: ({ methodName, params }) => {
					console.log('click handler from consumer ::: ', methodName, params);
				}
			},
			statusKey: 'Validity',
			isBody: false,
			tableActionData: {
				controlType: 'image',
				name: 'Actions',
				isSelected: true,
				link: false,
				tooltip: 'Click Here to access Options',
				rowData: [ 'OrderNumber' ],
				ActionData: {
					actionToBePerformed: 'redirect',
					imageType: 'floatIcon',
					IconType: 'icon-more',
					isChoiceAction: true,
					transitionData: {
						transitionName: 'slide',
						transitionAppear: true,
						transitionAppearTimeout: 100,
						transitionEnterTimeout: 300,
						transitionLeaveTimeout: 300
					},
					selectionData: [
						{
							label: 'Refresh',
							ActionMethod: 'approveCharges',
							params: [ 'OrderNumber' ]
						},
						{
							label: 'Refresh1',
							ActionMethod: 'approveCharges',
							params: [ 'OrderNumber' ]
						},
						{
							label: 'Refresh2',
							ActionMethod: 'approveCharges',
							params: [ 'OrderNumber' ]
						}
					],
					imagealt: 'AC actions',
					tooltip: 'Click here to access options'
				},
				sortable: false,
				type: 'control',
				key: 'revalidate',
				onClick: (value) => {
					console.log(value);
				}
			}
		}
	},
	content: {
		type: 'StaticAccordion',
		contentData: []
	},
	footer: {
		rowData: {
			uuid: '5fa59e05-5d72-6927-fc44-cd313ca5e592',
			OrderReferenceNumber: 'EWL-2016',
			QuoteReferenceNumber: '',
			ProductName: 'Ethernet Wireline',
			SavedOn: '8/31/2018'
		},
		type: 'Table',
		buttonData: {
			id: 'secondary',
			name: 'View summary',
			type: 'secondary',
			buttonType: 'button',
			onClick: () => {}
		}
	},
	selectButtonClick: (e) => {
		console.log(e);
	}
};
