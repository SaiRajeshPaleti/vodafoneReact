// export default {
// 	iconName: 'mobile',
// 	title: 'Devices',
// 	value: '1000',
// 	type: 'image',
// 	src: 'https://www.admecindia.co.in/sites/default/files/portfolio/vodafone-logo-ilustration.jpg'
// };
export default {
  iconName: 'icon-report',
  title: 'Devices',
  value: '1000',
  type: 'icon',
  src: ''
};
