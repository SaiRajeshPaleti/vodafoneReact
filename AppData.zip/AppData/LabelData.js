export default {
	labelHelper1: {
		type: 'labelHelperLightXS',
		labelname: 'Please confirm if you need a new VLAN or use existing VLAN'
	},
	labelHelper2: {
		id: 'label02',
		type: 'labelHelperLightSM',
		htmlFor: '',
		labelname: 'Please confirm if you need a new VLAN or use existing VLAN'
	},
	labelHelper3: {
		id: 'label03',
		type: 'labelHelperDarkXS',
		htmlFor: '',
		labelname: 'Please confirm if you need a new VLAN or use existing VLAN'
	},
	labelHelper4: {
		id: 'label04',
		type: 'labelHelperDarkSM',
		htmlFor: '',
		labelname: 'Please confirm if you need a new VLAN or use existing VLAN'
	},
	labelDefault: {
		id: 'label1',
		type: 'labelDefault',
		htmlFor: '',
		labelname: 'Subsidiary name'
	},
	labelCenter: {
		id: 'label2',
		type: 'labelCenter',
		htmlFor: '',
		labelname: 'Subsidiary name'
	},
	labelRight: {
		id: 'label3',
		type: 'labelRight',
		htmlFor: '',
		labelname: 'Subsidiary name'
	},
	labelRequired: {
		id: 'label4',
		type: 'labelRequiredDefault',
		htmlFor: '',
		labelname: 'Telephone or Mobile Number',
		isRequired: true
	},
	labelRequiredCenter: {
		id: 'label5',
		type: 'labelRequiredCenter',
		htmlFor: '',
		labelname: 'Telephone or Mobile Number',
		isRequired: true
	},
	labelRequiredRight: {
		id: 'label6',
		type: 'labelRequiredRight',
		htmlFor: '',
		labelname: 'Telephone or Mobile Number',
		isRequired: true
	},
	labelHeadingDefault: {
		id: 'label7',
		type: 'labelHeadingDefault',
		htmlFor: '',
		labelname: 'Sample Heading'
	},
	labelHeadingCenter: {
		id: 'label8',
		type: 'labelHeadingCenter',
		htmlFor: '',
		labelname: 'Sample Heading'
	},
	labelHeadingRight: {
		id: 'label9',
		type: 'labelHeadingRight',
		htmlFor: '',
		labelname: 'Sample Heading'
	},
	labelHeadingNBDefault: {
		id: 'label10',
		type: 'labelHeadingNBDefault',
		htmlFor: '',
		labelname: 'Sample Heading'
	},
	labelHeadingNBCenter: {
		id: 'label11',
		type: 'labelHeadingNBCenter',
		htmlFor: '',
		labelname: 'Sample Heading'
	},
	labelHeadingNBRight: {
		id: 'label12',
		type: 'labelHeadingNBRight',
		htmlFor: '',
		labelname: 'Sample Heading'
	}
};