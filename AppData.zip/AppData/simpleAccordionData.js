export default {
	id: 'simple_accordion',
	name: 'simpleaccordion',
	displayAccordion: true,
	//alwaysExpanded: true,
	header: {
		type: 'Simple',
		arrowTooltip: 'click here to expand',
		headerData: {
			title: 'Accordion heading 1'
		}
	},
	content: {
		type: 'Simple',
		contentData: [
			{
				description: 'description',
				content: 'This is description.....'
			}
		]
	}
};
