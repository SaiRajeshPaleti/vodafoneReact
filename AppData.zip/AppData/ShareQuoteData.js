export default {
	props: {
		data: {
			id: 'share_quote',
			name: 'sharequote',
			// { value: 'aaa', label: '', isValidateHOC: true },
			// { value: 'bt4r', label: '', isValidateHOC: true }
			initialEmail: [
				[
					{
						componentType: 'Label',
						props: {
							data: {
								id: 'email_ext',
								isRequired: false,
								htmlFor: 'ext_email_input_0',
								type: 'labelDefault',
								labelname: 'Email id'
							}
						}
					},
					{
						isValidateHOC: true,
						componentType: 'TextField',
						props: {
							data: {
								CreateHandler: 'getEmailHandler|onBlur',
								placeholder: 'emailid@company.com',
								name: 'ext_email_input_0',
								maxLength: 50,
								title: '',
								id: 'ext_email_input_0',
								value: 'ere',
								key: 0
							}
						}
					},
					{ componentType: 'Icon', props: { name: 'close', tooltip: 'Remove' } }
				],
				[
					{
						componentType: 'Label',
						props: {
							data: {
								id: 'email_ext',
								isRequired: false,
								htmlFor: 'ext_email_input_1',
								type: 'labelDefault',
								labelname: 'Email id'
							}
						}
					},
					{
						componentType: 'TextField',
						props: {
							data: {
								CreateHandler: 'getEmailHandler|onBlur',
								placeholder: 'emailid@company.com',
								name: 'ext_email_input_1',
								maxLength: 50,
								title: '',
								id: 'ext_email_input_1',
								value: 'ewrwe',
								key: 1
							}
						}
					},
					{ componentType: 'Icon', props: { name: 'close', tooltip: 'Remove' } }
				]
			],
			content: [
				{
					emailData: [
						{
							componentType: 'Label',
							props: {
								data: {
									id: 'Email_label',
									isRequired: false,
									htmlFor: 'input_email',
									type: 'labelDefault',
									labelname: 'Email id'
								}
							}
						},
						{
							componentType: 'TextField',
							props: {
								data: {
									placeholder: 'emailid@company.com',
									name: 'input_email',
									maxLength: 30,
									title: '',
									apiData: '@Query|getSubsidiaries|ContactDetails.EmailAddress',
									id: 'input_email'
								}
							}
						}
					]
				}
			],
			textAreaData: {
				id: 'notes',
				name: 'notes',
				rows: 5,
				label: 'Notes',
				maxLength: 4000,
				title: 'Please enter the description',
				placeholder: '',
				label_header_left: {
					labelname: 'Notes',
					type: 'labelDefault',
					isInline: true,
					fontSizeType: 'lg'
				},
				label_header_right: {
					labelname: 'characters left',
					type: 'labelDefault',
					isInline: true,
					fontSizeType: 'lg'
				},
				// label_helper: {
				// 	labelname: 'You can enter  +, (), /, space and – special characters',
				// 	type: 'labelDefault',
				// 	fontSizeType: 'sm'
				// },
				onChange: (value) => console.log('teaxtarea value:', value)
			},

			extraData: {
				noOfFields: 3,
				emailData: [
					{
						componentType: 'Label',
						props: {
							data: {
								id: 'ext_email',
								isRequired: false,
								htmlFor: 'ext_input_email',
								type: 'labelDefault',
								labelname: 'Email id'
							}
						}
					},
					{
						componentType: 'TextField',
						props: {
							data: {
								placeholder: 'emailid@company.com',
								name: 'ext_input_email',
								maxLength: 30,
								title: '',
								id: 'ext_input_email',
								onBlur: (e) => console.log(e.target.value)
							}
						}
					},
					{
						componentType: 'Icon',
						props: {
							name: 'close',
							tooltip: 'Remove'
						}
					}
				],
				emailFields: []
			}
		}
	}
};
