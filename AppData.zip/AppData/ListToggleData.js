export default {
	Icons: [
		{
			name: 'list',
			title: 'Table View',
			isIcon: true,
			selected: true,
			view: 'table'
		},
		{
			name: 'grid',
			title: 'Accordian View',
			isIcon: true,
			selected: false,
			view: 'accordian'
		}
	],
	onClick: (dataPassed, currentView) => {
		console.log('Seleted view is: ', dataPassed, ' and current view is: ', currentView);
		//	console.log('and current view from state is: ', this.state.currentView);
	}
};
