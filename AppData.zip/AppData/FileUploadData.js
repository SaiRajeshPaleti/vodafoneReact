export default {
	id: 'fileUpl',
	upload_text: 'Upload files',
	label_header_left: {
		labelname: 'Notes',
		type: 'labelDefault',
		isInline: true,
		fontSizeType: 'lg',
		isRequired: true
	},
	drag_drop_text: 'Drag and drop files here to upload',
	max_file: 'Max file size: 20mb per file',
	hintText: {
		labelname: 'Please note: you can upload only one file.',
		type: 'labelDefault',
		isInline: true,
		fontSizeType: 'lg',
		id: 'bulkQuoteUpload_label',
		htmlFor: ''
	},
	or: 'or',
	browser_btn_text: 'Browse files',
	url: '/upload',
	buttonConfig: {
		id: 'tertiary',
		name: 'Upload files',
		type: 'tertiary',
		buttonType: 'button',
		onClick: () => {}
	},
	getFiles: (files) => {
		console.log('files', files);
		return files;
	},
	// onChange: (e) => {
	// 	console.log('comingFiles', e);
	// 	// var temporaryURL = window.webkitURL.createObjectURL(e.value[0]);
	// },

	check: () => {
		return 100;
	}
};
