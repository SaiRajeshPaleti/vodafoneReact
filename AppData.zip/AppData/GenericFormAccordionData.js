export default {
	expandedData: {
		id: 'generic_form_accordion',
		name: 'genericformaccordion',
		displayAccordion: true,
		alwaysExpanded: true,
		header: {
			type: 'Title',
			headerData: {
				clickId: 'acc1',
				title: 'Customer details'
			}
		},
		content: {
			type: 'FormContent',
			summaryBody: true,
			gridEnable: true,
			contentData: [
				{
					componentType: 'NoService',
					props: {
						data: {
							noCountIcon: 'icon-info', //Consumer can change the ICON as per the requirement
							noRecordsTxt: 'No service/site currently added.'
						}
					}
				},
				{
					componentType: 'RepeatComponentsHOC',
					props: {
						data: {
							id: 'RepeatComponentsHOC',
							metaData: [
								{
									id: '1',
									postCode: 'SN1 2AT',
									siteAddressId: '1234',
									siteAddressLabel: 'ABCD',
									serviceSpeed: '12',
									serviceSpeedLabel: '123',
									accessType: 'Primary',
									accessTypeLabel: 'Secondary',
									bearerSpeed: '10 MBps',
									bearerSpeedLabel: '10 Mbps'
									// addressList,
									// SecondaryAccessResponse,
									// siteAAddressform: formData[currentStepName].siteAAddressform,
									// siteAddressform: selectAddress,
									// selectedSiteAddress
								},
								{
									id: '2',
									postCode: 'SN1 2AT',
									siteAddressId: '1234',
									siteAddressLabel: 'ABCD',
									serviceSpeed: '12',
									serviceSpeedLabel: '123',
									accessType: 'Primary',
									accessTypeLabel: 'Secondary',
									bearerSpeed: '10 MBps',
									bearerSpeedLabel: '10 Mbps'
									// addressList,
									// SecondaryAccessResponse,
									// siteAAddressform: formData[currentStepName].siteAAddressform,
									// siteAddressform: selectAddress,
									// selectedSiteAddress
								},
								{
									id: '2',
									postCode: 'SN1 2AT',
									siteAddressId: '1234',
									siteAddressLabel: 'ABCD',
									serviceSpeed: '12',
									serviceSpeedLabel: '123',
									accessType: 'Primary',
									accessTypeLabel: 'Secondary',
									bearerSpeed: '10 MBps',
									bearerSpeedLabel: '10 Mbps'
									// addressList,
									// SecondaryAccessResponse,
									// siteAAddressform: formData[currentStepName].siteAAddressform,
									// siteAddressform: selectAddress,
									// selectedSiteAddress
								}
							],
							// 	apiData: '@FormData.metaData|generalInfo.listOfSites',
							componentList: [
								{
									componentType: 'SummaryServiceSite',
									props: {
										data: {
											id: '12',
											//	apiData: '@FormData.id|id',
											bearerSpeed: {
												title: 'Bearer speed:',
												speed: '10 Mbps'
												//	apiData1: '@FormData.speed|bearerSpeedLabel'
											},
											accessType: {
												title: 'Access type:',
												type: 'Primary'
												//	apiData: '@FormData.type|accessTypeLabel'
											},
											siteAddress: {
												title: 'Site address:',
												address: 'ABCD'
												//	apiData: '@FormData.address|selectedSiteAddress'
											}
											//	CreateHandler: 'editSite|editSite',
											//	CreateHandler1: 'deleteSelectedSite|deleteSite'
										}
									}
								}
							]
						}
					}
				}
				// {
				//   componentType: 'Label',
				//   props: {
				//     data: {
				//       id: 'companyName_label',
				//       isRequired: false,
				//       htmlFor: '',
				//       type: 'labelDefault',
				//       labelname: 'Company name'
				//     }
				//   }
				// },
				// {
				//   componentType: 'Label',
				//   props: {
				//     data: {
				//       id: 'companyNameValue_label',
				//       isRequired: false,
				//       htmlFor: '',
				//       type: 'labelDefault',
				//       labelname: ''
				//     }
				//   }
				// },
				// {
				//   componentType: 'TextField',
				//   isValidateHOC: true,
				//   validateHOCContent: 'This field is required',
				//   props: {
				//     data: {
				//       placeholder: '',
				//       name: 'orderContactLastName',
				//       maxLength: 30,
				//       title: '',
				//       id: 'orderContactLastName',
				//       helpText: {
				//         labelname: 'Help text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       labelField: {
				//         labelname: 'Label Heading',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       classNames: {
				//         columnType: 'column-2'
				//       }
				//     }
				//   }
				// },
				// {
				//   componentType: 'TextField',
				//   isValidateHOC: true,
				//   validateHOCContent: 'This field is required',
				//   props: {
				//     data: {
				//       placeholder: '',
				//       name: 'orderContactLastName',
				//       maxLength: 30,
				//       title: '',
				//       id: 'orderContactLastName',
				//       helpText: {
				//         labelname: 'Help text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       labelField: {
				//         labelname: 'Label text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       classNames: {
				//         columnType: 'column-2'
				//       }
				//     }
				//   }
				// },
				// {
				//   componentType: 'DropdownComponent',
				//   isValidateHOC: true,
				//   props: {
				//     data: {
				//       id: 'subsidiaryName',
				//       name: 'subsidiaryName',
				//       title: 'Select subsidiary',
				//       helpText: {
				//         labelname: 'Label text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       label: {
				//         labelname: 'sample text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       classNames: {
				//         columnType: 'column-2'
				//       },
				//       dropdownValues: [
				//         {
				//           optionName: 'Select subsidiary',
				//           optionValue: '',
				//           id: 1
				//         },
				//         {
				//           optionName: 'Subsidiary 1',
				//           optionValue: 'Subsidiary1',
				//           id: 2
				//         },
				//         {
				//           optionName: 'Subsidiary 2',
				//           optionValue: 'Subsidiary2',
				//           id: 3
				//         },
				//         {
				//           optionName: 'Subsidiary 3',
				//           optionValue: 'Subsidiary3',
				//           id: 4
				//         }
				//       ]
				//     }
				//   }
				// },
				// {
				//   componentType: 'DropdownComponent',
				//   isValidateHOC: true,
				//   props: {
				//     data: {
				//       id: 'subsidiaryName',
				//       name: 'subsidiaryName',
				//       title: 'Select subsidiary',
				//       helpText: {
				//         labelname: 'Label text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       label: {
				//         labelname: 'sample text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       classNames: {
				//         columnType: 'column-2'
				//       },
				//       dropdownValues: [
				//         {
				//           optionName: 'Select subsidiary',
				//           optionValue: '',
				//           id: 1
				//         },
				//         {
				//           optionName: 'Subsidiary 1',
				//           optionValue: 'Subsidiary1',
				//           id: 2
				//         },
				//         {
				//           optionName: 'Subsidiary 2',
				//           optionValue: 'Subsidiary2',
				//           id: 3
				//         },
				//         {
				//           optionName: 'Subsidiary 3',
				//           optionValue: 'Subsidiary3',
				//           id: 4
				//         }
				//       ]
				//     }
				//   }
				// },
				// {
				//   componentType: 'DropdownComponent',
				//   isValidateHOC: true,
				//   props: {
				//     data: {
				//       id: 'subsidiaryName',
				//       name: 'subsidiaryName',
				//       title: 'Select subsidiary',
				//       helpText: {
				//         labelname: 'Label text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       label: {
				//         labelname: 'sample text',
				//         type: 'labelDefault',
				//         fontSizeType: 'sm'
				//       },
				//       classNames: {
				//         columnType: 'column-2'
				//       },
				//       dropdownValues: [
				//         {
				//           optionName: 'Select subsidiary',
				//           optionValue: '',
				//           id: 1
				//         },
				//         {
				//           optionName: 'Subsidiary 1',
				//           optionValue: 'Subsidiary1',
				//           id: 2
				//         },
				//         {
				//           optionName: 'Subsidiary 2',
				//           optionValue: 'Subsidiary2',
				//           id: 3
				//         },
				//         {
				//           optionName: 'Subsidiary 3',
				//           optionValue: 'Subsidiary3',
				//           id: 4
				//         }
				//       ]
				//     }
				//   }
				// },
				// {
				//   componentType: 'TextField',
				//   isValidateHOC: false,
				//   validateHOCContent: 'This field is required',
				//   props: {
				//     data: {
				//       placeholder: '',
				//       name: 'orderContactLastName',
				//       maxLength: 30,
				//       title: '',
				//       id: 'orderContactLastName',
				//       classNames: {
				//         columnType: 'column-1'
				//       }
				//     }
				//   }
				//}
			]
		}
	},
	nonExpanded: {
		id: 'generic_form_accordion',
		name: 'genericformaccordion',
		displayAccordion: true,
		alwaysExpanded: false,
		header: {
			type: 'Simple',
			headerData: {
				title: 'Customer details'
			}
		},
		content: {
			type: 'FormContent',
			showAccordion: false,
			contentData: [
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'companyName_label',
							isRequired: false,
							htmlFor: '',
							type: 'labelDefault',
							labelname: 'Company name'
						}
					}
				},
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'companyNameValue_label',
							isRequired: false,
							htmlFor: '',
							type: 'labelDefault',
							labelname: ''
						}
					}
				},
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'subsidiaryName_label',
							isRequired: true,
							htmlFor: 'subsidiaryName',
							type: 'labelDefault',
							labelname: 'Subsidiary name'
						}
					}
				},
				{
					componentType: 'DropdownComponent',
					props: {
						data: {
							id: 'subsidiaryName',
							name: 'subsidiaryName',
							title: 'Select subsidiary',
							dropdownValues: [
								{
									optionName: 'Select subsidiary',
									optionValue: '',
									id: 1
								},
								{
									optionName: 'Subsidiary 1',
									optionValue: 'Subsidiary1',
									id: 2
								},
								{
									optionName: 'Subsidiary 2',
									optionValue: 'Subsidiary2',
									id: 3
								},
								{
									optionName: 'Subsidiary 3',
									optionValue: 'Subsidiary3',
									id: 4
								}
							]
						}
					}
				},
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'orderContactFirstName_label',
							isRequired: true,
							htmlFor: 'orderContactFirstName',
							type: 'labelDefault',
							labelname: 'Order contact first name'
						}
					}
				},
				{
					componentType: 'TextField',
					props: {
						data: {
							id: 'orderContactFirstName',
							name: 'orderContactFirstName',
							title: '',
							placeholder: '',
							value: '',
							maxLength: 30
						}
					}
				},
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'orderContactLastName_label',
							isRequired: true,
							htmlFor: 'orderContactLastName',
							type: 'labelDefault',
							labelname: 'Order contact last name'
						}
					}
				},
				{
					componentType: 'TextField',
					props: {
						data: {
							placeholder: '',
							name: 'orderContactLastName',
							maxLength: 30,
							title: '',
							id: 'orderContactLastName'
						}
					}
				},
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'orderContactTelephoneNumber_label',
							isRequired: true,
							htmlFor: 'orderContactTelephoneNumber',
							type: 'labelDefault',
							labelname: 'Order contact telephone number'
						}
					}
				},
				{
					componentType: 'TextField',
					props: {
						data: {
							placeholder: '',
							name: 'orderContactTelephoneNumber',
							maxLength: 12,
							title: '',
							id: 'orderContactTelephoneNumber',
							helpText: 'Individual reference that you wish to save the order against.'
						}
					}
				},
				{
					componentType: 'Label',
					props: {
						data: {
							id: 'orderContactMobileNumber_label',
							isRequired: true,
							htmlFor: 'orderContactMobileNumber',
							type: 'labelDefault',
							labelname: 'Order contact mobile number'
						}
					}
				},
				{
					componentType: 'TextField',
					isValidateHOC: true,
					props: {
						data: {
							placeholder: '',
							name: 'orderContactMobileNumber',
							maxLength: 12,
							title: '',
							id: 'orderContactMobileNumber'
						}
					}
				}
			]
		}
	}
};
