export default {
  linkTile: [
    {
      businessServicename: 'Ethernet VPN',
      highlightText: 'e',
      tileData: [
        {
          id: 'linktile1',
          title: 'Raise incident',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'warning',
          onClick: (id, title) => {
            console.log('Clicked by ' + id + ' with the title ' + title);
          },
          highlightText: 'raise inci'
        },
        {
          id: 'linktile2',
          title: 'Raise service request',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'settings',
          onClick: (id, title) => {
            console.log('Clicked by ' + id + ' with the title ' + title);
          },
          highlightText: 'raise'
        },
        {
          id: 'linktile3',
          title: 'Raise order',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'icon-shopping-trolley',
          onClick: (id, title) => {
            console.log('Clicked by ', id);
          },
          highlightText: 'raise'
        }
      ]
    },
    {
      businessServicename: 'Ethernet ',
      highlightText: 'e',
      tileData: [
        {
          id: 'linktile1',
          title: 'Raise incident',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'warning',
          onClick: (id, title) => {
            console.log('Clicked by ' + id + ' with the title ' + title);
          },
          highlightText: 'raise inci'
        },
        {
          id: 'linktile2',
          title: 'Raise service request',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'settings',
          onClick: (id, title) => {
            console.log('Clicked by ' + id + ' with the title ' + title);
          },
          highlightText: 'raise'
        },
        {
          id: 'linktile3',
          title: 'Raise order',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'icon-shopping-trolley',
          onClick: (id, title) => {
            console.log('Clicked by ', id);
          },
          highlightText: 'raise'
        }
      ]
    },
    {
      businessServicename: 'VPN',
      highlightText: 'e',
      tileData: [
        {
          id: 'linktile1',
          title: 'Raise incident',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'warning',
          onClick: (id, title) => {
            console.log('Clicked by ' + id + ' with the title ' + title);
          },
          highlightText: 'raise inci'
        },
        {
          id: 'linktile2',
          title: 'Raise service request',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'settings',
          onClick: (id, title) => {
            console.log('Clicked by ' + id + ' with the title ' + title);
          },
          highlightText: 'raise'
        },
        {
          id: 'linktile3',
          title: 'Raise order',
          description: 'Allows you to raise an issue with your Business Service',
          icon: 'icon-shopping-trolley',
          onClick: (id, title) => {
            console.log('Clicked by ', id);
          },
          highlightText: 'raise'
        }
      ]
    }
  ]
};
