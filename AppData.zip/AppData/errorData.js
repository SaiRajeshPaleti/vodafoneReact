export default {
	errorIcon: 'block', //Consumer can change the ICON as per the requirement
	failTxt: 'Failed to load',
	pleaseWaitTxt: 'Please wait a few minutes and try again'
};
