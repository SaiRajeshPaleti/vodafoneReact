export default {
	loaderText: 'one moment please...',
	loaderIcon: 'dynamicloader'
};
