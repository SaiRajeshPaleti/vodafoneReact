import React from 'react';
import { getHeader, getAccordianFooter, getAccordianContent } from './AccordionSelector';
export const HeaderComponent = (props) => {
	const Header = getHeader(props.data.headerData.type);
	return <Header data={props.data} />;
};
export default HeaderComponent;
export const FooterComponent = (props) => {
	const Footer = getAccordianFooter(props.data.type);
	return props.data.type && props.data.active ? <Footer data={props.data} /> : '';
};
export const ContentComponent = (props) => {
	const Content = getAccordianContent(props.data.type);
	return <Content data={props.data} />;
};
