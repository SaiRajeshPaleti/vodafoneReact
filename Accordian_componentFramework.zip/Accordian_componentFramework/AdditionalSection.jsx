import React from 'react';
import PropTypes from 'prop-types';
import { getFormattedCurrency, predefinedPropTypes } from './Utilities/Utility';
import HeadStyles from './DefData/BearerAccordionDefData-Props';

export const additionalSection = (props) => {
	const { terms, control } = props.data.additionalData;
	const { constStyles, constData } = HeadStyles;
	const removeControl = control && (
		<div className={constStyles.remove_head} onClick={props.data.removeAdditional}>
			{constData.remove}
		</div>
	);
	return (
		<React.Fragment>
			<div className={constStyles.firstColumn}>
				<div className={constStyles.iconSection} />
				<div className={constStyles.titleClass}>
					<div>{constData.additionalServices}</div>
					{removeControl}
				</div>
			</div>
			<div className={constStyles.accMonthlyCost}>
				<div className={constStyles.accMonthlSiteAddr1}>
					<div className={constStyles.monthTitle}>{constData.addOneOffCharges}</div>
					<div className={constStyles.installPrice}>{getFormattedCurrency(terms[0].onOffCharge)}</div>
				</div>
				<div className={constStyles.accMonthlSiteAddr2}>
					<div className={constStyles.monthTitle}>{constData.addRentalAnnum}</div>
					<div className={constStyles.installPrice}>
						{getFormattedCurrency(terms[0].rentalPerAnnumCharge)}
					</div>
				</div>
			</div>
			<div className={constStyles.divide} />
			<div className={constStyles.accQuarterlyCost}>
				<div className={constStyles.accMonthlSiteAddr1}>
					<div className={constStyles.monthTitle}>{constData.addOneOffCharges}</div>
					<div className={constStyles.installPrice}>{getFormattedCurrency(terms[1].onOffCharge)}</div>
				</div>
				<div className={constStyles.accMonthlSiteAddr2}>
					<div className={constStyles.monthTitle}>{constData.addRentalAnnum}</div>
					<div className={constStyles.installPrice}>
						{getFormattedCurrency(terms[1].rentalPerAnnumCharge)}
					</div>
				</div>
			</div>
		</React.Fragment>
	);
};
export default additionalSection;

additionalSection.propTypes = {
	data: PropTypes.shape({
		additionalData: PropTypes.shape({
			control: PropTypes.string,
			displayAdditional: PropTypes.oneOf([ true, false, null ]),
			checked: PropTypes.bool,
			terms: PropTypes.arrayOf(predefinedPropTypes.plan.isRequired).isRequired
		}),
		removeAdditional: PropTypes.func.isRequired
	})
};
