import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import AccordionStyles from '../DefData/accordionDefData-Props';

export class simpleFooter extends BaseComponent {
	render() {
		const iconClass = this.props.data.active
			? AccordionStyles.defaultStyles.iconRotateClass
			: AccordionStyles.defaultStyles.iconClass;
		return (
			<div
				className={AccordionStyles.constStyles.accordion_footer_Active}
				onClick={(e) => this.delegateHandler(AccordionStyles.actions.onClick, e)}
			>
				<div>{this.props.data.title}</div>
				<div className={AccordionStyles.defaultStyles.defalutChevron}>
					<span className={iconClass}>
						<Icon name={AccordionStyles.defaultStyles.iconCode} />
					</span>
				</div>
			</div>
		);
	}
}
export default simpleFooter;

simpleFooter.propTypes = {
	data: PropTypes.shape({
		title: PropTypes.string.isRequired,
		active: PropTypes.bool.isRequired,
		onClick: PropTypes.func.isRequired
	})
};
