import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import { validateFunArgs } from '../Utilities/Utility';
import { constStyles, defaultStyles, actions } from '../DefData/ToggleTableDefData-Props';

export class TableFooter extends BaseComponent {
  constructor(props) {
    super(props);
    this.hadleClick = this.hadleClick.bind(this);
  }

  hadleClick() {
    this.props.data.method
      ? window[this.props.data.method] instanceof Function
        ? window[this.props.data.method](this.props.data.rowData)
        : this.delegateHandler(actions.method, this.props.data.btnName, validateFunArgs)
      : false;
  }
  render() {
    return (
      <div className={constStyles.buttonWrapper}>
        <span className={defaultStyles.button} onClick={this.hadleClick}>
          {this.props.data.btnName}
        </span>
      </div>
    );
  }
}
export default TableFooter;

TableFooter.propTypes = {
  data: PropTypes.shape({
    method: PropTypes.oneOfType[(PropTypes.func, PropTypes.string)],
    btnName: PropTypes.string.isRequired,
    rowData: PropTypes.object
  }).isRequired
};
