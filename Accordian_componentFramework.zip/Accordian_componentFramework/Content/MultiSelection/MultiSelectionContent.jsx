import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import MultiTable from '../MultiTable/MultiTable';
import MSPBearerContent from '../BearerOptions/MSPBearerContent';
import ThreeDHeader from '../../Header/ThreeD';
import ThreeDBody from '../ThreeD/ThreeDBody';
import contentStyles from '../../DefData/BearerAccordionDefData-Props';
import TableHead from '../MultiTable/TableHead';
import Switch from 'vf-ent-ws-switch';
import { addPrices, multiSelectionPropTypes, validateFunArgs, getClonedObject } from '../../Utilities/Utility';
let accordionHeaderData = [];
class MultiSelectionContent extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			threeDterms: {},
			speedterms: {},
			pstnTerms: {},
			beaerTerms: {},
			speedHeaderData: {},
			bearerHeaderData: {},
			contentData: this.props.data.bearerOptions
		};
		accordionHeaderData = [ ...this.props.data.headerData.terms ];
		// this.additionalPlan = this.additionalPlan.bind(this);
		this.threeDSelector = this.threeDSelector.bind(this);
		this.setBearerHeaderData = this.setBearerHeaderData.bind(this);
		this.setProps = this.setProps.bind(this);
		this.speedSelector = this.speedSelector.bind(this);
		this.toggleBackUpEvc = this.toggleBackUpEvc.bind(this);
		this.setContentData = this.setContentData.bind(this);
	}
	componentWillMount() {
		this.setProps(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.setProps(nextProps);
	}
	toggleBackUpEvc(status) {
		this.debugLog(status);
	}
	threeDSelector(charges, contentData1) {
		const contentData = JSON.parse(JSON.stringify(this.state.contentData));
		const classofService = contentData.classofService;
		let classofServiveContent = classofService.contentData;
		classofServiveContent = contentData1;
		classofService.classofServiveContent = classofServiveContent;
		contentData.classofService = classofService;
		this.setState({
			charges
		});
		const headerData = getClonedObject(this.state.headerData);
		headerData.terms.map((term, index) => {
			const rentalPerAnnumCharge = this.state.charges
				? addPrices([ term.rentalPerAnnumCharge + charges[index] ]) - this.state.charges[index]
				: addPrices([ term.rentalPerAnnumCharge + charges[index] ]);
			headerData.terms[index].rentalPerAnnumCharge = rentalPerAnnumCharge;
		});
		this.delegateHandler(contentStyles.actions.setHeaderData, headerData, validateFunArgs);
		this.props.data.setContentData(contentData);
	}
	speedSelector(selectedPlan) {
		const headerData = getClonedObject(this.state.headerData);
		if (selectedPlan.status) {
			selectedPlan.terms.map((term, index) => {
				headerData.terms[index] = {
					onOffCharge: term.onOffCharge,
					rentalPerAnnumCharge: term.rentalPerAnnumCharge
				};
			});
			const ThreeBodyProps = { ...this.state.ThreeBodyProps };
			const contentData = ThreeBodyProps.contentData;
			const bandwidth = selectedPlan.bandwidth.split(' ');
			contentData.map((term, index) => {
				term.one_year_term = 0;
				term.two_year_term = 0;
			});
			contentData[0].bandwidth = bandwidth[0];
			contentData[0].actualBandwidth = bandwidth[0];
			contentData[1].bandwidth = '0';
			contentData[2].bandwidth = '0';
			ThreeBodyProps.contentData = contentData;
			this.setState({
				ThreeBodyProps: ThreeBodyProps,
				charges: {}
			});
		} else {
			this.setState({
				speedHeaderData: selectedPlan
			});

			if (selectedPlan.additionalSection) {
				if (headerData.additionalSection) {
					const additionalData = JSON.parse(JSON.stringify(headerData.additionalData));
					selectedPlan.additionalData.terms.map((term, index) => {
						additionalData.terms[index] = {
							onOffCharge: addPrices([ term.onOffCharge, additionalData.terms[index].onOffCharge ]),
							rentalPerAnnumCharge: addPrices([
								term.rentalPerAnnumCharge,
								additionalData.terms[index].rentalPerAnnumCharge
							])
						};
					});
					headerData.additionalData = additionalData;
				} else {
					headerData.additionalSection = true;
					headerData.additionalData = selectedPlan.additionalData;
				}
			} else {
				if (this.state.bearerHeaderData.additionalSection) {
					if (this.state.speedHeaderData.additionalSection) {
						const additionalData = JSON.parse(JSON.stringify(headerData.additionalData));
						this.state.speedHeaderData.additionalData.terms.map((term, index) => {
							additionalData.terms[index] = {
								onOffCharge: additionalData.terms[index].onOffCharge - term.onOffCharge,
								rentalPerAnnumCharge:
									additionalData.terms[index].rentalPerAnnumCharge - term.rentalPerAnnumCharge
							};
						});
						headerData.additionalData = additionalData;
						this.setState({
							speedHeaderData: {}
						});
					} else {
						headerData.additionalData = {};
						headerData.additionalSection = false;
					}
				} else {
					headerData.additionalData = {};
					headerData.additionalSection = false;
					this.setState({
						bearerHeaderData: {},
						speedHeaderData: {}
					});
				}
			}
		}
		// if (this.state.speedHeaderData.additionalSection) {
		// } else {
		// 	headerData.additionalData = {};
		// 	headerData.additionalSection = false;
		// }

		this.delegateHandler(contentStyles.actions.setHeaderData, headerData, validateFunArgs);
	}
	setProps(props) {
		const headerData = { ...props.data.headerData };
		const contentData = { ...props.data.contentData };
		const multiTableProps = {
			...props.data.contentData.speedoptions,
			headerData: props.data.headerData,
			setPlan: this.speedSelector,
			onChange: this.props.data.onChange
		};
		const title = props.data.contentData.classofService.title;
		const bearerProps = {
			contentData: props.data.contentData.bearerOptions.contentData,
			setPlan: this.setBearerHeaderData,
			headerData: props.data.headerData,
			onChange: this.props.data.onChange,
			setContentData: this.setContentData
		};
		const pstnProps = {
			...props.data.contentData.pstnoptions,
			headerData: props.data.headerData,
			setPlan: this.speedSelector,
			onChange: this.props.data.onChange
		};
		const ThreeBodyProps = {
			contentData: props.data.contentData.classofService.contentData,
			headerData: props.data.headerData,
			setData: this.threeDSelector
		};

		this.setState({
			bearerProps,
			multiTableProps,
			pstnProps,
			ThreeBodyProps,
			headerData,
			title,
			contentData
		});
	}
	setBearerHeaderData(selectedPlan) {
		let headerData = JSON.parse(JSON.stringify(this.state.headerData));
		if (selectedPlan.additionalSection) {
			this.setState({
				bearerHeaderData: selectedPlan
			});

			if (headerData.additionalSection) {
				const additionalData = { ...headerData.additionalData };
				selectedPlan.additionalData.terms.map((term, index) => {
					additionalData.terms[index] = {
						onOffCharge: this.state.speedHeaderData.additionalSection
							? addPrices([
									term.onOffCharge,
									this.state.speedHeaderData.additionalData.terms[index].onOffCharge
								])
							: term.onOffCharge,
						rentalPerAnnumCharge: this.state.speedHeaderData.additionalSection
							? addPrices([
									term.rentalPerAnnumCharge,
									this.state.speedHeaderData.additionalData.terms[index].rentalPerAnnumCharge
								])
							: term.rentalPerAnnumCharge
					};
				});
				headerData.additionalData = additionalData;
			} else {
				////additionalData = selectedPlan;
				headerData.additionalData = selectedPlan.additionalData;
				headerData.additionalSection = true;

				//	headerData.additionalSection = true;
			}
			// if (headerData.additionalSection) {
			// 	const additionalData = JSON.parse(JSON.stringify(headerData.additionalData));
			// 	selectedPlan.additionalData.terms.map((term, index) => {
			// 		selectedPlan.additionalData.terms[index] = {
			// 			onOffCharge: this.state.speedHeaderData.additionalSection
			// 				? addPrices([
			// 						term.onOffCharge,
			// 						this.state.speedHeaderData.additionalData.terms[index].onOffCharge
			// 					])
			// 				: term.onOffCharge,
			// 			rentalPerAnnumCharge: this.state.speedHeaderData.additionalSection
			// 				? addPrices([
			// 						term.rentalPerAnnumCharge,
			// 						this.state.speedHeaderData.additionalData.terms[index].rentalPerAnnumCharge
			// 					])
			// 				: term.rentalPerAnnumCharge
			// 		};
			// 	});
			// 	headerData.additionalData = selectedPlan;
			// 	headerData.additionalSection = true;
			// 	//	if()
			// } else {
			// 	headerData.additionalData = selectedPlan.additionalData;
			// 	headerData.additionalSection = true;
			// }
			//headerData = selectedPlan;
		} else {
			if (this.state.speedHeaderData.additionalSection) {
				if (this.state.bearerHeaderData.additionalSection) {
					const additionalData = JSON.parse(JSON.stringify(headerData.additionalData));
					this.state.bearerHeaderData.additionalData.terms.map((term, index) => {
						additionalData.terms[index] = {
							onOffCharge: additionalData.terms[index].onOffCharge - term.onOffCharge,
							rentalPerAnnumCharge:
								additionalData.terms[index].rentalPerAnnumCharge - term.rentalPerAnnumCharge
						};
					});
					headerData.additionalData = additionalData;
					this.setState({
						bearerHeaderData: {}
					});
				} else {
					headerData.additionalData = {};
					headerData.additionalSection = false;
				}
			} else {
				headerData.additionalData = {};
				headerData.additionalSection = false;
				this.setState({
					bearerHeaderData: {},
					speedHeaderData: {}
				});
			}
			if (this.state.speedHeaderData.additionalSection) {
			} else {
				headerData.additionalData = {};
				headerData.additionalSection = false;
			}
		}
		this.delegateHandler(contentStyles.actions.setHeaderData, headerData, validateFunArgs);
	}
	setContentData(selectedData) {
		const contentData = JSON.parse(JSON.stringify(this.state.contentData));
		const bearerOptions = JSON.parse(JSON.stringify(contentData.bearerOptions));
		let bcontentData = JSON.parse(JSON.stringify(bearerOptions.contentData));
		bcontentData = selectedData;
		bearerOptions.contentData = bcontentData;
		contentData.bearerOptions = bearerOptions;
		this.props.data.setContentData(contentData);
	}
	render() {
		const switchProps = {
			id: 'backupevc',
			title: 'Back up EVC',
			mainClass: 'add_services_user_roles_list_right',
			name: 'backupevc',
			onClick: this.toggleBackUpEvc
		};
		return (
			<div className="accordionContentSection">
				{this.state.multiTableProps && <MultiTable data={this.state.multiTableProps} />}
				<div className="content-section multiTable">
					<TableHead data={this.state.title} />
				</div>{' '}
				<ThreeDBody data={this.state.ThreeBodyProps} />
				<div className="add-services-catalogue-list-item">
					<div className="add_services_user_roles_list_left">{switchProps.title}</div>
					<Switch data={switchProps} />
				</div>
				{this.state.pstnProps && <MultiTable data={this.state.pstnProps} />}
				<MSPBearerContent data={this.state.bearerProps} />
			</div>
		);
	}
}
export default MultiSelectionContent;
MultiSelectionContent.prototypes = {
	data: PropTypes.shape({
		headerData: multiSelectionPropTypes.headerData.isRequired,
		speedOptions: multiSelectionPropTypes.contentData.isRequired,
		setHeaderData: PropTypes.func.isRequired
	})
};
