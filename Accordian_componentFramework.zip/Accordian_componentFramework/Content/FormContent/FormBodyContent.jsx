import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import advSearchComponentStyles from '../../DefData/FormBodyDefData-Props';
import FormElememtRegistry from './FormElememtRegistry';
import ValidationHOC from 'vf-ent-ws-validation-hoc';

class FormBodyContent extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      active: false,
      filterCriteriaTree: {}
    };
    this.evaluateCriteria = this.evaluateCriteria.bind(this);
    this.renderField = this.renderField.bind(this);
    this.addToFilterCriteriaTree = this.addToFilterCriteriaTree.bind(this);
  }
  renderField(componentData) {
    if (componentData.criteria) {
      this.addToFilterCriteriaTree(componentData);
      return this.evaluateCriteria(componentData.criteria);
    } else {
      return true;
    }
  }
  addToFilterCriteriaTree(componentData) {
    let id = componentData.props.data.id;
    this.state.filterCriteriaTree[id] = componentData.criteria;
  }
  evaluateCriteria(criteria) {
    if (criteria.condition === 'AND' || criteria.condition === 'OR') {
      let result1 = this.evaluateCriteria(criteria.leftOperand);
      let result2 = this.evaluateCriteria(criteria.rightOperand);

      let result = criteria.condition === 'OR' ? result1 || result2 : result1 && result2;

      return result;
    } else {
      let filterCriteriaTree = this.state.filterCriteriaTree;
      if (filterCriteriaTree[criteria.leftOperand]) {
        let parentCriteriaOutcome = this.evaluateCriteria(filterCriteriaTree[criteria.leftOperand]);
        if (!parentCriteriaOutcome) {
          return false;
        }
      }
      let leftOperandValue = this.getValueFromMetaData(this.props.data.contentData, criteria.leftOperand);
      if (!leftOperandValue) {
        leftOperandValue = this.getValueFromFormData(this.props.data.formData, criteria.leftOperand);
      }
      if (leftOperandValue) {
        if (criteria.condition === 'EQUAL') {
          return leftOperandValue === criteria.rightOperand;
        } else if (criteria.condition === 'GREATERTHAN') {
          return leftOperandValue > criteria.rightOperand;
        } else if (criteria.condition === 'LESSTHAN') {
          return leftOperandValue < criteria.rightOperand;
        } else if (criteria.condition === 'CONTAINS') {
          return leftOperandValue.indexOf(criteria.rightOperand) > -1;
        } else if (criteria.condition === 'NOTEQUAL') {
          return leftOperandValue !== criteria.rightOperand;
        }
      } else {
        if (criteria.condition === 'NOTEQUAL') {
          return leftOperandValue !== criteria.rightOperand;
        } else {
          return false;
        }
      }
    }
  }
  getValueFromFormData(formData, searchItem) {
    let value;
    Object.keys(formData).forEach((key) => {
      if (key === searchItem) {
        if (formData[key] !== null && typeof formData[key] === 'object') {
          value = formData[searchItem].value;
        } else {
          value = formData[searchItem];
        }
      } else if (formData[key] !== null && (typeof formData[key] === 'object' || Array.isArray(formData[key]))) {
        let returnedValue = this.getValueFromFormData(formData[key], searchItem);
        if (returnedValue) {
          value = returnedValue;
        }
      }
    });
    return value;
  }
  getValueFromMetaData(pageData, searchItem) {
    let value;
    Object.keys(pageData).forEach((key) => {
      if (key === 'id') {
        if (searchItem === pageData[key]) {
          value = pageData['value'];
        }
      } else if (pageData[key] !== null && (typeof pageData[key] === 'object' || Array.isArray(pageData[key]))) {
        let returnedValue = this.getValueFromMetaData(pageData[key], searchItem);
        if (returnedValue) {
          value = returnedValue;
        }
      }
    });
    return value;
  }

  getValueListFromMetaData(pageData, searchItem) {
    let value = [];
    Object.keys(pageData).forEach((key) => {
      if (key === 'id') {
        if (searchItem.indexOf(pageData[key]) > -1) {
          if (pageData['value']) {
            value.push(pageData['value']);
          }
        }
      } else if (pageData[key] !== null && (typeof pageData[key] === 'object' || Array.isArray(pageData[key]))) {
        let returnedValue = this.getValueListFromMetaData(pageData[key], searchItem);
        if (returnedValue.length > 0) {
          value = value.concat(returnedValue);
        }
      }
    });
    return value;
  }
  isHOCRequired(isValidateHOC, Component, key, props, isReRender, updateFormData, validateHOCContent) {
    if (isValidateHOC) {
      props = isReRender ? { ...props, updateFormData: updateFormData } : props;
      const HOCExtension = ValidationHOC(Component, props, key, validateHOCContent);
      return <HOCExtension />;
    } else {
      props = isReRender ? { ...props, updateFormData: updateFormData } : props;
      return <Component key={key} {...props} />;
    }
  }
  renderDynamicData(componentData) {
    let renderDynamicData = componentData.renderDynamicData;
    let evaluatedCriteria = this.getValueListFromMetaData(
      this.props.data.contentData,
      renderDynamicData.selectionCriteria
    );
    if (!evaluatedCriteria || evaluatedCriteria.length === 0) {
      renderDynamicData.selectionCriteria.map((criteria) => {
        let evaluatedCriteria1 = this.getValueFromFormData(this.props.data.formData, criteria);
        if (evaluatedCriteria1) {
          evaluatedCriteria.push(evaluatedCriteria1);
        }
      });
    }
    if (evaluatedCriteria.length > 0) {
      let params = {
        selectionCriteria: evaluatedCriteria,
        fileName: renderDynamicData.fileName
      };
      let handler = renderDynamicData.dynamicDataHandler;
      let output = handler(params);
      componentData.props.data['dropdownValues'] = output;
    }
  }
  validationHandler(componentData) {
    let validationCriteria = componentData.validationCriteria;
    let ruleName = validationCriteria.ruleName;
    let result = this.evaluateCriteria(validationCriteria.criteria);
    if (result) {
      if (this.props.data.validationRules) {
        this.props.data.validationRules.rules.map((rule) => {
          if (rule.ruleName === ruleName) {
            let index = rule.applicableFields.indexOf(componentData.props.data['htmlFor']);
            if (index === -1) {
              rule.applicableFields.push(componentData.props.data['htmlFor']);
            }
            if (ruleName === 'REQUIRED') {
              componentData.props.data['isRequired'] = true;
            }
          }
        });
      }
    } else {
      if (this.props.data.validationRules) {
        this.props.data.validationRules.rules.map((rule) => {
          if (rule.ruleName === ruleName) {
            let index = rule.applicableFields.indexOf(componentData.props.data['htmlFor']);
            if (index > -1) {
              rule.applicableFields.splice(index, 1);
            }
            if (ruleName === 'REQUIRED') {
              componentData.props.data['isRequired'] = false;
            }
          }
        });
      }
    }
  }

  render() {
    const componentList = this.props.data.contentData;
    const gridWrapper = this.props.data.gridEnable ? advSearchComponentStyles.constStyles.gridWrapper : '';

    const fBReturn = (
      <div
        className={`${this.props.data.summaryBody
          ? advSearchComponentStyles.constStyles.summaryDataContent
          : advSearchComponentStyles.constStyles.formContent} ${gridWrapper}`}
      >
        {componentList.map((componentData, index) => {
          const compClass = componentData.props.data.classNames ? componentData.props.data.classNames.columnType : '';

          if (componentData.validationCriteria) {
            this.validationHandler(componentData);
          }
          if (this.renderField(componentData)) {
            const Component = FormElememtRegistry[componentData.componentType];
            if (componentData.renderDynamicData) {
              this.renderDynamicData(componentData);
            }
            const applicableComponent = this.isHOCRequired(
              componentData.isValidateHOC,
              Component,
              index,
              componentData.props,
              componentData.isReRendringRequired,
              this.props.data.updateFormData,
              componentData.validateHOCContent
            );
            return (
              <div className={`${advSearchComponentStyles.constStyles.contentData} ${compClass}`} key={index}>
                {applicableComponent}
              </div>
            );
          } else {
            return false;
          }
        })}
      </div>
    );
    return fBReturn;
  }
}
export default FormBodyContent;

FormBodyContent.propTypes = {
  data: PropTypes.shape({
    contentData: PropTypes.arrayOf(
      PropTypes.shape({
        componentType: PropTypes.string.isRequired,
        props: PropTypes.object.isRequired
      })
    ).isRequired,
    type: PropTypes.string.isRequired
  }).isRequired
};
