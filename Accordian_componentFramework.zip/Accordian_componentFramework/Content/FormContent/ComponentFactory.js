import React from 'react';
import FormElememtRegistry from './FormElememtRegistry';
import NewBillingAddress from './NewBillingAddress';
import BillingAddress from './BillingAddress';

const ComponentFactory = (component) => {
	const { componentData, dropDownVisibility, onClick } = component;
	const data = { ...componentData, dropDownVisibility, onClick };
	const CustomComponent = FormElememtRegistry[component.componentType];
	return <CustomComponent data={data} />;
};
export default ComponentFactory;

export const AddressComponent = (props) => {
	return !props.status ? <BillingAddress data={props.data} /> : <NewBillingAddress data={props.data} />;
};
