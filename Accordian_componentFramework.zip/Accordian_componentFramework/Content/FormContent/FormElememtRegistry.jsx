import TextField from 'vf-ent-ws-textfield';
import TextArea from 'vf-ent-ws-textarea';
import DropDownButtons from 'vf-ent-ws-dropdown-button';
import TabbedButtons from 'vf-ent-ws-tabbed-buttons';
import AddressSelector from 'vf-ent-ws-address-selector';
import DropdownComponent from 'vf-ent-ws-simple-dropdown';
import CustomDatePicker from 'vf-ent-ws-daypicker';
import Label from 'vf-ent-ws-label';
import RadioButton from 'vf-ent-ws-radiobutton';
import CheckBox from 'vf-ent-ws-checkbox';
import FileUpload from 'vf-ent-ws-fileUpload';
import AlertMessage from 'vf-ent-ws-alert-message';
import PriorityCards from 'vf-ent-ws-priority-cards';
import Button from 'vf-ent-ws-button';
import Link from 'vf-ent-ws-link';
import RangeSlider from 'vf-ent-ws-range-slider';
import RichTextBox from 'vf-ent-ws-rich-textbox';

const FormElementRegistry = {
	TextField,
	TextArea,
	DropDownButton    : DropDownButtons,
	TabbedButtons,
	AddressSelector,
	RadioButton,
	CheckBox,
	DropdownComponent,
	FileUpload,
	SimpleDate        : CustomDatePicker,
	Label,
	AlertMessage,
	PriorityCards,
	Button,
	Link,
	RichTextBox,
	RangeSlider
};

export default FormElementRegistry;
