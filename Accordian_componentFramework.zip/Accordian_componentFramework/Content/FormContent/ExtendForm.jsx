import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import { predefinedPropTypes, validateFunArgs } from '../../Utilities/Utility';
import advSearchComponentStyles from '../../DefData/FormBodyDefData-Props';
import { AddressComponent } from './ComponentFactory';

class ExtendForm extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			active: false,
			dropDownVisibility: false
		};
		this.toggleClick = this.toggleClick.bind(this);
		this.onSubmitHandler = this.onSubmitHandler.bind(this);
		this.updateChildComponent = this.updateChildComponent.bind(this);
	}
	componentWillMount() {
		this.updateChildComponent(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.updateChildComponent(nextProps);
	}

	updateChildComponent(props = this.props) {
		this.setState({
			headerData: props.data.headerData,
			data: props.data.contentData,
			ChildDropdownData: {
				contentData: props.data.contentData,
				onClick: this.toggleClick,
				dropDownVisibility: false,
				onSubmitHandler: this.onSubmitHandler
			}
		});
	}
	onSubmitHandler() {
		this.setState({
			dropDownVisibility: true
		});
	}
	toggleClick(event) {
		const data = Object.assign({}, this.state.data);
		const newState = !this.state.active;
		this.setState({
			active: newState,
			...data,
			dropDownVisibility: false
		});
		const title = this.state.active
			? this.props.data.headerData.title
			: advSearchComponentStyles.constData.bllingAddressTitle;
		const headerData = {
			...this.props.data.headerData,
			title
		};
		this.delegateHandler(advSearchComponentStyles.actions.setHeaderData, headerData, validateFunArgs);
	}
	render() {
		return (
			<div>
				<AddressComponent data={this.state.ChildDropdownData} status={this.state.active} />
			</div>
		);
	}
}

ExtendForm.propTypes = {
	data: PropTypes.shape({
		contentData: PropTypes.shape({
			extendedForm: PropTypes.arrayOf(predefinedPropTypes.component.isRequired).isRequired,
			formdata: PropTypes.arrayOf(predefinedPropTypes.component.isRequired).isRequired,
			link: PropTypes.arrayOf(PropTypes.shape({ text: PropTypes.string })).isRequired
		}),
		setContentData: PropTypes.func.isRequired,
		headerData: PropTypes.shape({
			title: PropTypes.string.isRequired
		}).isRequired,
		setHeaderData: PropTypes.func.isRequired
	})
};
export default ExtendForm;
