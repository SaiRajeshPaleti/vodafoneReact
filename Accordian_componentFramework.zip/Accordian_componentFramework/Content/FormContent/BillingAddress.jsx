import React from 'react';
import PropTypes from 'prop-types';
import { predefinedPropTypes } from '../../Utilities/Utility';
import ComponetFactory from './ComponentFactory';
import advSearchComponentStyles from '../../DefData/FormBodyDefData-Props';

const BillingAddress = (props) => {
	return (
		<div className={advSearchComponentStyles.constStyles.contentData}>
			{props.data.contentData.extendedForm.map((componentData, index) => (
				<div key={index}>{ComponetFactory({ ...componentData })}</div>
			))}

			<div className={advSearchComponentStyles.constStyles.link}>
				{props.data.contentData.link.map((link, index) => (
					<div key={index}>
						<span onClick={props.data.onClick} className={advSearchComponentStyles.constStyles.toggleClick}>
							{link.text}
						</span>
					</div>
				))}
			</div>
		</div>
	);
};
export default BillingAddress;

BillingAddress.propTypes = {
	data: PropTypes.shape({
		contentData: PropTypes.shape({
			extendedForm: PropTypes.arrayOf(predefinedPropTypes.component.isRequired).isRequired,
			formdata: PropTypes.arrayOf(predefinedPropTypes.component.isRequired).isRequired,
			link: PropTypes.arrayOf(PropTypes.shape({ text: PropTypes.string })).isRequired
		}).isRequired,
		onClick: PropTypes.func.isRequired
	})
};
