import React from 'react';
import PropTypes from 'prop-types';
import { predefinedPropTypes } from '../../Utilities/Utility';
import ComponetFactory from './ComponentFactory';
import advSearchComponentStyles from '../../DefData/FormBodyDefData-Props';
import Button from 'vf-ent-ws-button';
import BaseComponent from 'vf-ent-ws-utilities';

class NewBillingAddress extends BaseComponent {
	constructor(props) {
		super(props);
		this.onCancel=this.onCancel.bind(this);
		this.cancel = this.renderCancel(props);	
		this.state={ showCancel: true};
	}
	
	onCancel(e) {
		this.setState({ showCancel: false},this.props.data.onClick(e));
	}
	
	renderCancel(props) {
		const onClick = this.onCancel;
		const dataButton = { ...props.data.contentData.cancelButton, onClick };
		return (
			<div className={advSearchComponentStyles.formRow}>
				<Button data={dataButton} />
			</div>
		);
	}
	render(){
		let props=this.props;
		return (
			<div className={advSearchComponentStyles.constStyles.contentHiddenData}>
				<div>
					{props.data.contentData.formdata.map((componentData, index) => (
						<div key={index}>
							{ComponetFactory({
								...componentData,
								dropDownVisibility: props.data.dropDownVisibility,
								onSubmitHandler: props.data.onSubmitHandler
							})}
						</div>
					))}
				</div>
				{this.state.showCancel ? this.cancel : ''}
			</div>
		);
	}
};


NewBillingAddress.propTypes = {
	data: PropTypes.shape({
		dropDownVisibility: PropTypes.bool.isRequired,
		onSubmitHandler: PropTypes.func.isRequired,
		contentData: PropTypes.shape({
			formdata: PropTypes.arrayOf(predefinedPropTypes.component.isRequired)
		})
	})
};
export default NewBillingAddress;