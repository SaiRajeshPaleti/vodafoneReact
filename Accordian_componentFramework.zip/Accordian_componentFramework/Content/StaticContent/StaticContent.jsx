import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import '../../Styles/StaticContent.css';
import contentStyles from '../../DefData/accordionDefData-Props';
import Label from 'vf-ent-ws-label';

export default class StaticContent extends PureComponent {
	render() {
		const { contentData } = this.props.data;
		const { constStyles, defaultStyles } = contentStyles;
		return (
			<div className={constStyles.sum_catalogue_list_item}>
				<div>
					{contentData.map((compData, index) => {
						return (
							<div key={index} className={defaultStyles.belowSeperator}>
								<span className={defaultStyles.widthClass}>
									<Label data={compData.labelData} />
								</span>
								<span className={defaultStyles.floatRight}>{compData.value}</span>
							</div>
						);
					})}
				</div>
			</div>
		);
	}
}

StaticContent.propTypes = {
	data: PropTypes.shape({
		contentData: PropTypes.arrayOf(
			PropTypes.shape({
				labelData: PropTypes.object.isRequired,
				value: PropTypes.string.isRequired
			}).isRequired
		).isRequired
	}).isRequired
};
