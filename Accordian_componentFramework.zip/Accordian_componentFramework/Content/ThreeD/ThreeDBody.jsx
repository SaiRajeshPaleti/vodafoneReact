import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import TextField from 'vf-ent-ws-textfield';
import contentStyles from '../../DefData/ThreeColumnAccordionDefData-Props';
import { getCurrency, getClonedObject, addPrices, getFormattedCurrency } from '../../Utilities/Utility';

export default class ThreeDBody extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			headerData: this.props.data.headerData,
			contentData: this.props.data.contentData,
			actualBandwidth: parseInt(this.props.data.contentData[0].actualBandwidth, 10)
		};
		this.getServiceCost = this.getServiceCost.bind(this);
		this.onChange = this.onChange.bind(this);
	}
	componentWillMount() {
		this.setProps(this.props);
	}
	componentWillReceiveProps(nextProps) {
		console.log(nextProps);
		this.setProps(nextProps);
	}
	setProps(props) {
		const textfieldProps = [];
		const actualBandwidth = parseInt(this.props.data.contentData[0].actualBandwidth, 10);
		props.data.contentData.map((item, index) => {
			textfieldProps.push({
				...item.textfield,
				value: item.bandwidth,
				onBlur: this.getServiceCost,
				onChange: this.onChange
			});
		});
		this.setState({
			textfieldProps,
			contentData: props.data.contentData,
			actualBandwidth
		});
	}
	onChange(event) {
		this.debugLog('event id:', event.id);
	}
	getServiceCost(event) {
		const textfieldProps = [ ...this.state.textfieldProps ];
		const actualBandwidth = this.state.actualBandwidth;
		let standard = parseInt(textfieldProps[0].value, 10);
		let enhanced = parseInt(textfieldProps[1].value, 10);
		let premium = parseInt(textfieldProps[2].value, 10);
		const headerData = getClonedObject(this.state.headerData);
		const contentData = [ ...this.state.contentData ];
		textfieldProps.map((bandWidth, index) => {
			if (event.target.id === bandWidth.id) {
				if (index === 1) {
					if (parseInt(event.target.value, 10) + premium <= actualBandwidth) {
						standard = actualBandwidth - parseInt(event.target.value, 10) - premium;
						enhanced = parseInt(event.target.value, 10);
					} else {
						enhanced = actualBandwidth - premium;
						standard = '0';
					}
					textfieldProps[index].value = enhanced ? enhanced : '0';
				}

				if (index === 2) {
					if (parseInt(event.target.value, 10) + enhanced <= actualBandwidth) {
						standard = actualBandwidth - parseInt(event.target.value, 10) - enhanced;
						premium = parseInt(event.target.value, 10);
					} else {
						premium = actualBandwidth - enhanced;
						standard = '0';
					}
					textfieldProps[2].value = premium ? premium : '0';
				}
			}
		});
		textfieldProps[0].value = standard ? standard : '0';

		let one_year_term = 0,
			two_year_term = 0;
		contentData.map((term, index) => {
			if (term.key === event.target.id) {
				term.one_year_term = getFormattedCurrency(textfieldProps[index].value) * 1.0;
				term.two_year_term = getFormattedCurrency(textfieldProps[index].value) * 2.0;
			} else {
				term.one_year_term = term.one_year_term;
				term.two_year_term = term.two_year_term;
			}
			one_year_term = addPrices([ one_year_term, term.one_year_term ]);
			two_year_term = addPrices([ two_year_term, term.two_year_term ]);
		});
		headerData.terms.one_year_term = one_year_term;
		headerData.terms.two_year_term = two_year_term;

		const charges = [ one_year_term, two_year_term ];
		contentData.map((term, index) => {
			term.bandwidth = textfieldProps[index].value;
		});

		this.setState({
			textfieldProps
			//contentData
		});
		this.props.data.setContentData && this.props.data.setContentData(contentData);
		this.props.data.setHeaderData && this.props.data.setHeaderData(headerData);
		this.props.data.setData && this.props.data.setData(charges, contentData);
	}

	render() {
		const { constStyles } = contentStyles;
		return (
			<div className={constStyles.catalogue_content}>
				<div className={constStyles.emp_section}>
					<div className={constStyles.user_roles_list_left}>&nbsp;</div>
					<div className={constStyles.acc_monthly_cost}>&nbsp;</div>
					<div className={constStyles.divide} />
					<div className={constStyles.acc_quarterly_cost}>&nbsp;</div>
				</div>
				{this.state.contentData.map((item, index) => {
					return (
						<React.Fragment key={index}>
							<div className={constStyles.cos_catalogue_list_item} key={index}>
								<div className={constStyles.user_roles_list_left}>
									<div className={constStyles.inputEntry}>{item.type}</div>
									<div className={constStyles.cso_input}>
										<TextField data={this.state.textfieldProps[index]} />
									</div>
									<div className={constStyles.input_text}>{constStyles.Mbps}</div>
								</div>
								<div className={constStyles.acc_monthly_cost}>
									<div className={constStyles.cso_price}>
										<p>{getFormattedCurrency(item.one_year_term)}</p>
									</div>
								</div>
								<div className={constStyles.divide} />
								<div className={constStyles.acc_quarterly_cost}>
									<div className={constStyles.cso_price}>
										<p>{getFormattedCurrency(item.two_year_term)}</p>
									</div>
								</div>
							</div>
						</React.Fragment>
					);
				})}
			</div>
		);
	}
}

ThreeDBody.propTypes = {
	data: PropTypes.shape({
		contentData: PropTypes.arrayOf(
			PropTypes.shape({
				bandwidth: PropTypes.oneOfType([ PropTypes.number, PropTypes.string ]),
				one_year_term: PropTypes.string.isRequired,
				two_year_term: PropTypes.string.isRequired,
				type: PropTypes.string.isRequired,
				onSaveAddressHandler: PropTypes.func,
				'input-type': PropTypes.string,
				textfield: PropTypes.shape({
					componentType: PropTypes.string.isRequired,
					id: PropTypes.string.isRequired,
					name: PropTypes.string.isRequired,
					maxLength: PropTypes.number.isRequired,
					placeholder: PropTypes.string.isRequired
				}).isRequired
			}).isRequired
		).isRequired
	}).isRequired
};
