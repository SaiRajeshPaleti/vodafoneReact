import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Button from 'vf-ent-ws-button';
import { addPrices, bearerPropTypes, validateFunArgs } from '../../Utilities/Utility';
import contentStyles from '../../DefData/BearerAccordionDefData-Props';
import { ExtraTitle, HeaderCharges, BearerExtraOptionsContainer } from './BearerExtraOptions';
//let accordionHeaderData = [];
export default class MSPBearerContent extends BaseComponent {
	static propTypes = {
		data: PropTypes.shape({
			contentData: bearerPropTypes.contentData.isRequired,
			headerData: bearerPropTypes.headerData.isRequired,
			selectionHandler: PropTypes.func,
			setPlan: PropTypes.func,
			setHeaderData: PropTypes.func
		}).isRequired
	};
	constructor(props) {
		super(props);
		this.state = {
			standardOptions: this.props.data.contentData.additionalServices.standardOptions,
			//	headerData: this.props.data.headerData,
			contentData: this.props.data.contentData,
			performanceTerms: [],
			selectedPlan: {},
			extraPlans: this.props.data.contentData.additionalServices.extraPlans
		};
		this.toggleStandardOptions = this.toggleStandardOptions.bind(this);
		this.selectionHandler = this.selectionHandler.bind(this);
		this.onPerformanceChange = this.onPerformanceChange.bind(this);
		//	this.setHeaderData = this.setHeaderData.bind(this);
		//accordionHeaderData = [ ...this.props.data.headerData.terms ];
	}
	componentWillMount() {
		this.setState({
			standardButtonData: {
				...this.props.data.contentData.buttons.standardButton,
				onClick: this.toggleStandardOptions,
				type: !this.state.standardOptions
					? contentStyles.defaultData.teritaryButton
					: contentStyles.defaultData.secondaryButton
			},
			extraButtonData: {
				...this.props.data.contentData.buttons.extraButton,
				onClick: this.toggleStandardOptions,
				type: this.state.standardOptions
					? contentStyles.defaultData.teritaryButton
					: contentStyles.defaultData.secondaryButton
			},
			extraOptionsProps: {
				...this.props.data.contentData,
				onClick: this.selectionHandler,
				onChange: this.onPerformanceChange
			},
			headerData: this.props.data.headerData,
			contentData: this.props.data.contentData
		});
	}
	componentWillReceiveProps(nextProps) {
		const status = nextProps.data.contentData.additionalServices.standardOptions;
		const performanceStatus = nextProps.data.contentData.performanceReportData.switchStatus;
		this.setState({
			extraOptionsProps: {
				...nextProps.data.contentData,
				onClick: this.selectionHandler,
				onChange: this.onPerformanceChange
			},
			performanceTerms: performanceStatus ? nextProps.data.contentData.performanceReportData.terms : [],
			standardButtonData: {
				...nextProps.data.contentData.buttons.standardButton,
				onClick: this.toggleStandardOptions,
				type: !status ? contentStyles.defaultData.teritaryButton : contentStyles.defaultData.secondaryButton
			},
			extraButtonData: {
				...nextProps.data.contentData.buttons.extraButton,
				onClick: this.toggleStandardOptions,
				type: status ? contentStyles.defaultData.teritaryButton : contentStyles.defaultData.secondaryButton
			},
			headerData: nextProps.data.headerData,
			contentData: nextProps.data.contentData,
			standardOptions: nextProps.data.contentData.additionalServices.standardOptions
		});
	}
	toggleStandardOptions = (e) => {
		console.log('this.state.extraButtonData', this.state.extraButtonData.id);
		const status = e.id !== this.state.extraButtonData.id;
		this.setState({
			standardOptions: status,
			standardButtonData: {
				...this.state.standardButtonData,
				type: !status ? contentStyles.defaultData.teritaryButton : contentStyles.defaultData.secondaryButton
			},
			extraButtonData: {
				...this.state.extraButtonData,
				type: status ? contentStyles.defaultData.teritaryButton : contentStyles.defaultData.secondaryButton
			}
		});
		const terms = this.state.contentData.additionalServices.standard;
		const extraPlans = this.state.contentData.additionalServices.extraPlans;
		let selectedTerm = {};
		extraPlans.map((term, index) => {
			if (term.checked) {
				selectedTerm = term;
			}
		});
		!status && this.selectionHandler(selectedTerm, status);
		status && this.selectionHandler({ terms }, status);
	};
	onPerformanceChange(performanceCharges, status) {
		// this.setState({
		// 	performanceTerms: performanceCharges
		// });
		const headerData = JSON.parse(JSON.stringify(this.state.headerData)); // Object.assign({}, this.state.headerData);
		const additionalData = JSON.parse(JSON.stringify(headerData.additionalData));
		const selectedPlan = JSON.parse(JSON.stringify(this.state.selectedPlan));
		const selectedTerms = [ ...selectedPlan.terms ];
		const contentData = { ...this.state.contentData };
		const performanceReportData = { ...contentData.performanceReportData };
		performanceReportData.switchStatus = status;
		let setPlan = {
			additionalSection: false,
			additionalData: '',
			terms: [ ...performanceCharges ]
		};
		contentData.performanceReportData = performanceReportData;

		if (status) {
			this.setState({
				performanceTerms: performanceCharges
			});

			if (selectedTerms) {
				setPlan.terms.map((term, index) => {
					setPlan.terms[index] = {
						onOffCharge: addPrices([ term.onOffCharge, selectedTerms[index].onOffCharge ]),
						rentalPerAnnumCharge: addPrices([
							term.rentalPerAnnumCharge,
							selectedTerms[index].rentalPerAnnumCharge
						])
					};
				});
				this.setHeaderData(setPlan);
			} else {
			}
			//uncomment
			if (this.state.performanceTerms) {
				performanceCharges.map((term, index) => {
					additionalData.terms[index] = {
						onOffCharge: addPrices([ term.onOffCharge, additionalData.terms[index].onOffCharge ]),
						rentalPerAnnumCharge: addPrices([
							term.rentalPerAnnumCharge,
							additionalData.terms[index].rentalPerAnnumCharge
						])
					};
				});

				//	additionalData = selectedPlan;
				headerData.additionalData = additionalData;
			}
		} else {
			this.setState({
				performanceTerms: {}
			});

			//	}
			//	} else {
			//	selectedPlan.additionalData = selectedPlan;
			//}

			// selectedPlan.additionalSection = true;

			// performanceCharges.map((term, index) => {
			// 	additionalData.terms[index] = {
			// 		onOffCharge: addPrices([ term.onOffCharge, additionalData.terms[index].onOffCharge ]),
			// 		rentalPerAnnumCharge: addPrices([
			// 			term.rentalPerAnnumCharge,
			// 			additionalData.terms[index].rentalPerAnnumCharge
			// 		])
			// 	};
			// });

			// }
			//selectedPlan.additionalData = selectedPlan;
			// 	this.state.performanceTerms.map((term, index) => {
			// 		selectedPlan.terms[index] = {
			// 			onOffCharge: selectedPlan.terms[index].onOffCharge - term.onOffCharge,
			// 			rentalPerAnnumCharge: selectedPlan.terms[index].rentalPerAnnumCharge - term.rentalPerAnnumCharge
			// 		};
			// 	});
			// 	selectedPlan.additionalData = selectedPlan;
			// }
			if (this.state.performanceTerms && selectedTerms) {
				this.state.performanceTerms.map((term, index) => {
					setPlan.terms[index] = {
						onOffCharge: selectedTerms[index].onOffCharge - term.onOffCharge,
						rentalPerAnnumCharge: selectedTerms[index].rentalPerAnnumCharge - term.rentalPerAnnumCharge
					};
				});
				this.setHeaderData(setPlan);
			} else if (this.state.performanceTerms) {
				this.state.performanceTerms.map((term, index) => {
					setPlan.terms[index] = {
						onOffCharge:
							selectedTerms[index].onOffCharge + setPlan.terms[index].onOffCharge - term.onOffCharge,
						rentalPerAnnumCharge:
							selectedTerms[index].rentalPerAnnumCharge +
							setPlan.terms[index].rentalPerAnnumCharge -
							term.rentalPerAnnumCharge
					};
				});
				this.setHeaderData(setPlan);
			} else {
				//setPlan = selectedPlan;
				//this.setHeaderData(setPlan);
			}
			//uncomment
			performanceCharges.map((term, index) => {
				additionalData.terms[index] = {
					onOffCharge: additionalData.terms[index].onOffCharge - term.onOffCharge,
					rentalPerAnnumCharge: additionalData.terms[index].rentalPerAnnumCharge - term.rentalPerAnnumCharge
				};
			});
			headerData.additionalData = additionalData;
		}
		this.props.data.setContentData && this.props.data.setContentData(contentData);
		this.props.data.setHeaderData &&
			this.delegateHandler(contentStyles.actions.setHeaderData, headerData, validateFunArgs);
		//this.props.data.setPlan && this.delegateHandler(contentStyles.actions.setPlan, selectedPlan, validateFunArgs);
		//this.delegateHandler('onChange', speedchargeItem, validateFunArgs);
	}
	selectionHandler(plan, status) {
		this.debugLog('plan', plan);
		let selectedPlan = JSON.parse(JSON.stringify(plan));
		const contentData = JSON.parse(JSON.stringify(this.state.contentData));
		const additionalServices = JSON.parse(JSON.stringify(contentData.additionalServices));
		if (status === true || status === false) {
			additionalServices.standardOptions = status;
		} else {
			additionalServices.standardOptions = false;
			status = false;
		}
		// if (status === false) {

		// 	const performanceReportData = { ...contentData.performanceReportData };
		// 	performanceReportData.switchStatus = status;
		// 	contentData.performanceReportData = performanceReportData;
		// }
		const headerData = JSON.parse(JSON.stringify(this.state.headerData));
		if (!status) {
			this.setState({
				selectedPlan
			});
			const extraPlans = [ ...additionalServices.extraPlans ];
			extraPlans.map((term, index) => {
				if (term.id === selectedPlan.id) {
					term.checked = true;
				} else {
					term.checked = false;
				}
			});
			additionalServices.extraPlans = extraPlans;
			contentData.additionalServices = additionalServices;
			headerData.additionalSection = true;
			const terms = [ ...selectedPlan.terms ];
			if (this.state.performanceTerms.length > 0) {
				terms.map((term, index) => {
					terms[index] = {
						onOffCharge: addPrices([ this.state.performanceTerms[index].onOffCharge, term.onOffCharge ]),
						rentalPerAnnumCharge: addPrices([
							this.state.performanceTerms[index].rentalPerAnnumCharge,
							term.rentalPerAnnumCharge
						])
					};
				});
				selectedPlan.terms = terms;
				headerData.additionalData = selectedPlan;
			} else {
				headerData.additionalData = selectedPlan;
			}
			this.props.data.setContentData && this.props.data.setContentData(contentData);
			this.props.data.setHeaderData &&
				this.delegateHandler(contentStyles.actions.setHeaderData, headerData, validateFunArgs);
			this.setHeaderData(selectedPlan);
			//this.props.data.setPlan && this.delegateHandler(contentStyles.actions.setPlan, plan, validateFunArgs);
			this.delegateHandler('onChange', selectedPlan, validateFunArgs);
		} else {
			headerData.additionalSection = false;
			headerData.additionalData = {};
			selectedPlan = {};
			contentData.additionalServices = additionalServices;
			const performanceReportData = { ...contentData.performanceReportData };
			performanceReportData.switchStatus = false;
			contentData.performanceReportData = performanceReportData;
			this.setState({
				performanceTerms: []
			});
			this.props.data.setContentData && this.props.data.setContentData(contentData);
			this.delegateHandler(contentStyles.actions.setHeaderData, headerData, validateFunArgs);
			//this.setHeaderData(headerData);
			this.props.data.setPlan && this.delegateHandler(contentStyles.actions.setPlan, headerData, validateFunArgs);
			this.delegateHandler('onChange', selectedPlan, validateFunArgs);
		}
	}

	setHeaderData(plan) {
		let headerData = {
			additionalSection: false,
			additionalData: {
				terms: []
			}
		};
		if (plan.terms) {
			headerData.additionalSection = true;
			headerData.additionalData.terms = plan.terms;
		}
		this.delegateHandler(contentStyles.actions.setPlan, headerData, validateFunArgs);
	}
	render() {
		const { constStyles, constData } = contentStyles;
		const { additionalServices } = this.props.data.contentData;
		return (
			<React.Fragment>
				<div className={constStyles.defaultSelectedOption}>
					<div className={constStyles.bearerOptionlist}>
						<div className={constStyles.requestSelectionBlock}>
							<div className={constStyles.requestSelectionBtnsParent}>
								<div className={constStyles.requestSelectionBtns}>
									<div className="bearerTitle">{constData.bearerOptions}</div>
									<div className={constStyles.buttonstyle}>
										<Button data={this.state.standardButtonData} />
										<Button data={this.state.extraButtonData} />
									</div>
									<ExtraTitle
										data={this.props.data.contentData.heading}
										status={this.state.standardOptions}
									/>
								</div>
							</div>
						</div>
						<div className={constStyles.itemMonthlyCost}>
							<HeaderCharges data={additionalServices.standard[0]} status={!this.state.standardOptions} />
						</div>
						<div className={constStyles.divide} />
						<div className={constStyles.itemQuarterlyCost}>
							<HeaderCharges data={additionalServices.standard[1]} status={!this.state.standardOptions} />
						</div>
					</div>
				</div>
				<BearerExtraOptionsContainer data={this.state.extraOptionsProps} status={this.state.standardOptions} />
			</React.Fragment>
		);
	}
}
