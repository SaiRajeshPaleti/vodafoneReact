// import React from 'react';
// import PropTypes from 'prop-types';
// import BaseComponent from 'vf-ent-ws-utilities';
// import { predefinedPropTypes, ConditionalPrice, validateFunArgs } from '../../Utilities/Utility';
// import listStyles from '../../DefData/BearerAccordionDefData-Props';
// import RadioButton from 'vf-ent-ws-radiobutton';
// import TableContent from '../MultiTable/TableContent'
// export default class BearerOptionListItem extends BaseComponent {
// 	static propTypes = {
// 		data: PropTypes.shape({
// 			extraList: PropTypes.arrayOf(
// 				PropTypes.shape({
// 					charges: PropTypes.arrayOf(predefinedPropTypes.plan)
// 				})
// 			).isRequired,
// 			onClick: PropTypes.func
// 		}).isRequired
// 	};

// 	render() {
// 		const { constStyles, defaultData, actions } = listStyles;
// 		return (
// 			<React.Fragment>
// 				{this.props.data.extraList.map((listItem, index) => {
// 					const radioData = {
// 						name: defaultData.radioButtonName,
// 						id: listItem.id,
// 						tooltip: listItem.tooltip,
// 						displayValue: listItem.portName,
// 						onChange: () => this.delegateHandler(actions.onClick, listItem, validateFunArgs)
// 					};

// 					return (
// 						// <div className={constStyles.bearerCatalogueListItem} key={index}>
// 						// 	<div className={constStyles.accordionHeadLeftPerfReport}>
// 						// 		<span className={constStyles.selectOption}>
// 						// 			<RadioButton data={radioData} />
// 						// 		</span>
// 						// 	</div>
// 						// 	<div className={constStyles.accMonthlyCost}>
// 						// 		<div className={constStyles.monthlyChargesExtraList}>
// 						// 			<ConditionalPrice status price={listItem.terms[0].onOffCharge} />
// 						// 		</div>
// 						// 		<div className={constStyles.selectRightOptionsList}>
// 						// 			<ConditionalPrice status price={listItem.terms[0].rentalPerAnnumCharge} />
// 						// 		</div>
// 						// 	</div>
// 						// 	<div className={constStyles.divide} />
// 						// 	<div className={constStyles.accQuarterlyCost}>
// 						// 		<div className={constStyles.quarterlyChargesExList}>
// 						// 			<ConditionalPrice status price={listItem.terms[1].onOffCharge} />
// 						// 		</div>
// 						// 		<div className={constStyles.quarterlyChargesRightExList}>
// 						// 			<ConditionalPrice status price={listItem.terms[1].rentalPerAnnumCharge} />
// 						// 		</div>
// 						// 	</div>
// 						// </div>
// 					);
// 				})}
// 			</React.Fragment>
// 		);
// 	}
// }
