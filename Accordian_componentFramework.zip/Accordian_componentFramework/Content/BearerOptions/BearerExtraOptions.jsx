import React from 'react';
import CheckBox from 'vf-ent-ws-checkbox';
import contentStyles from '../../DefData/BearerAccordionDefData-Props';
import { ConditionalPrice } from '../../Utilities/Utility';
import BaseComponent from 'vf-ent-ws-utilities';
import Switch from 'vf-ent-ws-switch';
import { PerformanceReportList } from './PerformanceReportList';
//import BearerOptionListItem from './BearerOptionListItem';
import TableContent from '../MultiTable/TableContent';
export default class BearerExtraOptions extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			performanceStatus: this.props.data.performanceReportData.switchStatus,
			performanceprops: this.props.data.performanceReportData.terms,
			extraPlans: this.props.data.additionalServices.extraPlans
		};
		this.togglePerformaceReport = this.togglePerformaceReport.bind(this);
	}
	togglePerformaceReport(status) {
		this.setState({
			performanceStatus: status,
			status: !status
		});
		this.props.data.onChange(this.state.performanceprops, status);
	}
	componentWillMount() {
	}
	componentWillReceiveProps(nextProps) {
		this.setState({
			performanceStatus: nextProps.data.performanceReportData.switchStatus,
			performanceprops: nextProps.data.performanceReportData.terms,
			extraPlans: nextProps.data.additionalServices.extraPlans
		});
	}
	render() {
		const bererListItemProps = {
			plans: this.state.extraPlans,
			setData: this.props.data.onClick
		};
		const switchProps = {
			id: this.props.data.performanceReportData.id,
			mainClass: 'add_services_user_roles_list_right',
			name: this.props.data.performanceReportData.id,
			onClick: this.togglePerformaceReport
		};
		const performanceprops = {
			terms: this.state.performanceprops
		};
		return (
			<div className={contentStyles.constStyles.selectExtraOptions}>
				<div className={contentStyles.constStyles.accordionHead}>
					{/* <BearerOptionListItem data={bererListItemProps} /> */}
					<TableContent data={bererListItemProps} />
					<div className="add-services-catalogue-list-item">
						<div className="add_services_user_roles_list_left">
							{this.props.data.performanceReportData.title}
						</div>
						<Switch data={switchProps} />
					</div>
					{this.state.performanceStatus && <PerformanceReportList data={performanceprops} />}
				</div>
			</div>
		);
	}
}

export const BearerExtraOptionsContainer = (props) => {
	return !props.status && <BearerExtraOptions data={props.data} />;
};
export const ExtraTitle = (props) => {
	return (
		!props.status && (
			<div className={contentStyles.constStyles.extraPorts}>
				<strong>{props.data}</strong>
			</div>
		)
	);
};

export const HeaderCharges = (props) => {
	const styles = {
		oneOffCharge: !props.status
			? contentStyles.constStyles.listChargesQuarter
			: contentStyles.constStyles.extraListCharges,
		annumCharge: !props.status
			? contentStyles.constStyles.selectRightQuarter
			: contentStyles.constStyles.extraSelectRightQuarter
	};
	return (
		<React.Fragment>
			<div className={styles.oneOffCharge}>
				<p>{contentStyles.constData.bearerOneOffCharges}</p>
				<ConditionalPrice status={!props.status} price={props.data.onOffCharge} />
			</div>
			<div className={styles.annumCharge}>
				<p>{contentStyles.constData.bearerRentalAnnum}</p>
				<ConditionalPrice status={!props.status} price={props.data.rentalPerAnnumCharge} />
			</div>
		</React.Fragment>
	);
};
