import React from 'react';
import contentStyles from '../../DefData/BearerAccordionDefData-Props';
import { getFormattedCurrency } from '../../Utilities/Utility';
export const PerformanceReportList = (props) => {
	return (
		<div className="acc_catalogue_list_item">
			<div className="borderclass">
				<div className="user_roles_list_left" />
				<div className={contentStyles.accMonthlyCost}>
					<div className="speed-opt-monthlyprice">
						<p>{getFormattedCurrency(props.data.terms[0].onOffCharge)}</p>
					</div>
					<div className="speed-opt-monthlyrightprice">
						<p>{getFormattedCurrency(props.data.terms[0].rentalPerAnnumCharge)}</p>
					</div>
				</div>
				<div className="divide" />
				<div className="acc_quarterly_cost">
					<div className="speed-opt-quarterlyprice">
						<p>{getFormattedCurrency(props.data.terms[1].onOffCharge)}</p>
					</div>
					<div className="speed-opt-quarterlyrightprice">
						<p>{getFormattedCurrency(props.data.terms[1].rentalPerAnnumCharge)}</p>
					</div>
				</div>
			</div>
		</div>
	);
};
