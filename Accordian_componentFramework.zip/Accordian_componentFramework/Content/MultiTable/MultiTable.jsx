import PropTypes from 'prop-types';
import React from 'react';
import BaseComponent from 'vf-ent-ws-utilities';
import { multiTablePropTypes, validateFunArgs } from '../../Utilities/Utility';
import TableStyles from '../../DefData/MultiTablesAccordionDefData-Props';
import TableHead from './TableHead';
import TableContent from './TableContent';
import TableFooter from './TableFooter';

class MultiTable extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			active: false
		};
		this.toggleClick = this.toggleClick.bind(this);
		this.setData = this.setData.bind(this);
	}
	componentWillMount() {
		this.setState({
			contentData: this.props.data.contentData,
			headerData: this.props.data.headerData
		});
	}
	componentWillReceiveProps(nextProps) {
		const contentData = nextProps.data.contentData;
		console.log('contentData,.....', contentData);
		const headerData = nextProps.data.headerData;
		this.setState({
			contentData,
			headerData
		});
	}
	setData(SelectedPlan) {
		const headerData = Object.assign({}, this.state.headerData);
		if (SelectedPlan.displayAdditional) {
			headerData.additionalSection = true;
			headerData.additionalData = SelectedPlan;
		} else if (SelectedPlan.displayAdditional === null) {
			const bandwidth = SelectedPlan.bandwidth.split(' ');
			headerData.plan.accessSpeed = bandwidth[0];
			headerData.status = true;
			headerData.bandwidth = SelectedPlan.bandwidth;
			headerData.additionalSection
				? (headerData.additionalSection = true)
				: (headerData.additionalSection = false);
			SelectedPlan.terms.map((term, index) => {
				headerData.terms[index] = {
					onOffCharge: term.onOffCharge,
					rentalPerAnnumCharge: term.rentalPerAnnumCharge
				};
				return term;
			});
		} else {
			headerData.additionalSection = false;
		}

		this.props.data.setHeaderData
			? this.delegateHandler(TableStyles.actions.setHeaderData, headerData, validateFunArgs)
			: this.delegateHandler(TableStyles.actions.setPlan, headerData, validateFunArgs);
		this.delegateHandler('onChange', SelectedPlan, validateFunArgs);
	}
	toggleClick(event) {
		this.setState({
			active: !this.state.active
		});
	}
	render() {
		const { constData, constStyles } = TableStyles;
		return (
			<div className={constStyles.speed_section}>
				{this.state.contentData.map((data, index) => {
					const contentProps = {
						plans: data.plans,
						setData: this.setData,
						active: this.state.active
					};
					const footerProps = {
						isActive: this.state.active,
						footerData: constData.showmore,
						isShow: data.plans.length > 4
					};
					return (
						<React.Fragment key={index}>
							<TableHead data={data.heading} />
							<TableContent data={contentProps} />
							<div className={`${constStyles.subchevFooter}`} onClick={this.toggleClick}>
								<TableFooter data={footerProps} />
							</div>
						</React.Fragment>
					);
				})}
			</div>
		);
	}
}
export default MultiTable;
MultiTable.propTypes = {
	data: PropTypes.shape({
		setPlan: PropTypes.func,
		setHeaderData: PropTypes.func,
		headerData: multiTablePropTypes.headerData.isRequired,
		contentData: multiTablePropTypes.contentData.isRequired
	})
};
