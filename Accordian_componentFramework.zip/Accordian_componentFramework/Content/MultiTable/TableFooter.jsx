import React from 'react';
import PropTypes from 'prop-types';
import TableStyles from '../../DefData/MultiTablesAccordionDefData-Props';
import Icon from 'vf-ent-ws-svgicons';

const tableFooter = (props) => {
	return (
		props.data.isShow && (
			<div>
				<div>{!props.data.isActive ? props.data.footerData.show : props.data.footerData.hide}</div>
				<div className={TableStyles.defaultStyles.defalutChevron}>
					<span
						className={`${TableStyles.defaultStyles.iconClass} ${props.data.isActive &&
							TableStyles.defaultStyles.rotateClass}`}
					>
						<Icon name={TableStyles.defaultStyles.iconCode} />
					</span>
				</div>
			</div>
		)
	);
};
export default tableFooter;
tableFooter.propTypes = {
	data: PropTypes.shape({
		isShow: PropTypes.bool.isRequired,
		footerData: PropTypes.shape({
			show: PropTypes.string.isRequired,
			hide: PropTypes.string.isRequired
		}),
		isActive: PropTypes.bool.isRequired
	})
};
