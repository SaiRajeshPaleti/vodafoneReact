import PropTypes from 'prop-types';
import React from 'react';
import TheadStyles from '../../DefData/MultiTablesAccordionDefData-Props';

const TableHead = (props) => {
	const { constStyles } = TheadStyles;
	return (
		<div className={constStyles.acc_catalogue_list_item}>
			<div className={constStyles.user_roles_list_left}>
				<div className={constStyles.speed_options}>
					<strong>{props.data}</strong>
				</div>
			</div>
			<div className={constStyles.acc_monthly_cost} />
			<div className={constStyles.divide} />
			<div className={constStyles.acc_quaterly_cost} />
		</div>
	);
};

export default TableHead;

TableHead.propTypes = {
	data: PropTypes.string.isRequired
};
