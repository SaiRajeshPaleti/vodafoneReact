import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import contentStyles from '../../DefData/MultiTablesAccordionDefData-Props';
import RadioButton from 'vf-ent-ws-radiobutton';
import { getFormattedCurrency, predefinedPropTypes, validateFunArgs } from '../../Utilities/Utility';

class TableContent extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			plans: this.props.data.plans
			//	className:'acc_catalogue_list_item'
		};
		this.onChange = this.onChange.bind(this);
	}

	onChange(selectedPlan) {
		const plans = [ ...this.state.plans ];
		plans.map((plan, planIndex) => {
			plan.checked = selectedPlan.id === plan.id ? true : false;
			plan.className = plan.checked ? 'acc_catalogue_list_item selectedplan' : 'acc_catalogue_list_item';
			return plan;
		});
		this.setState({ plans });
		this.delegateHandler(contentStyles.actions.setData, selectedPlan, validateFunArgs);
	}
	componentWillMount() {
		const plans = [ ...this.props.data.plans ];
		this.setState({
			plans: plans.splice(0, 4)
		});
	}

	componentWillReceiveProps(nextProps) {
		const plans = [ ...nextProps.data.plans ];
		this.setState({
			plans: nextProps.data.active ? plans : plans.splice(0, 4)
		});
	}
	render() {
		const { constStyles } = contentStyles;
		return this.state.plans.map((item, index) => {
			const Data = {
				name: item.name,
				id: item.id,
				tooltip: item.tooltip,
				displayValue: item.bandwidth,
				checked: item.checked,
				onChange: (event) => this.onChange(item)
			};
			return (
				<div key={item.id} className={item.className}>
					<div className="borderclass">
						<div className={constStyles.user_roles_list_left}>
							<span className={constStyles.option_name}>
								<RadioButton data={Data} />
							</span>
						</div>
						<div className={constStyles.acc_monthly_cost}>
							<div className={constStyles.speed_opt_monthlyprice}>
								<p>{getFormattedCurrency(item.terms[0].onOffCharge ? item.terms[0].onOffCharge : 0)}</p>
							</div>
							<div className={constStyles.speed_opt_monthlyrightprice}>
								<p>
									{getFormattedCurrency(
										item.terms[0].rentalPerAnnumCharge ? item.terms[0].rentalPerAnnumCharge : 0
									)}
								</p>
							</div>
						</div>

						<div className={constStyles.divide} />
						<div className={constStyles.acc_quaterly_cost}>
							<div className={constStyles.speed_opt_quarterlyprice}>
								<p>{getFormattedCurrency(item.terms[1].onOffCharge ? item.terms[1].onOffCharge : 0)}</p>
							</div>
							<div className={constStyles.speed_opt_quarterlyrightprice}>
								<p>
									{' '}
									{getFormattedCurrency(
										item.terms[1].rentalPerAnnumCharge ? item.terms[1].rentalPerAnnumCharge : 0
									)}
								</p>
							</div>
						</div>
					</div>
				</div>
			);
		});
	}
}

export default TableContent;

TableContent.propTypes = {
	data: PropTypes.shape({
		setData: PropTypes.func.isRequired,
		plans: PropTypes.arrayOf(
			PropTypes.shape({
				bandwidth: PropTypes.string.isRequired,
				displayAdditional: PropTypes.oneOf([ null, true, false ]),
				charges: PropTypes.arrayOf(predefinedPropTypes.plan)
			})
		).isRequired
	})
};
