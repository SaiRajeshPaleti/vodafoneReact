import React, { PureComponent } from 'react';
import AccordionStyles from '../../DefData/accordionDefData-Props';
import PropTypes from 'prop-types';

export default class SimpleContent extends PureComponent {
	render() {
		return (
			<div>
				{this.props.data.contentData.map((data, index) => {
					return (
						<div key={index} className={AccordionStyles.constStyles.moreDetails}>
							<h3>{data.description}</h3>
							<p>{data.content}</p>
						</div>
					);
				})}
			</div>
		);
	}
}
SimpleContent.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		contentData: PropTypes.arrayOf(
			PropTypes.shape({
				content: PropTypes.string.isRequired,
				description: PropTypes.string.isRequired
			}).isRequired
		).isRequired
	}).isRequired
};
