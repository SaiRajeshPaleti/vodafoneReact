import React, { PureComponent } from 'react';
import RadioButton from 'vf-ent-ws-radiobutton';
import PropTypes from 'prop-types';

export default class RadioAccordionContent extends PureComponent {
	render() {
		return (
			<div>
				{this.props.data.contentData.map((label, index) => {
					return <RadioButton data={label} key={index} />;
				})}
			</div>
		);
	}
}
RadioAccordionContent.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		contentData: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				tooltip: PropTypes.string.isRequired,
				displayValue: PropTypes.string.isRequired,
				onChange: PropTypes.func.isRequired
			})
		)
	}).isRequired
};
