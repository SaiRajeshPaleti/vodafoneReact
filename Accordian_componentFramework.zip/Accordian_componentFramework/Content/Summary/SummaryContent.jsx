import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import AccordionStyles from '../../DefData/SummaryDefData-Props';
import { getFormattedCurrency } from '../../Utilities/Utility';
export default class SummaryAccordionContent extends PureComponent {
	constructor(props) {
		super(props);
		this.state = {};
	}
	render() {
		return (
			<div className={AccordionStyles.constStyles.content_section}>
				<div className={AccordionStyles.constStyles.catalogue_list}>
					{this.props.data.contentData.map((content, index) => {
						const { title, terms } = content;
						return (
							<div key={index} className={AccordionStyles.constStyles.catalogue_list_item}>
								<div className={AccordionStyles.constStyles.user_roles_list_left}>
									<h2>{title}</h2>
								</div>
								<Content data={terms} />
							</div>
						);
					})}
				</div>
			</div>
		);
	}
}

export const Content = (props) => {
	return (
		<React.Fragment>
			<div
				className={
					props.data[0].isActive ? (
						AccordionStyles.constStyles.active_monthly_cost
					) : (
						AccordionStyles.constStyles.monthly_cost
					)
				}
			>
				{getFormattedCurrency(props.data[0].cost)}
			</div>
			<div
				className={
					props.data[1].isActive ? (
						AccordionStyles.constStyles.active_quarterly_cost
					) : (
						AccordionStyles.constStyles.quarterly_cost
					)
				}
			>
				{getFormattedCurrency(props.data[1].cost)}
			</div>
			<div className={AccordionStyles.constStyles.noDiv}>&nbsp;</div>
		</React.Fragment>
	);
};
SummaryAccordionContent.propTypes = {
	data: PropTypes.shape({
		contentData: PropTypes.arrayOf(
			PropTypes.shape({
				title: PropTypes.string.isRequired,
				terms: PropTypes.arrayOf(
					PropTypes.shape({
						name: PropTypes.string.isRequired,
						cost: PropTypes.number.isRequired,
						isActive: PropTypes.bool.isRequired
					})
				)
			}).isRequired
		).isRequired
	})
};
