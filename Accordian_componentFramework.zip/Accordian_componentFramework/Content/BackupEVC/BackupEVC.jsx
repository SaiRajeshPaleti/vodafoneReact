import React from 'react';
import PropTypes from 'prop-types';
import Switch from 'vf-ent-ws-switch';
import TableHead from '../MultiTable/TableHead';
import ThreeDBody from '../ThreeD/ThreeDBody';
import BackupEVCHeader from './BackupEVCHeader';
import BaseComponent from 'vf-ent-ws-utilities';
export default class BackuoEVC extends BaseComponent {
	constructor(props) {
		super(props);
		this.toggleBackUpEvc = this.toggleBackUpEvc.bind(this);
	}

	toggleBackUpEvc(status) {
		this.debugLog(status);
	}
	componentWillMount() {
		this.setProps(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.setProps(nextProps);
	}
	setProps(props) {
		//const headerData = { ...props.data.headerData };
		const contentData = { ...props.data.contentData };
		const ThreeBodyProps = {
			contentData: props.data.contentData.classofService.contentData,
			headerData: props.data.headerData,
			setData: this.threeDSelector
		};
		const backupCharges = {
			charges: props.data.contentData.backupCharges
		};
		const title = props.data.contentData.classofService.title;
		this.setState({
			ThreeBodyProps,
			//headerData,
			title,
			contentData,
			backupCharges
		});
	}

	render() {
		return (
			<div>
				<div className="add-services-catalogue-list-item">
					<div className="add_services_user_roles_list_left">
						{this.props.data.contentData.switchProps.title}
					</div>
					<Switch data={this.props.data.contentData.switchProps} />
				</div>
				<BackupEVCHeader data={this.state.backupCharges} />
				<div className="content-section multiTable">
					<TableHead data={this.state.title} />
				</div>
				<ThreeDBody data={this.state.ThreeBodyProps} />
			</div>
		);
	}
}
