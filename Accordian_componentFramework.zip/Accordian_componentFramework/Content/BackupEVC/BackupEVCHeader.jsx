import React, { PureComponent } from 'react';
import ThreeColStyles from '../../DefData/BearerAccordionDefData-Props';
import { predefinedPropTypes, getTitlePrice, validateFunArgs } from '../../Utilities/Utility';

export default class BackupEVCHeader extends PureComponent {
	constructor(props) {
		super(props);
	}
	render() {
		const { constStyles, defaultStyles, defaultData, constData } = ThreeColStyles;
		return (
			<div className={constStyles.chevHead}>
				<div className={constStyles.accordionHead}>
					<div className={ThreeColStyles.constStyles.firstColumn}>
						<div className={ThreeColStyles.constStyles.iconSection} />
						<div className={constStyles.titleClass}>
							<span className={constStyles.accordionTitleLogo}>{this.props.data.charges.title}</span>
						</div>
					</div>

					<div className={constStyles.accMonthlyCost}>
						<div className={constStyles.accMonthlSiteAddr1}>
							<p>
								<span className={constStyles.monthTitle}>{constData.headinstallation}</span>
							</p>
						</div>
						<div className={constStyles.accMonthlSiteAddr2}>
							{getTitlePrice(
								constData.headRentalAnnum,
								this.props.data.charges.terms[0].rentalPerAnnumCharge,
								constStyles
							)}
						</div>
					</div>
					<div className={constStyles.divide} />
					<div className={constStyles.accQuarterlyCost}>
						<div className={constStyles.accMonthlSiteAddr1}>
							<p>
								<span className={constStyles.monthTitle}>{constData.headinstallation}</span>
							</p>
						</div>
						<div className={constStyles.accMonthlSiteAddr2}>
							{getTitlePrice(
								constData.headRentalAnnum,
								this.props.data.charges.terms[1].rentalPerAnnumCharge,
								constStyles
							)}
						</div>
					</div>
				</div>
			</div>
		);
	}
}
