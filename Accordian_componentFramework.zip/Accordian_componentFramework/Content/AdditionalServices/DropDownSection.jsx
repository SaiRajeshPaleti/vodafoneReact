import React from 'react';
import BaseComponent from 'vf-ent-ws-utilities';
import PropTypes from 'prop-types';
import AlertMessage from 'vf-ent-ws-alert-message';
import Label from 'vf-ent-ws-label';
import DropDownComponent from 'vf-ent-ws-simple-dropdown';

export default class DropDownSection extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			// showAlert: false
		};
		this.onChange = this.onChange.bind(this);
	}

	onChange(selectedObject) {
		this.props.setDropDown(selectedObject.value);
		// this.setState({ showAlert: true });
	}
	componentWillMount() {
		this.renderComponents(this.props.data);
	}
	renderComponents(props) {
		const dropDownData = props.dropDownData && {
			dropdown: {
				...props.dropDownData,
				onChange: this.onChange
			},
			labelData: props.labelData
		};
		const alertMessageData = props.alertMessageData && props.alertMessageData;

		this.setState({
			dropDownData,
			alertMessageData
		});
	}
	componentWillReceiveProps(nextProps) {
		this.renderComponents(nextProps.data);
	}
	render() {
		const { dropDownData, alertMessageData, labelData } = this.props.data;
		return (
			<div className="addServices_dropdown_section">
				<div className="addServices_alert">
					<AlertMessage data={this.state.alertMessageData} />
				</div>
				<div className="addServices_label">
					<Label data={this.state.dropDownData.labelData} />
				</div>
				<div className="addServices_dropDown">
					<DropDownComponent data={this.state.dropDownData.dropdown} />
				</div>
			</div>
		);
	}
}
