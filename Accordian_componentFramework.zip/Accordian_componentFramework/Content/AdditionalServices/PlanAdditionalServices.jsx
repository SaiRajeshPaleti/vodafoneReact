import React from 'react';
import PropTypes from 'prop-types';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';
import AdditionalServiceListItem from './AdditionalServiceListItem';

export const PlanAdditionalServices = (props) => {
	return (
		<React.Fragment>
			<div className={AdditionalServicesProps.constStyles.addServiceCatalogue}>
				<div className={AdditionalServicesProps.constStyles.addServicesRolesLeft}>
					<strong>{props.data.heading}</strong>
				</div>
			</div>
			{props.data.additionalServices.map((service, index) => {
				const contentProps = {
					service,
					selectionHandler: props.data.selectionHandler,
					setStatus: props.data.setStatus
				};
				return <AdditionalServiceListItem data={contentProps} key={index} />;
			})}
		</React.Fragment>
	);
};
export default PlanAdditionalServices;
PlanAdditionalServices.propTypes = {
	data: PropTypes.object
};
