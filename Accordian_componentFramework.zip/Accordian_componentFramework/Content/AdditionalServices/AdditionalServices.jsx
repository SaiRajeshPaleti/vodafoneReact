import React from 'react';
import BaseComponent from 'vf-ent-ws-utilities';
import PropTypes from 'prop-types';
import CheckBox from 'vf-ent-ws-checkbox';
//import CheckBox from '../../../CheckBox/checkBox';
import {
	getFormattedCurrency,
	validateFunArgs,
	getCalculateRouterCost,
	getCalculateAdditionalServicesData,
	getSelectedAdditionalServices,
	predefinedPropTypes,
	getClonedObject
} from '../../Utilities/Utility';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';
import AdditionalServiceRouter from './AdditionalServiceRouter';
import PlanAdditionalServices from './PlanAdditionalServices';
import DropDownSection from './DropDownSection';
export default class AdditionalServices extends BaseComponent {
	constructor(props) {
		super(props);
		this.toggleRouterRequired = this.toggleRouterRequired.bind(this);
		this.state = {
			routerCharges: {},
			managementCharges: {},
			domainCharges: [],
			routerCostDetails: props.data.contentData.routerModels.defaultRouterCost,
			type: 'rent'
			//routerModels: props.data.contentData.routerModels.ports
		};
		this.setDropDownValue = this.setDropDownValue.bind(this);
		this.updateRouterCost = this.updateRouterCost.bind(this);
		this.additionalServicesHandler = this.additionalServicesHandler.bind(this);
		this.routerSelectionHandler = this.routerSelectionHandler.bind(this);
		this.updateChildProps = this.updateChildProps.bind(this);
		this.setStatus = this.setStatus.bind(this);
		this.costCalculation = this.costCalculation.bind(this);
	}
	componentWillMount() {
		this.updateChildProps(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.updateChildProps(nextProps);
	}
	setStatus(status) {
		const contentData = getClonedObject(this.props.data.contentData);
		const additionalServices = contentData.additionalServices;
		console.log('type:status', status);
	}
	updateChildProps(props) {
		const planProps = {
			additionalServices: props.data.contentData.additionalServices,
			heading: props.data.contentData.heading,
			selectionHandler: this.additionalServicesHandler,
			setStatus: this.setStatus
		};
		this.setState({
			routerModelsData: {
				selectionHandler: this.routerSelectionHandler,
				routerModels: props.data.contentData.routerModels.ports,
				buttonsData: props.data.contentData.routerModels.buttons
			},
			routerRequired: props.data.contentData.routerModels.checkBoxContent.value,
			routerCostDetails: this.state.routerCostDetails,
			PlanAdditionalServices: props.data.contentData.additionalServices && (
				<PlanAdditionalServices data={planProps} />
			),
			DropDwonSection: props.data.contentData.dropdownSection && (
				<DropDownSection data={props.data.contentData.dropdownSection} setDropDown={this.setDropDownValue} />
			),
			additionalServices: props.data.contentData.additionalServices,
			checkBoxProps: {
				...props.data.contentData.routerModels.checkBoxContent,
				onChange: this.toggleRouterRequired
			}
		});
	}
	setDropDownValue(selectedDropDownValue) {
		const contentData = getClonedObject(this.props.data.contentData);
		const dropdownSection = contentData.dropdownSection;
		const dropDownData = dropdownSection.dropDownData;
		dropDownData.value = selectedDropDownValue;
		dropdownSection.dropDownData = dropDownData;
		contentData.dropdownSection = dropdownSection;
		this.props.data.setContentData(contentData);
	}
	toggleRouterRequired(e) {
		const contentData = getClonedObject(this.props.data.contentData);
		const routerModels = contentData.routerModels;
		const checkBoxContent = routerModels.checkBoxContent;
		checkBoxContent.value = e.value;
		routerModels.checkBoxContent = checkBoxContent;
		contentData.routerModels = routerModels;
		let routerCostObject = this.costCalculation(routerModels.ports, 'rent', e.value);
		//return false;
		// const checkBoxProps = { ...this.state.checkBoxProps };
		// checkBoxProps.checked = e.value;
		// this.setState({
		// 	routerRequired: e.value,
		// 	checkBoxProps
		// });
		this.setState({
			type: 'rent'
		});
		this.props.data.setContentData(contentData);
		this.updateHeaderData(routerCostObject, this.state.additionalServices, e.value);
	}

	updateHeaderData(routerPorts, additionalServicesData, status = true) {
		// const routerCostDetails = Object.assign({}, this.state.routerCostDetails);
		// routerPorts.map((port) => {
		// 	if (port.checked) {
		// 		port.installation.map((term, index) => {
		// 			const install = status ? term.install : 0;
		// 			const rentOrBuy = status ? term.rentOrBuy : 0;
		// 			routerCostDetails.terms[index] = {
		// 				name: term.name,
		// 				install,
		// 				rentOrBuy
		// 			};
		// 			return term;
		// 		});
		// 	}
		// 	this.setState({
		// 		routerCostDetails
		// 	});
		// 	return routerCostDetails;
		// });
		//const routerCostObject = getCalculateRouterCost(routerPorts, { ...routerCostDetails }, status);
		const additionalServices = getCalculateAdditionalServicesData(additionalServicesData);
		const updatedServicesData = getSelectedAdditionalServices(additionalServices, routerPorts);
		const headerData = {
			...this.props.data.headerData,
			additionalSection: updatedServicesData.status || status,
			additionalData: {
				...updatedServicesData,
				control: AdditionalServicesProps.constData.control,
				toggleRouterRequired: this.toggleRouterRequired
			}
		};
		// this.setState({
		// 	routerCostDetails
		// });
		this.delegateHandler(AdditionalServicesProps.actions.setHeaderData, headerData, validateFunArgs);
	}
	updateRouterCost(routerModels, status) {
		const routerCostDetails = getCalculateRouterCost(routerModels, { ...this.state.routerCostDetails }, status);
		this.setState({
			routerCostDetails
		});
		return routerCostDetails;
	}
	costCalculation(routerModels, type, status) {
		const routerCostDetails = Object.assign({}, this.state.routerCostDetails);
		routerModels.map((port) => {
			if (port.checked) {
				port.installation.map((term, index) => {
					const install = status ? term.install : 0;
					const rentOrBuy = status ? term.rentOrBuy : 0;
					routerCostDetails.terms[index] = {
						name: term.name,
						install,
						rentOrBuy
					};
					return term;
				});
			}

			return routerCostDetails;
		});
		const routerCostObject = getCalculateRouterCost(routerModels, { ...routerCostDetails }, status, type);
		this.setState({
			routerCostDetails,
			routerCostObject
		});
		return routerCostObject;
	}
	routerSelectionHandler(selectedItem) {
		const contentData = getClonedObject(this.props.data.contentData);
		const routerModels = contentData.routerModels;
		const ports = routerModels.ports;
		let routerCostObject = {};
		//const routerModelsData = { ...this.state.routerModelsData };

		if (selectedItem.id === 'buyButton') {
			routerCostObject = this.costCalculation(routerModels.ports, 'buy', this.state.routerRequired);
			this.setState({
				type: 'buy'
			});
			this.debugLog('buy button clicked');
		} else if (selectedItem.id === 'rentButton') {
			routerCostObject = this.costCalculation(routerModels.ports, 'rent', this.state.routerRequired);
			this.debugLog('rent button clicked');
			this.setState({
				type: 'rent'
			});
		} else {
			ports.map((port) => {
				port.checked = selectedItem.id === port.id;
				return port;
			});
			routerCostObject = this.costCalculation(routerModels.ports, this.state.type, this.state.routerRequired);
		}
		routerModels.ports = ports;
		contentData.routerModels = routerModels;
		// this.setState({
		// 	routerModelsData: routerModelsData
		// });
		//	return false;
		this.props.data.setContentData(contentData);
		this.updateHeaderData(routerCostObject, this.state.additionalServices, this.state.routerRequired);
	}
	additionalServicesHandler(selectedItem) {
		const contentData = getClonedObject(this.props.data.contentData);
		const additionalServices = contentData.additionalServices;
		const routerModels = contentData.routerModels;
		//const additionalServices = [ ...this.state.additionalServices ];
		additionalServices.map((listItem) => {
			if (listItem.id === selectedItem.name) {
				if (selectedItem.listStatus) {
					listItem.domains = selectedItem.domains;
					listItem.status = selectedItem.listStatus;
				} else {
					listItem.domains.map((domain, index) => {
						domain.value = 0;
						// domain.charges.map((term, index) => {
						// 	//console.log('term', term);
						// 	(term.onOffCharge = 0), (term.rentalPerAnnumCharge = 0);
						// });
					});
					listItem.status = selectedItem.listStatus;
				}
			}
			return listItem;
		});
		contentData.additionalServices = additionalServices;
		// this.setState({
		// 	additionalServices: additionalServices
		// });
		this.props.data.setContentData(contentData);
		const routerCostObject = this.costCalculation(routerModels.ports, this.state.type, this.state.routerRequired);
		this.updateHeaderData(routerCostObject, additionalServices, this.state.routerRequired);
	}
	render() {
		const classNames = AdditionalServicesProps.constStyles;
		return (
			<div className="additionalContainerSection">
				<div className={classNames.addServiceCatalogue}>
					<div className={classNames.dnsUserListLeft}>
						<CheckBox data={this.state.checkBoxProps} />
					</div>
					<div className={classNames.accMonthCost}>
						<div className={classNames.routerSiteAddress1}>
							<div className={classNames.title1}>{AdditionalServicesProps.constData.install}</div>
							<div className={classNames.price}>
								{getFormattedCurrency(this.state.routerCostDetails.terms[0].install)}
							</div>
						</div>
						<div className={classNames.routerSiteAddress2}>
							<div className={classNames.title1}>{AdditionalServicesProps.constData.rentBuy}</div>
							<div className={classNames.price}>
								{getFormattedCurrency(this.state.routerCostDetails.terms[0].rentOrBuy)}
							</div>
						</div>
					</div>
					<div className={classNames.divide} />
					<div className={classNames.accQuarterCost}>
						<div className={classNames.routerSiteAddress1}>
							<div className={classNames.title1}>{AdditionalServicesProps.constData.install}</div>
							<div className={classNames.price}>
								{getFormattedCurrency(this.state.routerCostDetails.terms[1].install)}
							</div>
						</div>
						<div className={classNames.routerSiteAddress2}>
							<div className={classNames.title1}>{AdditionalServicesProps.constData.rentBuy}</div>
							<div className={classNames.price}>
								{getFormattedCurrency(this.state.routerCostDetails.terms[1].rentOrBuy)}
							</div>
						</div>
					</div>
				</div>
				{this.state.routerRequired && <AdditionalServiceRouter data={this.state.routerModelsData} />}
				{this.state.DropDwonSection}
				{this.state.PlanAdditionalServices}
			</div>
		);
	}
}
AdditionalServices.propTypes = {
	data: PropTypes.shape({
		contentData: PropTypes.shape({
			additionalServices: PropTypes.arrayOf(
				PropTypes.shape({
					domains: PropTypes.arrayOf(
						PropTypes.shape({
							id: PropTypes.string.isRequired,
							name: PropTypes.string.isRequired,
							charges: PropTypes.arrayOf(predefinedPropTypes.plan).isRequired,
							value: PropTypes.number
						})
					),
					id: PropTypes.string.isRequired,
					notification: PropTypes.shape({
						messageBody: PropTypes.string.isRequired,
						messageTitle: PropTypes.string.isRequired
					}),
					title: PropTypes.string.isRequired
				})
			),
			heading: PropTypes.string,
			routerModels: PropTypes.shape({
				ports: PropTypes.arrayOf(
					PropTypes.shape({
						bandwidth: PropTypes.string.isRequired,
						checked: PropTypes.bool.isRequired,
						id: PropTypes.string.isRequired,
						name: PropTypes.string.isRequired,
						terms: PropTypes.arrayOf(predefinedPropTypes.plan).isRequired
					})
				).isRequired
			}).isRequired
		}).isRequired,
		headerData: PropTypes.shape({
			plan: PropTypes.shape({
				control: PropTypes.string,
				name: PropTypes.string.isRequired,
				speed: PropTypes.string.isRequired
			}).isRequired,
			terms: PropTypes.arrayOf(predefinedPropTypes.plan).isRequired,
			title: PropTypes.string.isRequired
		}).isRequired,
		setHeaderData: PropTypes.func.isRequired
	})
};
