import React from 'react';
import BaseComponent from 'vf-ent-ws-utilities';
import PropTypes from 'prop-types';
import CheckBox from 'vf-ent-ws-checkbox';
import AlertMessage from 'vf-ent-ws-alert-message';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';
import DomainListItem from './DomainListItem';
import { sendBackData } from '../../Utilities/Utility';

export default class ContentAdditionalServices extends BaseComponent {
	constructor(props) {
		super(props);
		this.handleInputChange = this.handleInputChange.bind(this);
		this.updateProps = this.updateProps.bind(this);
		this.mailRelay = this.mailRelay.bind(this);
	}
	componentWillMount() {
		this.updateProps(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.updateProps(nextProps);
	}
	updateProps(props) {
		const notificationData = {
			...props.data.notification,
			...AdditionalServicesProps.constData.notification
		};
		this.setState({
			selectedDomainIndexes: Array(props.data.domains.length).fill(0),
			domainListProps: {
				handleInputChange: this.handleInputChange,
				domains: props.data.domains,
				type: props.data.type
			},
			notification: props.data.notification && <AlertMessage data={notificationData} />,
			mailRelay: {
				...props.data.checkBoxContent,
				onChange: this.mailRelay
			}
		});
	}
	mailRelay(e) {
		//console.log(this.props, ',this.props.data');
		this.props.data.setStatus('CheckBox', e.value);
	}
	handleInputType(list, selIndex) {
		console.log('i iam in handle Input Type');
		return list.domains.map((item, index) => {
			item.value = index === selIndex ? 1 : 0;
			return item;
		});
	}
	handleInputChange(evt, selIndex) {
		const selectedDomainIndexes = [ ...this.state.selectedDomainIndexes ];
		const domainListProps = { ...this.state.domainListProps };
		selectedDomainIndexes[selIndex] = evt.type === 'radio' ? 1 : parseInt(evt.value, 10);
		if (evt.type === 'radio') {
			this.handleInputType(domainListProps, selIndex);
		} else {
			domainListProps.domains[selIndex].value = parseInt(evt.value, 10) || 0;
		}
		this.setState({
			selectedDomainIndexes,
			domainListProps
		});
		const selectedDomains = [];
		selectedDomainIndexes.map((domainCount, index) => {
			if (domainCount > 0) {
				selectedDomains.push(domainListProps.domains[index]);
			}
			return domainCount;
		});
		//this.props.data.selectionHandler(domainListProps.domains);
		this.delegateHandler(AdditionalServicesProps.constData.selectionHandler, domainListProps.domains, sendBackData);
	}
	render() {
		return (
			this.props.data.domains.length > 0 && (
				<div className={AdditionalServicesProps.constStyles.addServiceCatalogue}>
					{this.state.notification}
					<DomainListItem data={this.state.domainListProps} />
					{this.props.data.mailRelay && <CheckBox data={this.state.mailRelay} />}
				</div>
			)
		);
	}
}
ContentAdditionalServices.propTypes = {
	data: PropTypes.object
};
