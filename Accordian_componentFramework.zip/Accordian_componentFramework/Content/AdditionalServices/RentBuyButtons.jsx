import React from 'react';
import PropTypes from 'prop-types';
import Button from 'vf-ent-ws-button';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';
import BaseComponent from 'vf-ent-ws-utilities';
import { sendBackData } from '../../Utilities/Utility';

export default class RentBuyButtons extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			standardOptions: true,
			rentButtonData: {
				...props.data.buttons.rentButton,
				onClick: (e) => this.toggleStandardOptions(e, true)
			},
			buyButtonData: {
				...props.data.buttons.buyButton,
				onClick: (e) => this.toggleStandardOptions(e, false)
			}
		};
		this.toggleStandardOptions = this.toggleStandardOptions.bind(this);
	}
	toggleStandardOptions = (e, type) => {
		this.setState({
			standardOptions: type,
			rentButtonData: {
				...this.state.rentButtonData,
				type: !type ? 'tertiary' : 'secondary'
			},
			buyButtonData: {
				...this.state.buyButtonData,
				type: type ? 'tertiary' : 'secondary'
			}
		});
		e.name = e.id;
		this.delegateHandler(AdditionalServicesProps.constData.onClick, e, sendBackData);
	};
	render() {
		const classNames = AdditionalServicesProps.constStyles;
		return (
			<div className={classNames.addServiceCatalogue}>
				<div className={classNames.userRolesListLeft}>
					<div className={classNames.btnBuySellOption}>
						<div className={classNames.requestSelectionBtns}>
							<span>
								<Button data={this.state.rentButtonData} />
							</span>
							<span>
								<Button data={this.state.buyButtonData} />
							</span>
						</div>
					</div>
				</div>
			</div>
		);
	}
}
RentBuyButtons.propTypes = {
	data: PropTypes.object
};
