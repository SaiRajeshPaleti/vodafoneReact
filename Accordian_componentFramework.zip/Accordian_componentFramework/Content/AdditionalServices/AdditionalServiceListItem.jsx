import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Switch from 'vf-ent-ws-switch';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';
import ContentAdditionalServices from './ContentAdditionalServices';
import { sendBackData } from '../../Utilities/Utility';

export default class AdditionalServiceListItem extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			showAdditionalServicesDomain: false,
			listName: this.props.data.service.id,
			domains: this.props.data.service.domains
		};
		this.handleDomainChanges = this.handleDomainChanges.bind(this);
		this.toggleServiceAdditionalDetails = this.toggleServiceAdditionalDetails.bind(this);
	}
	componentWillReceiveProps(nextProps) {
		this.setState({
			listName: nextProps.data.service.id,
			mailRelay: nextProps.data.service.mailRelay,
			status: nextProps.data.service.status,
			domains: nextProps.data.service.domains,
			checkBoxContent: nextProps.data.service.checkBoxContent
		});
	}
	toggleServiceAdditionalDetails(status) {
		this.setState({ showAdditionalServicesDomain: status });
		this.handleDomainChanges(this.state.domains, status);
	}
	handleDomainChanges(selectedDomains, status = this.state.showAdditionalServicesDomain) {
		const data = {
			domains: selectedDomains,
			name: this.state.listName,
			listStatus: status
		};
		this.delegateHandler(AdditionalServicesProps.constData.selectionHandler, data, sendBackData);
		//this.props.data.selectionHandler(data);
	}
	render() {
		const classNames = AdditionalServicesProps.constStyles;
		const switchProps = {
			id: this.props.data.service.id,
			mainClass: classNames.addServicesRolesRight,
			name: this.props.data.service.id,
			status: this.state.status,
			onClick: this.toggleServiceAdditionalDetails
		};
		const contentProps = {
			domains: this.state.domains,
			notification: this.props.data.service.notification,
			mailRelay: this.state.mailRelay,
			type: this.props.data.service.type,
			selectionHandler: this.handleDomainChanges,
			checkBoxContent: this.state.checkBoxContent,
			setStatus: this.props.data.setStatus
		};
		return (
			<React.Fragment>
				<div className={classNames.addServiceCatalogue}>
					<div className={classNames.addServicesRolesLeft}>{this.props.data.service.title}</div>
					<Switch data={switchProps} />
				</div>
				{this.state.showAdditionalServicesDomain && <ContentAdditionalServices data={contentProps} />}
			</React.Fragment>
		);
	}
}
AdditionalServiceListItem.propTypes = {
	data: PropTypes.object
};
