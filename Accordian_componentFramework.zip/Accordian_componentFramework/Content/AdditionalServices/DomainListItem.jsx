import React from 'react';
import PropTypes from 'prop-types';
import TextField from 'vf-ent-ws-textfield';
import RadioButton from 'vf-ent-ws-radiobutton';
import { getFormattedCurrency } from '../../Utilities/Utility';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';

export const DomainListItem = (props) => {
	const classNames = AdditionalServicesProps.constStyles;
	return props.data.domains.map((domain, index) => {
		const data = {
			...AdditionalServicesProps.constData.inputText,
			id: domain.id,
			value: domain.value,
			onChange: (e) => props.data.handleInputChange(e, index)
		};
		const domainData = {
			...domain,
			type: props.data.type
		};
		const radioData = {
			...AdditionalServicesProps.constData.radio,
			id: domain.id,
			value: domainData,
			displayValue: domain.name,
			onChange: (e) => props.data.handleInputChange(domainData, index)
		};
		return (
			<div className={classNames.asaCatalogueListItem} key={index}>
				<div className={classNames.userRolesListLeft}>
					<div>
						{props.data.type === 'radio' ? <RadioButton data={radioData} /> : <TextField data={data} />}
					</div>
					{props.data.type !== 'radio' && <div className={classNames.domainInputText}>{domain.name}</div>}
				</div>
				<div className={classNames.accMonthCost}>
					<div className={classNames.routerSiteAddress1}>
						{getFormattedCurrency(domain.value * domain.charges[0].onOffCharge)}
					</div>
					<div className={classNames.routerSiteAddress2}>
						{getFormattedCurrency(domain.value * domain.charges[0].rentalPerAnnumCharge)}
					</div>
				</div>
				<div className={classNames.divide} />
				<div className={classNames.accQuarterCost}>
					<div className={classNames.routerSiteAddress1}>
						{getFormattedCurrency(domain.value * domain.charges[1].onOffCharge)}
					</div>
					<div className={classNames.routerSiteAddress2}>
						{getFormattedCurrency(domain.value * domain.charges[1].rentalPerAnnumCharge)}
					</div>
				</div>
			</div>
		);
	});
};
export default DomainListItem;
DomainListItem.propTypes = {
	data: PropTypes.object
};
