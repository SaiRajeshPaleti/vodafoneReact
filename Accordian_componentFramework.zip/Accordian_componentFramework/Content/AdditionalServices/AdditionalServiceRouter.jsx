import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import AdditionalServicesProps from '../../DefData/AdditionalServicesDefData-Props';
import RentBuyButtons from './RentBuyButtons';
import TableContent from '../MultiTable/TableContent';
import { sendBackData } from '../../Utilities/Utility';

export default class AdditionalServiceRouter extends BaseComponent {
	constructor(props) {
		super(props);
		this.handlePortClick = this.handlePortClick.bind(this);
	}
	handlePortClick(plan) {
		const updatedItem = {
			...plan,
			type: AdditionalServicesProps.constData.radioButtonNames.portButton
		};
		this.delegateHandler(AdditionalServicesProps.constData.selectionHandler, updatedItem, sendBackData);
	}

	render() {
		const { routerModels } = this.props.data;
		const classNames = AdditionalServicesProps.constStyles;
		const contentProps = {
			plans: routerModels,
			setData: this.handlePortClick,
			active: false
		};

		const buttonProps = {
			buttons: this.props.data.buttonsData,
			onClick: this.props.data.selectionHandler
		};
		return (
			<div className="router-model">
				<div className={classNames.addServiceCatalogue}>
					<div className={classNames.dnsUserListLeft}>
						<div>
							<strong>{AdditionalServicesProps.constData.routerModel}</strong>
						</div>
					</div>
					<div className={classNames.serviceMonthPrice}>
						<div className={classNames.routerSiteAddress1}>
							<span className={classNames.price}>{AdditionalServicesProps.constData.maintenance}</span>
						</div>
						<div className={classNames.routerSiteAddress2}>
							<span className={classNames.price}>{AdditionalServicesProps.constData.management}</span>
						</div>
					</div>
					<div className={classNames.divide} />
					<div className={classNames.serviceMonthPrice}>
						<div className={classNames.routerSiteAddress1}>
							<span className={classNames.price}>{AdditionalServicesProps.constData.maintenance}</span>
						</div>
						<div className={classNames.routerSiteAddress2}>
							<span className={classNames.price}>{AdditionalServicesProps.constData.management}</span>
						</div>
					</div>
				</div>
				<TableContent data={contentProps} />
				<div className="buttonoptions">
					<RentBuyButtons data={buttonProps} />
				</div>
				<br />
				<br />
			</div>
		);
	}
}
AdditionalServiceRouter.propTypes = {
	data: PropTypes.object
};
