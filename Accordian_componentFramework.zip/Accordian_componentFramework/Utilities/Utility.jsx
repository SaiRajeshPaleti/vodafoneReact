import React from 'react';
import PropTypes from 'prop-types';
export function getFormattedCurrency(actualPrice) {
	return `£${parseFloat(actualPrice).toFixed(2)}`;
}

export function getCurrency(actualPrice) {
	return `£${parseFloat(actualPrice)}`;
}
export function addPrices(prices) {
	return parseFloat(
		prices
			.reduce(function(sum, price) {
				return sum + parseFloat(price);
			}, 0)
			.toFixed(2)
	);
}
export function getClonedObject(data) {
	return JSON.parse(JSON.stringify(data));
}
export function getTitlePrice(title, price, constStyles) {
	return (
		<React.Fragment>
			<p>
				<span className={constStyles.monthTitle}>{title}</span>
			</p>
			<p>
				<span className={constStyles.installPrice}>{getFormattedCurrency(price)}</span>
			</p>
		</React.Fragment>
	);
}
export const ConditionalPrice = (props) => {
	return props.status ? <p>{getFormattedCurrency(props.price)}</p> : '';
};

export const validateFunArgs = (arg) => {
	return arg;
};

export const getCalculateRouterCost = (routerModels, routerCost, status, type) => {
	//const routerModelsData = { ...routerModels };
	const routerCostDetails = { ...routerCost };
	const routerObject = { terms: [] };
	routerModels.map((port) => {
		if (port.checked) {
			if (type === 'rent') {
				port.terms.map((term, index) => {
					const install = status ? routerCostDetails.terms[index].install : 0;
					const rent = status
						? addPrices([
								term.rentalPerAnnumCharge,
								term.onOffCharge,
								routerCostDetails.terms[index].rentOrBuy
							])
						: 0;
					routerObject.terms[index] = {
						name: term.name,
						install,
						rent
					};
					return term;
				});
			} else if (type === 'buy') {
				port.terms.map((term, index) => {
					const install = status
						? addPrices([
								routerCostDetails.terms[index].install,
								routerCostDetails.terms[index].rentOrBuy
							])
						: 0;
					const rent = status ? addPrices([ term.rentalPerAnnumCharge, term.onOffCharge ]) : 0;
					routerObject.terms[index] = {
						name: term.name,
						install,
						rent
					};
					return term;
				});
			}
		}
		return port;
	});
	return routerObject;
};
export const getCalculateAdditionalServicesData = (additionalServices) => {
	const additionalServicesData = [
		{
			onOffCharge: 0,
			rentalPerAnnumCharge: 0
		},
		{
			onOffCharge: 0,
			rentalPerAnnumCharge: 0
		}
	];
	additionalServices &&
		additionalServices.map((service) => {
			service.domains.map((domain) => {
				domain.charges.map((charge, i) => {
					if (domain.value > 0) {
						const domainCount = service.status ? domain.value : 0;
						additionalServicesData[i].onOffCharge += parseInt(domainCount, 10) * charge.onOffCharge;
						additionalServicesData[i].rentalPerAnnumCharge +=
							parseInt(domainCount, 10) * charge.rentalPerAnnumCharge;
					}
					return charge;
				});
				return domain;
			});
			return service;
		});
	return additionalServicesData;
};
export const getSelectedAdditionalServices = (additionalServices, routerCostDetails) => {
	const data = {
		terms: [
			{
				onOffCharge: 0,
				rentalPerAnnumCharge: 0
			},
			{
				onOffCharge: 0,
				rentalPerAnnumCharge: 0
			}
		],
		status: false
	};
	let status = false;
	data.terms.map((term, index) => {
		term.onOffCharge = addPrices([ routerCostDetails.terms[index].install, additionalServices[index].onOffCharge ]);
		term.rentalPerAnnumCharge = addPrices([
			routerCostDetails.terms[index].rent,
			additionalServices[index].rentalPerAnnumCharge
		]);
		if (!status && (term.onOffCharge > 0 || term.rentalPerAnnumCharge > 0)) {
			status = true;
		}
		return term;
	});
	data.status = status;
	return data;
};

export const predefinedPropTypes = {
	plan: PropTypes.shape({
		name: PropTypes.string,
		onOffCharge: PropTypes.string,
		rentalPerAnnumCharge: PropTypes.string
	}),
	headerPlan: PropTypes.shape({
		control: PropTypes.string,
		name: PropTypes.string,
		speed: PropTypes.string
	}),
	component: PropTypes.shape({
		componentType: PropTypes.string.isRequired,
		componentData: PropTypes.object.isRequired
	})
};
export const bearerPropTypes = {
	headerData: PropTypes.shape({
		title: PropTypes.string,
		plan: predefinedPropTypes.headerPlan.isRequired,
		terms: PropTypes.arrayOf(predefinedPropTypes.plan),
		tooltip: PropTypes.string
	}),
	contentData: PropTypes.shape({
		additionalServices: PropTypes.shape({
			standard: PropTypes.arrayOf(predefinedPropTypes.plan),
			extra: PropTypes.arrayOf(
				PropTypes.shape({
					portName: PropTypes.string,
					charges: PropTypes.arrayOf(predefinedPropTypes.plan)
				})
			)
		}),
		heading: PropTypes.string.isRequired,
		checkbox: PropTypes.shape({
			checkBoxText: PropTypes.string
		})
	})
};
export const multiSelectionPropTypes = {
	headerData: PropTypes.shape({
		title: PropTypes.string.isRequired,
		plan: predefinedPropTypes.headerPlan.isRequired,
		terms: PropTypes.arrayOf(predefinedPropTypes.plan).isRequired,
		tooltip: PropTypes.string
	}),
	contentData: PropTypes.shape({
		speedoptions: PropTypes.shape({
			contentData: PropTypes.arrayOf(
				PropTypes.shape({
					heading: PropTypes.string.isRequired,
					name: PropTypes.string.isRequired,
					plans: PropTypes.arrayOf(
						PropTypes.shape({
							bandwidth: PropTypes.string.isRequired,
							checked: PropTypes.bool.isRequired,
							displayAdditional: PropTypes.oneOf([ PropTypes.bool, PropTypes.object ]),
							terms: PropTypes.arrayOf(predefinedPropTypes.plan)
						})
					)
				})
			).isRequired
		}).isRequired,
		contentData: bearerPropTypes.contentData.isRequired
	})
};
export const multiTablePropTypes = {
	contentData: PropTypes.arrayOf(
		PropTypes.shape({
			heading: PropTypes.string.isRequired,
			plans: PropTypes.arrayOf(
				PropTypes.shape({
					bandwidth: PropTypes.string.isRequired,
					checked: PropTypes.bool.isRequired,
					displayAdditional: PropTypes.oneOf[(null, true, false)],
					terms: PropTypes.arrayOf(predefinedPropTypes.plan.isRequired).isRequired
				}).isRequired
			).isRequired
		})
	),
	headerData: PropTypes.shape({
		plan: predefinedPropTypes.headerPlan.isRequired,
		terms: PropTypes.arrayOf(predefinedPropTypes.plan.isRequired).isRequired,
		title: PropTypes.string
	})
};

export function sendBackData(obj) {
	return obj;
}
