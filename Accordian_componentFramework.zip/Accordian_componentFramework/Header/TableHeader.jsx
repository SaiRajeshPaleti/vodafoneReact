import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import AccordionStyles from '../DefData/accordionDefData-Props';
import { constStyles } from '../DefData/TableHeaderDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import TableActionImage from 'vf-ent-ws-tableactionimage';

export class TableHeader extends BaseComponent {
	constructor(props) {
		super(props);
		this.onArrowClick = this.onArrowClick.bind(this);
		this.onProceedArrowClick = this.onProceedArrowClick.bind(this);
		this.toggleSelect = this.toggleSelect.bind(this);
		this.state = {
			active: false
		};
	}

	componentWillMount() {
		this.initTableHeader(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.initTableHeader(nextProps);
	}
	onArrowClick(event) {
		if (this.props.data.headerData.isBody) {
			this.delegateHandler(AccordionStyles.actions.toggleClick, event);
		}
	}
	getIcon(value) {
		let htmlValue = '';
		if (value) {
			htmlValue = (
				<span className={constStyles.iconTickWrapTrue}>
					<Icon name={constStyles.iconTick} />
				</span>
			);
		} else {
			htmlValue = <span className={constStyles.iconTickWrapFalse} />;
		}
		return htmlValue;
	}

	initTableHeader(props) {
		const headData = props.data.headerData;
		const isSelected = props.data.headerData.isSelected ? true : false;
		const getStatus = headData.content.find((obj) => obj.title === headData.statusKey)
			? headData.content.find((obj) => obj.title === headData.statusKey)
			: '';
		this.isSelectHidden = props.data.headerData.isSelectHidden ? { display: 'none' } : { display: 'inline-block' };
		this.tableHeaderBody = headData.content.map((data, index) => {
			if (data.isHidden != true) {
				const value = typeof data.value === 'boolean' ? this.getIcon(data.value) : <h1>{data.value}</h1>;
				return (
					<div class={constStyles.box}>
						<h4>{data.title}</h4>
						{value}
					</div>
				);
			}
		});
		this.tableActionComponent = props.data.headerData.tableActionData ? (
			<TableActionImage data={this.props.data.headerData.tableActionData} />
		) : (
			''
		);
		this.iconTitle = props.data.headerData.arrowTooltip ? props.data.headerData.arrowTooltip : '';
		this.iconClassName = `${AccordionStyles.defaultStyles.iconClass} ${props.data.active &&
			AccordionStyles.defaultStyles.rotateClass}`;
		this.mainClass = `${AccordionStyles.constStyles.chevHead} ${this.props.data.active &&
			AccordionStyles.constStyles.active}`;
		this.statusClass = getStatus.value ? constStyles.impact[getStatus.value.replace(/ /g, '')] : '';
		this.chevronClass = props.data.headerData.isBody
			? AccordionStyles.defaultStyles.iconCode
			: AccordionStyles.defaultStyles.iconCodeRight;

		this.setState({ active: isSelected });
	}

	onProceedArrowClick(event, data, actionParam) {
		const returnParams = {};
		if (actionParam && actionParam.headerParams) {
			actionParam.headerParams.map((headParam, headIndex) => {
				returnParams[headParam] = data[headParam];
				console.log('on arrow click is called', returnParams);
			});

			const result = { methodName: actionParam.methodName, params: returnParams };
			console.log('result before sending', result);
			this.props.data.headerData.headerActionData.actionHandler({
				methodName: actionParam.methodName,
				params: returnParams
			});
		} else {
			console.log(' :> Header action parsm are not configured ');
		}
	}

	toggleSelect(id) {
		const currentState = this.state.active;
		this.setState({ active: !currentState });
		// this.delegateHandler('selectButtonClick', id, this.props.data.selectButtonClick);
		this.props.data.selectButtonClick(id); // temp fix
	}

	render() {
		console.log(this.props.data.headerData.rowData);
		return (
			<div className={this.mainClass}>
				<div className={`${constStyles.wrap} ${this.statusClass}`}>
					<span
						style={this.isSelectHidden}
						id={this.props.data.headerData.id}
						onClick={() => this.toggleSelect(this.props.data.headerData.id)}
						className={this.state.active ? constStyles.btnSelected : constStyles.btn}
					>
						<Icon name={constStyles.tick} />
					</span>
					<div className={constStyles.acc_left}>
						<div className={constStyles.row}>
							<div className={constStyles.col}>{this.tableHeaderBody}</div>
						</div>
					</div>
					<div className={constStyles.tableAction}>{this.tableActionComponent}</div>
					<div
						onClick={(event) => {
							this.props.data.headerData.headerActionData
								? this.onProceedArrowClick(
										event,
										this.props.data.headerData.rowData,
										this.props.data.headerData.headerActionData
									)
								: this.onArrowClick(event);
						}}
						className={AccordionStyles.defaultStyles.defalutChevron}
					>
						<span className={this.iconClassName} title={this.iconTitle}>
							<Icon name={this.chevronClass} />
						</span>
						{/* <a
							href={
								this.props.data.headerData.url ? this.props.data.headerData.url : 'javascript:void(0)'
							}
						>
							<span className={this.iconClassName} title={this.iconTitle}>
								<Icon name={this.chevronClass} />
							</span>
						</a> */}
					</div>
				</div>
			</div>
		);
	}
}
export default TableHeader;
TableHeader.propTypes = {
	data: PropTypes.shape({})
};
