import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import CheckBox from 'vf-ent-ws-checkbox';
import { constStyles, defaultStyles, actions, defaultData } from '../DefData/ToggleTableDefData-Props';
import '../Styles/ToggleTable.css';
export class ToggleTable extends BaseComponent {
  constructor(props) {
    super(props);
    this.handleSelection = this.handleSelection.bind(this);
    this.updateProps = this.updateProps.bind(this);
  }
  componentWillMount() {
    this.updateProps(this.props);
  }
  componentWillReceiveProps(nextprops) {
    this.updateProps(nextprops);
  }
  handleSelection(e) {
    this.props.data.headerData.handleSelection(e);
  }
  updateProps(props) {
    this.setState({
      checkboxData: {
        ...defaultData.inputs.checkbox,
        id: props.data.contentData.id,
        value: props.data.headerData.value,
        onChange: this.handleSelection
      },
      iconClass: `${defaultStyles.iconClass} ${props.data.active && defaultStyles.rotateClass}`
    });
  }
  render() {
    return (
      <div
        id={this.props.data.headerData.clickId}
        className={`${constStyles.chevHead} ${this.props.data.active && constStyles.active}`}
      >
        <div className={constStyles.tableCheckboxItem}>
          <CheckBox data={this.state.checkboxData} />
        </div>
        <div className={constStyles.toggleTableAccordion}>
          <span className={`${constStyles[this.props.data.headerData.priority]} ${constStyles.statusBox}`}>
            {this.props.data.headerData.priority}
          </span>
          <div
            className={constStyles.toggleTableAccordionRow}
            onClick={(event) => this.delegateHandler(actions.toggleClick, event)}
          >
            <div className={constStyles.tableRowItem}>
              <h4>{this.props.data.headerData.title}</h4>
              <h1>{this.props.data.headerData.lastUpdate}</h1>
            </div>
            <div className={constStyles.tableRowItem}>{this.props.data.headerData.status}</div>
            <div className={constStyles.tableRowItem}>{this.props.data.headerData.dueTime}</div>
            <div className={constStyles.tableRowItem}>
              <div className={defaultStyles.defalutChevron}>
                <span className={this.state.iconClass}>
                  <Icon name={defaultStyles.iconCode} />
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default ToggleTable;
ToggleTable.propTypes = {
  data: PropTypes.shape({
    headerData: PropTypes.shape({
      title: PropTypes.string.isRequired,
      arrowTooltip: PropTypes.string,
      control: PropTypes.string,
      priority: PropTypes.string.isRequired,
      status: PropTypes.string.isRequired,
      dueTime: PropTypes.string.isRequired,
      lastUpdate: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired
    }).isRequired,
    active: PropTypes.bool.isRequired,
    toggleClick: PropTypes.func.isRequired
  })
};
