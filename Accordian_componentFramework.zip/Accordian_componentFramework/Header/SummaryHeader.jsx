import React from 'react';
import BaseComponent from 'vf-ent-ws-utilities';
import AccordionStyles from '../DefData/SummaryDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import LavaLamp from 'vf-ent-ws-lavalamp';
import PropTypes from 'prop-types';
import { getFormattedCurrency } from '../Utilities/Utility';
export class SummaryHeader extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			headerData: this.props.data.headerData,
			showIcon: false,
			headLeftClass: AccordionStyles.constStyles.accordionHead_noCorser
		};
		this.onChange = this.onChange.bind(this);
		this.setContentData = this.setContentData.bind(this);
	}
	componentWillMount() {
		const headerData = Object.assign({}, this.props.data.headerData);
		const content = this.props.data.contentData;
		var monthcost = headerData.terms[0].cost,
			yearcost = headerData.terms[1].cost;
		content.contentData.length > 0 &&
			content.contentData.map((options, index) => {
				monthcost = monthcost + options.terms[0].cost;
				yearcost = yearcost + options.terms[1].cost;
			});
		headerData.terms[0].cost = monthcost;
		headerData.terms[1].cost = yearcost;
		if (!headerData.showIcon) {
			const onClick = this.props.data.toggleClick;
			const showIcon = true;

			this.setState({
				onClick,
				showIcon,
				headLeftClass: AccordionStyles.constStyles.accordionHead,
				headerData
			});
		}
	}

	onChange(tab) {
		const headerData = Object.assign({}, this.state.headerData);
		const terms = [ ...headerData.terms ];
		terms.map((term, index) => {
			const isActive = term.name === tab.id ? true : false;
			terms[index].isActive = isActive;
			return term;
		});
		headerData.terms = terms;
		this.setState({
			headerData
		});
		this.setContentData(tab);
		this.delegateHandler('getTab', tab, dataPassing);
		//this.props.data.headerData.lavalampdata.getTab(tab);
	}
	setContentData(tab) {
		const data = Object.assign({}, this.props.data.contentData);
		let contentData = [ ...data.contentData ];
		contentData.map((itemData, index) => {
			const terms = [ ...itemData.terms ];
			terms.map((term, termIndex) => {
				const isActive = term.name === tab.id ? true : false;
				term.isActive = isActive;
				terms[termIndex] = term;
				itemData.terms = terms;
				return term;
			});
			contentData[index] = itemData;
			return itemData;
		});
		data.contentData = contentData;
		this.props.data.setContentData(data);
	}
	componentWillReceiveProps(nextProps) {
		const headerData = Object.assign({}, nextProps.data.headerData);
		let onClick = '';
		let showIcon = '';
		if (!headerData.showIcon) {
			onClick = this.props.data.toggleClick;
			showIcon = true;
		}
		this.setState({
			headerData: nextProps.data.headerData,
			contentData: nextProps.data.contentData,
			onClick,
			showIcon
		});
	}

	render() {
		const { title, terms, lavalampdata } = this.state.headerData;
		const data = { ...lavalampdata, onChange: this.onChange };
		return (
			<div className={`${AccordionStyles.constStyles.summary_accordion_head}`}>
				{this.state.showIcon && (
					<div className={AccordionStyles.constStyles.sum_accordion_head_left}>
						<div className={AccordionStyles.constStyles.user_roles_list_left}>
							<div className={AccordionStyles.constStyles.summary_titleClass}>&nbsp;</div>
						</div>
						<div className={AccordionStyles.constStyles.accordian__lavalamp}>
							<LavaLamp data={data} />
						</div>
						<div className={AccordionStyles.constStyles.noDiv}>&nbsp;</div>
					</div>
				)}
				<div>
					<div className={this.state.headLeftClass} onClick={this.state.onClick}>
						<div className={AccordionStyles.constStyles.user_roles_list_left}>
							<div className={AccordionStyles.constStyles.summary_titleClass}>{title}</div>
						</div>
						<HeaderContent data={terms} />

						<div className={AccordionStyles.defaultStyles.defalutChevron}>
							{this.state.showIcon && (
								<span
									className={`${AccordionStyles.defaultStyles.iconClass} ${this.props.data.active &&
										AccordionStyles.defaultStyles.rotateClass}`}
									title={
										this.props.data.headerData.arrowTooltip &&
										this.props.data.headerData.arrowTooltip
									}
								>
									<Icon name={AccordionStyles.defaultStyles.iconCode} />
								</span>
							)}
						</div>
					</div>
				</div>
			</div>
		);
	}
}

export const HeaderContent = (props) => {
	return (
		<React.Fragment>
			<div
				className={
					props.data[0].isActive ? (
						AccordionStyles.constStyles.active_monthly_cost
					) : (
						AccordionStyles.constStyles.monthly_cost
					)
				}
			>
				{getFormattedCurrency(props.data[0].cost)}
			</div>
			<div
				className={
					props.data[1].isActive ? (
						AccordionStyles.constStyles.active_quarterly_cost
					) : (
						AccordionStyles.constStyles.quarterly_cost
					)
				}
			>
				{getFormattedCurrency(props.data[1].cost)}
			</div>
		</React.Fragment>
	);
};

export default SummaryHeader;
export function dataPassing(obj) {
	return obj;
}
SummaryHeader.propTypes = {
	data: PropTypes.shape({
		headerData: PropTypes.shape({
			title: PropTypes.string.isRequired,
			arrowTooltip: PropTypes.string,
			showIcon: PropTypes.string,
			type: PropTypes.string.isRequired,
			terms: PropTypes.arrayOf(
				PropTypes.shape({
					name: PropTypes.string.isRequired,
					cost: PropTypes.number.isRequired,
					isActive: PropTypes.bool.isRequired
				})
			),
			lavalampdata: PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				type: PropTypes.string,
				activeTabKey: PropTypes.string.isRequired,
				tab: PropTypes.arrayOf({
					id: PropTypes.string,
					name: PropTypes.string,
					key: PropTypes.string.isRequired,
					value: PropTypes.string.isRequired
				}),
				onClick: PropTypes.func
			}).isRequired
		}).isRequired
	}).isRequired
};
