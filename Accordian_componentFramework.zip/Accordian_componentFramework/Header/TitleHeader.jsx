import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import AccordionStyles from '../DefData/accordionDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
export class TitleHeader extends BaseComponent {
	render() {
		return (
			<div id={this.props.data.headerData.clickId} className={`${AccordionStyles.constStyles.chevHead}`}>
				<div
					className={`${AccordionStyles.constStyles.accordionHead} ${AccordionStyles.constStyles.noPadding}`}
				>
					<div className={AccordionStyles.constStyles.titleClass}> {this.props.data.headerData.title}</div>
				</div>
			</div>
		);
	}
}
export default TitleHeader;
TitleHeader.propTypes = {
	data: PropTypes.shape({
		headerData: PropTypes.shape({
			title: PropTypes.string.isRequired,
			arrowTooltip: PropTypes.string
		}).isRequired,
		active: PropTypes.bool.isRequired
	})
};
