import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
//import RadioButton from 'vf-ent-ws-radiobutton';
import { predefinedPropTypes, getTitlePrice, validateFunArgs } from '../Utilities/Utility';
import ThreeColStyles from '../DefData/BearerAccordionDefData-Props';
import SimpleFooter from '../Footer/SimpleFooter';
import AdditionalSection from '../AdditionalSection';
import Button from 'vf-ent-ws-button';

export class ThreeColHeader extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			//checkstatus: false,
			footerComponent: '',
			toolTip: this.props.data.headerData.tooltip ? this.props.data.headerData.tooltip : '',
			additionalSection: '',
			radioData: ThreeColStyles.constData.radioData,
			buttonSection: '',
			spanClass: ThreeColStyles.defaultStyles.radioIconClass
		};
		//this.setCheckStatus = this.setCheckStatus.bind(this);
		this.removeAdditional = this.removeAdditional.bind(this);
		this.onChange = this.onChange.bind(this);
		this.deleteHeader = this.deleteHeader.bind(this);
		this.onClick = this.onClick.bind(this);
	}

	componentWillMount() {
		this.additionalSectionComponent(this.props);
		this.showFooterComponent(this.props.data.active);
	}
	componentWillReceiveProps(nextprops) {
		this.showFooterComponent(nextprops.data.active);
		this.setState({
			toolTip: nextprops.data.headerData.tooltip && nextprops.data.headerData.tooltip
		});
		this.additionalSectionComponent(nextprops);
	}
	additionalSectionComponent(props) {
		const { plan, buttonList } = props.data.headerData;
		if (plan.control === 'radio') {
			// const radioData = {
			// 	...this.state.radioData,
			// 	onChange: (event) => this.onChange(event, props.data.headerData.terms)
			// };
			const buttonData = buttonList;
			buttonData.map((Button, index) => {
				Button.onClick = () => this.onClick(Button.id);
				buttonData[index] = Button;
			});
			this.setState({
				//radioData,
				buttonData,
				spanClass: this.state.status
					? ThreeColStyles.defaultStyles.clickedRadioStyle
					: ThreeColStyles.defaultStyles.radioIconClass,
				icon: this.state.status && ThreeColStyles.defaultStyles.radio_icon
			});
		}
		const additionalProps = {
			additionalData: props.data.headerData.additionalData,
			removeAdditional: this.removeAdditional
		};
		const additionalSection = props.data.headerData.additionalSection && (
			<div className={ThreeColStyles.constStyles.accordionHead}>
				<AdditionalSection data={additionalProps} />
			</div>
		);
		this.setState({
			additionalSection
		});
	}
	showFooterComponent(status) {
		const footerData = {
			...this.props.data.headerData,
			active: status,
			onClick: this.props.data.toggleClick
		};
		this.setState({
			footerComponent: !status ? <SimpleFooter data={footerData} /> : ''
		});
	}
	onChange(event, headerValue) {
		this.delegateHandler(ThreeColStyles.actions.getHeaderValue, headerValue, validateFunArgs);
		// const radioData = { ...this.state.radioData };
		// radioData.checked = true;
		this.setState({
			//radioData,
			spanClass: ThreeColStyles.defaultStyles.clickedRadioStyle,
			icon: ThreeColStyles.defaultStyles.radio_icon,
			status: true
		});
	}
	deleteHeader(headerValue) {
		this.delegateHandler(ThreeColStyles.actions.getHeaderValue, headerValue, validateFunArgs);
	}
	onClick(selectedId) {
		this.debugLog('i am selcted Id', selectedId);
		const buttonData = [ ...this.state.buttonData ];
		buttonData.map((Button, index) => {
			Button.id === selectedId
				? ((Button.isIcon = true), (Button.type = 'buttonActive'))
				: ((Button.isIcon = false), (Button.type = 'tertiary'));
			buttonData[index] = Button;
		});
		this.setState({
			buttonData
		});
	}
	removeAdditional() {
		const headerData = Object.assign({}, this.props.data.headerData);
		headerData.additionalSection = false;
		headerData.additionalData.toggleRouterRequired &&
			headerData.additionalData.toggleRouterRequired({ value: false });
		this.props.data.toggleClick();
		headerData.additionalData = '';
		this.delegateHandler(ThreeColStyles.actions.setHeaderData, headerData, validateFunArgs);
		//const data = { ...this.props.data.contentData };
		//const contentData = [ ...data.contentData ];
		// //this.props.data.setInitialState();
		// if (contentData.additionalServices) {
		// 	const additionalServices = JSON.parse(JSON.stringify(contentData.additionalServices));
		// 	additionalServices.standardOptions = true;
		// 	contentData.additionalServices = additionalServices;
		// } else {
		// 	contentData.map((options, index) => {
		// 		const plans = [ ...options.plans ];
		// 		plans.map((plan, i) => {
		// 			plan.displayAdditional === true &&
		// 				((plan.checked = false), (plan.className = 'acc_catalogue_list_item'));
		// 			plan.displayAdditional === false &&
		// 				((plan.checked = true), (plan.className = 'acc_catalogue_list_item selectedplan'));
		// 			return plan;
		// 		});
		// 		return options;
		// 	});
		// }
		// data.contentData = contentData;
		// contentData.length > 0 && this.delegateHandler(ThreeColStyles.actions.setContentData, data, validateFunArgs);

		this.props.data.setInitialState();
	}
	render() {
		const { constStyles, defaultStyles, defaultData, constData } = ThreeColStyles;
		const { plan, terms } = this.props.data.headerData;
		return (
			<React.Fragment>
				<div className={constStyles.chevHead}>
					<div className={constStyles.accordionHead}>
						<div className={ThreeColStyles.constStyles.firstColumn}>
							<div className={ThreeColStyles.constStyles.iconSection}>
								{plan.control && (
									<div className={defaultStyles.iconHeader}>
										{plan.control === defaultData.deletetype && (
											<span
												className={defaultStyles.iconClass}
												title={this.state.toolTip}
												onClick={this.props.data.deleteFlag && (() => this.deleteHeader(terms))}
											>
												<Icon name={defaultStyles.delete_icon} />
											</span>
										)}
										{plan.control === defaultData.radiotype && (
											<span
												className={this.state.spanClass}
												title={this.state.toolTip}
												onClick={(event) => this.onChange(event, terms)}
											>
												<Icon name={this.state.icon} />
											</span>
										)}
									</div>
								)}
							</div>
							<div className={constStyles.titleClass}>
								<span className={constStyles.accordionTitleLogo}>{plan.name}</span>
								<span className={constStyles.accordionSubTitle}>
									{plan.accessSpeed + '/' + plan.bearerSpeed} Mbps
								</span>
							</div>
						</div>

						<div className={constStyles.accMonthlyCost}>
							<div className={constStyles.accMonthlSiteAddr1}>
								{getTitlePrice(constData.headinstallation, terms[0].onOffCharge, constStyles)}
							</div>
							<div className={constStyles.accMonthlSiteAddr2}>
								{getTitlePrice(constData.headRentalAnnum, terms[0].rentalPerAnnumCharge, constStyles)}
							</div>
						</div>
						<div className={constStyles.divide} />
						<div className={constStyles.accQuarterlyCost}>
							<div className={constStyles.accMonthlSiteAddr1}>
								{getTitlePrice(constData.headinstallation, terms[1].onOffCharge, constStyles)}
							</div>
							<div className={constStyles.accMonthlSiteAddr2}>
								{getTitlePrice(constData.headRentalAnnum, terms[1].rentalPerAnnumCharge, constStyles)}
							</div>
						</div>
					</div>
					{this.state.additionalSection}
					{this.state.status && <ButtonSection data={this.state.buttonData} />}
				</div>

				{this.state.footerComponent}
			</React.Fragment>
		);
	}
}
export default ThreeColHeader;

export const ButtonSection = (props) => {
	return (
		<div className={ThreeColStyles.constStyles.accordionHead}>
			<div className={ThreeColStyles.constStyles.firstColumn} />
			<div className={ThreeColStyles.constStyles.accMonthlyCost}>
				<div className={ThreeColStyles.constStyles.pull_center}>
					<Button data={props.data[0]} />
				</div>
			</div>
			<div className={ThreeColStyles.constStyles.divide} />
			<div className={ThreeColStyles.constStyles.accQuarterlyCost}>
				<div className={ThreeColStyles.constStyles.pull_center}>
					<Button data={props.data[1]} />
				</div>
			</div>
		</div>
	);
};

ThreeColHeader.propTypes = {
	data: PropTypes.shape({
		active: PropTypes.bool.isRequired,
		setHeaderData: PropTypes.func,
		headerData: PropTypes.shape({
			plan: predefinedPropTypes.headerPlan.isRequired,
			terms: PropTypes.arrayOf(predefinedPropTypes.plan).isRequired,
			title: PropTypes.string,
			tooltip: PropTypes.string
		}).isRequired,
		toggleClick: PropTypes.func.isRequired,
		setContentData: PropTypes.func
	})
};
