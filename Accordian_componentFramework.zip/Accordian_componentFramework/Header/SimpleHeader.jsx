import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import AccordionStyles from '../DefData/accordionDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
export class simpleAccordionHeader extends BaseComponent {
	render() {
		return (
			<div
				id={this.props.data.headerData.clickId}
				className={`${AccordionStyles.constStyles.chevHead} ${this.props.data.active &&
					AccordionStyles.constStyles.active}`}
				onClick={(event) => this.delegateHandler(AccordionStyles.actions.toggleClick, event)}
			>
				<div
					className={`${AccordionStyles.constStyles.accordionHead} ${AccordionStyles.constStyles.noPadding}`}
				>
					<div className={AccordionStyles.constStyles.titleClass}> {this.props.data.headerData.title}</div>
				</div>
				<div className={AccordionStyles.defaultStyles.defalutChevron}>
					{this.props.data.headerData.showIcon === true ? (
						<span
							className={`${AccordionStyles.defaultStyles.iconClass} ${this.props.data.active &&
								AccordionStyles.defaultStyles.rotateClass}`}
							title={
								this.props.data.headerData.arrowTooltip ? this.props.data.headerData.arrowTooltip : ''
							}
						>
							<Icon name={AccordionStyles.defaultStyles.iconCode} />
						</span>
					) : (
						<span
							className={`${AccordionStyles.defaultStyles.iconClass} ${this.props.data.active &&
								AccordionStyles.defaultStyles.rotateClass}`}
							title={
								this.props.data.headerData.arrowTooltip ? this.props.data.headerData.arrowTooltip : ''
							}
						>
							<Icon name={AccordionStyles.defaultStyles.iconCode} />
						</span>
					)}
				</div>
			</div>
		);
	}
}
export default simpleAccordionHeader;
simpleAccordionHeader.propTypes = {
	data: PropTypes.shape({
		headerData: PropTypes.shape({
			title: PropTypes.string.isRequired,
			arrowTooltip: PropTypes.string
		}).isRequired,
		active: PropTypes.bool.isRequired
	})
};
