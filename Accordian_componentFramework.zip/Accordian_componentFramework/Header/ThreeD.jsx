import React from 'react';
import PropTypes from 'prop-types';
import ThreeDStyles from '../DefData/ThreeColumnAccordionDefData-Props';
import SimpleHeader from './SimpleHeader';
import { getFormattedCurrency } from '../Utilities/Utility';

const ThreeD = (props) => {
	const { constStyles } = ThreeDStyles;
	const headerData = props.data.headerData.terms;
	return (
		<React.Fragment>
			<div className={constStyles.accordionHead}>
				<div className={constStyles.user_roles_list_left}>
					<div className={constStyles.cos_title_heading}>{headerData.title}</div>
				</div>
				<div className={constStyles.acc_monthly_cost}>
					<div className={constStyles.cso_address}>
						<p>
							<span className={constStyles.price}>{getFormattedCurrency(headerData.one_year_term)}</span>
						</p>
					</div>
				</div>

				<div className={constStyles.divide} />
				<div className={constStyles.acc_quarterly_cost}>
					<div className={constStyles.cso_address}>
						<p>
							<span className={constStyles.price}>{getFormattedCurrency(headerData.two_year_term)}</span>
						</p>
					</div>
				</div>
			</div>

			<div className="title-center">{!props.data.active && <SimpleHeader data={props.data} />}</div>
		</React.Fragment>
	);
};
export default ThreeD;

ThreeD.propTypes = {
	data: PropTypes.shape({
		active: PropTypes.bool,
		headerData: PropTypes.shape({
			title: PropTypes.string,
			terms: PropTypes.shape({
				title: PropTypes.string.isRequired,
				one_year_term: PropTypes.string.isRequired,
				two_year_term: PropTypes.string.isRequired
			}).isRequired
		}).isRequired
	})
};
