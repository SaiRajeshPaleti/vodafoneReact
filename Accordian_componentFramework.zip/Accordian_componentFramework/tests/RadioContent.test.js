import React from 'react';
import renderer from 'react-test-renderer';
import RadioContent from '../Content/RadioContent/RadioContent';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';

import Adapter from 'enzyme-adapter-react-16';
import RadioAccordionData from '../../../AppData/RadioAccordionData';

Enzyme.configure({ adapter: new Adapter() });

describe('<RadioAccordionContent />', function() {
	const props = RadioAccordionData;
	let wrapper;
	beforeEach(() => {
		wrapper = shallow(<RadioContent data={props.content} GetClickEvent={props.GetClickEvent} />);
	});

	it('RadioContent contains div ', () => {
		expect(wrapper.find('div').length).toBe(1);
	});
});
