import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

import advSearchComponentStyles from '../DefData/FormBodyDefData-Props';
import FormBodyContent from '../Content/FormContent/FormBodyContent';
import GenericFromAccordionData from '../../../AppData/GenericFormAccordionData';

Enzyme.configure({ adapter: new Adapter() });

describe('<FormBodyContent />', function() {
	const props = GenericFromAccordionData;
	let wrapper;
	beforeEach(() => {
		wrapper = mount(<FormBodyContent data={props.content} />);
	});

	it('Form Accordion contains Fields ', () => {
		expect(wrapper.find('.content_data').length).toBeGreaterThan(1);
	});
});
