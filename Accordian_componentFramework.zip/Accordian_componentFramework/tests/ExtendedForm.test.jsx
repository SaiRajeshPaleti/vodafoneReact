import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
// import Button from 'vf-ent-ws-button';

import advSearchComponentStyles from '../DefData/FormBodyDefData-Props';
import ExtendForm from '../Content/FormContent/ExtendForm';
import BillDetailsAccordionData from '../../../AppData/BillDetailsAccordionData';

Enzyme.configure({ adapter: new Adapter() });

describe('<ExtendForm />', function() {
	const props = BillDetailsAccordionData;
	let wrapper;
	let shallowWrapper;
	beforeEach(() => {
		wrapper = mount(<ExtendForm data={BillDetailsAccordionData.content} setHeaderData={(data) => {}} />);
	});

	//const componentHiddenDatas = BillDetailsAccordionData.Data.hidden_data;
	// console.log(componentHiddenDatas);

	it('Form Accordion contains content_data div ', () => {
		expect(wrapper.find('.content_data').length).toBe(1);
	});

	it('Form Accordion contains mode than one hidden Fields ', () => {
		expect(wrapper.find('.content_hidden_data').length).toBe(0);
	});

	it('event handler to be called on clicking button', () => {
		let active = wrapper.instance().state.active;
		let toggoleClick = wrapper.find('.toggle-click').simulate('click');
		expect(wrapper.instance().toggleClick).toHaveBeenCalled;
		expect(ExtendForm.handler).toHaveBeenCalled;
		expect(wrapper.instance().updateChildComponent).toHaveBeenCalled;
		setTimeout(() => {
			let active = wrapper.instance().state.active;
		}, 2);
	});

	it('Check the toggle Click', () => {
		shallowWrapper = shallow(
			<ExtendForm styleData={advSearchComponentStyles.className} contentData={BillDetailsAccordionData.Data} />
		);
		shallowWrapper.toggleClick;
	});

	it('Check the onSubmitHandler function', () => {
		//let event = {};
		expect(wrapper.instance().onSubmitHandler());
	});
});
