import React from 'react';
import StaticContent from '../Content/StaticContent/StaticContent';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import data from '../../../AppData/staticAccordionData';
Enzyme.configure({ adapter: new Adapter() });

describe('Static accordion', function () {
    let props, enzymeWrapper

    beforeEach(() => {
        props = data;
        enzymeWrapper = mount(<StaticContent data={data.content} />)

    });

    it('checks if all the received objects are mapped.', () => {
        expect(enzymeWrapper.find('.lineSep').length).toEqual(data.Data.length);
    });


});