import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Accordion from '../Accordion';
import BearerAccordionData from '../../../AppData/BearerAccordionData';

Enzyme.configure({ adapter: new Adapter() });

describe('<Accordion />', function() {
	let wrapper;
	beforeEach(() => {
		wrapper = mount(<Accordion data={BearerAccordionData} />);
	});
	it('Accordion  contains one main', () => {
		expect(wrapper.find('.accordion__item.accordion_common').length).toBe(1);
	});
	it('Should render footer', () => {
		expect(wrapper.find('.accordion__title').length).toBe(1);
	});
	it('Should trigger footer click', () => {
		const buttonclick = wrapper.find('.accordion__title').simulate('click');
		expect(wrapper.toggleClick).toHaveBeenCalled;
	});
	it('Should render extra button', () => {
		wrapper.find('.accordion__title').simulate('click');
		expect(wrapper.find('#extraButton').length).toBe(1);
	});
	it('Should render radio buttons ', () => {
		wrapper.find('.accordion__title').simulate('click');
		const { extra } = BearerAccordionData.content.contentData.additionalServices;
		wrapper.find('#extraButton').simulate('click');
		expect(wrapper.find('.select-extra-options').find('.select-option input[type="radio"]').length).toBe(
			extra.length
		);
	});

	it('Should trigger radio button click ', () => {
		wrapper.find('.accordion__title').simulate('click');
		wrapper.find('#extraButton').simulate('click');
		console.log(wrapper.find('.select-extra-options').find('.select-option input[type="radio"]').at(0));
		const buttonclick = wrapper
			.find('.select-extra-options')
			.find('.select-option input[type="radio"]')
			.at(0)
			.simulate('click');
		// const listData = {
		// 	portName: 'ADVA 206 14 Port',
		// 	charges: [
		// 		{
		// 			name: '1 Year term',
		// 			onOffCharge: 1250.0,
		// 			rentalPerAnnumCharge: 1990.0
		// 		},
		// 		{
		// 			name: '3 Years term',
		// 			onOffCharge: 0.0,
		// 			rentalPerAnnumCharge: 1840.0
		// 		}
		// 	]
		// };
		// expect(wrapper.instance().selectionHandler(listData)).toHaveBeenCalled;
		// expect(wrapper.instance().selectionHandler(listData)).toHaveBeenCalled;
	});
});
