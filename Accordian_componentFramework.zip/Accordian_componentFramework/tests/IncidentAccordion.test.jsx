import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Accordion from '../Accordion';
import IncidentAccordionData from '../../../AppData/IncidentAccordionData';

Enzyme.configure({ adapter: new Adapter() });

describe('<Accordion />', function() {
	let wrapper;
	beforeEach(() => {
		wrapper = mount(<Accordion data={IncidentAccordionData} />);
	});
	it('Accordion  contains one main', () => {
		expect(wrapper.find('.accordion__item.accordion_common').length).toBe(1);
	});
	it('Should render header', () => {
		expect(wrapper.find('.toggle-accordion-header').length).toBe(1);
	});
	it('Should render checkbox', () => {
		expect(wrapper.find('.table-checkbox-item').length).toBe(1);
	});
	it('Should trigger checkbox click', () => {
		wrapper.find('.table-checkbox-item .label_box input').simulate('change');
		expect(wrapper.handleSelection).toHaveBeenCalled;
	});
	it('Should render title', () => {
		expect(wrapper.find('.table-row-item h4').length).toBe(1);
	});
	it('Should trigger header click', () => {
		wrapper.find('.toggle-table-accordion-row').simulate('click');
		expect(wrapper.toggleClick).toHaveBeenCalled;
	});
	it('Should trigger componentWillRecieveProps', () => {
		const newProps = {
			...IncidentAccordionData,
			btnName: 'View'
		};
		wrapper.setProps({ data: newProps });
	});
});
