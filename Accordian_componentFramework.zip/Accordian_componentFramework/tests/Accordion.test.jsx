import React from 'react';
import renderer from 'react-test-renderer';
import Accordion from '../Accordion';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import AccordianData from '../../../AppData/simpleAccordionData';
Enzyme.configure({ adapter: new Adapter() });

describe('<Accordian />', function () {
	const props = AccordianData;
	let wrapper;
	beforeEach(() => {
		wrapper = mount(
			<Accordion data ={AccordianData}/>
		);
	});
	it('Accordion  contains one main', () => {
		expect(wrapper.find('.accordion_common').length).toBe(1);
	});
	
	it('Accordion functional component', () => {
		wrapper.instance().componentWillReceiveProps(props);
	});

	it('Accordion click handler event ', () => {
		let headclick = wrapper.find('.accordion__heading').simulate('click');
		expect(Accordion.toggleClick).toHaveBeenCalled;
	});
	it('Accordion click handler event ', () => {
		let headclick = wrapper.find('.accordion__heading').simulate('click');
		expect(Accordion.toggleClick).toHaveBeenCalled;
	});
});
