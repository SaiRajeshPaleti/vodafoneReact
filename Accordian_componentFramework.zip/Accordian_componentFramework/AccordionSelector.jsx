import SimpleHeader from './Header/SimpleHeader';
import ThreeColHeader from './Header/ThreeColHeader';
import ThreeD from './Header/ThreeD';
import SummaryHeader from './Header/SummaryHeader';
import TableHeader from './Header/TableHeader';
import TitleHeader from './Header/TitleHeader';
import ToggleTable from './Header/ToggleTable';

import RadioContent from './Content/RadioContent/RadioContent';
import MultiTable from './Content/MultiTable/MultiTable';
import FormBodyContent from './Content/FormContent/FormBodyContent';
import SimpleContent from './Content/SimpleContent/SimpleContent';
import MSPBearerContent from './Content/BearerOptions/MSPBearerContent';
import AdditionalServices from './Content/AdditionalServices/AdditionalServices';
import StaticContent from './Content/StaticContent/StaticContent';
import ThreeDBody from './Content/ThreeD/ThreeDBody';
import MultiSelectContent from './Content/MultiSelection/MultiSelectionContent';
import ExtendForm from './Content/FormContent/ExtendForm';
import SummaryContent from './Content/Summary/SummaryContent';
import BackupEVC from './Content/BackupEVC/BackupEVC';
import SimpleFooter from './Footer/SimpleFooter';
import TableFooter from './Footer/TableFooter';
import SimpleCenterFooter from './Footer/SimpleCenterFooter';

export const HeaderDictionary = {
	Simple: SimpleHeader,
	ThreeColumn: ThreeColHeader,
	ThreeDAccordion: ThreeD,
	Summary: SummaryHeader,
	Table: TableHeader,
	Title: TitleHeader,
	ToggleTable: ToggleTable
};

export const ContentDictionary = {
	Radio: RadioContent,
	FormContent: FormBodyContent,
	MultiTable: MultiTable,
	Simple: SimpleContent,
	BearerAccordion: MSPBearerContent,
	AdditionalServices: AdditionalServices,
	StaticAccordion: StaticContent,
	ThreeDAccordion: ThreeDBody,
	MultiSelect: MultiSelectContent,
	ExtendedFormAccordion: ExtendForm,
	SummaryContent: SummaryContent,
	BackupEVC: BackupEVC
};

export const FooterDictionary = {
	Simple: SimpleFooter,
	Table: TableFooter,
	Center: SimpleCenterFooter
};

const Dictionary = {};
const BearerOption = {};
const IsContentCalculationDone = {};

export function getHeader(type) {
	return HeaderDictionary[type];
}

export function getAccordianContent(type) {
	return ContentDictionary[type];
}

export function getAccordianFooter(type) {
	return FooterDictionary[type];
}

export function getIsShow(type) {
	return Dictionary[type] ? true : false;
}
export function getIsBearerOption(type) {
	return BearerOption[type] ? true : false;
}

export function getIsCaculated(type) {
	return IsContentCalculationDone[type] ? true : false;
}
