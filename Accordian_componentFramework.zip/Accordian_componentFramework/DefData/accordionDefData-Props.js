const accordianProps = {
	constStyles: {
		accordionItem: 'accordion__item accordion_common',
		active: 'active',
		chevHead: 'accordion__heading',
		accordionHead: 'accordion_head_left',
		noPadding: 'nopadding',
		titleClass: 'title_heading',
		accContent: 'accordion__content accordion__content--collapse',
		accActiveContent: 'accordion__content accordion__content--collapse active',
		accordion_footer_Active: 'accordion__title active',
		center_footer_active: 'accordion__title  center-heading active',
		defalutChevron: 'chevron_default show_services',
		moreDetails: 'moreDetailsContr',
		sum_catalogue_list_item: 'sum_catalogue_list_item static_content',
		user_roles_list_left: 'user_roles_list_left'
	},
	defaultStyles: {
		iconCode: 'chevron-down',
		iconCodeRight: 'chevron-right',
		iconClass: 'sprite__icon',
		rotateClass: 'rotate',
		iconRotateClass: 'sprite__icon rotate',
		defalutChevron: 'chevron_default show_services',

		//StaticAccordion
		bold: 'boldClass',
		belowSeperator: 'lineSep',
		floatRight: 'floatR',
		widthClass: 'fixWidth'
	},
	constData: {},
	defaultData: {},
	actions: {
		onClick: 'onClick',
		toggleClick: 'toggleClick'
	}
};
export default accordianProps;
