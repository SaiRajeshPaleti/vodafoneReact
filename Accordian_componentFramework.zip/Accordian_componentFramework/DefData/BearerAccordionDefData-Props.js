const BearerAccordianProps = {
	constStyles: {
		monthTitle: 'title-1',
		installPrice: 'Price',
		accordionHead: 'accordion_head_left header_bg_clr',
		firstColumn: 'firstcolumn',
		iconSection: 'icon-section',
		additionalSection: 'accordion_head_left section_color',
		chevHead: 'accordion__heading accordion__head_content',
		titleClass: 'user_roles_list_left',
		accordionTitleLogo: 'accordion-title-logo',
		accordionSubTitle: 'subtitle_heading',
		accMonthlyCost: 'acc_monthly_cost',
		accMonthlSiteAddr1: 'site-address1',
		accQuarterlyCost: 'acc_quarterly_cost',
		accMonthlSiteAddr2: 'site-address2',
		divide: 'divide',
		listChargesQuarter: 'list-charges',
		extraListCharges: 'extra-list-charges',
		selectRightQuarter: 'select-right',
		extraSelectRightQuarter: 'extra-select-right',
		defaultSelectedOption: 'default-selected-option content-section',
		bearerOptionlist: 'bearer-options-list',
		requestSelectionBlock: 'request_selection_block',
		requestSelectionBtnsParent: 'request_selection_btns_parent',
		requestSelectionBtns: 'request_selection_btns',
		buttonstyle: 'bearer_buttons',
		extraPorts: 'extra-ports',
		itemMonthlyCost: 'item_monthly_cost',
		itemQuarterlyCost: 'item_quarterly_cost',
		selectExtraOptions: 'select-extra-options',
		bearerCatalogueListItem: 'acc_catalogue_list_item',
		accordionHeadLeftPerfReport: 'user_roles_list_left',
		selectOption: 'select-option',
		monthlyChargesExtraList: 'monthly-charges',
		selectRightOptionsList: 'select-right-options',
		quarterlyChargesExList: 'quarterly-charges',
		quarterlyChargesRightExList: 'quarterly-charges-right',
		remove_head: 'remove_head_title',
		pull_center: 'pull_center'
	},
	defaultStyles: {
		iconHeader: 'icon-header',
		iconClass: 'sprite__icon',
		radioIconClass: 'service_button',
		clickedRadioStyle: 'service_button_selected service_button',
		delete_icon: 'icon-delete',
		radio_icon: 'tick-white'
	},
	constData: {
		buttons: {
			standardButton: {
				id: 'standardButton',
				name: 'Standard',
				type: 'secondary',
				buttonType: 'button'
			},
			extraButton: {
				id: 'extraButton',
				name: 'Extra',
				type: 'tertiary',
				buttonType: 'button'
			}
		},
		radioData: {
			id: 'radio_header_id',
			name: 'header_name',
			displayValue: '',
			checked: false
		},
		bearerOneOffCharges: 'One Off Charges',
		bearerRentalAnnum: 'Rental/Annum',
		addOneOffCharges: 'One Off Charges',
		addRentalAnnum: 'Rental/Annum',
		bearerOptions: 'Bearer Options',
		additionalServices: 'Additional services',
		remove: 'Remove',
		headinstallation: 'Installation',
		headRentalAnnum: 'Rental/Annum'
	},
	defaultData: {
		radioButtonName: 'extraOptions',
		deletetype: 'delete',
		radiotype: 'radio',
		secondaryButton: 'secondary',
		teritaryButton: 'tertiary'
	},
	actions: {
		onClick: 'onClick',
		setHeaderData: 'setHeaderData',
		setPlan: 'setPlan',
		getHeaderValue: 'getHeaderValue',
		setContentData: 'setContentData'
	}
};
export default BearerAccordianProps;
