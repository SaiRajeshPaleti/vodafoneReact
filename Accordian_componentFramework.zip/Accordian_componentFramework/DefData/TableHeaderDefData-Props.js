export const constStyles = {
	tick: 'service_button',
	acc_left: 'table_accordion_head_left',
	row: 'table_accordion_box_wrap',
	col: 'table_accordion_box_row',
	btnSelected: 'table_service_button table_service_button_selected',
	btn: 'table_service_button',
	box: 'table_accordion_box_cell',
	wrap: 'table_accordion impact_status',
	tick: 'tick-white',
	impact: {
		Expired: 'critical',
		Expiring: 'emergency',
		Expiringsoon: 'emergency',
		Active: 'normal',
		Completed: 'normal'
	},
	iconTickWrapTrue: 'wrap_true',
	iconTickWrapFalse: 'wrap_false',
	iconTick: 'tick-white',
	tableAction: 'chevron_default show_services table_action'
};
