export const constStyles = {
  accordionItem: 'accordion__item accordion_common',
  active: 'active',
  chevHead: 'toggle-accordion-header',
  toggleTableAccordion: 'toggle-table-accordion',
  P1: 'priority_1',
  P2: 'priority_2',
  P3: 'priority_3',
  P4: 'priority_4',
  statusBox: 'status_box',
  toggleTableAccordionRow: 'toggle-table-accordion-row',
  tableCheckboxItem: 'table-checkbox-item',
  tableRowItem: 'table-row-item',

  buttonWrapper: 'button_wrapper'
};
export const defaultStyles = {
  iconCode: 'chevron-down',
  iconClass: 'sprite__icon',
  rotateClass: 'rotate',
  defalutChevron: 'chevron_default show_services',
  button: 'button button--secondary'
};
export const actions = {
  toggleClick: 'toggleClick',
  method: 'method'
};
export const defaultData = {
  inputs: {
    checkbox: {
      id: '1',
      name: 'checkbox',
      tooltip: '',
      displayValue: ''
    }
  }
};
