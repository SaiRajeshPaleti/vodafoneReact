const AdditionalServicesProps = {
	constData: {
		buttons: {
			rentButton: {
				id: 'rentButton',
				name: 'Rent',
				type: 'secondary',
				buttonType: 'button'
			},
			buyButton: {
				id: 'buyButton',
				name: 'Buy',
				type: 'tertiary',
				buttonType: 'button'
			}
		},
		radioButtonNames: { portButton: 'routerPorts', managementButton: 'routerManagement' },
		inputText: {
			maxLength: 5,
			title: 'DNS count',
			name: 'domain'
		},
		radio: {
			id: 'radio',
			name: 'additionalService'
		},
		checkBox: {
			id: 'checkbox',
			name: 'mailRelay',
			displayValue: 'Mail relay'
		},
		notification: {
			type: 'info',
			name: 'info',
			id: 'l_i',
			lightBackground: true,
			arrowRequired: false,
			messageTitle: 'Quantity for domains between 0 to 10000',
			messageBody: `You should not keep all the domain quantity required as '0'. At least one domain quantity should have non zero value.`
		},
		defaultCost: 0.0,
		defaultTerms: {
			name: 'Default',
			terms: [
				{
					name: '1 Year term',
					onOffCharge: 0,
					rentalPerAnnumCharge: 0
				},
				{
					name: '3 Years term',
					onOffCharge: 0,
					rentalPerAnnumCharge: 0
				}
			]
		},
		control: 'remove',
		install: 'Install',
		rentBuy: 'Rental/Buy',
		routerModel: 'Router model',
		routerInstall: 'Router Install',
		purchaseCharge: 'Purchase Charge',
		maintenance: 'Maintenance',
		management: 'Management',
		checkBoxContent: {
			name: 'RouterRequired',
			id: 'RouterRequired',
			displayValue: 'Router required',
			checked: false
		},
		selectionHandler: 'selectionHandler',
		onClick: 'onClick'
	},
	constStyles: {
		addServiceCatalogue: 'add-services-catalogue-list-item',
		dnsUserListLeft: 'firstcolumn dns_users_list_left',
		accMonthCost: 'acc_monthly_cost',
		routerSiteAddress: 'router-site-address',
		routerSiteAddress1: 'router-site-address-1',
		routerSiteAddress2: 'router-site-address-2',
		divide: 'divide',
		accQuarterCost: 'acc_quarterly_cost',
		title1: 'title-1',
		price: 'Price',
		addServicesRolesLeft: 'add_services_user_roles_list_left',
		addServicesRolesRight: 'add_services_user_roles_list_right',
		serviceMonthPrice: 'services-monthly-price',
		secondaryButton: 'button--secondary',
		userRolesListLeft: 'user_roles_list_left',
		btnBuySellOption: 'btn-buy-sell-option',
		requestSelectionBtns: 'request_selection_btns',
		cosCatalogueListItem: 'cos_catalogue_list_item',
		asaCatalogueListItem: 'asa_catalogue_list_item',
		domainInputText: 'domain-input-text'
	},
	actions: {
		setHeaderData: 'setHeaderData'
	}
};
export default AdditionalServicesProps;
