const accordianProps = {
	constStyles: {
		active: 'active',
		summary_accordion_head: 'accordion__heading accordion_head',
		sum_accordion_head_left: 'sum_accordion_head_left',
		accordionHead: 'accordion_head_left',
		noPadding: 'nopadding',
		accordionHead_noCorser: ' accordion_head_left nocursor',
		sum_catalogue_list_item: 'sum_catalogue_list_item',
		user_roles_list_left: 'user_roles_list_left',
		summary_titleClass: 'item_title_heading',
		monthly_cost: 'monthly_cost',
		active_monthly_cost: 'monthly_cost active_quote_tab',
		active_quarterly_cost: 'quarterly_cost active_quote_tab',
		quarterly_cost: 'quarterly_cost',
		content_section: 'content-section summary_section',
		catalogue_list: 'catalogue_list',
		catalogue_list_item: 'add-services-catalogue-list-item',
		accordian__lavalamp: 'tab_monthly_cost accordian__lavalamp',
		noDiv: 'nodiv'
	},
	defaultStyles: {
		iconCode: 'chevron-down',
		iconClass: 'sprite__icon',
		rotateClass: 'rotate',
		defalutChevron: 'chevron_default show_services sum_arrow'
	},
	constData: {},
	defaultData: {},
	actions: {
		toggleClick: 'toggleClick'
	}
};
export default accordianProps;
