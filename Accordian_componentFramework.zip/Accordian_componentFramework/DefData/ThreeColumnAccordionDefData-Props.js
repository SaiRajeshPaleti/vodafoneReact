const accordianProps = {
	constStyles: {
		accordionHead: 'accordion_head_left classOfService',
		classOfService: 'classOfService',
		user_roles_list_left: 'user_roles_list_left',
		acc_monthly_cost: 'acc_monthly_cost',
		cso_address: 'cso_address',
		acc_quarterly_cost: 'acc_quarterly_cost',
		price: 'price',
		divide: 'divide',
		catalogue_content: 'catalogue_content',
		cos_title_heading: 'cos_title_heading',
		cos_catalogue_list_item: 'cos_catalogue_list_item',
		emp_section: 'emp_section',
		input_text: 'input-text',
		cso_input: 'cso_input',
		cso_price: 'cso_price',
		inputEntry: 'input-entry',
		Mbps: 'Mbps'
	},
	defaultStyles: {},
	constData: {},
	defaultData: {}
};
export default accordianProps;
