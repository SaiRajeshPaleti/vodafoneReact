const accordianProps = {
	constStyles: {
		speed_section: 'content-section multiTable',
		subchevFooter: 'sub_accordion_title',
		active: 'active',
		acc_catalogue_list_item: 'acc_catalogue_list_item',
		user_roles_list_left: 'user_roles_list_left',
		speed_options: 'speed-options',
		acc_monthly_cost: 'acc_monthly_cost',
		divide: 'divide',
		acc_quaterly_cost: 'acc_quarterly_cost',
		speed_opt_monthlyprice: 'speed-opt-monthlyprice',
		speed_opt_monthlyrightprice: 'speed-opt-monthlyrightprice',
		speed_opt_quarterlyprice: 'speed-opt-quarterlyprice',
		speed_opt_quarterlyrightprice: 'speed-opt-quarterlyrightprice',
		option_name: 'select-option'
	},
	defaultStyles: {
		iconCode: 'chevron-down',
		iconClass: 'sprite__icon',
		rotateClass: 'rotate',
		iconRotateClass: 'sprite__icon rotate',
		defalutChevron: 'chevron_default show_services'
	},
	constData: {
		startIndex: 0,
		endIndex: 4,
		showmore: {
			show: 'See all speed options',
			hide: 'Hide all speed options'
		}
	},
	defaultData: {},
	actions: {
		setHeaderData: 'setHeaderData',
		setPlan: 'setPlan',
		setData: 'setData',
		toggleClick: 'toggleClick'
	}
};
export default accordianProps;
