const advSearchComponentStyles = {
	constData: {
		submitButton: {
			buttonType: 'button',
			id: 'submitbtnid',
			name: 'Submit',
			type: 'primary'
		},

		bllingAddressTitle: 'Add new billing account address'
	},
	constStyles: {
		contentData: 'content_data',
		formContent: 'formcontent',
		summaryDataContent: 'formcontent bgColor',
		gridWrapper: 'grid-wrapper',
		toggleClick: 'toggle-click',
		link: 'link',
		contentHiddenData: 'content_hidden_data'
	},
	actions: {
		onClick: 'onClick',
		setHeaderData: 'setHeaderData',
		onSubmitHandler: 'onSubmitHandler'
	},
	formRow: 'form__row'
};

export default advSearchComponentStyles;
