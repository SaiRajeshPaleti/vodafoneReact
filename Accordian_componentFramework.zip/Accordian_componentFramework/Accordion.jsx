import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import './Accordion.css';
import './Styles/FormBody.css';
import './Styles/TableAccordion.css';
import './Styles/MultiTablesAccordion.css';
import './Styles/MSPBearerAccordion.css';
import './Styles/ThreeColumnAccordion.css';
import './Styles/SummaryAccordion.css';
import './Styles/AdditionalServices.css';
import AccordionStyles from './DefData/accordionDefData-Props';
import { HeaderComponent, FooterComponent, ContentComponent } from './AccordionComponents';

class Accordion extends PureComponent {
	constructor(props) {
		super(props);
		const contentData = this.props.data.content && JSON.parse(JSON.stringify(this.props.data.content));
		let rowData = [];
		if (this.props.data.footer && this.props.data.footer.rowData) rowData = this.props.data.footer.rowData;

		this.state = {
			initialContent: contentData,
			active: false,
			headerData: {
				...this.props.data.header.headerData,
				type: this.props.data.header.type,
				showIcon: this.props.data.alwaysExpanded,
				rowData
			},
			contentData: this.props.data.content,
			activeClass: AccordionStyles.constStyles.accContent,
			displayAccordion: this.props.data.displayAccordion
		};
		this.toggleClick = this.toggleClick.bind(this);
		this.setHeaderData = this.setHeaderData.bind(this);
		this.setContentData = this.setContentData.bind(this);
		this.setInitialState = this.setInitialState.bind(this);
	}

	componentWillReceiveProps(nextProps) {
		// if (nextProps.data.alwaysExpanded) {
		// 	this.setState({ activeClass: AccordionStyles.constStyles.accActiveContent, active: true });
		// }

		//this.props.data.content.showAccordion && this.setState({ active: true });
		let rowData = [];
		if (nextProps.data.footer && nextProps.data.footer.rowData) rowData = nextProps.data.footer.rowData;
		this.setState({
			headerData: {
				...nextProps.data.header.headerData,
				type: nextProps.data.header.type,
				showIcon: nextProps.data.alwaysExpanded,
				rowData: rowData
			},

			contentData: nextProps.data.content,
			displayAccordion: nextProps.data.displayAccordion
		});
	}
	toggleClick(event) {
		const active = this.state.active;
		this.setState({
			active: !active,
			activeClass: !active ? AccordionStyles.constStyles.accActiveContent : AccordionStyles.constStyles.accContent
		});
	}
	setHeaderData(headerData) {
		this.setState({ headerData });
	}
	setContentData(contentData) {
		const content = JSON.parse(JSON.stringify(this.state.contentData));
		content.contentData = contentData;
		this.setState({
			contentData: content
		});
	}
	setInitialState() {
		this.setState({
			contentData: this.state.initialContent
		});
	}
	componentWillMount() {
		console.log('AccordionData.length', this.props.length);
		//let deleteFlag = true;
		if (this.props.length > 1) {
			this.setState({
				deleteFlag: true
			});
		}
		if (this.props.data.alwaysExpanded) {
			this.setState({
				activeClass: AccordionStyles.constStyles.accActiveContent,
				active: true
			});
		}

		//this.props.data.content.showAccordion && this.setState({ active: true });
	}
	render() {
		const headerData = {
			headerData: this.state.headerData,
			getHeaderValue: this.props.data.getHeaderValue,
			selectButtonClick: this.props.data.selectButtonClick,
			active: this.state.active,
			getTab: this.props.data.getTab,
			toggleClick: this.toggleClick,
			setHeaderData: this.setHeaderData,
			setContentData: this.setContentData,
			contentData: this.state.contentData,
			setInitialState: this.setInitialState,
			deleteFlag: this.state.deleteFlag
		};
		const footerProps = {
			...this.props.data.footer,
			active: this.state.active,
			onClick: this.toggleClick
		};
		const contentProps = {
			...this.props,
			type: this.props.data.content.type,
			...this.state.contentData,
			setHeaderData: this.setHeaderData,
			onChange: this.props.data.onChange,
			headerData: this.state.headerData,
			setContentData: this.setContentData
		};
		{
			if (this.state.displayAccordion) {
				return (
					<div
						className={AccordionStyles.constStyles.accordionItem}
						id={this.props.data.id}
						name={this.props.data.name}
					>
						<HeaderComponent data={headerData} />
						{contentProps.type && (
							<div className={this.state.activeClass}>
								<ContentComponent data={contentProps} />
							</div>
						)}
						<FooterComponent data={footerProps} />
					</div>
				);
			} else {
				return false;
			}
		}
	}
}
export default Accordion;
Accordion.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		name: PropTypes.string,
		header: PropTypes.object.isRequired,
		content: PropTypes.object.isRequired,
		footer: PropTypes.object
	})
};
