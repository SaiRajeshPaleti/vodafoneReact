import React from 'react';
import { constStyles, defaultData, constData } from './priorityCardsDefData-Props';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class priorityCardsComponentSummaryList extends BaseComponent {
    constructor(props) {
        super(props);
        this.setCardData = this.setCardData.bind(this);
        this.setCardData(props);
        this.state = {
            commonCardFooter: this.commonCardFooter
        };
    }

    componentWillReceiveProps(nextProps) {
        this.setCardData(nextProps);
        this.setState({
            commonCardFooter: this.commonCardFooter
        });
    }

    setCardData(props) {
        this.commonCardFooter =
            props.data.content.dataFooter.length > 0 &&
            props.data.content.dataFooter.map((data, index) => {
                return (
                    <div key={index}>
                        <span>{data.name}</span>
                        <span>{data.description}</span>
                    </div>
                );
            });
    }

    render() {
        const cardData = this.props.data;
        return (
            <div className={`${constStyles.card_section} ${cardData.type}`}>
                <div className={constStyles.fullClass}>
                    <div className={constStyles.prioryCardServiceName}>{cardData.title}</div>
                    <div className={constStyles.raisedListInfo}>
                        <span className={constStyles.raisedBy}>{constData.raisedBy}</span>
                        <span className={constStyles.raisedName}>{cardData.raisedByName}</span>
                    </div>
                </div>
                <div className={constStyles.cardFooter}>
                    {this.commonCardFooter && (
                        <div className={constStyles.fullClassFt}>{this.state.commonCardFooter}</div>
                    )}
                </div>
            </div>
        );
    }
}

priorityCardsComponentSummaryList.propTypes = {
    data: PropTypes.shape({
        title: PropTypes.string.isRequired,
        type: PropTypes.string.isRequired,
        content: PropTypes.shape({
            dataFooter: PropTypes.arrayOf(
                PropTypes.shape({
                    name: PropTypes.string.isRequired,
                    description: PropTypes.string.isRequired
                })
            )
        })
    }).isRequired
};

priorityCardsComponentSummaryList.defaultProps = {
    data: defaultData.card1
};

export default priorityCardsComponentSummaryList;
