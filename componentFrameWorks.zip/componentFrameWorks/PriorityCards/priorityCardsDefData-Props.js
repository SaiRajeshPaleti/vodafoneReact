export const constStyles = {
    //SVG & Select
    prorityCardwrapper: 'prorityCard--wrapper',
    priority_cards: 'priority_cards',
    iconClass: 'svg',
    svgClass: 'circle',
    circleSelectClass: 'circleSelect',
    tabsCls: 'tabs__tab tabs__tab--active',
    select: 'priority_tabs card5',
    svg: 'priority_tabs card4',

    // Nikhil TODO
    idPTag: '_heading',
    paragraphUnderLineClass: 'underline-link',
    divContentClass: 'tabsp1Contents',
    tickClass: 'tick',
    fullClass: 'prioritycardFull',
    card_section: 'card_section',
    fullClassHead: 'prioritycardFull_Head',
    fullClassL: 'prioritycardFull_left',
    fullClassR: 'prioritycardFull_right',
    fullClassAdr: 'prioritycardFull_Addr',
    fullClassStep: 'prioritycardFull_Step',
    fullClassOD: 'prioritycardFull_OrderDetail',
    fullClassFt: 'prioritycardFull_Footer',
    listClass: 'priorityCardList',
    emptyCircle: 'empty-circle',
    clearClass: 'clear-class',
    marginReset: 'margin-reset',
    serviceWrapper: 'serviceWrapper',
    service__wrapper: 'service__wrapper',
    statusWrapper: 'statusWrapper',
    title: 'title',
    statusInfo: 'status__info',
    statuswrapper: 'status__wrapper',
    statusRequest: 'status__request',
    reference: 'reference',
    iconEdit: 'iconEdit',
    statusUpdate: 'status__update',
    updatedInfo: 'updated__info',
    txtInfo: 'txt__info',
    dateTime: 'date__time',
    summaryData: 'summaryData',
    cardFooter: 'card__footer',
    iconName: 'edit',
    prioryCardServiceName: 'prioritycard-service-name',
    raisedListInfo: 'raised-list-info',
    raisedBy: 'raised-by',
    raisedName: 'raised-name',

    // Generic
    mainClass: 'card-wrapper',
    PriorityClass: {
        P1: {
            divPriorityClass: 'priority_tabs critical_impact_tab',
            spanPriorityClass: 'critical_impact status'
        },
        P2: {
            divPriorityClass: 'priority_tabs emergency_impact_tab',
            spanPriorityClass: 'emergency_impact status'
        },
        P3: {
            divPriorityClass: 'priority_tabs normal_impact_tab',
            spanPriorityClass: 'normal_impact status'
        },
        P4: {
            divPriorityClass: 'priority_tabs low_impact_tab',
            spanPriorityClass: 'low_impact status'
        }
    }
};

export const constData = {
    cardType: [ 'card1', 'card2', 'card3', 'card4', 'card5', 'card6', 'card7', 'card11', 'card12' ],
    uniqueDataFields: [ 'reference', 'priority', 'url' ],
    IgnoreFields: [ 'type' ],
    selectField: 'speed',
    descField: 'Mbps',
    svg: 'url',
    descC41: 'name',
    descC42: 'description',
    onClick: 'onClick',
    value: 'value',
    raisedBy: 'Raised by:'
};

export const defaultData = {
    card1: {
        type: 'card1',
        name: 'card1',
        id: 'i1',
        reference: 'INC0010691',
        priority: 'P1',
        body: {
            description: 'SLA for Incident'
        },
        onClick: () => {}
    },
    card2: {
        type: 'card2',
        name: 'card2',
        id: 'j1',
        reference: 'VFTOP_75192_180531_376149',
        body: {
            productName: 'Ethernet Wireline - Interconnect',
            description: 'Test Quote 1'
        },
        onClick: () => {}
    },
    card3: {
        title: 'Ethernet Wireline - Interconnect',
        additional_title: '500 Mbps',
        type: 'card3',
        content: {
            body: [
                {
                    name: 'Interconnect location:',
                    description:
                        'Birmingham - Unit 8, Keyway Business Park, Kingsbury Road, Erdington, Birmingham, B24 9PT'
                },
                {
                    name: 'Site address:',
                    description:
                        'Edinburgh - Unit 8, Keyway Business Park, Kingsbury Road, Erdington, Edinburgh, EH3 8AX'
                }
            ],
            dataFooter: [
                {
                    name: 'Contract term:',
                    description: '1 year'
                },
                {
                    name: 'Quote date:',
                    description: '12 Mar 2018'
                },
                {
                    name: 'Quote expiry date:',
                    description: '22 May 2018'
                },
                {
                    name: 'Quote reference:',
                    description: 'VFTOP_71885_180510_324028'
                }
            ]
        }
    },
    card4: {
        type: 'card4',
        url: 'EWL_interconnect',
        name: 'Ethernet Privateline',
        description: 'Interconnect',
        onClick: () => {}
    },
    card5: {
        type: 'card5',
        speed: '450',
        onClick: () => {}
    },
    card6: {
        type: 'card6',
        title: 'Vodafone Enterprise',
        address: '123 London street, London - BH3 8AG',
        step_tracker_title: 'Order stage',
        date_data: {
            heading: 'Order date',
            value: '12 Mar 2018'
        },
        order_details: [
            {
                name: 'Quote reference',
                description: 'VFTOP_71885_180523_360511'
            },
            {
                name: 'Product',
                description: 'Ethernet Wireline - Interconnect'
            },
            {
                name: 'Contract term',
                description: '1 Year'
            },
            {
                name: 'Contact number',
                description: '220-3444589'
            }
        ],
        trackerType: 'tracker2',
        stepTrackerData: {
            steptrackerlabel: [
                { name: 'Site 1 Details', stepNo: '1', isComplete: true, isActive: false },
                { name: 'Site 2 Details', stepNo: '2', isComplete: true, isActive: false },
                { name: 'Site 3 Details', stepNo: '3', isComplete: false, isActive: true },
                { name: 'Site 4 Details', stepNo: '4', isComplete: false, isActive: false },
                { name: 'Site 5 Details', stepNo: '5', isComplete: false, isActive: false },
                { name: 'Site 6 Details', stepNo: '6', isComplete: false, isActive: false }
            ],
            orderTrackerData: [
                { name: 'Quote Submitted', isComplete: true, isActive: false, icon: 'icon-reports' },
                { name: 'Ordered', isComplete: true, isActive: false, icon: 'shopping-trolley' },
                { name: 'Planning', isComplete: true, isActive: false, icon: 'EPL_interconnect' },
                { name: 'Build', isComplete: false, isActive: true, icon: 'rank-networker' },
                { name: 'Test', isComplete: false, isActive: false, icon: 'diagnostics' },
                { name: 'Ready', isComplete: false, isActive: false, icon: 'completed' }
            ],
            stepImplementation: function stepImplementation() {
                // step implementation goes here
                console.log('step clicked');
            }
        }
    },
    card7: [
        {
            type: 'card7',
            dataList: {
                heading: 'Template One',
                name: 'Ethernet Interconnect',
                url: 'http://www.vodafone.co.uk/',
                item1: true,
                item2: true,
                item3: true,
                item4: false
            },
            card7_mapping: {
                item1: {
                    label: 'Customer And Billing Details',
                    key: 'CustomerAndBillingDetails'
                },
                item2: {
                    label: 'Site A Details',
                    key: 'SiteADetails'
                },
                item3: {
                    label: 'Site B Details',
                    key: 'SiteBDetails'
                },
                item4: {
                    label: 'Service Details',
                    key: 'ServiceDetails'
                }
            }
        },
        {
            type: 'card7',
            dataList: {
                heading: 'Template Two',
                name: 'Ethernet Interconnect',
                url: 'http://www.vodafone.co.uk/',
                item1: true,
                item2: true,
                item3: true,
                item4: false
            },
            card7_mapping: {
                item1: {
                    label: 'Customer And Billing Details',
                    key: 'CustomerAndBillingDetails'
                },
                item2: {
                    label: 'Site A Details',
                    key: 'SiteADetails'
                },
                item3: {
                    label: 'Site B Details',
                    key: 'SiteBDetails'
                },
                item4: {
                    label: 'Service Details',
                    key: 'ServiceDetails'
                }
            }
        },
        {
            type: 'card7',
            dataList: {
                heading: 'Template Three',
                name: 'Ethernet Interconnect',
                url: 'http://www.vodafone.co.uk/',
                item1: true,
                item2: true,
                item3: true,
                item4: false
            },
            card7_mapping: {
                item1: {
                    label: 'Customer And Billing Details',
                    key: 'CustomerAndBillingDetails'
                },
                item2: {
                    label: 'Site A Details',
                    key: 'SiteADetails'
                },
                item3: {
                    label: 'Site B Details',
                    key: 'SiteBDetails'
                },
                item4: {
                    label: 'Service Details',
                    key: 'ServiceDetails'
                }
            }
        },
        {
            type: 'card7',
            dataList: {
                heading: 'Template Four',
                name: 'Ethernet Interconnect',
                url: 'http://www.vodafone.co.uk/',
                item1: true,
                item2: true,
                item3: true,
                item4: false
            },
            card7_mapping: {
                item1: {
                    label: 'Customer And Billing Details',
                    key: 'CustomerAndBillingDetails'
                },
                item2: {
                    label: 'Site A Details',
                    key: 'SiteADetails'
                },
                item3: {
                    label: 'Site B Details',
                    key: 'SiteBDetails'
                },
                item4: {
                    label: 'Service Details',
                    key: 'ServiceDetails'
                }
            }
        }
    ]
};
