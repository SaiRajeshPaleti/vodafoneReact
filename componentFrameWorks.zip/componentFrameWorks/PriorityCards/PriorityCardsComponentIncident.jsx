import React from 'react';
import { constStyles, defaultData } from './priorityCardsDefData-Props';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class priorityCardsComponentIncident extends BaseComponent {
    constructor(props) {
        super(props);
        this.setCardData = this.setCardData.bind(this);
    }

    componentWillMount() {
        this.setCardData(this.props);
    }

    componentWillReceiveProps(nextProps) {
        this.setCardData(nextProps);
    }

    setCardData(props) {
        this.cardData = Object.keys(props.data.body).map((key, index) => (
            <div key={index} className={constStyles.divContentClass}>
                <p>{props.data.body[key]}</p>
            </div>
        ));
        this.dynamicClass =
            props.data.FrameworkCard === true ? constStyles.priority_cards : constStyles.paragraphUnderLineClass;
        this.classToBeAdded = constStyles.PriorityClass[this.props.data.priority]
            ? constStyles.PriorityClass[this.props.data.priority]
            : constStyles.PriorityClass.P1;
    }

    render() {
        const recProp = this.props.data;
        return (
            <div
                id={recProp.id}
                className={`${this.classToBeAdded.divPriorityClass} ${this.props.data.type}`}
                title={recProp.title}
                onClick={recProp.onClick}
            >
                <p id={`${recProp.id}${constStyles.idPTag}`} className={this.dynamicClass}>
                    {recProp.reference}
                </p>
                {this.cardData}
                <span className={this.classToBeAdded.spanPriorityClass}>{recProp.priority}</span>
            </div>
        );
    }
}

priorityCardsComponentIncident.propTypes = {
    data: PropTypes.oneOfType([
        PropTypes.shape({
            type: PropTypes.string.isRequired,
            name: PropTypes.string.isRequired,
            id: PropTypes.string.isRequired,
            reference: PropTypes.string.isRequired,
            priority: PropTypes.string.isRequired,
            body: PropTypes.shape({
                description: PropTypes.string.isRequired
            }),
            onClick: PropTypes.func
        }),
        PropTypes.shape({
            type: PropTypes.string.isRequired,
            name: PropTypes.string.isRequired,
            id: PropTypes.string.isRequired,
            reference: PropTypes.string.isRequired,
            body: {
                productName: PropTypes.string.isRequired,
                description: PropTypes.string.isRequired
            },
            onClick: PropTypes.func
        })
    ]).isRequired
};

priorityCardsComponentIncident.defaultProps = {
    data: defaultData.card2
};

export default priorityCardsComponentIncident;
