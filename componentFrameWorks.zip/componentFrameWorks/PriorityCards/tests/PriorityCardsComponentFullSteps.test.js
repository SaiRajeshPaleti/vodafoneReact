import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsFullSteps from '../priorityCardsComponentFullSteps';

Enzyme.configure({ adapter: new Adapter() });

describe('<priorityCardsFullSteps />', function () {
    let props, enzymeWrapper;

    props={
        data:{
            type: 'card10',
            stepTrackerData: {
				stepImplementation: function stepImplementation() {
					// step implementation goes here
					console.log('step clicked');
				},
				id: '2',
				name: 'Order Step Tracker',
				type: 'orderTracker',
				data: [
					{ id: '1', name: 'Quote Submitted', isComplete: true, isActive: false, icon: 'icon-reports' },
					{ id: '2', name: 'Ordered', isComplete: true, isActive: false, icon: 'shopping-trolley' },
					{ id: '3', name: 'Planning', isComplete: true, isActive: false, icon: 'EPL_interconnect' },
					{ id: '4', name: 'Build', isComplete: false, isActive: true, icon: 'rank-networker' },
					{ id: '5', name: 'Test', isComplete: false, isActive: false, icon: 'diagnostics' },
					{ id: '6', name: 'Ready', isComplete: false, isActive: false, icon: 'completed' }
				]
			},
            title: 'Vodafone Enterprise',
            date_value: '12 Mar 2018',
            address: '123 London street, London - BH3 8AG',
            date_data: {
				heading: 'Order date',
				value: '12 Mar 2018'
            },
            product_data: {
				heading: 'Product',
				value: 'Access'
            },
            order_ref: {
				heading: 'Order reference',
				value: '5556777888'
            },
            step_tracker_title: 'Order stage',
            order_details: [
				{
					name: 'Quote reference',
                    value: 'VFTOP_71885_180523_360511',
                    description: 'Interconnect'
				},
				{
					name: 'Product',
                    value: 'Ethernet Wireline - Interconnect',
                    description: 'Interconnect'
				},
				{
					name: 'Contract term',
                    value: '1 Year',
                    description: 'Interconnect'
				},
				{
					name: 'Contact number',
                    value: '220-3444589',
                    description: 'Interconnect'
				}
			]
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsFullSteps {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

    it('invocation of componentWillMount method',()=>{
        enzymeWrapper.instance().componentWillMount();
    });

    it('invocation of componentWillReceiveProps method',()=>{
        enzymeWrapper.instance().componentWillReceiveProps(props);
    });


});