import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsComponentIncident from '../PriorityCardsComponentIncident';

Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCardsComponentIncident />', function () {
    let props, enzymeWrapper;

    props={
        data:{
           type: 'card5',
           priority: 'P1',
           id: 'i1',
           reference: 'INC0010691',
           onClick: () => {
            console.log('Function called INC0010691');
        },
        reference: 'INC0010693'
        },
        data:{
            body: {
            productName: 'Ethernet Wireline - Internet Access',
            description: 'Test Quote 1'
        }}
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsComponentIncident {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

    it('check for setCardData invocation',() =>{
        enzymeWrapper.instance().setCardData(props);
    });

    it('check for componentWillMount invocation',() =>{
        enzymeWrapper.instance().componentWillMount();
    });

    it('check for componentWillReceiveProps invocation',() =>{
        enzymeWrapper.instance().componentWillReceiveProps(props);
    });

});