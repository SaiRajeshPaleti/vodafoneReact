import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCards from '../priorityCardsComponent';
import PriorityData from '../../../AppData/priorityCardsData';

Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCards />', function () {
    let props, enzymeWrapper;

    props={
        data:{
           data:PriorityData,
           type: 'card5'
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCards {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

    it('check for componentWillReceiveProps invocation', () =>{
        expect(enzymeWrapper.instance().componentWillReceiveProps(props));
    })
     
    it('check for div element', () =>{
        expect(enzymeWrapper.find('.card-wrapper').length).toBe(1);
    })

});