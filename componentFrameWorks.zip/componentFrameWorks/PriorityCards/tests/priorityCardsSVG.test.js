import React from 'react';
import PriorityCards from '../priorityCardsComponent';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Priority from '../../../AppData/priorityCardsData';
Enzyme.configure({ adapter: new Adapter() });



describe('<PriorityCards cardType="card4" />', function () {
    let props, enzymeWrapper

    beforeEach(() => {
        props = Priority;        
        enzymeWrapper = mount(<PriorityCards cardType="card4" PriorityCards={props.priorityData.card4.data[0]} clickHandler={() => {}} />)
        
    });

    it('PrioritycardSVG  main div', () => {
        expect(enzymeWrapper.find('.card4').length).toEqual(1);
    });
    it('PrioritycardSVG  circle', () => {
        expect(enzymeWrapper.find('.circle').length).toEqual(1);
    });
    it('PrioritycardSVG  other div', () => {
        expect(enzymeWrapper.find('.tabsp1Contents').length).toEqual(2);
    });
});

