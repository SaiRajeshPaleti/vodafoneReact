import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsFullTitle from '../priorityCardsComponentFullTitle';
import PriorityData from '../../../AppData/priorityCardsData';

Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCardsFullTitle />', function () {
    let props, enzymeWrapper;

    props={
        data:{
            type: 'card10',
            title: 'Vodafone Enterprise',
            additional_title: '500 Mbps',
            content: {
                body: [
                    {
                        name: 'Interconnect location:',
                        description:
                            'Birmingham - Unit 8, Keyway Business Park, Kingsbury Road, Erdington, Birmingham, B24 9PT'
                    }
                ],
                dataFooter: [
                    {
                        name: 'Contract term:',
                        description: '1 year'
                    }
                ]
            }
        }
    }

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsFullTitle {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

    it('check for setCardData invocation', () =>{
        enzymeWrapper.instance().setCardData(props);
    });

    it('check for componentWillReceiveProps invocation', () =>{
        enzymeWrapper.instance().componentWillReceiveProps(props);
    });

    it('check for componentWillMount invocation', () =>{
        enzymeWrapper.instance().componentWillMount();
    });

});