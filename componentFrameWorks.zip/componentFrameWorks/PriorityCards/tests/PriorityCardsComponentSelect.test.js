import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsSelect from '../priorityCardsComponentSelect';
import PriorityComponentFactory  from '../PriorityComponentFactory';

Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCardsSelect />', function () {
    let props, enzymeWrapper;

    props={
        data:{
            onClick: () => {},
            id: 'w1',
            name: 'Ethernet Wireline'
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsSelect {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

    it('invoke selectFunction method', () =>{
        enzymeWrapper.instance().selectFunction();
    });

});

describe('<PriorityComponentFactory />', function(){
    let props, enzymeWrapper;

    props={
        data:{
            date_value: '12 Mar 2018',
            order_ref: {
                heading: 'Order reference',
                value: '5556777888'
            },
            order_details: [
                {
                    name: 'Quote reference',
                    value: 'VFTOP_71885_180523_360511'
                },
                {
                    name: 'Customer reference',
                    value: 'John Doe'
                },
                {
                    name: 'Site A address',
                    value: 'HAINAULT ROAD, LONDON, GBR'
                },
                {
                    name: 'Site B address',
                    value: 'HAINAULT ROAD, LONDON, GBR'
                }
            ],
           type:'card1',
           stepTrackerData: {
            stepImplementation: function stepImplementation() {
                // step implementation goes here
                console.log('step clicked');
            },
            id: '2',
            currentActive: 'Build',
            name: 'Order Step Tracker',
            type: 'orderTracker',
            data: [
                { id: '1', name: 'Quote', icon: 'icon-reports' },
                { id: '2', name: 'Request', icon: 'icon-reports' },
                { id: '3', name: 'Order Planning', icon: 'icon-reports' },
                { id: '4', name: 'Build', icon: 'icon-reports' },
                { id: '5', name: 'Test', icon: 'icon-reports' },
                { id: '6', name: 'Ready for Use', icon: 'icon-reports' }
            ]
        },
        product_data: {
            heading: 'Product',
            value: 'Access'
        },
        title: 'Vodafone Enterprise',
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityComponentFactory {...props} />);

    });

    it('invoke selectFunction method', () =>{
        enzymeWrapper.instance().PriorityComponentFactory (props);
    });

    it('check for ComponentContent',()=>{
        enzymeWrapper.find('ComponentContent')
    });
});