import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import priorityCardsComponentHeaderList from '../priorityCardsComponentHeaderList';
import PriorityData from '../../../AppData/priorityCardsData';

Enzyme.configure({ adapter: new Adapter() });

describe('<priorityCardsComponentHeaderList />', function() {
    let props, enzymeWrapper;

    props = {
        type: 'card11',
        title: 'Vodafone customer',
        status: 'In progress',
        reference: 'ORA001/68293',
        firstoccured: 'First occurred',
        dateraised: '15 Sep 2018 13:21',
        lastUpdate: 'Last updated',
        updatedDate: '25 Aug 2018 10:01',
        summary: 'Summary',
        summaryText:
            'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus vestibulum lectus ut magna mattis, et finibus nisi luctus. Class aptent taciti sociosqu ad lit..',
        content: {
            dataFooter: [
                {
                    name: 'Priority:',
                    description: 'Priority 1'
                },
                {
                    name: 'Escalation level:',
                    description: 'Level 4'
                },
                {
                    name: 'Request raised:',
                    description: '15 Sep 2018 13:21'
                },
                {
                    name: 'Time to restore:',
                    description: 'ETA - 6 Hours'
                }
            ]
        },
        onClick: () => {
            console.log('function passed');
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount(<priorityCardsComponentServiceRequest {...props} />);
    });

    it('check for rendering', () => {
        expect(enzymeWrapper).not.toBe(null);
    });

    it('check for setCardData invocation', () => {
        enzymeWrapper.instance().setCardData(props);
    });

    it('Handler testing', () => {
        const iconEdit = enzymeWrapper.find('.iconEdit span');
        iconEdit.at(1).simulate('click');
        expect(enzymeWrapper.iconEditClick).toHaveBeenCalled;
    });

    it('check for componentWillReceiveProps invocation', () => {
        enzymeWrapper.instance().componentWillReceiveProps(props);
    });

    it('check for componentWillMount invocation', () => {
        enzymeWrapper.instance().componentWillMount();
    });
});
