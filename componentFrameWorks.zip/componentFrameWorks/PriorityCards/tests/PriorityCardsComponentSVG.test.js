import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsSVG from '../priorityCardsComponentSVG';

Enzyme.configure({ adapter: new Adapter() });

describe('<priorityCardsFullSteps />', function () {
    let props, enzymeWrapper;

    props={
        data:{
            id: 's1',
            name: 'card5'
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsSVG {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

    it('identify div', ()=>{
        enzymeWrapper.find('div').at(0).simulate('click');
    });

    it('check for contentBody rendering', () =>{
        enzymeWrapper.instance().contentBody(props);
    });

    it('invocation of componentWillReceiveProps',()=>{
        enzymeWrapper.instance().componentWillReceiveProps(props);
    });

});