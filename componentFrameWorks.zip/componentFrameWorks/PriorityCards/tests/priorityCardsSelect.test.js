import React from 'react';
import PriorityCards from '../priorityCardsComponent';
import {  mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Priority from '../../../AppData/priorityCardsData';
Enzyme.configure({ adapter: new Adapter() });



describe('<PriorityCards cardType="card4" />', function () {
    let props, enzymeWrapper

    beforeEach(() => {
        props = Priority;
        enzymeWrapper = mount(<PriorityCards cardType="card5" PriorityCards={props.priorityData.card5.data[0]} clickHandler={() => { }} />)

    });

    it('PrioritycardSelect  main div', () => {
        expect(enzymeWrapper.find('.card5').length).toEqual(1);
    });
    it('PrioritycardSelect  circle', () => {
        expect(enzymeWrapper.find('.circle').length).toEqual(1);
    });
    it('PrioritycardSelect  other div', () => {
        expect(enzymeWrapper.find('.tabsp1Contents').length).toEqual(1);
    });
    it('Calls a function', () => {
        let button = enzymeWrapper.find('.circle');
        button.simulate('click');
        expect(props.selectFunction).toHaveBeenCalled;
    });
    it('Adds class on click', () => {
        let button = enzymeWrapper.find('.circle');
        button.simulate('click');
        expect(enzymeWrapper.find('.circleSelect').length).toEqual(1);
        button.simulate('click');
        expect(enzymeWrapper.find('.circleSelect').length).toEqual(0);
    });
   
   
});

