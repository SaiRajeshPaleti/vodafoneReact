import React from 'react';
import PriorityCards from '../priorityCardsComponent';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Priority from '../../../AppData/priorityCardsData';
Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCards cardType="card1" />', function() {
    let props, clickHandler, enzymeWrapper;

    beforeAll(() => {
        props = Priority;
        props.card1.map((prop, index) => {
            enzymeWrapper = mount(<PriorityCards cardType='card1' key={index} clickHandler={() => {}} />);
        });
    });

    it('Prioritycard  Component contains  div', () => {
        expect(enzymeWrapper.find('.priority_tabs').length).toEqual(1);
    });

    it('Prioritycard  Component contains  paragraph', () => {
        expect(enzymeWrapper.find('#i1_heading').length).toEqual(1);
    });

    it('Verifies that paragraph elements contains your  text', () => {
        expect(enzymeWrapper.find('#i1_heading').text()).toEqual(props.card1[0].reference);
    });

    it('Prioritycard  Component contains  div', () => {
        expect(enzymeWrapper.find('.tabsp1Contents').length).toEqual(1);
    });
    it('Verifies that div elements contains your  text', () => {
        expect(enzymeWrapper.find('.tabsp1Contents').text()).toEqual(props.card1[0].body.description);
    });
    it('identify that div contains paragaraph', () => {
        expect(enzymeWrapper.find('.tabsp1Contents').childAt(0).type()).toBe('p');
    });
    it('Prioritycard  Component contains span', () => {
        expect(enzymeWrapper.find('.critical_impact').length).toEqual(1);
    });
    it('Verifies that span elements contains your  text', () => {
        expect(enzymeWrapper.find('.critical_impact').text()).toEqual(props.card1[0].priority);
    });
    it('event handler to be called on clicking a card', () => {
        let card = enzymeWrapper.find('.priority_tabs');
        card.simulate('click');
        expect(props.clickHandler).toHaveBeenCalled;
    });
});

describe('<PriorityCards cardType="card2" />', function() {
    let props, clickHandler, enzymeWrapper;

    beforeAll(() => {
        props = Priority;
        props.card2.map((prop, index) => {
            enzymeWrapper = shallow(<PriorityCards cardType='card2' key={index} clickHandler={() => {}} />);
        });
    });

    it('Prioritycard  Component contains  div', () => {
        expect(enzymeWrapper.find('.priority_tabs').length).toEqual(1);
    });

    it('event handler to be called on clicking a card', () => {
        let card = enzymeWrapper.find('.priority_tabs');
        card.simulate('click');
        expect(props.clickHandler).toHaveBeenCalled;
    });
});
