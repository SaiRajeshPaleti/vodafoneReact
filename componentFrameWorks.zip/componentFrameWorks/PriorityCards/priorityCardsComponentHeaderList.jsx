import React from 'react';
import { constStyles, defaultData, constData } from './priorityCardsDefData-Props';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class priorityCardsComponentHeaderList extends BaseComponent {
    constructor(props) {
        super(props);
        this.setCardData = this.setCardData.bind(this);
        this.setCardData(props);
        this.state = {
            commonCardFooter: this.commonCardFooter
        };
    }

    componentWillReceiveProps(nextProps) {
        this.setCardData(nextProps);
        this.setState({
            commonCardFooter: this.commonCardFooter
        });
    }

    setCardData(props) {
        this.commonCardFooter =
            props.data.content.dataFooter.length > 0 &&
            props.data.content.dataFooter.map((data, index) => {
                return (
                    <div key={index}>
                        <span>{data.name}</span>
                        <span>{data.description}</span>
                    </div>
                );
            });
    }

    render() {
        const cardData = this.props.data;
        return (
            <div className={constStyles.card_section}>
                <div className={`${constStyles.fullClass} ${cardData.type}`}>
                    <div className={constStyles.serviceWrapper}>
                        <div className={constStyles.service__wrapper}>
                            <div className={constStyles.statusWrapper}>
                                <div class={constStyles.title}>{cardData.title}</div>
                                <div class={constStyles.statuswrapper}>
                                    <div class={`${constStyles.statusInfo} ${constStyles.statusRequest}`}>
                                        {cardData.status}
                                    </div>
                                </div>
                            </div>
                            <div className={constStyles.statusUpdate}>
                                <div className={constStyles.updatedInfo}>
                                    <div className={constStyles.txtInfo}>{cardData.firstoccured}:</div>
                                    <div className={constStyles.dateTime}>{cardData.dateraised}</div>
                                </div>
                                <div className={constStyles.updatedInfo}>
                                    <div className={constStyles.txtInfo}>{cardData.lastUpdate}:</div>
                                    <div className={constStyles.dateTime}>{cardData.updatedDate}</div>
                                </div>
                            </div>
                        </div>
                        <div className={constStyles.summaryData}>
                            {cardData.summary}: {cardData.summaryText}
                        </div>
                    </div>
                </div>
                <div className={constStyles.cardFooter}>
                    {this.commonCardFooter && (
                        <div className={constStyles.fullClassFt}>{this.state.commonCardFooter}</div>
                    )}
                </div>
            </div>
        );
    }
}

priorityCardsComponentHeaderList.propTypes = {
    data: PropTypes.shape({
        title: PropTypes.string.isRequired,
        type: PropTypes.string.isRequired,
        status: PropTypes.string.isRequired,
        reference: PropTypes.string.isRequired,
        firstoccured: PropTypes.string,
        dateraised: PropTypes.string,
        lastUpdate: PropTypes.string.isRequired,
        updatedDate: PropTypes.string.isRequired,
        summary: PropTypes.string,
        summaryText: PropTypes.string,
        content: PropTypes.shape({
            dataFooter: PropTypes.arrayOf(
                PropTypes.shape({
                    name: PropTypes.string.isRequired,
                    description: PropTypes.string.isRequired
                })
            )
        })
    }).isRequired
};

priorityCardsComponentHeaderList.defaultProps = {
    data: defaultData.card11
};

export default priorityCardsComponentHeaderList;
