import React from 'react';
import './prioritycards.css';
import { constStyles, defaultData } from './priorityCardsDefData-Props';
import BaseComponent from 'vf-ent-ws-utilities';
import ComponentFactory from './PriorityComponentFactory';
import { getContent } from './PriorityElementRegistry';

class PriorityCards extends BaseComponent {
    constructor(props) {
        super(props);
        this.state = {
            data: props.data,
            type: props.data.type
        };
    }

    componentWillReceiveProps(nextProps) {
        /* this.setState({
			data: nextProps.data,
			type: nextProps.data.type
		}); */
        this.forceUpdate();
    }

    render() {
        return (
            <div className={this.props.data.FrameworkCard ? constStyles.prorityCardwrapper : constStyles.mainClass}>
                {ComponentFactory(this.props.data, this.props.type, getContent)}
            </div>
        );
    }
}

PriorityCards.defaultProps = {
    data: defaultData.card1
};
export default PriorityCards;
