import priorityCardsFullTitle from './priorityCardsComponentFullTitle';
import priorityCardsFullSteps from './priorityCardsComponentFullSteps';
import priorityCardsComponentList from './priorityCardsComponentList';
import PriorityCardsSelect from './priorityCardsComponentSelect';
import priorityCardsSVG from './priorityCardsComponentSVG';
import priorityCardsComponentIncident from './PriorityCardsComponentIncident';
import priorityCardsIconText from './priorityCardsComponentIconText';
import priorityCardsComponentHeaderList from './priorityCardsComponentHeaderList';
import priorityCardsComponentSummaryList from './priorityCardsComponentSummaryList';

const PriorityElementRegistry = {
    card1: priorityCardsComponentIncident,
    card2: priorityCardsComponentIncident,
    card3: priorityCardsFullTitle,
    card4: priorityCardsSVG,
    card5: PriorityCardsSelect,
    card6: priorityCardsFullSteps,
    card7: priorityCardsComponentList,
    card8: priorityCardsFullTitle,
    card9: priorityCardsIconText,
    card10: priorityCardsFullSteps,
    card11: priorityCardsComponentHeaderList,
    card12: priorityCardsComponentSummaryList
};

export function getContent(type) {
    return PriorityElementRegistry[type];
}
