import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import { constStyles, defaultData, actions } from './FloatNavdefData-Props';
import './FloatNav.css';

class FloatNav extends BaseComponent {
    constructor(props) {
        super(props);
        this.state = {
            hovering: false
        };

        this.MouseEnter = this.handleMouseEnter.bind(this);
        this.MouseLeave = this.handleMouseLeave.bind(this);
        this.ulClass = constStyles.displayNone;
    }

    componentWillMount() {
        this.childIcons = this.renderOnHover(this.props);
    }
    componentWilReceiveProps(nextProps) {
        this.childIcons = this.renderOnHover(nextProps);
    }
    handleMouseEnter() {
        this.setState({ hovering: true });
        this.ulClass = '';
    }
    handleMouseLeave() {
        this.setState({ hovering: false });
        this.ulClass = constStyles.displayNone;
    }
    handleClick(targetId) {
        this.delegateHandler(actions.onClick, targetId, (targetId) => targetId);
    }

    renderOnHover = (props) => {
        return props.data.hoverIcons.map((icon, index) => {
            return (
                <li key={index}>
                    <div>
                        <span className={constStyles.iconClass} onClick={() => this.handleClick(icon.targetId)}>
                            <Icon name={icon.iconName} />
                        </span>
                        <b>{icon.hoverTitle}</b>
                    </div>
                </li>
            );
        });
    };

    render() {
        return (
            <div className={constStyles.Nav} onMouseEnter={this.MouseEnter} onMouseLeave={this.MouseLeave}>
                <div className={constStyles.items}>
                    <ul className={this.ulClass}>{this.childIcons}</ul>
                </div>
                <div className={constStyles.floatIcon}>
                    <span className={constStyles.iconClass} title={this.props.data.hoverTitle}>
                        <Icon name={this.props.data.iconPrimary} />
                    </span>
                </div>
            </div>
        );
    }
}

FloatNav.propTypes = {
    data: PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string,
        iconPrimary: PropTypes.string.isRequired,
        hoverTitle: PropTypes.string,
        hoverIcons: PropTypes.arrayOf(
            PropTypes.shape({
                id: PropTypes.string,
                name: PropTypes.string,
                hoverTitle: PropTypes.string,
                iconName: PropTypes.string.isRequired,
                targetId: PropTypes.string.isRequired
            })
        ).isRequired,
        onClick: PropTypes.func
    }).isRequired
};

FloatNav.defaultProps = {
    data: defaultData
};

export default FloatNav;
