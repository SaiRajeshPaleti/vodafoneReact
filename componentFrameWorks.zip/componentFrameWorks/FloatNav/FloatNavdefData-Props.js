export const constStyles = {
	items: 'hoverItems',
	displayNone: 'display_none',
	iconClass: 'sprite__icon',
	navSection: 'floatingNavSection',
	Nav: 'floatingNav',
	clear: 'clear_all',
	floatIcon: 'floatIcon'
};
export const constData = {
	upArrow: 'arrow-up'
};
export const actions = {
	onClick: 'onClick'
};
export const defaultData = {
	id: 'float1',
	name: 'floatIcon',
	iconPrimary: 'more-android',
	hoverTitle: 'Do some Action',
	hoverIcons: [
		{
			id: '1',
			name: 'overView',
			hoverTitle: 'Overview',
			iconName: 'arrow-up',
			targetId: 'body'
		},
		{
			id: '2',
			name: 'search',
			hoverTitle: 'Search',
			iconName: 'search',
			targetId: 'ContextSearch'
		}
	],
	onClick: () => {}
};
