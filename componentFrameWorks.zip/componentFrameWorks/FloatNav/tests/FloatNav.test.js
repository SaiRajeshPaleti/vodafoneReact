import React from 'react';
import renderer from 'react-test-renderer';
import FloatNav from '../FloatNav';
import FloatNavData from '../../../AppData/FloatNavData';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';

import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });
function setup() {
	let props;
	const enzymeWrapper = shallow(<FloatNav />);
	return { enzymeWrapper, props };
}

describe('components', function() {
	describe('<FloatNav/>', function() {
		let props, enzymeWrapper, mouseEnter, mouseLeave;
		beforeEach(() => {
			props = FloatNavData;
			mouseEnter = FloatNav.handleMouseEnter;
			mouseLeave = FloatNav.handleMouseLeave;
			enzymeWrapper = mount(<FloatNav FloatNavItems={FloatNavData} />);
		});

		it('Float Nav contains floatIcon', () => {
			expect(enzymeWrapper.find('.floatIcon').length).toEqual(1);
		});

		it('Float Nav contains hover title tags', () => {
			expect(enzymeWrapper.find('b').length).toEqual(2);
		});

		it('event handler to be called on click', () => {
			let floatNav = enzymeWrapper.find('.icon-more-android');
			floatNav.simulate('click');
			expect(floatNav.onClick).toHaveBeenCalled;
		});

		it('event handler to be called on click', () => {
			let floatNav = enzymeWrapper.find('.icon-search');
			floatNav.simulate('click');
			expect(floatNav.onClick).toHaveBeenCalled;
		});

		it('event handler to be called on click', () => {
			let floatNav = enzymeWrapper.find('.icon-arrow-up');
			floatNav.simulate('click');
			expect(floatNav.onClick).toHaveBeenCalled;
		});
		
		it('Float Nav contains sprite__icon', () => {
			expect(enzymeWrapper.find('.sprite__icon').length).toEqual(3);
		});

		it('event handler to be called on mouseenter', () => {
			let floatNav = enzymeWrapper.find('.floatingNav');
			floatNav.simulate('change');
			expect(FloatNav.handleMouseEnter).toHaveBeenCalled;
		});

		it('event handler to be called on mouseleave', () => {
			let floatNav = enzymeWrapper.find('.floatingNav');
			floatNav.simulate('change');
			expect(FloatNav.handleMouseLeave).toHaveBeenCalled;
		});

		it('set state on mouse enter method', () => {
			enzymeWrapper.setState({ props }, () => {
				enzymeWrapper.instance().handleMouseEnter();
				const userState = enzymeWrapper.state('props');
				expect(userState.handleMouseEnter).toHaveBeenCalled;
			});
		});

		it('set state on mouse leave method', () => {
			enzymeWrapper.setState({ props }, () => {
				enzymeWrapper.instance().handleMouseLeave();
				const userState = enzymeWrapper.state('props');
				expect(userState.handleMouseLeave).toHaveBeenCalled;
			});
		});
		it('Should trigger componentWillRecieveProps', () => {
			enzymeWrapper.setProps({ data: props });
		});
	});
});
