import React from 'react';
import './button.css';
import { constBtnStyles, constBtnIconStyle, constData, defaultData } from './buttonDefData-Props';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

class Button extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {};
	}
	componentWillMount() {
		this.checkForOptionalProps(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.checkForOptionalProps(nextProps);
	}

	checkDirection(dir1, dir2) {
		return dir1 === dir2;
	}

	getIcon(loc) {
		return constBtnIconStyle[loc];
	}

	buttonWithIcon(data) {
		const rightText = this.checkDirection(data.location, 'right') ? data.name : '';
		const leftText = this.checkDirection(data.location, 'left') ? data.name : '';
		const text = this.checkDirection(data.location, 'lefttick') ? data.name : '';
		const styling = this.getIcon(data.location);
		return (
			<span className={constBtnStyles.btnInside}>
				{rightText}
				<Icon name={styling.btnIcon} />
				{leftText}
				{text}
			</span>
		);
	}

	checkForOptionalProps(props) {
		const buttonName = props.data.isIcon ? this.buttonWithIcon(props.data) : props.data.name;
		this.isDisabled = props.data.isDisabled ? props.data.isDisabled : false;
		this.setState({
			buttonName
		});
	}
	dataPassing(id) {
		return { id: id, value: undefined };
	}

	render() {
		return (
			<button
				name={this.props.data.name}
				type={this.props.data.buttonType}
				id={this.props.data.id}
				onClick={() => this.delegateHandler(constData.propsProperty, this.props.data.id, this.dataPassing)}
				className={constBtnStyles[this.props.data.type]}
				disabled={this.isDisabled}
			>
				{this.state.buttonName}
			</button>
		);
	}
}
Button.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		type: PropTypes.oneOf(Object.keys(constBtnStyles)),
		className: PropTypes.string,
		buttonType: PropTypes.string.isRequired,
		onClick: PropTypes.func,
		isIcon: PropTypes.bool
	}).isRequired
};

Button.defaultProps = {
	data: defaultData
};

export default Button;
