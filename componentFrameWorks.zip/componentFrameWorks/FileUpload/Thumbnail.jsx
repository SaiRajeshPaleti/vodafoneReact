import React from 'react';
import { constStyle } from './FileUploadDefData-Props';
import PropTypes from 'prop-types';

const Thumbnail = (props) => {

	let divStyle = {
		backgroundImage: 'url(' + props.url + ')'
	};
	return (
		<div className={constStyle.className.file}>
			<picture>
				<div className={constStyle.className.thumb} title={props.name} style={divStyle} />
			</picture>
		</div>
	)

}

Thumbnail.propTypes = {
	url: PropTypes.string
};

export default Thumbnail;



