import React from 'react';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Thumbnail from '../Thumbnail';

import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<Thumbnail>', () => {
	let file = [];
	let url = 'upload';
	let wrapper;

	beforeEach(() => {
		wrapper = mount(<Thumbnail title="image" url={'/img.jpg'} key="1" />);
	});

	it('Thumbnail  contains one file', () => {
		expect(wrapper.find('.file').length).toBe(1);
	});

	it('Thumbnail contains one thumb', () => {
		expect(wrapper.find('.thumb').length).toBe(1);
	});
});
