import React from 'react';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import UploadStatus from '../UploadStatus';

import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<UploadStatus>', () => {
	let file = [];
	let url = 'upload';
	let wrapper;

	beforeEach(() => {
		wrapper = mount(<UploadStatus loaded={8} />);
	});

	it('Upload  contains one main', () => {
		expect(wrapper.find('.upload_progress_bar').length).toBe(1);
	});

	it('Upload contains one progress_zero', () => {
		expect(wrapper.find('.progress_zero').length).toBe(1);
	});
});
