import React from 'react';
import renderer from 'react-test-renderer';
import TestUtils from 'react-dom/test-utils';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import DropZoneBox from '../DropZoneBox';
import Adapter from 'enzyme-adapter-react-16';

import FileUploadData from '../../../AppData/FileUploadData';
import data from '../../../AppData/FileUploadData';

Enzyme.configure({ adapter: new Adapter() });

describe('<DropZoneBox>', () => {
	// let file = [];
	let url = 'upload';
	let dropZoneBoxWrapper, dropZoneBoxMountWrapper, enzymeWrapper;
	let appendThumbnail = (event) => { };
	let event = {
		preventDefault: () => { },
		stopPropagation: () => { },
		dropEffect: 'copy',
		target: {
			files: [
				{
					name: 'test'
				}
			]
		}
	};
	let fileContents = 'file contents';
	let file = new Blob([fileContents], { type: 'text/plain' });
	let propsData = FileUploadData;
	let props = {
		data: {
			drag_drop_text: 'Drag and drop files here to upload',
			extensionsAllowed: '',
			id: 123,
			hadleValidationError: () => { },
			onUploaded: () => { }
		}
	}

	beforeEach(() => {
		enzymeWrapper = shallow(< DropZoneBox { ...props } 
			hadleValidationError = {() => { }} onUploaded ={ () => { } } />);		
	});

	it('dropZoneBox contains one div', () => {
		expect(enzymeWrapper).toBeDefined;
	});
	it('should render component will mount before rendering the actual component', () => {
		expect(enzymeWrapper.instance().componentWillMount()).toHaveBeenCalled;
		expect(enzymeWrapper.instance().browseRender()).toHaveBeenCalled;

	});
	it('dropZoneBox call handleFileSelect', () => {
			expect(enzymeWrapper.instance().handleFileSelect(event)).toHaveBeenCalled;
			setTimeout(() => {
				let active = enzymeWrapper.instance().state.progress;
			}, 2);
	});

	it('dropZoneBox call handleDragOver', () => {
		expect(enzymeWrapper.instance().handleDragOver(event)).toHaveBeenCalled;
	});

	it('dropZoneBox call handleDragEnter', () => {
		expect(enzymeWrapper.instance().handleDragEnter(event)).toHaveBeenCalled;
	});
	it('dropZoneBox call handleDragLeave', () => {
		expect(enzymeWrapper.instance().handleDragLeave(event)).toHaveBeenCalled;
	});

	it('dropZoneBox call getFiles', () => {
		expect(enzymeWrapper.instance().getFiles(event)).toHaveBeenCalled;
	});

	it('dropZoneBox call abortUpload', () => {
		expect(enzymeWrapper.instance().abortUpload(event)).toHaveBeenCalled;
	});

	// 

	// it('Drag leave event test', function() {
	// 	let headclick = dropZoneBoxWrapper.find('.dragdropzone').simulate('dragLeave', { target: { files: [ file ] } });
	// 	expect(DropZoneBox.handleDragLeave).toHaveBeenCalled;
	// 	expect(dropZoneBoxMountWrapper.instance().handleDragLeave(event));
	// });

	// it('Drag enter event test', function() {
	// 	const fileContents = 'file contents';
	// 	const file = new Blob([ fileContents ], { type: 'text/plain' });
	// 	let headclick = dropZoneBoxWrapper.find('.dragdropzone').simulate('dragEnter', { target: { files: [ file ] } });
	// 	expect(DropZoneBox.handleDragEnter).toHaveBeenCalled;
	// 	expect(dropZoneBoxWrapper.instance().state.dragover).toEqual('');
	// });

	// it('Drop event test', function() {
	// 	const fileContents = 'file contents';
	// 	const file = new Blob([ fileContents ], { type: 'text/plain' });
	// 	const event = {
	// 		preventDefault: () => {},
	// 		stopPropagation: () => {},
	// 		dropEffect: 'copy'
	// 	};
	// 	let headclick = dropZoneBoxWrapper.find('.dragdropzone').simulate('drop', { target: { files: [ file ] } });
	// 	expect(DropZoneBox.handleFileSelect).toHaveBeenCalled;
	// });

	// it('should mark items as draggable', function() {
	// 	const fileContents = 'file contents';
	// 	const file = new Blob([ fileContents ], { type: 'text/plain' });
	// 	const event = {
	// 		preventDefault: () => {},
	// 		dropEffect: 'copy'
	// 	};
	// 	let headclick = dropZoneBoxWrapper.find('.dragdropzone').simulate('dragOver', { target: { files: [ file ] } });
	// 	expect(DropZoneBox.handleFileSelect).toHaveBeenCalled;
	// });

	// it('DropZoneBox click handler event ', () => {
	// 	// console.log(dropZoneBoxWrapper.find('.fileInput'));
	// 	const fileContents = 'file contents';
	// 	const file = new Blob([ fileContents ], { type: 'text/plain' });
	// 	const event = {
	// 		preventDefault: () => {},
	// 		stopPropagation: () => {},
	// 		dropEffect: 'copy'
	// 	};
	// 	let headclick = dropZoneBoxWrapper.find('.file_input').simulate('change');
	// 	expect(dropZoneBoxMountWrapper.instance().handleFileSelect(event));
	// 	expect(DropZoneBox.instance().state.dragover).toEqual('dragover');
	// 	expect(DropZoneBox.instance().state.progress).toEqual(100);
	// });

	// it('event handler to be called on  clicking button', () => {
	// 	const event = {target: { value: "Address"}};
	// 	dropZoneBoxWrapper.find('.file_input').simulate('change',event);
	// });
});
