import React from 'react';
import PropTypes from 'prop-types';
import DropZoneBox from './DropZoneBox';
import Output from './Output';
import './FileUpload.css';
import Label from 'vf-ent-ws-label';
import { constStyle, defaultData, constData } from './FileUploadDefData-Props';
import BaseComponent from 'vf-ent-ws-utilities';

export default class FileUpload extends BaseComponent {
  constructor(props) {
    super(props);
    let files = [];
    let output = '';
    this.state = { files, output, fileUrl: '', progress: 100 };
    this.appendThumbnail = this.appendThumbnail.bind(this);
    this.hadleValidationError = this.hadleValidationError.bind(this);
    this.onDelete = this.onDelete.bind(this);
    this.checkUploadProgress = this.checkUploadProgress.bind(this);
  }
  componentWillMount() {
    this.val = this.befRender();
    this.fileUpl = this.renderFileUpload();
  }
  componentDidMount() {
    if (this.props.data.fileDetails !== undefined && this.props.data.fileDetails.files !== undefined) {
      let files = [];
      let output = '';
      files = this.props.data.fileDetails.files;
      output = this.filesStatus(this.props.data.fileDetails.files);
      this.setState({ files, output });
    }
  }
  componentWillReceiveProps(nextProps) {
    this.newData = nextProps;
    if (nextProps.data.hasOwnProperty('fileDetails')) {
      //this.filesStatus(nextProps);
      let output = '';
      if (nextProps.data.fileDetails && nextProps.data.fileDetails.files) {
        output = this.filesStatus(nextProps.data.fileDetails.files);
      }
      this.setState({ files: nextProps.data.fileDetails.files, output });
    }
  }
  filesStatus(files) {
    if (files && files.length > 0) {
      return (
        <div className='list_files'>
          <Output
            files={files}
            onDelete={this.onDelete}
            url={this.state.fileUrl}
            progress={this.state.progress}
            // checkUploadProgress={this.checkUploadProgress}
          />
        </div>
      );
    } else {
      return '';
    }
  }
  onDelete(val) {
    const stateFiles = this.state.files;
    const deletedFiles = stateFiles.splice(val, 1);
    const file = {
      target: {
        id: val,
        file: deletedFiles
      }
    };
    this.delegateHandler(constData.Data.onDelete, file, constData.Data.deleteFile);
    let output = this.filesStatus(stateFiles);
    let noOfUploadedFiles = 0;
    if (stateFiles.length > 0) {
      stateFiles.map((fileList) => {
        if (fileList.length > 0) {
          noOfUploadedFiles++;
        }
      });
    }
    if (noOfUploadedFiles === 0) {
      document.getElementById(this.props.data.id).value = '';
    }
    this.setState({ files: stateFiles, output });
  }
  checkUploadProgress() {
    var check = this.props.data.check();
    this.setState({ progress: check });
  }
  befRender = () => {
    return (
      <div className={constStyle.className.dragHead}>
        <span className={constStyle.className.uploadText}>
          <Label data={this.props.data.label_header_left} />
        </span>
        <span className={constStyle.className.uploadSize}>{this.props.data.max_file}</span>
      </div>
    );
  };

  fileDetails = () => {
    return;
  };

  appendThumbnail(e, f) {
    f._id = Date.now();
    let files = this.state.files;
    if (!files) {
      files = [];
    }
    let newFiles = files.concat([ f ]);
    this.debugLog(e, 'event');
    const E = {
      target: {
        id: e.target.id,
        files: newFiles
      }
    };
    this.delegateHandler(constData.Data.onChange, E, constData.Data.value);
    let output = '';
    if (newFiles) {
      output = this.filesStatus(newFiles);
    }
    this.setState({ files: newFiles, output });
  }
  hadleValidationError(error) {
    const E = {
      target: {
        id: this.props.data.id,
        type: error.type
      }
    };
    console.log('in handleValidation error method of FileUpload  ', error);
    this.delegateHandler('hadleValidationError', E, constData.Data.typevalue);
  }

  renderFileUpload = () => {
    return (
      <DropZoneBox
        url={this.props.data.url}
        data={this.props.data}
        onUploaded={this.appendThumbnail}
        hadleValidationError={this.hadleValidationError}
      />
    );
  };

  render() {
    return (
      <div>
        <div className={constStyle.className.upload_box} id={this.props.data.id}>
          {this.val}
          <div className={constStyle.className.dropZoneBox}>
            <div className={constStyle.className.dropBox}>{this.fileUpl}</div>
          </div>
          {this.state.output && this.state.output}
          {this.props.data.hintText && <Label data={this.props.data.hintText} />}
        </div>
      </div>
    );
  }
}

FileUpload.propTypes = {
  data: PropTypes.shape({
    label_header_left: PropTypes.shape({
      labelname: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired,
      isInline: PropTypes.bool.isRequired,
      fontSizeType: PropTypes.string
    }).isRequired,
    upload_text: PropTypes.string.isRequired,
    drag_drop_text: PropTypes.string.isRequired,
    max_file: PropTypes.string.isRequired,
    or: PropTypes.string.isRequired,
    browser_btn_text: PropTypes.string.isRequired,
    url: PropTypes.string.isRequired,
    getFiles: PropTypes.func.isRequired
  })
};

FileUpload.defaultProps = {
  data: defaultData
};
