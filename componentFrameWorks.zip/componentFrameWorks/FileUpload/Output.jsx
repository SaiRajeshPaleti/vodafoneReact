import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import UploadStatus from './UploadStatus';
import { constStyle, defaultData, constData } from './FileUploadDefData-Props';

const Output = ({files,onDelete}) => {
	let thumbnailNodes = '';
	(files && files[0])
		? (thumbnailNodes = files.map((file, key) => {
				if (file[0])
					return (
						<div key={key} className={constStyle.className.btnBlock}>
							<div className={constStyle.className.raiseBtns}>
								<a className={constStyle.className.roundCircles} title={file[0].name}>
									<span className={constStyle.className.spriteIcon}>
										<Icon name={constStyle.className.iconReport} />
									</span>
								</a>
								<a className={constStyle.className.fileCloseSymbol} title="Cancel">
									<span className={constStyle.className.spriteIcon} onClick={() => onDelete(key)}>
										<span className={constStyle.className.iconClose}>
											<Icon name={constStyle.className.iconCloseName} />
										</span>
									</span>
								</a>
							</div>
							<div className={constStyle.className.fileText}>
								<span className={constStyle.className.spriteIcon}>
									<Icon name={constStyle.className.uploadedIcon} />
								</span>{' '}
								<a href={file[0].url} target="_blank">
									{file[0].name}
								</a>
							</div>
							<div className={constStyle.className.fileText}>
								<p className={constStyle.className.fileSize}>{file[0].size / 1024}KB</p>
							</div>
						</div>
					);
			}))
		: null;
	return <React.Fragment>{thumbnailNodes}</React.Fragment>;
};

export default Output;
