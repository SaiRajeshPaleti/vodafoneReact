export const constStyle = {
	chooseColumns: 'filtering__dropdown dropdown customDropdown choose_columns',
	filteringBtn: 'filtering__dropdown--button dropdown__button',
	dropdownHeading: 'dropdown__heading',
	headingLite: 'dropdown__heading--light',
	dropdownMenu: 'dropdown__panel dropdown__panel--column dropdown-menu display_block',
	// hideMenu: "dropdown__panel dropdown__panel--column dropdown-menu display_none",
	defaultView: 'default-view-button',
	transparentBtn: 'button button--transparent',
	inputForm: 'form__input form__input--checkable form__input--all',
	labelCheckable: 'form__label--checkable filter__label',
	colText: 'columsText',
	priArrows: 'priorityArrows table__chevrons',
	spriteIon: 'sprite__icon down__arrow',
	chevronDown: 'sprite__icon table__chevron table__chevron--down',
	chevronUp: 'sprite__icon table__chevron table__chevron--up',
	displayNone: 'display_none',
	upIconVal: 'chevron-up',
	downIconVal: 'chevron-down',
	chooseLabelBld: 'choose_label',
	downArrow: 'chevron-down'
};

export const defaultData = {
	columns: [
		{
			id: 'data2',	
			name: 'Sample',
			key: 'reference',
			type: 'string',
			isSelected: true,
			sortable: false,
			link: true
		},
	],
	chooseColumnProps: {
		chooseLabel: 'Demo',
		columnLabel: 'columns',
		defaultBtn: {
			id: 'transparent',
			name: 'Sample Button',
			type: 'transparent',
			buttonType: 'button',
			onClick: (value) => { console.log("Button Clicked", value); }
		}
	},
	chooseColumnMethod: (value) => { console.log("Checkbox Clicked", value); }, 
	tooltip: 'Click here to expand or collpse',
	chooseColumn: (value) => {
		console.log(value);
	},
	defaultView: (value) => {
		console.log(value);
	},
	moveDown: (value) => {
		console.log(value);
	},
	moveUp: (value) => {
		console.log(value);
	}
}

