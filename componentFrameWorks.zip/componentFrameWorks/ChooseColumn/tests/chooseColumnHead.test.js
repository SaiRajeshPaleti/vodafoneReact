import React from 'react';
import renderer from 'react-test-renderer';
import chooseColumnHead from '../chooseColumnHead';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import chooseColumnData from '../../../AppData/chooseColumnData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<chooseColumnHead />', function () {
            let props, enzymeWrapper;            
 
			beforeEach(() => {
					props = chooseColumnData;
                    enzymeWrapper = shallow( < chooseColumnHead data = { props } />);
            });
            
			it('Should render column Head', () => {
				expect(enzymeWrapper.find('.dropdown__button')).toBeDefined();
            });
            it('identify render Icon', () => {
				expect(enzymeWrapper.find('Icon').length).not.toBe(null);
            });
								
});