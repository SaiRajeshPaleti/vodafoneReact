import React from 'react';
import renderer from 'react-test-renderer';
import chooseColumnBody from '../chooseColumnBody';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import chooseColumnData from '../../../AppData/chooseColumnData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<chooseColumnBody />', function () {
            let props, enzymeWrapper;            
 
			beforeEach(() => {
					props = chooseColumnData;
					enzymeWrapper = shallow( < chooseColumnBody data = { props } />);
            });
            
			it('Should render column Head', () => {
				expect(enzymeWrapper.find('li')).toBeDefined();
            });
            it('identify render Icon', () => {
				expect(enzymeWrapper.find('Checkbox')).toBeDefined();
            });

								
});