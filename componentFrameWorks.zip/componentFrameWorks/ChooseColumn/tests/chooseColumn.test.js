import React from 'react';
import renderer from 'react-test-renderer';
import ChooseColumn from '../chooseColumn';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import chooseColumnData from '../../../AppData/chooseColumnData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<ChooseColumn />', function () {
            let props, enzymeWrapper;            
 
			beforeEach(() => {
					props = chooseColumnData;
					enzymeWrapper = shallow( < ChooseColumn data = { props } />);
            });
            
			it('Should render column Component', () => {
				expect(enzymeWrapper.find('ChooseColumnHead')).toBeDefined();
            });
            it('identify render Icon', () => {
				expect(enzymeWrapper.find('ul')).toBeDefined();
            });

            it('should show props',() => {
                enzymeWrapper.instance().componentWillReceiveProps(props);
            });
								
});