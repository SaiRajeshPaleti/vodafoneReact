import React from 'react'
import Icon from 'vf-ent-ws-svgicons';
import PropTypes from 'prop-types';
import { constStyle } from './chooseColumnDefData-Props';

const chooseColumnHead = (props) => {
  return (
    <div className={constStyle.filteringBtn} onClick={props.viewColumn}>
        <div className={constStyle.dropdownHeading}>
            <span className={constStyle.chooseLabelBld}>
                {props.chooseColumnProps.chooseLabel}
            </span>&nbsp;
            <span className={constStyle.headingLite}>{props.chooseColumnProps.columnLabel}</span>
        </div>
        <span className={constStyle.spriteIon} title={props.arrowTooltip ? props.arrowTooltip : ''}>
            <Icon name={constStyle.downArrow} />
        </span>
    </div>
  )
}

chooseColumnHead.propTypes = {
    viewColumn: PropTypes.func,
    chooseColumnProps: PropTypes.shape({
        columnLabel: PropTypes.string.isRequired,
        chooseLabel:  PropTypes.string.isRequired
    }).isRequired,
    arrowTooltip: PropTypes.bool
};

export default chooseColumnHead;


