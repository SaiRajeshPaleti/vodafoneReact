import React from 'react';
import Dial from '../Dial';
import {
    mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import DialData from '../../../AppData/DialData';
Enzyme.configure({
    adapter: new Adapter()
});
describe('<Dial/>', function () {
            let props, enzymeWrapper;

            beforeAll(() => {
                    props = DialData;
                    enzymeWrapper = mount( < Dial data = {
                            props[0]
                        }
                        />);
                    });

                it('should render Dial component', () => {
                    expect(enzymeWrapper).not.toBe(null);
                });
                it('should render dailInfo function ', () => {
                    enzymeWrapper.instance().dailInfo(12, true);
                });
            });