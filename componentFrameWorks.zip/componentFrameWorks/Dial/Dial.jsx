import React from 'react';
import './Dial.css';
import SVGCompElement from 'vf-ent-ws-svg';
import PropTypes from 'prop-types';
import { constData, defaultData, classNames } from './DialDefProps';

const Dial_Component = (props) => {
	return props.data.values.type === constData.dialTypeText ? (
		<Dial_New data={props.data} />
	) : (
		<Dial data={props.data} />
	);
};

export const Dial = (props) => {
	constData.components[constData.text1].style = `${constData.strokeText}: ${props.data.values.circleColor}`;
	constData.components[constData.text1].text = props.data.values.text1;
	constData.components[constData.text2].text = props.data.values.text2;
	constData.components[constData.text3].text = props.data.values.text3;
	constData.components[constData.path].strokedasharray = `${props.data.values
		.completionPercentage} ${constData.percentageValue}`;
	const tooltip = props.data.tooltip ? props.data.tooltip : '';

	return (
		<span title={tooltip} className={`${classNames.dialWrapper} ${classNames.dial_svg}`}>
			<svg viewBox={constData.svgDimension} className={props.data.values.circleStyle} onClick={props.data.action}>
				{constData.components.map((component, index) => <SVGElement data={component} key={index} />)}
			</svg>
		</span>
	);
};

export const Dial_New = (props) => {
	let DialPercentage = props.data.values.text1 / props.data.values.total * 100;

	constData.components[constData.text1].text = '';
	constData.components[constData.text2].text = '';
	constData.components[constData.text3].text = '';
	constData.components[constData.path].strokedasharray = `${DialPercentage} ${constData.percentageValue}`;
	const deg = 360 * DialPercentage / 100;

	const styles = {
		transform: `rotate(${deg}deg)`
	};
	return (
		<div className={`${classNames.dialWrapper} ${classNames.circle_bg_varient}`}>
			<div className={classNames.dial_valuewrapper} title={props.data.tooltip} onClick={props.data.action}>
				<div className={classNames.dial__valuelabel}>{props.data.values.text1}</div>
				<div className={classNames.text_wrapper}>
					<div className={classNames.dial__value}>{props.data.values.text2}</div>
					<span className={classNames.activeText}>{props.data.values.text3}</span>
				</div>
			</div>
			<span className={classNames.dial__indicator} style={styles} />
			<svg viewBox={constData.svgDimension} className={props.data.values.circleStyle}>
				{constData.components.map((component, index) => <SVGElement data={component} key={index} />)}
			</svg>
		</div>
	);
};
export const SVGElement = (props) => {
	return SVGCompElement(props.data);
};
Dial.propTypes = {
	data: PropTypes.shape({
		values: PropTypes.shape({
			text1: PropTypes.string,
			text2: PropTypes.string,
			text3: PropTypes.string,
			completionPercentage: PropTypes.string,
			type: PropTypes.string.isRequired,
			circleStyle: PropTypes.string.isRequired
		}).isRequired,
		action: PropTypes.func,
		tooltip: PropTypes.string
	}).isRequired
};

Dial.defaultProps = {
	data: defaultData
};

export default Dial_Component;
