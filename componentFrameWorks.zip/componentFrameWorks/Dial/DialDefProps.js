export const classNames = {
	dial_valuewrapper: 'dial__value-wrapper',
	dial_svg: 'dial__svg-wrapper',
	dial__valuelabel: 'dial__value-label',
	dial__value: 'dial__value',
	dialWrapper: 'dial__wrapper',
	activeText: 'activeText',
	text_wrapper: 'text--wrapper',
	dial__indicator: 'dial__indicator',
	circle_bg_varient: 'circle-bg_varient',
	dial__indicator: 'dial__indicator'
};
export const constData = {
	iconName: 'dial',
	percentageValue: 100,
	strokeText: 'stroke',
	dialTypeText: 'DialReverse',
	svgDimension: '0 0 36 36',
	class: 'circular-chart green',
	text1: 1,
	text2: 2,
	text3: 3,
	circle: 4,
	path: 5,
	components: [
		{
			paths: 'M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831',
			style: '',
			class: 'circle-bg',
			type: 'path'
		},
		{
			paths: '',
			text: '106',
			x: 18,
			y: 15.35,
			class: 'countStyle',
			type: 'text'
		},
		{
			paths: '',
			text: 'Active',
			x: 18,
			y: 20.35,
			class: 'statusStyle',
			type: 'text'
		},
		{
			paths: '',
			text: 'Quotes',
			x: 18,
			y: 25.35,
			class: 'typeStyle',
			type: 'text'
		},
		{
			cx: 50,
			cy: 1.5,
			class: 'progressbar-marker',
			type: 'circle'
		},
		{
			paths: 'M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831',
			strokedasharray: '100, 100',
			class: 'circle',
			type: 'path'
		}
	]
};

export const defaultData = {
	values: {
		text1: '25',
		text2: 'Priority1',
		text3: 'Expired',
		completionPercentage: '50',
		type: 'Dial',
		circleStyle: 'expired_dial'
	},
	action: function submitHandler() {
		console.log('clicked dial with unknown status ');
	},
	tooltip: 'Click here to get the filtered list view'
};
