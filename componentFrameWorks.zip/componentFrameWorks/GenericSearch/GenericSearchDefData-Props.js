export const defaultStyle = {
	gridItem: 'search_order_filter generic_seacrh position_relative search_input',
	close: 'close',
	inputClass: 'input-group__input form__input form__text js-sayt-input input-focus',
	inputClear: 'input-group__clear',
	iconClass: 'sprite__icon search_icon IconsFonts button button--primary search-but generic',
	search: 'search'
};
export const defaultData = {
	onChangeHandler: function changeHandler() {},

	searchIconFont: 'p',
	clearIconFont: '3',

	textField: {
		id: 'search-snack-input',
		name: 'txt1',
		title: '',
		placeholder: 'Enter some text',
		maxLength: 40,
		onChange: (value) => console.log('input value:', value)
	},
	buttonWithIconData: [
		{
			location: 'right',
			id: 'rightIconButton',
			name: 'Right icon button',
			type: 'primary',
			buttonType: 'button',
			isIcon: true
		}
	]
};
