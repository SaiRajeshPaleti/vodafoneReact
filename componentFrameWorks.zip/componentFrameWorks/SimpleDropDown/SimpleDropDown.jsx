import React from 'react';
import { defaultStyles, defaultData, constData } from './SimpleDropDownDefData-Props';
import './SimpleDropDown.css';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import Label from 'vf-ent-ws-label';
import BaseComponent from 'vf-ent-ws-utilities';

class DropdownComponent extends BaseComponent {
  constructor(props) {
    super(props);

    this.resetToDefault = this.resetToDefault.bind(this);
    this.dropDown = this.dropDown.bind(this);
    this.loadInit = this.loadInit.bind(this);
    this.loadContent = this.loadContent.bind(this);

    this.getDropDownList = this.getDropDownList.bind(this);
    this.hideContent = this.hideContent.bind(this);

    this.resetToDefault();
  }

  componentWillMount() {
    this.checkForOptionalProps(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.checkForOptionalProps(nextProps);
  }

  checkForOptionalProps(props) {
    let textToprint = props.data.title;
    props.data.dropdownValues &&
      props.data.dropdownValues.map((test) => {
        if (test.optionValue == props.data.value) textToprint = test.optionName;
      });
    this.setState({
      displayText: textToprint
    });
    this.loadInit();

    this.LabelComponent = props.data.label ? <Label data={props.data.label} /> : '';
    this.LabelHelpText = props.data.helpText ? <Label data={props.data.helpText} /> : '';
  }

  resetToDefault() {
    let textTodisplay = this.props.data.title;
    this.props.data.dropdownValues
      ? this.props.data.dropdownValues.map((test) => {
          if (test.optionValue == this.props.data.value) textTodisplay = test.optionName;
        })
      : null;
    this.state = {
      arrowIcon: false,
      displayText: textTodisplay
    };
  }

  dropDown() {
    this.setState({
      arrowIcon: !this.state.arrowIcon
    });
    const self = this;

    //Hide Dropdown content when click Outside
    document.addEventListener('click', function(evt) {
      let flyoutElement = document.getElementById(self.props.data.id),
        targetElement = evt.target;

      do {
        if (targetElement == flyoutElement) {
          //Click Inside
          return;
        }
        targetElement = targetElement.parentNode;
      } while (targetElement);
      //Click Outside
      self.setState({
        arrowIcon: false
      });
    });
  }

  getDropDownList(label, value) {
    console.log(label, 'event');
    const event = {
      target: {
        id: this.props.data.id,
        value: {
          label: label,
          value: value
        }
      }
    };
    this.delegateHandler('onChange', event, 'value');
    this.setState({
      displayText: label,
      arrowIcon: !this.state.arrowIcon
    });
    // Updated for delegate handler
  }

  hideContent() {
    this.setState({ arrowIcon: false });
  }

  loadInit() {
    return (
      <DropInit
        data={this.props.data}
        text={this.state.displayText}
        arrowIcon={this.state.arrowIcon}
        dropDown={this.dropDown}
      />
    );
  }

  loadContent() {
    if (this.state.arrowIcon) {
      return (
        <DropContent
          data={this.props.data}
          arrowIcon={this.state.arrowIcon}
          getDropDownList={this.getDropDownList}
          hideContent={this.hideContent}
        />
      );
    } else {
      return '';
    }
  }

  render() {
    return (
      <div
        id={this.props.data.id}
        name={this.props.data.name}
        className={`${defaultStyles.cusDropDown} ${this.state.arrowIcon ? defaultStyles.activeWrapperCls : ''}`}
      >
        {this.LabelComponent}
        {this.loadInit()}
        {this.loadContent()}
        {this.LabelHelpText}
      </div>
    );
  }
}

const DropInit = ({ data, arrowIcon, dropDown, text }) => (
  <div
    className={arrowIcon ? defaultStyles.activeCls : defaultStyles.inactiveCls}
    title={data.title}
    onClick={dropDown}
  >
    <div className={defaultStyles.heading}>
      <span>{text}</span>
    </div>
    <span className={defaultStyles.Sprite}>
      <Icon name={defaultStyles.iconName} />
    </span>
  </div>
);

const DropContent = ({ data, hideContent, arrowIcon, getDropDownList }) => (
  <div className={arrowIcon ? defaultStyles.activeRelativeCls : defaultStyles.display_none} onClick={hideContent}>
    <ul className={defaultStyles.listRest}>
      {data.dropdownValues ? (
        data.dropdownValues.map((dropDownData, index) => (
          <li key={index} onClick={() => getDropDownList(dropDownData.optionName, dropDownData.optionValue)}>
            {dropDownData.optionName}
          </li>
        ))
      ) : (
        ''
      )}
    </ul>
  </div>
);

DropdownComponent.propTypes = {
  data: PropTypes.shape({
    id: PropTypes.string,
    name: PropTypes.string,
    clickTxt: PropTypes.string,
    title: PropTypes.string,
    dropdownValues: PropTypes.arrayOf(
      PropTypes.shape({
        optionName: PropTypes.string.isRequired,
        optionValue: PropTypes.string
      })
    ),
    onChange: PropTypes.func
  })
};

export default DropdownComponent;
