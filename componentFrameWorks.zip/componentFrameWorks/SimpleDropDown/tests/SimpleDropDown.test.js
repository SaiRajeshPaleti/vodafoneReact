import React from 'react';
import DropdownComponent from '../SimpleDropDown';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Data from './../../../AppData/simpleDropDownData';

Enzyme.configure({ adapter: new Adapter() });


describe('<DropdownComponent />', function () {
    let props, enzymeWrapper;

    beforeAll(() => {
        props = Data;
        enzymeWrapper = mount(<DropdownComponent data={props} />);
    });

    it('Dropdown Component contains  div', () => {
        expect(enzymeWrapper.find('div').length).toEqual(3);
    });
    it('Dropdown Component should render dropdown box', () => {
        expect(enzymeWrapper.instance().loadInit()).toBeDefined;
        expect(enzymeWrapper.find('DropInit').length).toEqual(1);
    });
    it('tries to test ternary',() => {        
        enzymeWrapper.instance().dropDown();
        enzymeWrapper.setState({ arrowIcon: false }); 
        expect(enzymeWrapper.state().arrowIcon).toBeDefined;
    });
    it('Dropdown Component should render dropdown content', () => {
        expect(enzymeWrapper.instance().loadContent()).toBeDefined;
        expect(enzymeWrapper.instance().getDropDownList).toBeDefined;
    });
 
    it('should load content',() => {
        enzymeWrapper.instance().loadContent()
        enzymeWrapper.setState({ arrowIcon: 'bar' });      
    });
    it('should hide Content',() =>{
        enzymeWrapper.instance().hideContent();
        enzymeWrapper.setState({ arrowIcon: false }); 
        expect(enzymeWrapper.state().arrowIcon).toBe(false);
    });
    
    it('should receive props',() =>{        
        enzymeWrapper.setProps({ props });
        enzymeWrapper.instance().componentWillReceiveProps(props);
    });
});


