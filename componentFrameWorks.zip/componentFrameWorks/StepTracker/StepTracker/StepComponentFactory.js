import React from 'react';
import { getContent } from './StepRegistry';

const StepComponentFactory = (key, fieldData, handler, type) => {
	const ComponentContent = getContent(type);
	return <ComponentContent key={key} index={key} tracker={fieldData} clickStep={handler} trackerType={type} />;
};
export default StepComponentFactory;
