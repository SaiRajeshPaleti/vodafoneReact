export const constStyles = {
	stepTracker: 'cove_steptracker',
	orderTracker: 'cove_steptracker order__step__tracker',
	supportingText: 'card__supporting-text',
	stepDone: 'op_steptracker__step step-done',
	activeStep: 'op_steptracker__step active-step',
	untouchedStep: 'op_steptracker__step',
	title: 'stepper1-title',
	stepperContainer:'stepper-title',
	circle: 'stepper-circle',
	spriteIcon: 'sprite__icon',
	lineWrapper: 'cove_line-wrapper',
	line: 'cove_line',
	lineGreen: 'arrow_sym arrow_sys_prev',
	lineGrey: 'arrow_sym arrow_sys_after',
	completeStepIcon: 'tick',
	stepText: 'step-txt'
};
export const constData = {
	onClickProperty: 'onClick'
};
export const defaultData = {
	stepImplementation: function stepImplementation() {
		// step implementation goes here
		//console.log('step clicked');
	},
	id: '1',
	name: 'Step Tracker',
	type: 'stepTracker',
	data: [
		{ id: '1', name: 'Site 1 Details', stepNo: '1', isComplete: true, isActive: false },
		{ id: '2', name: 'Site 2 Details', stepNo: '2', isComplete: false, isActive: true },
		{ id: '3', name: 'Site 3 Details', stepNo: '3', isComplete: false, isActive: false }
	]
};
