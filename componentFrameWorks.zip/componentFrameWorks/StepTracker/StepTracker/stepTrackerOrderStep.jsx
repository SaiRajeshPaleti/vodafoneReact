import React from 'react';
import './stepTracker.css';
import { constStyles } from './stepTrackerDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
const StepTrackerOrderStep = (props) => {
	return (
		<div
			onClick={() => props.clickStep(props.index, props.tracker)}
			className={
				props.tracker.isComplete ? (
					constStyles.stepDone
				) : (
					`${props.tracker.isActive ? constStyles.activeStep : constStyles.untouchedStep}`
				)
			}
		>
			<div className={constStyles.stepperContainer}>
				<div className={constStyles.circle}>
					<span className={constStyles.spriteIcon}>
						<Icon name={props.tracker.icon} />
					</span>
				</div>
				<span
					className={
						props.tracker.isComplete || props.tracker.isActive ? (
							constStyles.lineGreen
						) : (
							constStyles.lineGrey
						)
					}
				/>
				<div className={constStyles.title}>{props.tracker.name}</div>
			</div>
		</div>
	);
};
export default StepTrackerOrderStep;
