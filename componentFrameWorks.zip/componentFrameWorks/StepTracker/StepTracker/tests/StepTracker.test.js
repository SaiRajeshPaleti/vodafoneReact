import React from 'react';
import renderer from 'react-test-renderer';
import { shallow ,mount} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import StepTracker from './../stepTrackerComponent';
import StepTrackerStep from './../stepTrackerStep';
import StepTrackerOrderStep from './../stepTrackerOrderStep';


Enzyme.configure({ adapter: new Adapter() });

describe('<StepTracker test cases />', function() {
    let enzymeWrapper, props;
  
    beforeEach(() => {
		props = {
     data:{
      onClick: function onClick(step) {
        // step implementation goes here
       
      },
      id: '1',
      name: 'Step Tracker',
      type: 'stepTracker',
      data :[
        { id: '1', name: 'Site 1 Details', stepNo: '1', isComplete: true, isActive: false},
        { id: '2', name: 'Site 2 Details', stepNo: '2', isComplete: true, isActive: false },
        { id: '3', name: 'Site 3 Details', stepNo: '3', isComplete: false, isActive: true },
        { id: '4', name: 'Site 4 Details', stepNo: '4', isComplete: false, isActive: false },
        { id: '5', name: 'Site 5 Details', stepNo: '5', isComplete: false, isActive: false },
        { id: '6', name: 'Site 6 Details', stepNo: '6', isComplete: false, isActive: false }
          ]
          
     }
    };
    enzymeWrapper = shallow(<StepTracker {...props} />);
    });

  	it('should render StepTracker component', () => {
      expect(enzymeWrapper).not.toBe(null);
    });

    it('should show StepTracker props', () => {
      enzymeWrapper.instance().componentWillReceiveProps(props);
    });
      
    it('should StepTracker resetData', () => {
        enzymeWrapper.instance().resetData(props.data);
      });
          
    it('should StepTracker clickStep', () => {
      let clickstepprops;
      clickstepprops = {
        step:{
               id: '1',
              name: 'Step Tracker'    
             }
       };
        enzymeWrapper.instance().clickStep('1',clickstepprops.step);
      });    
      
    it('should show StepTracker componentDidMount', () => {
      enzymeWrapper.instance().componentDidMount(props);
    });
});

describe('<StepTrackerStep/>', function () {  

  let StepTrackerWrapper, StepTrackerProps;

      beforeEach(() => {
      StepTrackerProps = {
        clickStep: (id, test) => {
        
        },
       tracker:{
        onClick: function onClick(step) {
          // step implementation goes here
          
        },
        id: '1',
        name: 'Step Tracker',
        type: 'stepTracker',
        data :[
          { id: '1', name: 'Site 1 Details', stepNo: '1', isComplete: true, isActive: false},
          { id: '2', name: 'Site 2 Details', stepNo: '2', isComplete: true, isActive: false },
          { id: '3', name: 'Site 3 Details', stepNo: '3', isComplete: false, isActive: true },
          { id: '4', name: 'Site 4 Details', stepNo: '4', isComplete: false, isActive: false },
          { id: '5', name: 'Site 5 Details', stepNo: '5', isComplete: false, isActive: false },
          { id: '6', name: 'Site 6 Details', stepNo: '6', isComplete: false, isActive: false }
            ]
            
       }
      };
      StepTrackerWrapper = shallow(<StepTrackerStep {...StepTrackerProps} />);
      });
    it('should render StepTrackerStep component', () => {
      expect(StepTrackerWrapper).not.toBe(null);
    });
  

    it('should call handleMouseEnter', () => {
      expect(StepTrackerWrapper.instance().handleMouseEnter()).toHaveBeenCalled;
    });

    it('should call handleMouseLeave', () => {
      expect(StepTrackerWrapper.instance().handleMouseLeave()).toHaveBeenCalled;
    });  
    it('StepTrackerOrderStep click handler event ', () => {
      StepTrackerWrapper.find('div').at(0).simulate('click');
     });
  
});

  
  describe('<StepTrackerOrderStep />', function () {
    let props, enzymeWrapper;
    
    beforeEach(() => {
      props = {
        clickStep: (id, test) => {
          
        },
       tracker:{
        onClick: function onClick(step) {
          // step implementation goes here
          
        },
        id: '1',
        name: 'Step Tracker',
        type: 'stepTracker',
        data :[
          { id: '1', name: 'Site 1 Details', stepNo: '1', isComplete: true, isActive: false},
          { id: '2', name: 'Site 2 Details', stepNo: '2', isComplete: true, isActive: false },
          { id: '3', name: 'Site 3 Details', stepNo: '3', isComplete: false, isActive: true },
          { id: '4', name: 'Site 4 Details', stepNo: '4', isComplete: false, isActive: false },
          { id: '5', name: 'Site 5 Details', stepNo: '5', isComplete: false, isActive: false },
          { id: '6', name: 'Site 6 Details', stepNo: '6', isComplete: false, isActive: false }
            ],
            
            
       }
      };
      enzymeWrapper = shallow(<StepTrackerOrderStep {...props} />);
      }); 
         it('should render the div',() => {
              expect(enzymeWrapper.find('div')).toBeDefined;

           });        

        it('StepTrackerOrderStep click handler event ', () => {
         enzymeWrapper.find('div').at(0).simulate('click');
        });
    
  });