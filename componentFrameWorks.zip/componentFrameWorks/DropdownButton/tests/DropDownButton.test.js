import React from 'react';
import dropDownButtonData from '../../../AppData/DropDownButtonData';
import DropDownButtons from '../DropDownButton';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<DropDownButtons/>', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		enzymeWrapper = mount(<DropDownButtons data={dropDownButtonData} />);
	});

	it('Drop Down Button  main div', () => {
		expect(enzymeWrapper.find('.customDropdown').length).toEqual(1);
	});

	it('Drop Down Button Heading', () => {
		expect(enzymeWrapper.find('.dropdown__heading').text()).toEqual('Click me');
	});

	it('Drop Down lable Input to be Check box', () => {
		expect(enzymeWrapper.find('.dropdown__heading').type()).toBe('div');
	});

	it('To be Check box in drop down ', () => {
		expect(enzymeWrapper.find('.dropdown__heading').type()).toBe('div');
	});

	it('event handler to be called on onClick for dropdown toggle', () => {
		const dropdownArr = enzymeWrapper.find('.filtering__dropdown--button');
		dropdownArr.simulate('click');
		expect(DropDownButtons.dropDown).toHaveBeenCalled;
	});

	it('Drop Down Label contains Single Check all check box', () => {
		expect(enzymeWrapper.find('.f__left').length).toBe(1);
	});

	it('event handler to be called on click', () => {
		let dropdown = enzymeWrapper.find('.filtering__dropdown--button');
		dropdown.simulate('click');
		let checkbox = enzymeWrapper.find('.litest').first();
		checkbox.simulate('click');
		expect(enzymeWrapper.instance().checkFn).toHaveBeenCalled;
	});

	it('Drop down button  contains  main check box Component', () => {
		expect(enzymeWrapper.find('.filtering__dropdown--button').length).toBe(1);
	});

	it('tries to test ternary', () => {
		let dropdown = enzymeWrapper.find('.filtering__dropdown--button');
		expect(enzymeWrapper.state().arrowIcon).toBe(true);
		dropdown.simulate('click');
		expect(enzymeWrapper.find('.active').length).toBe(1);
		expect(enzymeWrapper.state().arrowIcon).toBe(false);
	});
});
