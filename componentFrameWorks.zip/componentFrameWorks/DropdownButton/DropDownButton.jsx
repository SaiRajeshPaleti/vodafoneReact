import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import RadioButton from 'vf-ent-ws-radiobutton';
import CheckBox from 'vf-ent-ws-checkbox';
import { defaultStyles, defaultData, constData } from './DropDownButtonDefData-Props';
import './DropDownButton.css';

class DropDownButtons extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			arrowIcon: true,
			popupVisible: true,
			isFlag: true
		};

		this.setWrapperRef = this.setWrapperRef.bind(this);
		this.handleClickOutside = this.handleClickOutside.bind(this);
		this.dropDown = this.dropDown.bind(this);
		this.checkFn = this.checkFn.bind(this);
		this.loadInit = this.loadInit.bind(this);
		this.loadContent = this.loadContent.bind(this);
		this.returnValue = new Array(this.props.data.dropdownButtonValues.length);
		this.returnValue.fill(false);
	}
	componentWillMount() {
		this.init = this.loadInit();
	}
	componentDidMount() {
		document.addEventListener(constData.dropDownContentType.event, this.handleClickOutside);
	}
	componentWillUnmount() {
		document.removeEventListener(constData.dropDownContentType.event, this.handleClickOutside);
	}
	componentWillUpdate() {
		this.content = this.loadContent();
	}

	setWrapperRef(node) {
		this.wrapperRef = node;
	}
	dropDown() {
		this.setState({
			popupVisible: true,
			arrowIcon: !this.state.arrowIcon
		});
	}
	handleClickOutside(event) {
		if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
			this.setState(
				{
					isFlag: false,
					arrowIcon: true
				},
				() => {
					this.content = this.loadContent(this.state.isFlag, this.state.arrowIcon);

					this.setState({
						isFlag: true
					});
				}
			);
		}
	}
	checkFn(e) {
		this.returnValue[e.id - 1] = e.value;
		this.props.data.checkedElements(this.returnValue);
		this.props.handler ? this.props.handler(e) : '';
	}

	loadInit() {
		return <DropInit data={this.props.data} arrowIcon={this.state.arrowIcon} dropDown={this.dropDown} />;
	}
	loadContent(isFlag, isArrow) {
		return (
			<DropContent
				data={this.props.data}
				arrowIcon={isArrow ? isArrow : this.state.arrowIcon}
				checkFn={this.checkFn}
				popupVisible={this.state.popupVisible}
				isFlag={isFlag === false ? isFlag : this.state.isFlag}
			/>
		);
	}

	render() {
		return (
			<div
				id={this.props.data.id}
				ref={this.setWrapperRef}
				name={this.props.data.name}
				className={defaultStyles.cusDropDown}
			>
				{this.init}
				{this.content}
			</div>
		);
	}
}

const DropInit = ({ data, arrowIcon, dropDown }) => (
	<div
		className={arrowIcon ? defaultStyles.activeCls : defaultStyles.inactiveCls}
		title={data.title}
		onClick={dropDown}
	>
		<div className={defaultStyles.heading}>
			<span>{data.clickTxt}</span>
		</div>
		<span className={defaultStyles.Sprite}>
			<Icon name={defaultStyles.iconName} />
		</span>
	</div>
);

const DropContent = ({ data, arrowIcon, checkFn, popupVisible, isFlag }) => {
	return (
		<div className={arrowIcon && isFlag === true ? defaultStyles.activeRelativeCls : defaultStyles.display_none}>
			<ul className={defaultStyles.listRest}>
				{data.dropdownButtonValues.map((dropDownData) => (
					<li key={dropDownData.id}>
						{data.dropDownButtonType === constData.dropDownContentType.radioType ? (
							<RadioButton data={Object.assign({}, dropDownData, { onChange: checkFn })} />
						) : data.dropDownButtonType === constData.dropDownContentType.checkType ? (
							<CheckBox data={Object.assign({}, dropDownData, { onChange: checkFn })} />
						) : (
							''
						)}
					</li>
				))}
			</ul>
		</div>
	);
};

DropDownButtons.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		name: PropTypes.string,
		dropDownButtonType: PropTypes.string,
		clickTxt: PropTypes.string,
		title: PropTypes.string,
		checkedElements: PropTypes.func,
		dropdownButtonValues: PropTypes.arrayOf(
			PropTypes.shape({
				name: PropTypes.string.isRequired,
				id: PropTypes.string.isRequired,
				checked: PropTypes.bool,
				tooltip: PropTypes.string,
				displayValue: PropTypes.string
			})
		)
	})
};

DropDownButtons.defaultProps = {
	data: defaultData
};

export default DropDownButtons;
