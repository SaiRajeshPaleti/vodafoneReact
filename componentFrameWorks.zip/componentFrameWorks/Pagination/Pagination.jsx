import React from 'react';
import paginationStyles from './PaginationDefData-Props';
import './Pagination.css';
import PropTypes from 'prop-types';
import Content from './Content';
import BaseComponent from 'vf-ent-ws-utilities';

class Pagination extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      currentPage: 0,
      totalNoPages: 0
    };
    this.enterKeyPress = true;

    this.prevPageClick = this.prevPageClick.bind(this);
    this.nextPageClick = this.nextPageClick.bind(this);
    this.onChange = this.onChange.bind(this);
    this.sendData = this.sendData.bind(this);
    this.getPaginationData = this.getPaginationData.bind(this);
  }
  componentWillMount() {
    this.getPaginationData(this.props);
  }
  componentWillReceiveProps(nextProps) {
    this.getPaginationData(this.props);
  }
  getPaginationData(props) {
    this.setState({
      currentPage: this.props.data.pagenumber,
      totalNoPages: this.props.data.totalPages
    });
  }
  nextPageClick(event) {
    let paginationData = { ...this.state };
    let currPage = paginationData.currentPage;
    let totalPages = paginationData.totalNoPages;
    if (currPage >= 0 && currPage < totalPages) {
      currPage++;
      this.delegateHandler(paginationStyles.constData.getCurrentPage, currPage, this.sendData);
      this.setState({ currentPage: currPage });
    }
  }

  prevPageClick(event) {
    let paginationPrevData = { ...this.state };
    let currPagePrev = paginationPrevData.currentPage;
    let totalPages = paginationPrevData.totalNoPages;
    if (currPagePrev <= totalPages && currPagePrev >= 2) {
      currPagePrev = currPagePrev - 1;
      this.delegateHandler(paginationStyles.constData.getCurrentPage, currPagePrev, this.sendData);
      this.setState({ currentPage: currPagePrev });
    }
  }
  onChange(event) {
    const totalPages = this.props.data.totalPages;

    this.enterKeyPress = false;

    if (event.key === 'Enter' && event.target.value != '') {
      this.enterKeyPress = true;
      if (event.target.value <= totalPages && event.target.value != 0) {
        this.delegateHandler(paginationStyles.constData.getCurrentPage, event.target.value, this.sendData);
      }
    }

    if (event.target.value <= totalPages && event.target.value != '' && event.target.value != 0) {
      this.setState({
        currentPage: event.target.value,
        enterKeyPress: event.key
      });
    }
  }

  sendData(event) {
    return event;
  }
  render() {
    const PaginationData = {
      prevPageClick: this.prevPageClick,
      nextPageClick: this.nextPageClick,
      currentPage: this.state.currentPage,
      onChange: this.onChange,
      totalPages: this.state.totalNoPages,

      enterKeyPress: this.enterKeyPress
    };
    return (
      <div>
        <nav className={paginationStyles.constStyles.mainCls}>
          <div className={paginationStyles.constStyles.componentCls}>
            <div className={paginationStyles.constStyles.pagination}>
              <div className={paginationStyles.constStyles.springCls} />
              <Content data={PaginationData} />
            </div>
          </div>
        </nav>
      </div>
    );
  }
}

Pagination.propTypes = {
  data: PropTypes.shape({
    pagenumber: PropTypes.number.isRequired,
    totalPages: PropTypes.number.isRequired,
    getPaginationData: PropTypes.func
  }).isRequired
};

export default Pagination;
