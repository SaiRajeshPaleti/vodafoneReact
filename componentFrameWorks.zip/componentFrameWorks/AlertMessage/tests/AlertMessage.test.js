import React from 'react';
import AlertMessage from '../AlertMessage';
import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import AlertMessageData from '../../../AppData/AlertMessageData';

Enzyme.configure({ adapter: new Adapter() });

describe('<AlertMessage />', function() {
	// let props={type:"warning",arrowRequired:false,messageTitle:"Title",messageBody:"message",backgroundRequired:true}
	let props, enzymeWrapper;
	beforeAll(() => {
		props = AlertMessageData.messagedata;
		props.forEach((prop) => {
			enzymeWrapper = shallow(<AlertMessage message={prop} />);
		});
	});

	it('contains divs', () => {
		expect(enzymeWrapper.find('.spring').length).toBe(1);
	});

	it('contains h1 in divs', () => {
		expect(enzymeWrapper.find('.spring').childAt(0).type()).toBe('h1');
	});
});
