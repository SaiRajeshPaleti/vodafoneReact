export const constStyles = {
	arrowStyle: 'arrowStyle',
	bgStyle: 'bgStyle',
	class: {
		mainClass: 'spring',
		warning: 'alert_notifications warning_msgs',
		info: 'alert_notifications info_msgs',
		alert: 'alert_notifications',
		arrowStyle: 'alert_msg_arr',
		bgStyle: 'alert_notifications_light',
		linkUnderline: 'text-underline'
	},
	data: {
		warning: 'Warning Messages',
		info: 'Information Messages',
		alert: 'Alert Messages',
		alertIcon: 'alert_notifications_icon sprite__icon'
	},
	icon: {
		warning: 'block',
		info: 'info',
		alert: 'warning'
	},
	isVaidate: 'validate_msg'
};

export const defaultData = {
	type: 'warning',
	name: 'warning',
	id: 'd_w',
	lightBackground: false,
	arrowRequired: false,
	messageTitle: 'Please Enter the content',
	messageBody: 'Please pass the appropriate data',
	showHeader: false
};
