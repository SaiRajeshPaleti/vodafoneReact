import React from 'react';
import PropTypes from 'prop-types';
import { constStyles, defaultData } from './LabelDefData-Props';
import './labelComponent.css';
import LabelComponentFactory from './LabelComponentFactory';
import BaseComponent from 'vf-ent-ws-utilities';

class LabelComponent extends BaseComponent {
	constructor(props){
		super(props);
		this.state={
			data:props.data
		}
	}
	componentWillReceiveProps(nextProps){
		let data=JSON.parse(JSON.stringify(nextProps.data));
		this.setState({
			data:data
		});
	}
	render() {
		return LabelComponentFactory(this.state.data)
	}
}

LabelComponent.defaultProps = {
	data: defaultData
}; 

LabelComponent.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		labelname: PropTypes.string.isRequired,
		htmlFor: PropTypes.string,
		type: PropTypes.oneOf(constStyles.labelTypes).isRequired,
		isRequired: PropTypes.bool
	}).isRequired
};

export default LabelComponent;
