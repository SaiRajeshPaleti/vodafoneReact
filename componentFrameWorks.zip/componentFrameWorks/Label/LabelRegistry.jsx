import { LabelHelperLightXS } from './LabelVariations';
import { LabelHelperLightSM } from './LabelVariations';
import { LabelHelperDarkXS } from './LabelVariations';
import { LabelHelperDarkSM } from './LabelVariations';
import { LabelDefault } from './LabelVariations';
import { LabelCenter } from './LabelVariations';
import { LabelRight } from './LabelVariations';
import { LabelRequiredDefault } from './LabelVariations';
import { LabelRequiredCenter } from './LabelVariations';
import { LabelRequiredRight } from './LabelVariations';
import { LabelHeadingDefault } from './LabelVariations';
import { LabelHeadingCenter } from './LabelVariations';
import { LabelHeadingRight } from './LabelVariations';
import { LabelHeadingNBDefault } from './LabelVariations';
import { LabelHeadingNBCenter } from './LabelVariations';
import { LabelHeadingNBRight } from './LabelVariations';
import { LineNoMargin } from './LabelVariations';

const LabelRegistry = {
	labelHelperLightXS: LabelHelperLightXS,
	labelHelperLightSM: LabelHelperLightSM,
	labelHelperDarkXS: LabelHelperDarkXS,
	labelHelperDarkSM: LabelHelperDarkSM,
	labelDefault: LabelDefault,
	labelCenter: LabelCenter,
	labelRight: LabelRight,
	labelRequiredDefault: LabelRequiredDefault,
	labelRequiredCenter: LabelRequiredCenter,
	labelRequiredRight: LabelRequiredRight,
	labelHeadingDefault: LabelHeadingDefault,
	labelHeadingCenter: LabelHeadingCenter,
	labelHeadingRight: LabelHeadingRight,
	labelHeadingNBDefault: LabelHeadingNBDefault,
	labelHeadingNBCenter: LabelHeadingNBCenter,
	labelHeadingNBRight: LabelHeadingNBRight,
	lineNoMargin:LineNoMargin
};
export function getContent(type) {
	if (!(type in LabelRegistry)) {
		type = 'labelDefault';
	}
	return LabelRegistry[type];
}
