import React from 'react';
import LabelComponent from '../labelComponent';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Data from './../../../AppData/LabelData';
import { CommonLabel, LabelHelperLightXS, LabelHelperDarkXS, LabelHelperDarkSM, LabelCenter, LabelRight, LabelRequiredDefault, LabelRequiredCenter, LabelRequiredRight, LabelHeadingDefault, LabelHeadingCenter, LabelHeadingRight, LabelHeadingNBDefault, LabelHeadingNBCenter, LabelHeadingNBRight } from './../LabelVariations';
Enzyme.configure({ adapter: new Adapter() });

describe('<LabelComponent/>', function() {
	let props, enzymeWrapper;

	props = {
		data: {
			id: 'label02',
			type: 'labelHelperLightSM',
			htmlFor: '',
			labelname: 'Please confirm if you need a new VLAN or use existing VLAN'
		}
	};	

	beforeAll(() => {
		enzymeWrapper = mount(<LabelComponent data={props} />);
	});

	it('should render LabelComponent component', () => {
		expect(enzymeWrapper).not.toBe(null);
	});
	
	it('Label Component should render div', () => {		 		     
        expect(enzymeWrapper.find('div').length).toBe(1);
	});

	it('should render componentWillReceiveProps function', () => {		 		     
        enzymeWrapper.instance().componentWillReceiveProps(props);
	});

});

describe('<CommonLabel/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<CommonLabel { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHelperLightXS/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHelperLightXS { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHelperDarkXS/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHelperDarkXS { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHelperDarkSM/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHelperDarkSM { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelCenter/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelCenter { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelRight/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelRight { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelRequiredDefault/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelRequiredDefault { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelRequiredCenter/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelRequiredCenter { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelRequiredRight/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelRequiredRight { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHeadingDefault/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHeadingDefault { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHeadingCenter/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHeadingCenter { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHeadingRight/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHeadingRight { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHeadingNBDefault/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHeadingNBDefault { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHeadingNBCenter/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHeadingNBCenter { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});

describe('<LabelHeadingNBRight/>', function() {
	let commonLabelWrapper, props;

	props = {
		data: {
			id: '12',
			fontSizeType: true,
			className: true,
			isRequired: true,
			isInline: true,
			styling: 'test',
			htmlFor: 'test',
			labelname: 'test'
		},
		helperFontClass: 'italic',
		wrapperStyling: 'test'
	}

	beforeAll(() => {
		commonLabelWrapper = mount(<LabelHeadingNBRight { ... props } />);
	});

	it('should render CommonLabel component', () => {
		expect(commonLabelWrapper).not.toBe(null);
	});
	
});
