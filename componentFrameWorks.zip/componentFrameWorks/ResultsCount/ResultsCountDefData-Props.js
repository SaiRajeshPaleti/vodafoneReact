export const constStyles = {
	gridItem: 'grid__item grid__item--gutter customDisplay',
	paginationInfo: 'pagination-info itemCount',
	mr10: 'm-r-10',
	reg: 'regularClass',
	bold: 'boldClass'
};
