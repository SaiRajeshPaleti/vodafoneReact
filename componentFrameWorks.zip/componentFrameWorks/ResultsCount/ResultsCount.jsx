import React from 'react';
import { constStyles } from './ResultsCountDefData-Props';
import './ResultsCount.css';
import BaseComponent from 'vf-ent-ws-utilities';

class ResultsCount extends BaseComponent {
  constructor(props) {
    super(props);
    this.prepareData = this.prepareData.bind(this);
  }
  componentWillMount() {
    this.prepareData(this.props.data);
  }
  componentWillReceiveProps(nextProps) {
    this.prepareData(nextProps.data);
  }
  prepareData(data) {
    this.setState({
      data: data
    });
  }
  render() {
    return (
      <div className={constStyles.gridItem}>
        <div className={constStyles.paginationInfo}>
          {
            <p>
              <span className={constStyles.reg}>{this.state.data.labels.label1}</span>
              <span className={constStyles.bold}>
                {this.state.data.pageIndex * this.state.data.noOfResultsPerPage + 1}-{this.state.data.pageIndex *
                  this.state.data.noOfResultsPerPage +
                  this.state.data.noOfResults}
              </span>
              {this.state.data.labels.label2 && (
                <span className={constStyles.reg}>{this.state.data.labels.label2}</span>
              )}
              {this.state.data.totalNumberOfResults && (
                <span className={constStyles.bold}>{this.state.data.totalNumberOfResults}</span>
              )}
              <span className={constStyles.reg}>{this.state.data.labels.label3}</span>
            </p>
          }
        </div>
      </div>
    );
  }
}
export default ResultsCount;
