import React from 'react';
import renderer from 'react-test-renderer';
import ResultsCount from '../ResultsCount';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import resultsCountData from '../../../AppData/resultsCountData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<ResultsCount />', function () {
            let props, enzymeWrapper;
            
 
			beforeEach(() => {
					props = resultsCountData;
					enzymeWrapper = shallow( <ResultsCount data = { props } />);
					});

				it('Should render Results Count component', () => {
					expect(enzymeWrapper.find('div').length).toBe(2);
				});

				it('Should render the result count in paragraph', () => {
					expect(enzymeWrapper.find('p').length).not.toBe(null)	;
				});
				
			});