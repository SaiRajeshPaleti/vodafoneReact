import React from 'react';
import { constStyles, constData, defaultData } from './checkBoxDefData-Props';
import './checkBox.css';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class CheckBox extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			checked: props.data.value ? 'checked' : '',
			disabled: props.data.disabled ? true : false
		};
		this.onChange = this.onChange.bind(this);
	}

	componentWillReceiveProps(nextprops) {
		this.setState({
			checked: nextprops.data.value ? 'checked' : '',
			disabled: nextprops.data.disabled ? true : false
		});
	}
	onChange(event) {
		if (this.state.checked === 'checked') {
			this.setState({ checked: '' });
		} else {
			this.setState({ checked: 'checked' });
		}
		this.delegateHandler(constData.onChangeProperty, event, constData.checked);
	}
	render() {
		return (
			<div className={constStyles.checkBoxClass}>
				<input
					type={constData.inputType}
					name={this.props.data.name}
					className={constStyles.boxClass}
					id={this.props.data.id}
					onChange={this.onChange}
					checked={this.state.checked}
					title={this.props.data.tooltip}
					disabled={this.state.disabled}
				/>
				<p htmlFor={this.props.data.checkBoxId} className={constStyles.checkBoxTextClass}>
					{this.props.data.displayValue}
				</p>
			</div>
		);
	}
}

CheckBox.propTypes = {
	data: PropTypes.shape({
		name: PropTypes.string.isRequired,
		id: PropTypes.string.isRequired,
		checked: PropTypes.bool,
		tooltip: PropTypes.string,
		displayValue: PropTypes.string,
		onChange: PropTypes.func.isRequired
	}).isRequired
};
CheckBox.defaultProps = {
	data: defaultData
};

export default CheckBox;
