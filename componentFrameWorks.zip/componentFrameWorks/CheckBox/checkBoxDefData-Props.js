export const constStyles = {
    checkBoxClass: 'label_box',
    checkBoxTextClass: 'checkboxtext',
    boxClass: 'check'
};
export const constData = {
    inputType: 'checkbox',
    onChangeProperty: 'onChange',
    checked: 'checked'
};
export const defaultData = {
    onChange: function onChange(event) {
        //Method Implementation goes here
        //console.log(' I am in CheckBox data function');
    },
    id: '1',
    name: 'checkbox',
    tooltip: 'Click on CheckBox to select',
    displayValue: 'Check Box Text'
};
