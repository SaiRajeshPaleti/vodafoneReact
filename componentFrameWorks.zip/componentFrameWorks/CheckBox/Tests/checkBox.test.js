import React from 'react';
import renderer from 'react-test-renderer';
import CheckBox from '../checkBox';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import CheckBoxData from '../../../AppData/checkBoxData';

Enzyme.configure({ adapter: new Adapter() });

describe('<CheckBox />', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = CheckBoxData;
		enzymeWrapper = shallow(<CheckBox data={props} />);
	});

	it('verifying number of divisions', () => {
		expect(enzymeWrapper.find('div').length).toBe(1);
	});
	it('verifying input field', () => {
		expect(enzymeWrapper.find('div').childAt(0).type()).toBe('input');
	});
	it('Check Component contains CHeck OnChange', () => {
		let check = enzymeWrapper.find('input');
		check.simulate('change');
		expect(check.onChange).toHaveBeenCalled;
	});
});
