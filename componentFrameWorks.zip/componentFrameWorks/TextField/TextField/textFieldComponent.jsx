import React from 'react';
import { constStyles, constData, defaultData } from './textFieldDefData-Props';
import PropTypes from 'prop-types';
import './textField.css';
import Label from 'vf-ent-ws-label';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';

class TextField extends BaseComponent {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.handleKeyPress = this.handleKeyPress.bind(this);
    this.applicableClass = props.data.className ? props.data.className : constStyles.input;
    this.clearText = this.clearText.bind(this);
    this.editContent = this.editContent.bind(this);
    this.handleEnter = this.handleEnter.bind(this);
    this.state = {
      showEdit: true,
      editableInput: ''
    };
  }

  componentWillMount() {
    this.checkForOptionalProps(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.checkForOptionalProps(nextProps);
  }
  editContent() {
    const status = !this.state.showEdit;
    this.setState({
      showEdit: status,
      editContent: {
        ...JSON.parse(JSON.stringify(this.state.editContent)),
        showEdit: status,
        onClick: this.editContent
      },
      cancelContent: {
        ...JSON.parse(JSON.stringify(this.state.cancelContent)),
        showCancel: this.state.showEdit,
        onClick: this.editContent
      },
      editClass: status ? 'input-edit' : ''
    });
  }
  checkForOptionalProps(props) {
    this.disabled = props.data.disabled ? 'disabled' : '';
    this.LabelHelpText = props.data.helpText ? <Label data={props.data.helpText} /> : '';
    this.LabelFieldComponent = props.data.labelField ? <Label data={props.data.labelField} /> : '';
    this.setState({
      value: props.data.value ? props.data.value : '',
      format: props.data.format,
      editContent: {
        edit: props.data.edit,
        showEdit: true,
        onClick: this.editContent
      },
      cancelContent: {
        edit: props.data.edit,
        showCancel: false,
        onClick: this.editContent
      },
      editClass: props.data.edit ? 'input-edit' : '',
      editableInput: props.data.edit ? 'input-edit-wrapper' : ''
    });
  }
  handleKeyPress(event) {
    if (this.props.data.keyCode && this.props.data.keyCode === event.key) {
      this.delegateHandler('onKeyDown', event, constData.eventProperty);
    }
  }
  handleEnter(event) {
    if (event.keyCode == 13) this.delegateHandler('onKeyUp', event, event.keyCode);
  }
  clearText() {
    this.setState({
      value: ''
    });
    this.delegateHandler(constData.propsProperty, '', (e) => e);
  }
  handleChange(event) {
    let flag = true;
    if (this.state.format && this.state.format.test(event.target.value)) {
      flag = false;
    }
    if (flag) {
      this.setState({
        value: event.target.value
      });
      this.delegateHandler(constData.propsProperty, event, constData.eventProperty);
    }
  }

  render() {
    return (
      <div className={this.state.editableInput}>
        {this.LabelFieldComponent}
        <EditCancelComponent data={this.state.editContent} />
        <div className={this.state.editableInput && constStyles.editInpWrapper}>
          <input
            id={this.props.data.id}
            onChange={this.handleChange}
            type='text'
            name={this.props.data.name}
            className={`${this.applicableClass} ${this.state.editClass}`}
            onBlur={this.props.data.onBlur}
            onKeyPress={this.handleKeyPress}
            maxLength={this.props.data.maxLength}
            title={this.props.data.title}
            value={this.state.value}
            placeholder={this.props.data.placeholder}
            disabled={this.disabled}
            onKeyUp={this.handleEnter}
          />
          <EditCancelComponent data={this.state.cancelContent} />
        </div>
        {this.state.value.length > 0 &&
        this.props.data.clear && (
          <span className={constStyles.iconClose} onClick={this.clearText}>
            <Icon name='close' />
          </span>
        )}
        {this.LabelHelpText}
      </div>
    );
  }
}
const EditCancelComponent = (props) => {
  return props.data.edit ? (
    <React.Fragment>
      {props.data.showEdit && (
        <span onClick={props.data.onClick} className={constStyles.editIcon}>
          <Icon name='edit' />
        </span>
      )}
      {props.data.showCancel && (
        <span onClick={props.data.onClick} className={constStyles.cancelTxt}>
          Cancel
        </span>
      )}
    </React.Fragment>
  ) : (
    ''
  );
};
TextField.propTypes = {
  data: PropTypes.shape({
    id: PropTypes.string.isRequired,
    onChange: PropTypes.func,
    name: PropTypes.string.isRequired,
    onBlur: PropTypes.func,
    maxLength: PropTypes.number.isRequired,
    title: PropTypes.string,
    value: PropTypes.oneOfType([ PropTypes.string, PropTypes.number ]),
    placeholder: PropTypes.string,
    label_helper: PropTypes.shape({
      labelname: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired,
      fontSizeType: PropTypes.string
    }),
    onChange: PropTypes.func,
    disabled: PropTypes.string
  }).isRequired
};

TextField.defaultProps = { data: defaultData };

export default TextField;
