export const defaultStyles = {
	iconName: 'close',
	openLink: 'link',
	dialogueScrollable: 'dialog dialog--interstitial dialog--scrollable',
	overLayModal: 'dialog dialog--interstitial dialog--scrollable dialog--display',
	closeSpring: 'spring dialog__close-spring',
	dialogueClose: 'dialog__close',
	accordionCls: 'sprite__icon',
	dialogueContent: 'dialog__content',
	ajaxCls: 'ajax',
	springmdCls: 'spring spring--md',
	centerCls: 'align--center',
	secRulCls: 'section section--ruled flush--top align--center',
	headingCls: 'heading heading--2 heading--light heading--leading',
	gutterBtmCls: 'display no-gutter--bottom',
	gutterTopCls: 'display no-gutter--top',
	alignLeftCls: 'grid__item grid__item--sm-1/1 mt50 grid__item--1/2 align--left gutter--top',
	buttonSecCls: 'button button--secondary  button--secondary--dark',
	alignRightCls: 'grid__item grid__item--sm-1/1 mt50 grid__item--1/2 align--right gutter--top',
	primaryDark: 'button button--primary  button--primary--dark',
	className: {
		bold: 'boldClass',
		belowSeperator: 'lineSep',
		floatRight: 'floatR',
		widthClass: 'fixWidth',
		redColor: 'required_star',
		floatLeft: 'floatL',
		nextLine: 'newLine',
		padding: 'paddingClass'
	}
};

export const defaultData = {
	show: true,
	index: 0,
	childList: [
		{
			type: 'Generic',
			text: 'Are you sure?',
			leftButton: 'cancelBtn',
			rightButton: 'deleteBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'StaticText',
					body: {
						className: 'nextLine',
						data: 'You are about to permanently delete this message.'
					}
				}
			]
		}
	],
	buttondata: {
		deleteBtn: {
			id: 'primary',
			name: 'Delete',
			type: 'primary',
			buttonType: 'button'
		},

		cancelBtn: {
			id: 'secondary',
			name: 'Cancel',
			type: 'secondary',
			buttonType: 'reset'
		}
	},
	tooltip: 'Click Here to Close',
	MODAL_OPEN_CLASS: 'body--modal-open'
};
