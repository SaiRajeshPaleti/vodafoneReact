import React from 'react';
import renderer from 'react-test-renderer';
import overlayData from '../../../AppData/overlayData';
import overlayFormData from '../../../AppData/overlayFormData';
import Overlay from '../overlay';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import overlayStyles from '../overlayDefData-Props';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<Overlay/>', function() {
	let props, enzymeWrapper, modalviewHandler, closemodalHandler, delHandler, cancelHandler, ewrapper;

	beforeEach(() => {
		props = overlayData;
		modalviewHandler = Overlay.modalView;
		closemodalHandler = Overlay.closeModal;
		delHandler = overlayData.deleteMethod;
		cancelHandler = overlayData.cancelMethod;
		enzymeWrapper = mount(<Overlay overlayContent={overlayData} />);
		ewrapper = mount(<Overlay overlayContent={overlayFormData} index="0" />);
	});

	it('Overlay main div', () => {
		expect(enzymeWrapper.find('.dialog--scrollable').length).toEqual(1);
	});

	it('event handler to be called on modal view', () => {
		const span = enzymeWrapper.find('#openModal').simulate('click');
		expect(Overlay.modalView).toHaveBeenCalled;
	});

	it('event handler to be called on close Modal', () => {
		const span = enzymeWrapper.find('.accordion__chevron').simulate('click');
		expect(Overlay.closeModal).toHaveBeenCalled;
	});

	it('event handler to be called on delete method', () => {
		const span = enzymeWrapper.find('.button--primary').simulate('click');
		expect(overlayData.deleteMethod).toHaveBeenCalled;
	});

	it('event handler to be called on close Modal', () => {
		const span = enzymeWrapper.find('.button--secondary').simulate('click');
		expect(overlayData.cancelMethod).toHaveBeenCalled;
	});

	it('checks the modal count', () => {
		expect(eWrapper.find('#openModal').length).toEqual(OverlayFormData.childList.length);
	});
});
