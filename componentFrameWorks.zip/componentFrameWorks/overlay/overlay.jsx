import React from 'react';
import './overlay.css';
import { defaultStyles, defaultData } from './overlayDefData-Props';
import Button from 'vf-ent-ws-button';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import OverlayContent from './OverlayContent';
import BaseComponent from 'vf-ent-ws-utilities';

let submittedData = {};
let requiredIDs = [];
class Overlay extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			overlayView: this.props.data.show,
			overlayData: this.props.data
		};
		this.getRequired(this.props.data);
		this.closeModal = this.closeModal.bind(this);
		this.cancelMethod = this.cancelMethod.bind(this);
		this.clickHandler = this.clickHandler.bind(this);
		this.rejectHandler = this.rejectHandler.bind(this);
	}
	clickHandler(attribute) {
		if (attribute.value != '') {
			submittedData[attribute.id] = attribute.value;
		}
	}

	cancelHandler() {
		this.setState({ overlayView: false });
	}

	rejectHandler(operationName) {
		let unfilledArr =
			requiredIDs[this.props.data.index] != undefined
				? Object.keys(requiredIDs[this.props.data.index]).filter((e) => {
						return submittedData[e] == undefined;
					})
				: [];
		if (unfilledArr.length == 0) {
			this.props.overlayActionHandler &&
				this.props.overlayActionHandler(operationName, submittedData, requiredIDs[this.props.data.index]);
			this.debugLog(operationName + '::::' + JSON.stringify(submittedData));
			this.setState({ overlayView: false });
		} else {
			this.setMissing(unfilledArr);
		}
	}
	componentWillMount() {}
	componentWillReceiveProps(nextProps) {
		this.setState({ overlayView: true });
		this.setState({ overlayData: nextProps.data });
		submittedData = {};
		this.getRequired(nextProps.data);
	}
	getRequired = (data) => {
		let obj = {};
		data.childList[this.props.data.index].data.map((e) => {
			if (e.body.isMandatory == true && requiredIDs.indexOf(e.body.id) == -1) {
				obj[e.body.id] = 'mandatory';
				requiredIDs[this.props.data.index] = obj;
			}
		});
	};
	setMissing = (arr) => {
		let newData = JSON.parse(JSON.stringify(this.props.data));
		newData.childList[this.props.data.index].data.map((e) => {
			if (e.body.isMandatory && arr.indexOf(e.body.id) > -1) {
				e.body.isMissing = true;
			}
		});
		this.setState({
			overlayData: newData
		});
	};

	prepareData() {
		let rejectedData = this.state.overlayData.childList;

		const operation = rejectedData[0].type;
		//	this.debugLog('rejectedData :::' + JSON.stringify(rejectedData));
		const onDelete = () => {
			const data = this.props.data.buttondata;
			const buttonInfo = data[this.props.data.childList[this.props.data.index].rightButton];

			if (buttonInfo.onClick) {
				buttonInfo.onClick(buttonInfo);
			} else {
				this.rejectHandler(operation);
			}
		};

		this.state.overlayData.deleteMethod = onDelete;

		let updatedRejectData = rejectedData[0].data.filter(
			(data) => data.type === 'Dropdown' || data.type === 'TextArea' || data.type === 'TextField'
		);

		updatedRejectData &&
			updatedRejectData.map((element) => {
				let onChange = (event) => {
					this.clickHandler(event);
				};
				element.body.onChange = onChange;
			});
		this.debugLog(this.state.overlayData);
	}
	closeModal() {
		this.setState({ overlayView: false });
		document.body.classList.remove(defaultData.MODAL_OPEN_CLASS);
	}

	cancelMethod() {
		const data = this.props.data.buttondata;
		const buttonInfo = data[this.props.data.childList[this.props.data.index].leftButton];

		if (buttonInfo.onClick) {
			buttonInfo.onClick(buttonInfo);
		} else {
			this.setState({ overlayView: false });
			this.props.overlayActionHandler && this.props.overlayActionHandler('Cancel', {});
		}
	}
	headerFn() {
		return <Header data={this.state.overlayData} closeModal={this.closeModal} />;
	}
	contentFn() {
		this.debugLog(this.state.overlayData);
		return <Content data={this.state.overlayData} cancelMethod={this.cancelMethod} clickHandler={this.clickHandler} />;
	}
	render() {
		this.prepareData();
		const DATA = this.state.overlayData;
		this.header = this.headerFn();
		this.content = this.contentFn();
		return (
			<div
				id={DATA.childList[DATA.index].id}
				name={DATA.childList[DATA.index].name}
				className={this.state.overlayView ? defaultStyles.overLayModal : defaultStyles.dialogueScrollable}
			>
				{this.header}
				{this.content}
			</div>
		);
	}
}

const Header = (props) => (
	<div
		className={defaultStyles.dialogueClose}
		onClick={props.closeModal}
		title={props.data.tooltip ? props.data.tooltip : ''}
	>
		<Icon name={defaultStyles.iconName} />
	</div>
);

const Content = (props) => (
	<form className={`${defaultStyles.centerCls}  ${defaultStyles.springmdCls} ${defaultStyles.dialogueContent}`}>
		<div className={defaultStyles.secRulCls}>
			<p className={defaultStyles.headingCls}>{props.data.childList[props.data.index].text}</p>
			{props.data.childList[props.data.index].data.map((content, index) => (
				<OverlayContent key={index} data={content} clickHandler={props.clickHandler} />
			))}
		</div>
		<span className={defaultStyles.alignLeftCls}>
			<Button
				data={Object.assign({}, props.data.buttondata[props.data.childList[props.data.index].leftButton], {
					onClick: props.cancelMethod
				})}
			/>
		</span>

		<span className={defaultStyles.alignRightCls}>
			<Button
				data={Object.assign({}, props.data.buttondata[props.data.childList[props.data.index].rightButton], {
					onClick: props.data.deleteMethod
				})}
			/>
		</span>
	</form>
);

Overlay.propTypes = {
	data: PropTypes.shape({
		show: PropTypes.bool.isRequired,
		index: PropTypes.number,
		childList: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				type: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				leftButton: PropTypes.string.isRequired,
				rightButton: PropTypes.string.isRequired,
				leftHandler: PropTypes.func,
				rightHandler: PropTypes.func,
				data: PropTypes.arrayOf(
					PropTypes.shape({
						type: PropTypes.string.isRequired,
						body: PropTypes.shape({
							className: PropTypes.string,
							data: PropTypes.string
						})
					})
				)
			})
		),
		buttondata: PropTypes.shape({
			deleteBtn: PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				type: PropTypes.string.isRequired,
				buttonType: PropTypes.string.isRequired
			}),

			cancelBtn: PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				type: PropTypes.string.isRequired,
				buttonType: PropTypes.string.isRequired
			})
		}),
		tooltip: PropTypes.string
	})
};

Overlay.defaultProps = {
	data: defaultData
};

export default Overlay;
