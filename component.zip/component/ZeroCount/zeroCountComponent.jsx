import React, { PureComponent } from 'react';
import { constStyles } from './zeroCountDefData-Props';
import './zeroCount.css';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

export default class ZeroCount extends BaseComponent {
	render() {
		return (
			<div className={constStyles.zeroCountCls}>
				<span class={constStyles.iconClass}>
					<Icon name={this.props.data.noCountIcon} />
				</span>
				<div class={constStyles.msgDisplay}>
					<div>{this.props.data.noRecordsTxt}</div>
					<div>{this.props.data.noQuotesTxt}</div>
				</div>
			</div>
		);
	}
}
