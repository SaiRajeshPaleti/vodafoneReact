export const constStyles = {
	iconClass: 'sprite__icon',

	zeroCountCls: 'zeroCount',
	msgDisplay: 'zeroCountText'
};
