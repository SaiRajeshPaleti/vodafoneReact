import React from 'react';
import renderer from 'react-test-renderer';
import ZeroCount from '../zeroCountComponent';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import zeroCountData from '../../../AppData/zeroCountData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<ZeroCount />', function () {
            let props, enzymeWrapper;            
 
			beforeEach(() => {
					props = zeroCountData;
					enzymeWrapper = shallow( < ZeroCount data = { props } />);
			});

				it('Should render ZeroCount component', () => {
					expect(enzymeWrapper.find('div').length).not.toBe(null);
				});
				it('Should render  Count', () => {
					expect(enzymeWrapper.find('.zeroCount')).not.toBe(null);
				});

				it('should render error Icon', () => {
					expect(enzymeWrapper.find('Icon').length).not.toBe(null);
				});
				it('should render the error data',() => {					
					expect(enzymeWrapper.find('.zeroCountText')).toBeDefined();
				});								
});