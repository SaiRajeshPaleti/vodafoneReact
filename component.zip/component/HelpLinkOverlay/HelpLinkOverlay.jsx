import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import './HelpLinkOverlay.css';
import { constData, constStyles } from './HelpLinkOverlayData-Props';
import Overlay from 'vf-ent-ws-overlay';

class HelpLinkOverlay extends BaseComponent {
	constructor(props) {
		super(props);
		this.clickHandler = this.clickHandler.bind(this);
		this.state = { show: false };
	}
	clickHandler = () => {
		document.body.classList.add(constData.MODAL_OPEN_CLASS);
		this.setState({ show: !this.state.show });
	};

	render() {
		return (
			<div className={constStyles.raiseWrapper}>
				<div className={constStyles.helpTextLink} onClick={this.clickHandler}>
					{constData.helpText}
				</div>
				<Overlay
					data={{
						...this.props.data.OverlayData,
						show: this.state.show
					}}
				/>
			</div>
		);
	}
}

HelpLinkOverlay.propTypes = {
	data: PropTypes.shape({
		OverlayData: PropTypes.shape({
			show: PropTypes.bool.isRequired,
			index: PropTypes.number,
			childList: PropTypes.arrayOf(
				PropTypes.shape({
					id: PropTypes.string,
					name: PropTypes.string,
					type: PropTypes.string.isRequired,
					text: PropTypes.string.isRequired,
					leftButton: PropTypes.string.isRequired,
					rightButton: PropTypes.string.isRequired,
					data: PropTypes.arrayOf(
						PropTypes.shape({
							type: PropTypes.string.isRequired,
							body: PropTypes.shape({
								className: PropTypes.string,
								data: PropTypes.string
							})
						})
					)
				})
			),
			buttondata: PropTypes.shape({
				incidentButton: PropTypes.shape({
					id: PropTypes.string.isRequired,
					name: PropTypes.string.isRequired,
					type: PropTypes.string.isRequired,
					buttonType: PropTypes.string.isRequired,
					onClick: PropTypes.func.isRequired
				}),

				serviceButton: PropTypes.shape({
					id: PropTypes.string.isRequired,
					name: PropTypes.string.isRequired,
					type: PropTypes.string.isRequired,
					buttonType: PropTypes.string.isRequired,
					onClick: PropTypes.func.isRequired
				})
			}),
			tooltip: PropTypes.string
		})
	}).isRequired
};

export default HelpLinkOverlay;
