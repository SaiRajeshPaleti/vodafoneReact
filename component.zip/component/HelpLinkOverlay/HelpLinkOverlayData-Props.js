export const constData = {
	helpText: 'What type should I raise?',
	MODAL_OPEN_CLASS: 'body--modal-open'
};

export const constStyles = {
	helpTextLink: 'helpTextLink',
	raiseWrapper: 'raiseWrapper'
};
