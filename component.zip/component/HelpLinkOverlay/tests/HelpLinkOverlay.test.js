import React from 'react';

import HelpLinkOverlay from '../HelpLinkOverlay';
import HelpLinkOverlayData from '../../../AppData/HelpLinkOverlayData';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';

import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('component: Help Link overlay:', function() {
	describe('<HelpLinkOverlay/>', function() {
		let props, enzymeWrapper;

		beforeEach(() => {
			props = HelpLinkOverlayData;
			enzymeWrapper = mount(<HelpLinkOverlay data={HelpLinkOverlayData} />);
		});
		it('Testing for main div', () => {
			expect(enzymeWrapper.find('.raiseWrapper').length).toBe(1);
			//expect(enzymeWrapper.find('.radio--circle').length).toBe(3);
		});

		it('Handler testing', () => {
			const timeCircles = enzymeWrapper.find('.helpTextLink');
			timeCircles.at(0).simulate('click');
			expect(enzymeWrapper.flag).toHaveBeenCalled;
		});
	});
});
