import React from 'react';
import Icon from 'vf-ent-ws-svgicons';
const IconHoc = (props) => {
	return (
		<div className="grid__item grid__item--gutter grid__item--md-1/10 grid__item--1/2 p-0">
			<span className="remove" onClick={props.onClick} title={props.tooltip ? props.tooltip : ''}>
				<Icon key={+new Date()} {...props} />
			</span>
		</div>
	);
};
export default IconHoc;
