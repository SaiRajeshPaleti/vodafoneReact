import React from 'react';
import renderer from 'react-test-renderer';
import DynamicEmail from '../DynamicEmail';
import {
    shallow,
    mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ShareQuoteData from '../../../AppData/ShareQuoteData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<DynamicEmail />', function () {
            let props = ShareQuoteData, 
            enzymeWrapper;            
 
			beforeEach(() => {
                enzymeWrapper = shallow ( < DynamicEmail  data = { props }/>) ;	
                
            });
            
            it('should render DynamicEmail', () => {                              
                expect(enzymeWrapper.find('div').length).toEqual(1);

            });
            
});