import React from 'react';
import renderer from 'react-test-renderer';
import EmailID from '../EmailID';
import {
    shallow,
    mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ShareQuoteData from '../../../AppData/ShareQuoteData';
import { Content } from '../../Accordion/Content/Summary/SummaryContent';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<EmailID />', function () {
            let props = ShareQuoteData.props.data,
             enzymeWrapper; 
			
			enzymeWrapper = mount( < EmailID  data = { props }/>);           
            
            it('should render the component', () => {
                expect(enzymeWrapper.find('div')).toBeDefined;                       
            });

            it('should render compoenent will mount',() => {               
                expect( enzymeWrapper.instance().componentWillMount()).toHaveBeenCalled;
            });            
            it('should call onclick method',() => {
                enzymeWrapper.find('.font_16').simulate('click');
            });               
              			
	});