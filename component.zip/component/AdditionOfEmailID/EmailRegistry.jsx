import TextFieldHoc from './textFieldHOC';
import Label from 'vf-ent-ws-label';
import IconHOC from './IconHOC';

const FormElementRegistry = {
	TextField: TextFieldHoc,
	Label,
	Icon: IconHOC
};

export default FormElementRegistry;
