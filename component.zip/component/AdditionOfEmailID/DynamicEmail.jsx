import React, { PureComponent } from 'react';
import FormStyles from './EmailIDDefData-Props.js';
import PropTypes from 'prop-types';
import EmailRegistry from './EmailRegistry';
import ValidationHOC from 'vf-ent-ws-validation-hoc';
export default class DynamicEmail extends PureComponent {
	isHOCRequired(isValidateHOC, Component, key, props, validateHOCContent) {
		if (isValidateHOC) {
			const HOCExtension = ValidationHOC(Component, props, key, validateHOCContent);
			return <HOCExtension key={key} />;
		} else {
			return <Component key={key} {...props} />;
		}
	}
	render() {
		return (
			<div className={`${FormStyles.constStyles.gridHalf}`}>
				{this.props.data.map((componentData, index) => {
					const Component = EmailRegistry[componentData.componentType];
					return this.isHOCRequired(
						componentData.isValidateHOC,
						Component,
						index,
						componentData.props,
						componentData.validateHOCContent
					);
				})}
			</div>
		);
	}
}
PropTypes.arrayOf(
	PropTypes.shape({
		componentType: PropTypes.string.isRequired,
		props: PropTypes.object.isRequired
	})
);

DynamicEmail.propTypes = {
	data: PropTypes.arrayOf(
		PropTypes.shape({
			componentType: PropTypes.string.isRequired,
			props: PropTypes.object.isRequired
		})
	)
};
