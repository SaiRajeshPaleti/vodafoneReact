import React from 'react';
import TextArea from 'vf-ent-ws-textarea';
import './EmailID.css';
import FormStyles from './EmailIDDefData-Props.js';
import DynamicEmail from './DynamicEmail';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class EmailID extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			email: [],
			data: this.props.data,
			numChildren: 0,
			extraEmailFields: [],
			initialEmail: props.data.initialEmail,
			textAreaValue: props.data.textAreaData.value
		};
		this.addChild = this.addChild.bind(this);
		this.removeChild = this.removeChild.bind(this);
		this.textAreaOnChange = this.textAreaOnChange.bind(this);
		this.e = [];
	}

	componentWillMount() {
		const Data = this.state.data.content;
		const email = [ ...this.state.email ];
		Data.map((content, index) => {
			email.push(<DynamicEmail data={content.emailData} key={index} />);
			return content;
		});

		const initialEmail = this.state.initialEmail ? this.state.initialEmail : [];

		initialEmail.map((e) => {
			this.addChild(e);
			return e;
		});
		this.setState({
			email
		});
	}

	addChild(val) {
		console.log(val.type);
		const extraEmailFields = val.type !== 'click' ? [ ...this.e ] : [ ...this.state.extraEmailFields ];
		let limit = this.state.data.extraData.noOfFields ? this.state.data.extraData.noOfFields : 2;
		let temp = extraEmailFields.map((e) => {
			return e.props.data.filter((f) => {
				return f.componentType === 'TextField';
			})[0].props.data.key;
		});
		console.log(temp);
		let arr = Array.from(Array(limit).keys());
		arr = arr.filter((el) => !temp.includes(el));
		console.log(arr);
		if (extraEmailFields.length < limit) {
			let a = [];
			let c = Math.random();
			if (val.type === 'click') {
				this.state.data.extraData.emailData.map((e) => {
					let b = JSON.parse(JSON.stringify(e));
					if (e.componentType === 'Icon') {
						b.props.onClick = () => this.removeChild(c);
					} else if (e.componentType === 'TextField') {
						b.props.data.id = b.props.data.id + '_' + arr[0];
						b.props.data.name = b.props.data.id;
						b.props.data.key = arr[0];
						b.props.data.value = '';
						b.isValidateHOC = val.isValidateHOC;
						b.props.data.onBlur = e.props.data.onBlur.bind({});
					}
					a.push(b);
					return e;
				});
			} else {
				a = val;
				a.map((e) => {
					if (e.componentType === 'Icon') {
						e.props.onClick = () => this.removeChild(c);
					}
					return e;
				});
			}
			console.log(a);
			extraEmailFields.push(<DynamicEmail data={a} key={c} />);
			this.e = extraEmailFields;
			this.setState({
				numChildren: this.state.numChildren + 1,
				extraEmailFields
			});
		}
	}
	removeChild(i) {
		console.log('i in remove:', i, typeof i);
		let extraEmailFields = [ ...this.state.extraEmailFields ];
		extraEmailFields = extraEmailFields.filter((e) => {
			console.log(e.key, typeof e.key);
			return e.key !== i.toString();
		});
		this.setState({
			numChildren: this.state.numChildren - 1,
			extraEmailFields
		});
	}

	textAreaOnChange(e) {
		this.setState({
			textAreaValue: e.target.value
		});
	}
	render() {
		// const Data = this.state.data.content;
		return (
			<div
				className={FormStyles.constStyles.addressselectorformlabel}
				id={this.props.data.id}
				name={this.props.data.name}
			>
				<h2 className={FormStyles.constStyles.secondHeading}>{FormStyles.constData.heading}</h2>
				<div className={FormStyles.constStyles.gridGutter}>
					{this.state.email}
					{this.state.extraEmailFields}
					<div className={FormStyles.constStyles.formClear} />
					<div className={FormStyles.constStyles.addButton}>
						<div className={FormStyles.constStyles.font16} onClick={this.addChild}>
							{FormStyles.constData.AdditionalField}
						</div>
					</div>

					<div className={FormStyles.constStyles.marginClass}>
						<div className={FormStyles.constStyles.formClear} />
					</div>
					<div className={FormStyles.constStyles.gridFull}>
						<TextArea
							data={Object.assign({}, this.state.data.textAreaData, { value: this.state.textAreaValue })}
							onDataChange={this.textAreaOnChange}
							value={this.state.textAreaValue}
						/>
					</div>
				</div>
			</div>
		);
	}
}

export default EmailID;
EmailID.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		content: PropTypes.arrayOf(
			PropTypes.shape({
				emailData: PropTypes.array.isRequired
			})
		),
		textAreaData: PropTypes.object.isRequired,
		extraData: PropTypes.shape({
			emailData: PropTypes.array.isRequired
		})
	})
};
