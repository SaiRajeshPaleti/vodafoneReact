import React from 'react';
import TextField from 'vf-ent-ws-textfield';
const TextFieldHoc = (props) => {
	return (
		<div className="grid__item grid__item--gutter grid__item--md-9/10 grid__item--1/2 p-0 dynamic_input_wrapper">
			<TextField key={+new Date()} {...props} />
		</div>
	);
};
export default TextFieldHoc;
