const FormStyles = {
	constData: {
		heading: 'Share quote',
		AdditionalField: "+ Add additional email ID's"
	},
	constStyles: {
		addressselectorformlabel: 'address_selector email_section',
		secondHeading: 'second_heading',
		gridGutter: 'grid',
		font16: 'font_16',
		addButton: 'add_button',
		formClear: 'formclear',
		marginClass: '"margin_b_20"',
		gridFull: 'grid__item grid__item--gutter grid__item--md-1/1 grid__item--1/1 p-0',
		gridHalf: 'dynamic_email content_data'
	},
	className: {
		formInputSelectable: 'form__input--selectable',
		formLabelRequiredAfter: 'form__-required::after',
		displayInlineBlock: 'display--inline-block',

		addressSelectorFormRow: 'address_selector .form__row',
		selectChevron: 'select_chevron',
		findAddress: 'find_address form__label',
		addressBottom: 'address_bottom form__row',
		gridGutter: 'grid',

		gridHalf: 'grid__item grid__item--gutter grid__item--md-1/1 grid__item--1/2 p-0',
		gridItemHalf: 'grid__item grid__item--gutter grid__item--bottom grid__item--md-1/1 grid__item--1/2 p-0',
		selectchevronIcon: 'select_chevron sprite__icon',
		forminputAndSelectable: 'form__input form__input--selectable',
		formLabelRequired: 'form__label form__labrequired',
		formRow: 'form__row',
		formLabel: 'form__label'
	}
};
export default FormStyles;
