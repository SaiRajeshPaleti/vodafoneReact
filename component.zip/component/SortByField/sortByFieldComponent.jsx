import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import './sortByField.css';
import BaseComponent from 'vf-ent-ws-utilities';
import { defaultStyles, defaultData, constData } from './sortByFieldDefData-Props';

class SortByFieldComponent extends BaseComponent {
    constructor(props) {
        super(props);
        this.state = {
            arrowIcon: true,
            displayText: { title: "Sort" },
            sortingData: { title: "Sort", key: "" },
            isFlag: true,
            asc: "Ascending Data in table grid",
            dsc: "Descending Data in table grid"
        };

        this.expand = this.expand.bind(this);
        this.sortByFieldHeader = this.sortByFieldHeader.bind(this);
        this.sortByFieldContent = this.sortByFieldContent.bind(this);
        this.hideContent = this.hideContent.bind(this);

        this.getSortAsc = this.getSortAsc.bind(this);
        this.getSortDsc = this.getSortDsc.bind(this);
    }
    componentWillMount() {
        this.init = this.sortByFieldHeader();

    }
    componentWillUpdate() {

        this.content = this.sortByFieldContent();

    }
    hideContent() {

        this.setState({ isFlag: false });

    }

    getSortAsc(data) {

        this.setState({ displayText: data.title }, () => {
            this.setState({ arrowIcon: !this.state.arrowIcon });
            this.init = this.sortByFieldHeader();

        });

        this.setState({
            sortingData: { title: data.title, action: "asc", key: data.key }
        }, () => {
            this.props.sortByFieldData.moveUp(this.state.sortingData);

        })


    }
    getSortDsc(data) {

        this.setState({ displayText: data.title }, () => {
            this.setState({ arrowIcon: !this.state.arrowIcon });
            this.init = this.sortByFieldHeader();

        });
        this.setState({
            sortingData: { title: data.title, action: "dsc", key: data.key }
        }, () => {
            this.props.sortByFieldData.moveDown(this.state.sortingData);

        })

    }
    expand() {

        this.setState({ arrowIcon: !this.state.arrowIcon });
        this.setState({ isFlag: !this.state.isFlag });
    }
    sortByFieldHeader() {


        return <SortByFieldHeader expand={this.expand} title={this.state.sortingData} arrowIcon={this.state.arrowIcon} />;
    }
    sortByFieldContent() {

        return <SortByFieldContent getSortAsc={this.getSortAsc} getSortDsc={this.getSortDsc} getSortColumn={this.getSortColumn} isFlag={this.state.isFlag} hideContent={this.hideContent} tabledata={this.props.tabledata} arrowIcon={this.state.arrowIcon} />;
    }

    render() {
        return (
            <div id={this.props.tabledata.id} name={this.props.tabledata.name} className={defaultStyles.cusDropDown}>
                {this.init}
                {this.content}
            </div>
        );
    }
}

const SortByFieldHeader = ({ expand, title, arrowIcon }) => (
    <div
        className={arrowIcon ? defaultStyles.activeCls : defaultStyles.inactiveCls}
        title={title}
        onClick={expand}
    >
        <div className={defaultStyles.heading}>
            <span>{title.title}</span>
        </div>

        <span className={defaultStyles.sortArrows}>
            <Icon name={defaultStyles.iconNameUp} />
        </span>
        <span className={defaultStyles.sortArrows}>
            <Icon name={defaultStyles.iconName} />
        </span>

    </div>
);

const SortByFieldContent = ({ getSortColumn, getSortAsc, getSortDsc, isFlag, hideContent, tabledata, sortByFieldData, arrowIcon }) => (
    <div className={(arrowIcon && isFlag == true) || (arrowIcon && isFlag == false) ? defaultStyles.activeRelativeCls : defaultStyles.display_none} onClick={hideContent}>
        <ul className={defaultStyles.listRest}>
            {tabledata.header.headerData.content.map((sortData) => (
                <li key={sortData.title} >
                    {sortData.title}


                    <span className={defaultStyles.sortArrows} onClick={() => getSortAsc(sortData)}>  <Icon name={defaultStyles.iconNameUp} /></span>
                    <span className={defaultStyles.sortListView} onClick={() => getSortDsc(sortData)}> <Icon name={defaultStyles.iconName} /></span>



                </li>
            ))}
        </ul>

    </div>
);

const TableData = ({ data }) => (
    <div>
        <h4><u>Table Grid</u></h4>
        <span>{data}</span>
    </div>
);


SortByFieldComponent.propTypes = {
    data: PropTypes.shape({
        id: PropTypes.string,
        name: PropTypes.string,
        clickTxt: PropTypes.string,
        title: PropTypes.string,
        dropdownValues: PropTypes.arrayOf(
            PropTypes.shape({
                optionName: PropTypes.string.isRequired,
                optionValue: PropTypes.string
            })
        ),
        onChange: PropTypes.func
    })
};


export default SortByFieldComponent;
