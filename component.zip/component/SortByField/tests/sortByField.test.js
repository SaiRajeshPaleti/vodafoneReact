import React from 'react';
import SortByFieldComponent from '../sortByFieldComponent';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('components', function() {
	describe('<SortByFieldComponent />', function() {
		let props, enzymeWrapper;

		props = {
			data: {
				id: 'burstspeed',
				name: 'Please select',
				clickTxt: 'Please select',
				title: 'Please select',
				dropdownValues: [
					{
						optionName: 'Please select',
						optionValue: 'Please select',
						id: 1
					},
					{
						optionName: '100 Mbps',
						optionValue: '100 Mbps',
						id: 2
					}
				],
				onchange: () => {
					console.log('test')
				}
			},
			sortByFieldData: {
				moveDown: (value) => {
        
					console.log(value);
				  
				},
				moveUp: (value) => {
					
					console.log(value);
					
				}
			},
			tabledata: {
				id: 'table_accordion',
				name: 'tableaccordion',
				displayAccordion: true,
				header: {
					type: 'Table',
					headerData: {
						id: 't1',
						isSelected: true,
						isSelectHidden: true,
						content: [
							{
								title: 'Quote reference',
								value: 'VFTOP_75192_180424_267316',
								key: 'QuoteReference',
								isHidden: true
							},
							{
								title: 'Product',
								value: 'Ethernet Wireline - Point to Point',
								key: 'Product'
							},
							{
								title: 'Site A details',
								value: false,
								key: 'SiteADetails'
							},
							{
								title: 'Validity',
								value: 'Active',
								key: 'Validity'
							},
							{
								title: 'Quote type',
								value: 'Standard',
								key: 'QuoteType'
							},
							{
								title: 'Site B details',
								value: 'UB4 8HP',
								key: 'SiteBDetails'
							}
						],
						statusKey: 'Validity',
						isBody: true,
						tableActionData: {
							controlType: 'image',
							name: 'Actions',
							isSelected: true,
							link: false,
							tooltip: 'Click Here to access Options',
							rowData: [ 'OrderNumber' ],
							ActionData: {
								actionToBePerformed: 'redirect',
								imageType: 'floatIcon',
								IconType: 'icon-more',
								isChoiceAction: true,
								transitionData: {
									transitionName: 'slide',
									transitionAppear: true,
									transitionAppearTimeout: 100,
									transitionEnterTimeout: 300,
									transitionLeaveTimeout: 300
								},
								selectionData: [
									{
										label: 'Refresh',
										ActionMethod: 'approveCharges',
										params: [ 'OrderNumber' ]
									}
								],
								imagealt: 'AC actions',
								tooltip: 'Click here to access options'
							},
							sortable: false,
							type: 'control',
							key: 'revalidate',
							onClick: (value) => {
								console.log(value);
							}
						}
					}
				},
				content: {
					type: 'StaticAccordion',
					contentData: [
						{
							labelData: {
								type: 'labelDefault',
								labelname: ' Quote date:',
								styling: 'boldClass'
							},
							value: '06 Jul 2018'
						},
						{
							labelData: {
								type: 'labelDefault',
								labelname: 'Customer reference:',
								styling: 'boldClass'
							},
							value: 'Cust_12340987'
						}
					]
				},
				footer: {
					type: 'Table',
					buttonData: {
						id: 'secondary',
						name: 'View summary',
						type: 'secondary',
						buttonType: 'button',
						onClick: () => {}
					}
				},
				selectButtonClick: (e) => {
					console.log(e);
				}
			}
		}
		let event = {target: { value: "text"}};

		beforeEach(() => {
			
			enzymeWrapper = mount(
				<SortByFieldComponent {...props} />
			);
		});

		it(' sortByFieldComponent contains main Div', () => {
			expect(enzymeWrapper.find('.mob_excel_dropdown').length).toBe(1);
		});

		it('should render getSortAsc function', () => {
			const data = {
				title: 'Quote reference',
				value: 'VFTOP_75192_180424_267316',
				key: 'QuoteReference',
				isHidden: true
			};
			enzymeWrapper.instance().getSortAsc(data);
		});

		it('should render getSortDsc function', () => {
			const data = {
				title: 'Quote reference',
				value: 'VFTOP_75192_180424_267316',
				key: 'QuoteReference',
				isHidden: true
			};
			enzymeWrapper.instance().getSortDsc(data);
		});

		it('should render hideContent function', () => {
			enzymeWrapper.instance().hideContent();
		});

		it('should render componentWillUpdate function', () => {
			enzymeWrapper.instance().componentWillUpdate();
		});

		it('should render expand function', () => {
			enzymeWrapper.instance().expand();
		});

		it('should render sortByFieldContent function', () => {
			enzymeWrapper.instance().sortByFieldContent();
		});
		
	});
});
