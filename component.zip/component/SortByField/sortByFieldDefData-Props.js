export const defaultStyles = {
	cusDropDown: 'filtering__dropdown dropdown customDropdown mob_excel_dropdown',
	inactiveCls: 'filtering__dropdown--button dropdown__button dropdown__button',
	activeCls: 'filtering__dropdown--button dropdown__button dropdown__button active',
	heading: 'dropdown__heading f__left',
	headlingLight: 'dropdown__heading--light',
	Sprite: 'sprite__icon down_arrow',
	activeRelativeCls: 'dropdown__panel p__relative display_block',
	listRest: 'list list--reset p-l-20',
	display_none: 'display_none',
	test: 'test',
	liTest: 'litest',
    iconName: 'chevron-down',
    iconNameUp:'chevron-up',
    sortArrows:'sortArrows',
    sortListView:'sortArrows sort-list-view'

};