import React, { PureComponent } from 'react';
import { constStyles } from './errorDefData-Props';
import './error.css';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

export default class Error extends BaseComponent {
	render() {
		return (
			<div className={constStyles.errorCls}>
				<span class={constStyles.spriteCls}>
					<Icon name={this.props.data.errorIcon} />
				</span>
				<div className={constStyles.msgDisplay}>
					<div>{this.props.data.failTxt}</div>
					<div>{this.props.data.pleaseWaitTxt}</div>
				</div>
			</div>
		);
	}
}
