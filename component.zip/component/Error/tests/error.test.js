import React from 'react';
import renderer from 'react-test-renderer';
import Error from '../error';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import errorData from '../../../AppData/errorData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<Error />', function () {
            let props, enzymeWrapper;            
 
			beforeEach(() => {
					props = errorData;
					enzymeWrapper = shallow( < Error data = { props } />);
			});

				it('Should render Error component', () => {
					expect(enzymeWrapper.find('div').length).not.toBe(null);
				});

				it('identify error render Icon', () => {
					expect(enzymeWrapper.find('Icon').length).not.toBe(null);
				});
				it('should render error text', () => {
					expect(enzymeWrapper.find('.errorText')).toBeDefined();
				});
								
});