export const constStyles = {
	spriteCls: 'sprite__icon',
	errorCls: 'error',
	msgDisplay: 'errorText'
};
