import React from 'react';
import renderer from 'react-test-renderer';
import IconWithTitle from '../IconWithTitle.jsx';

import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import IconWithTitleData from '../../../AppData/IconWithTitleData';

Enzyme.configure({
    adapter: new Adapter()
});

describe(<IconWithTitle />, function () {
    let props, enzymeWrapper;

    beforeEach(() => {
        props = IconWithTitleData;
        enzymeWrapper = shallow(<IconWithTitle data = {
            props} />);

    });

    it('IconWithTitle  contains 3 divs', () => {
        expect(enzymeWrapper.find('div').length).toBe(3);
    });

    it('IconWithTitle  contains heading', () => {
        expect(enzymeWrapper.find('h6').length).toBe(1);
    });
    it('IconWithTitle  contains value', () => {
        expect(enzymeWrapper.find('p').length).toBe(1);
    });
});