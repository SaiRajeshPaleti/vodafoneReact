import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import './iconWithTitle.css';
import { constStyles, constData } from './iconWithTitleDefData-Props';

const IconWithTitle = (props) => {
	return (
		<div className={constStyles.iconTextCard}>
			<div className={constStyles.iconTextCardBlock}>
				<span className={constStyles.cardIcon}>
					{props.data.type === 'icon' ? (
						<Icon name={props.data.iconName} />
					) : (
						<img src={props.data.src} alt={constData.imageAlt} />
					)}
				</span>
				<h6 className={constStyles.cardTitle}>{props.data.title}</h6>
				{props.data.value && <p className={constStyles.cardText}>{props.data.value}</p>}
			</div>
		</div>
	);
};
IconWithTitle.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		src: PropTypes.string,
		title: PropTypes.string.isRequired,
		value: PropTypes.string
	}).isRequired
};

export default IconWithTitle;
