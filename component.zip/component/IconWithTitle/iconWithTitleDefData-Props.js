export const constStyles = {
	iconTextCard: 'icon-text-card',
	iconTextCardBlock: 'icon-text-card-block',
	cardIcon: 'card_icon',
	cardTitle: 'card-title',
	cardText: 'card-text'
};
export const constData = {
	imageAlt: 'image'
};
