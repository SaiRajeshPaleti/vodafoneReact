import React from 'react';
import PropTypes from 'prop-types';
import Link from 'vf-ent-ws-link';
import Icon from 'vf-ent-ws-svgicons';
import './AwaitingBubble.css';
import { constStyles, defaultData } from './AwaitingBubbleDefData-Props';

const AwaitingBubbleComponent = (props) => {
    return (
        <div className={constStyles.bubbleWrapper}>
            <div className={constStyles.bubbleBlock}>
                <h1 className={constStyles.talktext}>
                    <span>{defaultData.helloLabel}</span> {props.data.loggedInUser},
                </h1>
                <p>
                    <span>{defaultData.awaitingLabelContent}</span>
                </p>
                <div
                    className={`${constStyles.requestsLinks} ${constStyles.customLink}${props.data.journeyInfo.length}`}
                >
                    {props.data.journeyInfo.map((data, index) => {
                        const linkName = `${props.data.journeyData[data.key]} ${data.name} `;
                        const linkData = {
                            ...props.data.linkInfo,
                            id: index.toString(),
                            label: index < props.data.journeyInfo.length - 2 ? `${linkName}, ` : linkName,
                            onClick: (e) => props.data.onClick(e, { index, linkName })
                        };
                        const linkCalling =
                            index == props.data.journeyInfo.length - 1 && index > 0 ? (
                                <React.Fragment key={index}>
                                    <div className={constStyles.andText}>{defaultData.andText}</div>
                                    <Link data={linkData} />
                                </React.Fragment>
                            ) : (
                                <Link key={index} data={linkData} />
                            );

                        return linkCalling;
                    })}
                </div>
                <div className={constStyles.bubbleMsgTailIcon}>
                    <Icon name={constStyles.bubbleIcon} />
                </div>
            </div>
        </div>
    );
};

AwaitingBubbleComponent.propTypes = {
    data: PropTypes.shape({
        journeyInfo: PropTypes.arrayOf(
            PropTypes.shape({
                key: PropTypes.string,
                name: PropTypes.string
            }).isRequired
        ).isRequired,
        journeyData: PropTypes.shape({
            incident: PropTypes.string,
            serviceRequest: PropTypes.string,
            changeRequest: PropTypes.string,
            problem: PropTypes.string
        }).isRequired,
        loggedInUser: PropTypes.string.isRequired,
        linkInfo: PropTypes.shape({
            id: PropTypes.string.isRequired,
            name: PropTypes.string.isRequired,
            linkType: PropTypes.string.isRequired,
            url: PropTypes.string.isRequired,
            label: PropTypes.string.isRequired
        }).isRequired,
        onClick: PropTypes.func.isRequired
    }).isRequired
};

export default AwaitingBubbleComponent;
