import React from 'react';
import AwaitingBubble from '../AwaitingBubble';

import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import AwaitingBubbleData from '../../../AppData/AwaitingBubbleData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<AwaitingBubble />', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = AwaitingBubbleData;
		enzymeWrapper = mount(<AwaitingBubble data={props} />);
	});
	it('Text field  contains one div', () => {
		expect(enzymeWrapper.find('a').length).toBe(props.journeyInfo.length);
	});

	it('Handler testing', () => {
		const link = enzymeWrapper.find('a');
		link.at(1).simulate('click');
		expect(enzymeWrapper.handleChange).toHaveBeenCalled;
	});
});
