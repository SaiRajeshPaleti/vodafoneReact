export const constStyles = {
    bubbleWrapper: 'bubble--wrapper',
    bubbleBlock: 'bubbleBlock talk-bubble tri-right round btm-left',
    talkBubble: 'talk-bubble',
    vLine: 'v-line',
    talktext: 'talktext',
    requestsLinks: 'requests-links',
    linkBlock: 'linkBlock',
    bubbleMsgTailIcon: 'icon bubble-message-msg bubble-message__tail',
    incidentNav: 'incident-nav',
    bubbleIcon: 'bubble',
    customLink: 'customLink',
    andText: 'andText'
};

// export const constData = {
// 	propsProperty: 'onChange',
// 	eventProperty: 'value'
// };

export const defaultData = {
    awaitingLabelContent: 'You have the following notifications that are awaiting your urgent attention;',
    helloLabel: 'Hello',
    andText: 'and'
};
