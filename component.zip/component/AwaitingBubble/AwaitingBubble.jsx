import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

import AwaitingBubbleComponent from './AwaitingBubbleComponent';

class AwaitingBubble extends BaseComponent {
	constructor(props) {
		super(props);

		this.handleChange = this.handleChange.bind(this);
		this.state = {
			data: {
				...this.props.data,
				onClick: this.handleChange
			}
		};
	}

	handleChange(event, data) {
		console.log(event, data);
	}

	componentWillMount() {
		let props = this.props;
		let joureyInfoTemp = [ ...props.data.journeyInfo ];
		let journeyDataTemp = { ...props.data.journeyData };

		props.data.journeyInfo.map((data, index) => {
			if (!props.data.rolesInfo[data.key]) {
				joureyInfoTemp.splice(joureyInfoTemp.findIndex((item) => item.key == data.key), 1);
				delete journeyDataTemp[data.key];
			}
		});
		props.data.journeyInfo = joureyInfoTemp;
		props.data.journeyData = journeyDataTemp;
		this.setState({ data: { ...props.data, onClick: this.handleChange } });
	}

	render() {
		return (
			<div>
				<AwaitingBubbleComponent data={this.state.data} />
			</div>
		);
	}
}

AwaitingBubble.propTypes = {
	data: PropTypes.shape({
		journeyInfo: PropTypes.arrayOf(PropTypes.shape({ key: PropTypes.string, name: PropTypes.string }).isRequired)
			.isRequired,
		journeyData: PropTypes.shape({
			incident: PropTypes.string,
			serviceRequest: PropTypes.string,
			changeRequest: PropTypes.string,
			problem: PropTypes.string
		}).isRequired,
		loggedInUser: PropTypes.string.isRequired,
		linkInfo: PropTypes.shape({
			id: PropTypes.string.isRequired,
			name: PropTypes.string.isRequired,
			linkType: PropTypes.string.isRequired,
			url: PropTypes.string.isRequired,
			label: PropTypes.string.isRequired
		}).isRequired,
		onClick: PropTypes.func
	}).isRequired
};

export default AwaitingBubble;
