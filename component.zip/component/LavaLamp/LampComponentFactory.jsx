import React from 'react';
import { getLamp } from './LampRegistry';

const LampComponentFactory = (LampData) => {
	const ComponentContent = getLamp(LampData.type);
	return <ComponentContent data={LampData} />;
};

export default LampComponentFactory;
