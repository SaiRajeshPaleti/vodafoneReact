import React from 'react';
import renderer from 'react-test-renderer';
import LavaLamp from '../LavaLampComponent';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import LavaLampData from '../../../AppData/LavaLampData';
import TwoWayLamp from '../LavaLamp';
import LampComponentFactory from '../LavaLamp';
Enzyme.configure({ adapter: new Adapter() });
describe('<LavaLamp />', function() {
	let props, enzymeWrapper,enzymeWrapperTwoWayLamp,enzymeWrapperLampComponentFactory;

	beforeEach(() => {
		props = LavaLampData;
		enzymeWrapper = shallow(<LavaLamp data={props} />);
		enzymeWrapperTwoWayLamp = shallow(<TwoWayLamp data={props}/>);
		enzymeWrapperLampComponentFactory = shallow(<LampComponentFactory data={props}/>);
	});

	it('Lava lamp  contains one div', () => {
		expect(enzymeWrapper.find('div').length).toBe(1);
	});
	it('Lava lamp  contains one nav', () => {
		expect(enzymeWrapper.find('nav').length).toBe(1);
	});
	it('identify that div contains 5 a tags', () => {
		expect(enzymeWrapper.find('a').length).toBe(5);
	});
	it('Verifies that elements contains Incidents text', () => {
		expect(enzymeWrapper.find('nav').childAt(0).text()).toEqual('Incidents');
	});
	it('Verifies that elements contains Service requests text', () => {
		expect(enzymeWrapper.find('nav').childAt(1).text()).toEqual('Service requests');
	});

	it('Verifies that elements contains Change requests text', () => {
		expect(enzymeWrapper.find('nav').childAt(2).text()).toEqual('Change requests');
	});

	it('Verifies that elements contains Problems text', () => {
		expect(enzymeWrapper.find('nav').childAt(3).text()).toEqual('Problems');
	});

	it('Verifies that elements contains My services text', () => {
		expect(enzymeWrapper.find('nav').childAt(4).text()).toEqual('My services');
	});
	it('Verifies that Incidents tab is active', () => {
		expect(enzymeWrapper.find('nav').childAt(0).hasClass('tabs__tab--active')).toEqual(true);
	});

	it('method to be called on clicking on lavalamp', () => {
		let lavaLamp = enzymeWrapper.find('nav').childAt(0);
		lavaLamp.simulate('click');
		expect(props.method).toHaveBeenCalled;
	});

	it('Check TwoWayLamp instance presence', () => {
		const instance = enzymeWrapperTwoWayLamp.instance();
		expect(instance).not.toBe(null);
	});

	it('check LampComponentFactory instance presence', () => {
		const instance = enzymeWrapperLampComponentFactory.instance();
		expect(instance).not.toBe(null);
	});

	it('invoke handleTabClick',() => {
		const tab={id:'',
			name:'',
			key: '',
			value:''
		}
		enzymeWrapper.instance().handleTabClick(tab);
	}); 
});
