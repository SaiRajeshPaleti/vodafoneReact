import React from 'react';
import { constStyles } from './LavaLampDefProps';
const twoWayLamp = (LampData) => {
	return (
		<div className={constStyles.accordion_head_left} id={LampData.data.id} name={LampData.data.name}>
			<div className={constStyles.user_roles_list_left}>
				<span className={constStyles.accordion_title_logo}>&nbsp;</span>
			</div>
			<div className={constStyles.lava_lamp}>
				<div className={constStyles.tabs_content}>
					<div className={constStyles.tabs_navigation}>
						<div className={constStyles.plane_tab}>
							<a>{LampData.data.tabs[0].value}</a>
						</div>
						<div className={constStyles.divide} />
						<div className={constStyles.plane_tab}>
							<a>{LampData.data.tabs[1].value}</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};
export default twoWayLamp;
