import LavaLamp from './LavaLamp';
import TwoWayLamp from './TwoWayLamp';

const LampRegistry = {
	tabWhiteBG: LavaLamp,
	tabBlackBG: LavaLamp,
	planeTab: TwoWayLamp
};

export function getLamp(type) {
	if (!(type in LampRegistry)) {
		type = 'tabBlackBG';
	}
	return LampRegistry[type];
}
