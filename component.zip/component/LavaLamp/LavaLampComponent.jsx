import React from 'react';
import { constData, defaultData } from './LavaLampDefProps';
import './LavaLamp.css';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import ComponentFactory from './LampComponentFactory';

class LavaLamp extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			activeTabKey: props.data.activeTabKey
		};
		this.handleTabClick = this.handleTabClick.bind(this);
	}
	dataPassing(obj) {
		return {
			id: obj.id,
			value: obj.value
		};
	}

	handleTabClick(tab) {
		this.setState({ activeTabKey: tab.key });
		this.delegateHandler(constData.onChangeProperty, tab, this.dataPassing);
	}

	render() {
		return ComponentFactory({
			...this.props.data,
			active: this.state.activeTabKey,
			handleTabClick: this.handleTabClick
		});
	}
}

LavaLamp.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		name: PropTypes.string,
		type: PropTypes.string,
		activeTabKey: PropTypes.string.isRequired,
		tab: PropTypes.arrayOf({
			id: PropTypes.string,
			name: PropTypes.string,
			key: PropTypes.string.isRequired,
			value: PropTypes.string.isRequired
		}),
		onClick: PropTypes.func
	}).isRequired
};
LavaLamp.defaultProps = {
	data: defaultData
};
export default LavaLamp;
