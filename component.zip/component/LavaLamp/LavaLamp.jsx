import React from 'react';
import { constStyles, constData } from './LavaLampDefProps';
//import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
class LavaLamp extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {};
	}
	render() {
		return (
			<div className={constStyles[this.props.data.type]}>
				{' '}
				<nav className={constStyles.customTabsClass}>
					{this.props.data.tabs.map((tab, i) => (
						<a
							key={i}
							className={
								this.props.data.active === tab.key ? (
									constStyles.jsTabsActiveClass
								) : (
									constStyles.jsTabsClass
								)
							}
							onClick={() => this.delegateHandler(constData.handleTabClick, tab, dataPassing)}
						>
							{tab.value}
						</a>
					))}
				</nav>
			</div>
		);
	}
}

export function dataPassing(obj) {
	return obj;
}

export default LavaLamp;
