export const constStyles = {
	tabBlackBG: 'tabs tabsContent-v2 tabs_dark_bg',
	tabWhiteBG: 'tabs tabsContent-v2 tabs_white_bg',
	customTabsClass: 'customTabs-v2 tabs__navigation--overflow',
	jsTabsActiveClass: 'tabs__tab--active',
	jsTabsClass: 'tabs__tab',
	accordion_head_left: 'accordion_head_left term_tabs_wrap',
	user_roles_list_left: 'user_roles_list_left',
	accordion_title_logo: 'accordion-title-logo',
	lava_lamp: 'lava-lamp',
	tabs_content: 'tabs tabsContent-v2',
	tabs_navigation: 'customTabs-v2  tabs__navigation tabs__navigation--overflow',
	divide: 'divide',
	plane_tab: 'lava--tabs__tab lava--tabs__tab'
};
export const constData = {
	onChangeProperty: 'onChange',
	handleTabClick: 'handleTabClick',
	selectedTab: 'value'
};

export const defaultData = {
	activeTabKey: 'Incidents',
	id: 'lamp1',
	name: 'lavaLamp',
	tabs: [
		{
			id: 'tab1',
			name: 'lavaLamp1',
			key: 'Incidents',
			value: 'Incidents'
		},
		{
			id: 'tab2',
			name: 'lavaLamp2',
			key: 'serviceRequests',
			value: 'Service requests'
		},
		{
			id: 'tab3',
			name: 'lavaLamp3',
			key: 'changeRequests',
			value: 'Change requests'
		},
		{
			id: 'tab4',
			name: 'lavaLamp4',
			key: 'problems',
			value: 'Problems'
		},
		{
			id: 'tab5',
			name: 'lavaLamp5',
			key: 'myServices',
			value: 'My services'
		}
	],
	onChange: function onChange(tab) {
		// 	//Write your logic Here
		//console.log('data', tab);
	}
};
