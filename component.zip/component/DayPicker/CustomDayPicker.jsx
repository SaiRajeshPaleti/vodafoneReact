// import React from 'react';
// import moment from 'moment';
// import 'vf-ent-ws-reactdaypicker-external/lib/style.css';
// import DayPickerInput from 'vf-ent-ws-reactdaypicker-external/DayPickerInput';
// import './CustomDatePicker.css';
// import Icon from 'vf-ent-ws-svgicons';
// import PropTypes from 'prop-types';
// import ReactDOM from 'react-dom';
// import { constStyles, defaultData } from './CustomDatePickerDefData-Props';
// import Label from 'vf-ent-ws-label';
// import BaseComponent from 'vf-ent-ws-utilities';
// import dateFnsFormat from 'date-fns/format';
// import dateFnsParse from 'date-fns/parse';
// // import { DateUtils } from 'react-day-picker';

// export default class CustomDatePicker extends BaseComponent {
// 	constructor(props) {
// 		super(props);
// 		this.state = { dateVal: '' };
// 		this.nameInput = React.createRef();
// 		this.calenderClick = this.calenderClick.bind(this);
// 		this.parseDate = this.parseDate.bind(this);
// 		this.formatDate = this.formatDate.bind(this);
// 	}
// 	calenderClick() {
// 		ReactDOM.findDOMNode(this.refs.daypic.input).focus();
// 	}

// 	parseDate(str, format, locale) {
// 		// added fix for space parsing.
// 		str = this.replaceAll(str, ' ', '-');
// 		format = this.replaceAll(format, ' ', '-');
// 		const parsed = dateFnsParse(str, format, { locale });
// 		// if (DateUtils.isDate(parsed)) {
// 		return parsed;
// 		// }
// 		// return undefined;
// 	}

// 	replaceAll(str, find, replace) {
// 		return str.replace(new RegExp(find, 'g'), replace);
// 	}

// 	formatDate(date, format, locale) {
// 		const formatedDate = dateFnsFormat(date, format, { locale });
// 		//this.setState({ dateVal: formatedDate });
// 		console.log('formatedDate ....', formatedDate);
// 		return formatedDate; //dateFnsFormat(date, format, { locale });
// 	}

// 	componentWillMount() {
// 		let dateData = this.props.data;
// 		let dateVal = dateData.data.value;
// 		let placeHolder = dateData.data.placeholder;
// 		this.helper = this.props.data.labelDefault ? <Label data={this.props.data.labelDefault} /> : null;
// 		dateVal = dateVal ? moment(dateVal).format(this.props.data.data.format) : dateVal;
// 		this.placeHolder = dateData.data.formatPlaceHolder
// 			? moment(placeHolder).format(this.props.data.data.format)
// 			: placeHolder;
// 		this.setState({ dateVal });
// 	}
// 	componentWillReceiveProps(nextProps) {
// 		let dateData = nextProps.data;
// 		let dateVal = dateData.data.value;
// 		let placeHolder = dateData.data.placeholder;
// 		this.helper = nextProps.data.labelDefault ? <Label data={nextProps.data.labelDefault} /> : null;
// 		dateVal = dateVal ? moment(dateVal).format(nextProps.data.data.format) : dateVal;
// 		this.placeHolder = dateData.data.formatPlaceHolder
// 			? moment(placeHolder).format(this.props.data.data.format)
// 			: placeHolder;
// 		this.setState({ dateVal: dateVal });
// 	}
// 	componentDidMount() {
// 		let input = document.getElementById('dayPicker').getElementsByTagName('input');
// 		input[0].id = this.props.data.data.id;
// 		input[0].name = this.props.data.data.name;
// 		if (this.props.data.data.readOnly !== undefined) {
// 			input[0].readOnly = this.props.data.data.readOnly;
// 		}
// 		//
// 	}

// 	getDaysAgo(b) {
// 		var a = new Date();
// 		a.setDate(a.getDate() - b);
// 		return a;
// 	}
// 	getDaysAfter(b) {
// 		var a = new Date();
// 		a.setDate(a.getDate() + b);
// 		return a;
// 	}

// 	getDayPickerProps = (d) => {
// 		let disabledDaysValue = {};
// 		//console.log('' + JSON.stringify(d));
// 		const befVal = d.before && !d.before.isNAN && d.before;
// 		const aftVal = d.after && !d.after.isNAN && d.after;
// 		console.log(befVal, aftVal);
// 		if (!isNaN(aftVal) && aftVal != null) {
// 			const afterDate = new Date(this.getDaysAfter(aftVal));
// 			if (afterDate && afterDate != null) disabledDaysValue['after'] = afterDate;
// 		}
// 		if (!isNaN(befVal) && befVal != null) {
// 			const beforeDate = new Date(this.getDaysAgo(befVal));
// 			if (beforeDate && beforeDate != null) disabledDaysValue['before'] = beforeDate;
// 		}

// 		const disabledDays = [];
// 		disabledDays.push(disabledDaysValue);
// 		console.log('disabled days val ::', JSON.stringify(disabledDays));
// 		return {
// 			disabledDays: disabledDays
// 			//disabledDays: [ { before: new Date(this.getDaysAgo(befVal)), after: this.getDaysAfter(aftVal) } ]
// 		};
// 	};

// 	render() {
// 		let dateData = this.props.data;
// 		return (
// 			<React.Fragment>
// 				<div className={constStyles.wrapper} id="dayPicker" name="dayPicker">
// 					<DayPickerInput
// 						ref="daypic"
// 						formatDate={this.formatDate}
// 						format={this.props.data.data.format}
// 						parseDate={this.parseDate}
// 						value={this.state.dateVal}
// 						onDayChange={(e) => {
// 							let dateVal = e ? moment(e).format(this.props.data.data.format) : e;
// 							this.setState({ dateVal: dateVal });
// 							dateData.onChange != undefined && dateData.onChange(e);
// 						}}
// 						placeholder={this.placeHolder}
// 						dayPickerProps={this.getDayPickerProps(dateData.data)}
// 					/>
// 					<span className={constStyles.icon} onClick={this.calenderClick}>
// 						<Icon name={constStyles.icon_name} />
// 					</span>
// 				</div>
// 				{this.helper}
// 			</React.Fragment>
// 		);
// 	}
// }

// CustomDatePicker.propTypes = {
// 	data: PropTypes.shape({
// 		data: PropTypes.shape({
// 			name: PropTypes.string,
// 			id: PropTypes.string,
// 			title: PropTypes.string,
// 			searchAttribute: PropTypes.string,
// 			componentType: PropTypes.string,
// 			inputId: PropTypes.string,
// 			placeholder: PropTypes.string,
// 			value: PropTypes.string
// 		}),
// 		helperText: PropTypes.string,
// 		locale: PropTypes.string,
// 		format: PropTypes.string,
// 		onChange: PropTypes.func
// 	}).isRequired
// };

// CustomDatePicker.defaultProps = {
// 	data: defaultData
// };
