export const constStyles = {
	icon_name: 'calendar-31',
	wrapper: 'date_picker_wrapper',
	icon: 'sprite__icon date-icon',
	label: 'helperLabel'
};
export const defaultData = {
	data: {
		name: 'datePicker',
		id: 'date_picker',
		title: 'EndDate',
		searchAttribute: 'EndDate',
		componentType: 'SimpleDate',
		inputId: 'cove-200',
		placeholder: 'Enter date',
		value: '2018-06-05',
		locale: 'en',
		format: 'DD MMM YYYY'
	},
	helperText: 'If the date selected is less than lead time, it will be assumed as soon as possible',
	onChange: () => {}
};
