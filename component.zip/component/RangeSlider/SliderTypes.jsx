import React from 'react';
import './RangeSlider.css';
import RangeSlider from './RangeSlider';
import SliderStyles from './RangeSliderDefData-Props';
export class SliderTypes extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      sliderList: this.props.data
    };
    this.handleSliderChange = this.handleSliderChange.bind(this);
  }
  handleSliderChange(e) {
    const sliderListData = [ ...this.state.sliderList ];
    sliderListData.map((sliderData) => {
      if (sliderData.id === e.id) {
        sliderData.defaultValue = e.value;
      }
      return sliderData;
    });
    this.setState({
      sliderList: sliderListData
    });
  }
  render() {
    return (
      <div className={SliderStyles.constStyles.sliderWrapper}>
        <h1>{SliderStyles.constData.title}</h1>
        {this.state.sliderList.map((sliderContent, index) => {
          const sliderData = {
            ...sliderContent,
            onChange: this.handleSliderChange
          };
          return (
            <React.Fragment key={index}>
              <RangeSlider key={index} data={sliderData} />
            </React.Fragment>
          );
        })}
      </div>
    );
  }
}
export default SliderTypes;
