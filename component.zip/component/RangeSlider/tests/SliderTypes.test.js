import React from 'react';
import Enzyme, { mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import RangeSliderData from '../../../AppData/RangeSliderData';
import SliderTypes from '../SliderTypes';

Enzyme.configure({ adapter: new Adapter() });

describe('<SliderTypes />', function() {
	let wrapper;

	beforeEach(() => {
		wrapper = mount(<SliderTypes data={RangeSliderData} />);
	});

	it('Should render sliders', () => {
		expect(wrapper.find('.slidecontainer').length).toEqual(RangeSliderData.length);
	});
	it('Should trigger handleSliderChange', () => {
		const input = wrapper.find('#discount');
		expect(wrapper.instance().handleSliderChange({ value: 3, id: 'discount' })).toHaveBeenCalled;
		expect(wrapper.handleSliderChange).toHaveBeenCalled;
	});
});
