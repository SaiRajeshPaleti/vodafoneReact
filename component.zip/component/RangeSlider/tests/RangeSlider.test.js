import React from 'react';
import Enzyme, { mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import RangeSliderData from '../../../AppData/RangeSliderData';
import RangeSlider, { SliderComponent } from '../RangeSlider';

Enzyme.configure({ adapter: new Adapter() });

describe('<RangeSlider />', function() {
	let props, wrapper;

	beforeEach(() => {
		props = {
			...RangeSliderData[1],
			onChange: jest.fn()
		};
		wrapper = mount(<RangeSlider data={props} />);
	});

	it('Should render container div', () => {
		expect(wrapper.find('.slidecontainer').length).toEqual(1);
	});
	it('Should render slider parent div', () => {
		expect(wrapper.find('.rc-slider-wrapper').length).toEqual(1);
	});
	it('Should render slider steps', () => {
		expect(wrapper.find('.rc-slider-step span').length).toEqual(11);
	});
	it('Should trigger componentWillRecieveProps', () => {
		const newProps = {
			...RangeSliderData[0],
			onChange: jest.fn()
		};
		wrapper.setProps({ data: newProps });
	});
	it('Should render slider custom marks', () => {
		const newProps = {
			...RangeSliderData[0],
			onChange: jest.fn()
		};
		wrapper.setProps({ data: newProps });
		expect(wrapper.find('.rc-slider-mark span').length).toEqual(Object.keys(newProps.customMarks).length);
	});
	it('Should handle slider change', () => {
		const newProps = {
			...RangeSliderData[0],
			onChange: () => jest.fn()
		};
		wrapper.setProps({ data: newProps });
		const step = wrapper.find('.rc-slider-mark .rc-slider-mark-text');
		step.at(1).simulate('click');
		expect(wrapper.instance().sliderChange(25, newProps.id)).toHaveBeenCalled;
	});
	it('Should not render tooltip', () => {
		const compProps = {
			tooltip: false,
			onChange: jest.fn()
		};
		const sliderWrapper = mount(<SliderComponent data={compProps} />);
		expect(sliderWrapper.find('rc-slider-tooltip').length).toEqual(0);
	});
});
