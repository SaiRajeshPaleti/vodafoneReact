const RangeSliderProps = {
  constStyles: {
    slidecontainer: 'slidecontainer',
    sliderWrapper: 'rc-slider-wrapper',
    slideInput: 'slideInput',
    slider: 'slider',
    sliderValue: 'sliderValue',
    stepTracker: 'stepTracker',
    customMarks: 'customMarks'
  },
  constData: {
    sliderSelectedColor: '#C5C5C5',
    sliderUnSelectedColor: '#9c2aa0',
    id: '',
    title: 'Range Slider'
  },
  actions: {
    onChange: 'onChange',
    props: 'value'
  },
  defaultProps: {
    data: {
      min: 0,
      max: 100,
      step: 10,
      defaultValue: 10
    }
  }
};
export default RangeSliderProps;
