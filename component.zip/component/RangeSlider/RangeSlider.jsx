import React from 'react';
import PropTypes from 'prop-types';
import Slider, { createSliderWithTooltip } from 'rc-slider';
import BaseComponent from 'vf-ent-ws-utilities';
import './RangeSlider.css';
import SliderStyles from './RangeSliderDefData-Props';
const SliderWithTooltip = createSliderWithTooltip(Slider);

export default class RangeSlider extends BaseComponent {
  constructor(props) {
    super(props);
    this.updateSlider = this.updateSlider.bind(this);
    this.sliderChange = this.sliderChange.bind(this);
  }
  componentWillMount() {
    this.updateSlider(this.props);
  }
  componentWillReceiveProps(nextProps) {
    this.updateSlider(nextProps);
  }
  updateSlider(props) {
    const marks = props.data.customMarks ? props.data.customMarks : props.data.marks ? sliderMarks(props) : {};
    const marksLength = props.data.customMarks ? Object.keys(props.data.customMarks).length : 0;

    this.setState({
      rangeValue: props.data.defaultValue,
      rangeValueText: props.data.defaultValue,
      rangeId: `${SliderStyles.constData.id}${props.data.id}`,
      marks: marks,
      dots: props.data.dots,
      tooltip: props.data.tooltip,
      showTooltipByDefault: props.data.showTooltipByDefault,
      customMarksClass: marksLength > 0 ? `${SliderStyles.constStyles.customMarks}${marksLength}` : ''
    });
  }

  sliderChange(value, id, markValue) {
    this.delegateHandler(SliderStyles.actions.onChange, { value, id, markValue }, (e) => {
      return e;
    });
  }
  render() {
    return (
      <div className={SliderStyles.constStyles.slidecontainer} id={this.state.rangeId}>
        <div dangerouslySetInnerHTML={{ __html: this.props.data.labelname }} />
        <div className={`${SliderStyles.constStyles.sliderWrapper} ${this.state.customMarksClass}`}>
          <SliderComponent
            data={{
              dots: this.state.dots,
              marks: this.state.marks,
              min: this.props.data.min,
              max: this.props.data.max,
              step: this.props.data.step,
              value: this.state.rangeValue,
              id: this.props.data.id,
              tooltip: this.state.tooltip,
              tipProps: { visible: this.state.showTooltipByDefault },
              onChange: this.sliderChange
            }}
          />
        </div>
      </div>
    );
  }
}
export const SliderComponent = (props) => {
  const data = {
    ...props.data,
    onChange: (e) => props.data.onChange(e, props.data.id, props.data.marks[e])
  };
  return props.data.tooltip ? <SliderWithTooltip {...data} /> : <Slider {...data} />;
};
RangeSlider.propTypes = {
  data: PropTypes.shape({
    customMarks: PropTypes.object,
    id: PropTypes.string.isRequired,
    marks: PropTypes.bool,
    min: PropTypes.number.isRequired,
    max: PropTypes.number.isRequired,
    step: PropTypes.number,
    defaultValue: PropTypes.number,
    onChange: PropTypes.func.isRequired,
    tooltip: PropTypes.bool
  }).isRequired
};
RangeSlider.defaultProps = SliderStyles.defaultProps;

const sliderMarks = (props) => {
  const numberObj = {};
  for (let i = props.data.min; i <= props.data.max; i = i + props.data.step) {
    numberObj[i] = i;
  }
  return numberObj;
};
