import React from 'react';
import AddressSelectorDropdown from '../AddressSelectorDropdown';
//import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import addressSelectorData from './../../../AppData/addressSelectorData';
Enzyme.configure({ adapter: new Adapter() });

describe('<AddressSelectorDropdown />', function() {
	let props , 
		enzymeWrapper, 
		datalength;

		beforeEach (() => {
			enzymeWrapper = shallow (< AddressSelectorDropdown 
				data={addressSelectorData}
				manualClickData = {addressSelectorData.manualAddressLabel } 
			/>);
		});

	it('Address Dropdown Component should render div', () => {
		expect(enzymeWrapper.find('div').length).toBeDefined();
	});
	it('should call onchange handler',() =>{
		enzymeWrapper.find('u').simulate('click');
		expect(enzymeWrapper.find('u').length).toBeDefined;
	});

});
