import React from 'react';
import renderer from 'react-test-renderer';
import AddressSelectorForm from '../AddressSelectorForm';
import {
    shallow,
    mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import addressSelectorData from '../../../AppData/addressSelectorData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('AddressSelector Form Component', function () {
            let props = addressSelectorData ,
                enzymeWrapper;

            beforeEach(() => {

                enzymeWrapper = shallow ( < AddressSelectorForm 
                    data = {addressSelectorData}
                    formTextFieldsData ={  addressSelectorData.formTextFieldsData}
                    />);
            });
            
            it('Should render Address selector component',() => {                                
                expect(enzymeWrapper.find('div').length).toBeDefined();
            });
            
});