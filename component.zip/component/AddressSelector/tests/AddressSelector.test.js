import React from 'react';
import renderer from 'react-test-renderer';
import AddressSelector from '../AddressSelector';
import {
    shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import addressSelectorData from '../../../AppData/addressSelectorData';

Enzyme.configure({
    adapter: new Adapter()
});

describe('<AddressSelector />', function () {
    let enzymeWrapper;
    let props = {
        data: {
            value: 123,
            onFindAddress: () =>{},
            findButton: {
                id: 'secondary',
                name: 'Find Address',
                type: 'secondary',
                buttonType: 'button'
            }
        }
    }

    beforeEach(() => {
        enzymeWrapper = shallow(<AddressSelector { ...props }
            onFindAddress ={() =>{}}
        />);
    });

    it('Should render Address selector component', () => {
        expect(enzymeWrapper.find('.address_selector').text()).toEqual('<FindAddressSection />');
    });

    it('event handler to be called on the component', () => {
        const event = { target: { value: "text" } };
        enzymeWrapper.instance().changeHandler(event);
        expect(AddressSelector.changeHandler).toHaveBeenCalled;
        enzymeWrapper.setState({
            searchValue: "search for something"
        });

    });

    it('should find for Address', () => {
        const event = { target: { value: "Address" } };
        enzymeWrapper.find('.address_selector').simulate('onFindAddress', event);
    });
    it('should call this to check post code value', () => {
        const event = { target: { value: "Address" } };
        expect(enzymeWrapper.instance().onFindAddress(event)).toHaveBeenCalled;    

    });

    it('should call componentwillReceiveprops', () => {        
        enzymeWrapper.instance().componentWillReceiveProps(props);
        expect(AddressSelector.componentWillReceiveProps).toHaveBeenCalled;
        enzymeWrapper.setState({
            searchValue: "search for something"
        });

    });

});