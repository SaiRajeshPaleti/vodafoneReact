import React from 'react';
import TextField from 'vf-ent-ws-textfield';
import Label from 'vf-ent-ws-label';
import { constStyles } from './AddressSelectorDefData-Props';
import './AddressSelector.css';

const AddressSelectorForm = (props) => {
	return (
		<div className={constStyles.gridGutter}>
			<div className={constStyles.gridHalf}>
				{props.formTextFieldsData.map((field, index) => {
					const onChange = props.onChange;
					const textdata = { ...field, onChange };
					return (
						<div key={index} className={constStyles.formRow}>
							<Label data={field.labelData} />
							<TextField data={textdata} />
						</div>
					);
				})}
			</div>
		</div>
	);
};

export default AddressSelectorForm;
