import React from 'react';
import Button from 'vf-ent-ws-button';
import TextField from 'vf-ent-ws-textfield';
import { constStyles, defaultData } from './AddressSelectorDefData-Props';
import PropTypes from 'prop-types';
import './AddressSelector.css';
import BaseComponent from 'vf-ent-ws-utilities';
//import ValidationHOC from 'vf-ent-ws-validation-hoc';
import AlertMessage from 'vf-ent-ws-alert-message';

class AddressSelector extends BaseComponent {
	constructor(props) {
		super(props);
		let searchValue = '';
		this.datatext = constStyles.addressInputComponentData;
		this.changeHandler = this.changeHandler.bind(this);
		this.onFindAddress = this.onFindAddress.bind(this);
		this.onBlur = this.onBlur.bind(this);
		if (props.data.value) {
			searchValue = props.data.value;
		}
		this.state = {
			searchValue,
			isValidateHOC: props.data.isValidateHOC
		};
	}
	componentWillReceiveProps(nextProps) {
		let searchValue = '';
		if (nextProps.data.value) {
			searchValue = nextProps.data.value;
		}
		this.setState({
			searchValue
		});
	}
	changeHandler = (e) => {
		this.setState({
			searchValue: e.value
		});
	};
	onFindAddress = (e) => {
		if (!this.state.searchValue || this.state.searchValue.length === 0) {
			console.log("Please enter Post Code, It can't be Empty!");
			this.setState({ isValidateHOC: true });
		} else {
			this.state.isValidateHOC && this.setState({ isValidateHOC: false });
			this.props.data.onFindAddress && this.props.data.onFindAddress(this.state.searchValue);
		}
	};
	onBlur = () => {
		if (this.state.searchValue.length > 0) {
			this.setState({ isValidateHOC: false });
		}
	};

	render() {
		return (
			<div className={constStyles.addressselector}>
				<FindAddressSection
					changeHandler={this.changeHandler}
					onFindAddress={this.onFindAddress}
					searchValue={this.state.searchValue}
					data={this.props.data}
					isValidateHOC={this.state.isValidateHOC}
					onBlur={this.onBlur}
				/>
			</div>
		);
	}
}

const FindAddressSection = (props) => {
	const onBlur = props.onBlur;

	const onChange = props.changeHandler;
	const dataText = {
		...props.data,
		onChange,
		value: props.searchValue,
		onBlur
	};
	const onClick = props.onFindAddress;
	const dataButton = { ...props.data.findButton, onClick };
	let TextRender;
	if (props.isValidateHOC) {
		let alertData = defaultData.alertData;
		alertData.messageBody = props.data.validationContent;
		TextRender = (
			<div className={constStyles.validwrap}>
				{props.data.validationContent && <AlertMessage data={alertData} />}
			</div>
		);
	}

	return (
		<React.Fragment>
			{TextRender}
			<div className={constStyles.gridGutter}>
				<div className={constStyles.gridHalf}>
					<TextField data={dataText} />
				</div>
				<div className={constStyles.gridItemHalf}>
					<div className={constStyles.findAddress}>
						<Button data={dataButton} />
					</div>
				</div>
			</div>
		</React.Fragment>
	);
};

AddressSelector.propTypes = {
	data: PropTypes.shape({
		onFindAddress: PropTypes.func.isRequired,
		id: PropTypes.string,
		name: PropTypes.string
	}).isRequired
};
AddressSelector.defaultProps = {
	data: defaultData
};
export default AddressSelector;
