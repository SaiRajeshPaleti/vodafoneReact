import React from 'react';
import Label from 'vf-ent-ws-label';
import { constStyles } from './AddressSelectorDefData-Props';
import './AddressSelector.css';
import DropdownComponent from 'vf-ent-ws-simple-dropdown';

const AddressSelectorDropdown = (props) => {
	return (
		<div className={constStyles.addressselectorformlabel}>
			<div className={constStyles.gridGutter}>
				<div className={constStyles.gridHalf}>
					<Label data={props.addressLabel} />
				</div>
				<div className="dropdown_section">
					<div className="grid">
						<div className={constStyles.gridHalf}>
							<DropdownComponent data={props.data} />
						</div>
					</div>
				</div>
				<div className={constStyles.gridHalf}>
					<span className={constStyles.manualAddress}>
						<u
							onClick={(e) => {
								props.onClick(true);
							}}
						>
							{props.manualClickData.name}
						</u>
					</span>
				</div>
			</div>
		</div>
	);
};
export default AddressSelectorDropdown;
