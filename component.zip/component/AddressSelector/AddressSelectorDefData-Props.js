export const constStyles = {
	formInputSelectable: 'form__input--selectable',
	formLabelRequiredAfter: 'form__label--required::after',
	displayInlineBlock: 'display--inline-block',
	addressselector: 'address_selector .form__label',
	addressSelectorFormRow: 'address_selector .form__row',
	selectChevron: 'select_chevron',
	findAddress: 'find_address form__label',
	addInterConnectAddress: 'add_address form__label ',
	addressBottom: 'address_bottom form__row',
	gridGutter: 'grid',
	gridHalf: 'grid__item grid__item--gutter grid__item--sm-1/1 grid__item--md-1/2 grid__item--1/2',
	gridItemHalf:
		'grid__item grid__item--gutter grid__item--bottom grid__item--sm-1/1 grid__item--md-1/2 grid__item--1/2',
	selectchevronIcon: 'select_chevron sprite__icon',
	forminputAndSelectable: 'form__input form__input--selectable',
	formLabelRequired: 'form__label form__label--required',
	formRow: 'form__row',
	formLabel: 'form__label',
	inputClear: 'input-group__clear',
	clearIcon: 'IconsFonts clear_icon',
	manualAddress: 'address_manual',
	address_heading: 'address_heading',
	addressselectorformlabel: 'address_selector .form__label',
	validwrap: 'valid-hoc-wrapper'
};

export const defaultData = {
	onSubmitHandler: function submitHandler(searchCriteria) {
		return true;
	},
	dropDownVisibility: false,
	id: 'AddressSelctor1',
	name: 'AddressSelector',
	heading: 'Site A Address',
	DropDownData: {
		arrowText: 'Click on DropDown',
		id: 'dropDown1',
		name: 'DropDown',
		CategoryName: 'Category',
		title: 'Please select',
		selectedCategoryLabel: 'Please select',
		dropdownValues: [
			{
				optionName: '17/2, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
				optionValue: 'This is an details'
			},
			{
				optionName: '17/3, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
				optionValue: 'This is an details1'
			},
			{
				optionName: '17/4, UPPER GROVE PLACE, EDINBURGH EH3 8AX',
				optionValue: 'This is an details2'
			}
		]
	},

	formTextFieldsData: [
		{
			id: 'buildingNumber',
			name: 'txt1',
			title: '',
			placeholder: 'Enter Building Number',
			maxLength: 50,
			labelData: {
				id: 'buildingNumber',
				type: 'labelRequiredDefault',
				htmlFor: '',
				labelname: 'Building Number',
				isRequired: false
			}
		},
		{
			id: 'buildingName',
			name: 'txt2',
			title: '',
			placeholder: 'Enter Building Name',
			maxLength: 50,
			labelData: {
				id: 'buildingName',
				type: 'labelRequiredDefault',
				htmlFor: '',
				labelname: 'Building Name',
				isRequired: false
			}
		},
		{
			id: 'street',
			name: 'txt3',
			title: '',
			placeholder: 'Enter Street',
			maxLength: 50,
			labelData: {
				id: 'street',
				type: 'labelRequiredDefault',
				htmlFor: '',
				labelname: 'Street',
				isRequired: true
			}
		},
		{
			id: 'town',
			name: 'txt4',
			title: '',
			placeholder: 'Enter Town',
			maxLength: 50,
			labelData: {
				id: 'town',
				type: 'labelRequiredDefault',
				htmlFor: '',
				labelname: 'Town/City',
				isRequired: false
			}
		},
		{
			id: 'country',
			name: 'txt5',
			title: '',
			placeholder: 'Enter Country',
			maxLength: 50,
			labelData: {
				id: 'country',
				type: 'labelRequiredDefault',
				htmlFor: '',
				labelname: 'Country',
				isRequired: false
			}
		}
	],
	findButton: {
		id: 'secondary',
		name: 'Find Address',
		type: 'secondary',
		buttonType: 'button'
	},
	manualAddressLabel: {
		id: 'manualaddressentry',
		name: 'Enter Address Manually?'
	},
	addressInputComponentData: {
		id: 'input_id1',
		name: 'txt1',
		title: '',
		placeholder: 'Enter some text',
		maxLength: 50,
		helperText: ''
	},
	postcodeLabel: {
		id: 'postcode',
		type: 'labelRequiredDefault',
		htmlFor: '',
		labelname: 'Site Post Code'
	},
	addressLabel: {
		id: 'postcode',
		type: 'labelRequiredDefault',
		htmlFor: '',
		labelname: 'Please confirm your address'
	},
	addressManualLabel: {
		htmlFor: '',
		styling: '',
		labelname: 'Enter Address Manually?'
	},
	alertData: {
		type: 'warning',
		name: 'warning',
		id: 'l_w_wa',
		lightBackground: true,
		arrowRequired: true,
		isValidate: true,
		messageBody: 'This is a mandotary field'
	}
};
