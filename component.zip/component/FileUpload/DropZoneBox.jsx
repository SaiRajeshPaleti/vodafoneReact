import React from 'react';
import PropTypes from 'prop-types';
import UploadStatus from './UploadStatus';
import Output from './Output';
import { constStyle, constData } from './FileUploadDefData-Props';
import Button from 'vf-ent-ws-button';
import BaseComponent from 'vf-ent-ws-utilities';

export default class DropZoneBox extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			progress: 0,
			dragover: ''
		};
		this.abortUpload = this.abortUpload.bind(this);
		this.handleFileSelect = this.handleFileSelect.bind(this);
		this.handleDragEnter = this.handleDragEnter.bind(this);
		this.handleDragLeave = this.handleDragLeave.bind(this);
	}

	componentWillMount() {
		this.browse = this.browseRender();
	}
	abortUpload(e) {
		e.stopPropagation();
		e.preventDefault();
		this.setState({ progress: 0 });
	}

	handleFileSelect(e) {
		e.stopPropagation();
		e.preventDefault();
		this.setState({ dragover: '', progress: 0, showProgress: true });
		let files = this.getFiles(e);
		if(files[0].name!==undefined){
			const index=files[0].name.lastIndexOf('.');
			const extension=files[0].name.slice(index,files[0].name.length);
			
			if(this.props.data.extensionsAllowed!==undefined && this.props.data.extensionsAllowed.indexOf(extension.toLowerCase())<0){
				const error = {
					type:'invalidFile'
				};
				this.props.hadleValidationError(error);
				return;
			}else{
				const error = {
					type:'validFile'
				};
				this.props.hadleValidationError(error);
			}
		}
		this.props.onUploaded(e, files);
		this.setState({ progress: 100 });
		setTimeout(
			function() {
				this.setState({ progress: 0, showProgress: false });
			}.bind(this),
			3000
		);
	}

	getFiles(e) {
		return e.dataTransfer ? e.dataTransfer.files : e.target.files;
	}

	handleDragEnter(e) {
		e.stopPropagation();
		e.preventDefault();
		this.setState({ dragover: constData.dragover });
	}

	handleDragLeave(e) {
		e.stopPropagation();
		e.preventDefault();
		this.setState({ dragover: '' });
	}

	handleDragOver(e) {
		e.stopPropagation();
		e.preventDefault();
		e.dataTransfer.dropEffect = constData.copy;
	}

	browseRender = () => {
		return (
			<div
				onDragEnter={this.handleDragEnter}
				onDragLeave={this.handleDragLeave}
				onDragOver={this.handleDragOver}
				onDrop={this.handleFileSelect}
			>
				<h1 className={constStyle.className.uploadMessage}>{this.props.data.drag_drop_text}</h1>
				<div className={constStyle.className.uploadText}>Or</div>
				<div>
					<span>
						<input
							id={this.props.data.id}
							className={constStyle.className.fileInput}
							type="file"
							onChange={this.handleFileSelect}
							accept={this.props.data.extensionsAllowed}
							ref={(fileInput) => (this.fileInput = fileInput)}
						/>
					</span>

					<Button
						data={Object.assign({}, this.props.data.buttonConfig, {
							onClick: () => this.fileInput.click()
						})}
					/>
				</div>
			</div>
		);
	};

	render() {
		return (
			<React.Fragment>
				{this.browse}
				{this.state.showProgress ? (
					<UploadStatus
						loaded={this.state.progress}
						//onUploadAbort={props.abortUpload}
						// checkProgress={props.checkUploadProgress}
					/>
				) : (
					''
				)}
			</React.Fragment>
		);
	}
}

DropZoneBox.propTypes = {
	url: PropTypes.string.isRequired,
	data: PropTypes.shape({
		upload_text: PropTypes.string.isRequired,
		drag_drop_text: PropTypes.string.isRequired,
		max_file: PropTypes.string.isRequired,
		browser_btn_text: PropTypes.string.isRequired,
		or: PropTypes.string.isRequired
	}),
	onUploaded: PropTypes.func.isRequired
};
