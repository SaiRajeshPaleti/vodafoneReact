export const constStyle = {
	className: {
		wrapper: 'wrapper',
		dropZoneBox: 'dragdropzone',
		dropBox: 'drop-box',
		thumb: 'thumb',
		fileInput: 'file_input',
		uploadMessage: 'text-center upload-msg',
		dragHead: 'dragdrop_head',
		uploadSize: 'uplaod_size pull-right',
		upload_box: 'upload_box',
		file: 'file',
		progressMain: 'upload_progress_bar',
		progressInit: 'progress_zero',
		progressMid: 'progress_bar',
		progressStatus: 'progress-status',
		progressEnd: 'progress_hundred',
		btnBlock: 'btnBlock',
		raiseBtns: 'raise_btns',
		roundCircles: 'round-circles',
		spriteIcon: 'sprite__icon',
		iconReport: 'icon-report',
		fileCloseSymbol: 'file-close-symbol',
		iconClose: 'icon icon-close-symbol',
		iconCloseName: 'close',
		fileText: 'file-text-links',
		uploadedIcon: 'tick',
		fileSize: 'm-0 file-size',
		//asjdh;la
		uploadText: 'upload-text'
	}
};
export const constData = {
	Data: {
		title: 'View more details',
		errormessage: 'No data for Accordian',
		dragover: 'dragover',
		perc: '%',
		initVal: 0,
		finVal: 100,
		copy: 'copy',
		onChange: 'onChange',
		value: 'files',
		typevalue: 'type',
		onDelete: 'onDelete',
		deleteFile: 'file'
	}
};

export const defaultData = {
	upload_text: 'Upload files',
	drag_drop_text: 'Drag and drop files here to upload',
	max_file: 'Max file size: 20mb per file',
	or: 'or',
	browser_btn_text: 'Browse files',
	url: '/upload',
	getFiles: (files) => {
		console.log('files', files);
	}
};
