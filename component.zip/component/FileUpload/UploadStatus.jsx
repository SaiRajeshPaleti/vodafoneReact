import React from 'react';
import { constStyle, constData } from './FileUploadDefData-Props';
import PropTypes from 'prop-types';

const UploadStatus = (props) => {
	let loaded = props.loaded;
	// if (loaded === 100) {
	// 	clearInterval();
	// } else {
	// 	setInterval(() => {
	// 		props.checkProgress();
	// 	}, 5000);
	// }
	let progressBar = { width: loaded.toString() + constData.Data.perc };
	return (
		<div className={constStyle.className.progressMain}>
			<div className={constStyle.className.progressInit}>{`${constData.Data.initVal}  ${constData.Data
				.perc}`}</div>
			<div className={constStyle.className.progressMid}>
				<div style={progressBar} className={constStyle.className.progressStatus} />
			</div>
			<div className={constStyle.className.progressEnd}>{`${constData.Data.finVal}  ${constData.Data.perc}`}</div>
		</div>
	);
};

UploadStatus.propTypes = {
	loaded: PropTypes.number.isRequired
};

export default UploadStatus;
