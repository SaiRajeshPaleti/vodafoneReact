import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Output from '../Output';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<Output>', () => {
	let wrapper, props;
	props = {
			files:[
				[{
				name: 'test',
				url: '/upload',
				size: 10
				}]
			],
			onDelete: (key) => {
				console.log(key);
			}
	}

	beforeEach(() => {
		wrapper = mount(<Output { ...props } />);
	});

	it('Should render output component', () => {
		expect(wrapper).not.toBe(null);
	});
});
