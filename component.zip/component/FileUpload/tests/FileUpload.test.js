import React from 'react';
import renderer from 'react-test-renderer';
import FileUpload from '../FileUpload';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import DropZoneBox from '../DropZoneBox';
import ReactTestUtils from 'react-dom/test-utils';

import Adapter from 'enzyme-adapter-react-16';
import FileUploadData from '../../../AppData/FileUploadData';

Enzyme.configure({ adapter: new Adapter() });

describe('<FileUpload />', function() {
	let fileUploadWrapper;
	let fileContents = 'file contents';
	let file = new Blob([ fileContents ], { type: 'text/plain' });
	let props ={
		data:{
			upload_text: 'test',
			drag_drop_text: 'test',
			or: 'test',
			browser_btn_text: 'test',
			getFiles: () => {

			},
			max_file: 'Max file size: 20mb per file',
			label_header_left: {
				labelname: 'Notes',
				type: 'labelDefault',
				isInline: true,
				fontSizeType: 'lg',
				isRequired: true
			},
			id: 'fileUpl',
			url :'/upload',
			fileDetails:{
				files:[
					[{
					name: 'test',
					url: '/upload',
					size: 10
					}]
				]
			},
			check: () => {
				return 100;
			}
		}
	};


	beforeEach(() => {
		fileUploadWrapper = mount(<FileUpload { ...props } />);
	});

	it('should call componentWillMount before render',() => {
		expect(fileUploadWrapper.instance().componentWillMount()).toHaveBeenCalled;

	});

	it('should call renderFileUpload',() => {
		expect(fileUploadWrapper.instance().renderFileUpload()).toHaveBeenCalled;
	});	

	it('should call appendThumbnail',() => {
		const f={
			_id: ''
		};
		expect(fileUploadWrapper.instance().appendThumbnail({target: {id: 1}}, f)).toHaveBeenCalled;
	})

	it('Fileupload contains one main', () => {
		expect(fileUploadWrapper.find('div').length).toBe(14);
	});
	it('should call componentDidMount',() => {
		expect(fileUploadWrapper.instance().componentDidMount()).toHaveBeenCalled;
	});
	it('should call componentWillReceiveProps',() => {
		const nextProps = props;		
		expect(fileUploadWrapper.instance().componentWillReceiveProps(nextProps)).toHaveBeenCalled;		
	});

	it('should call checkUploadProgress',() => {
		expect(fileUploadWrapper.instance().checkUploadProgress()).toHaveBeenCalled;
	});

	it('should call onDelete',() => {
		fileUploadWrapper.instance().onDelete(1);
	});
});
