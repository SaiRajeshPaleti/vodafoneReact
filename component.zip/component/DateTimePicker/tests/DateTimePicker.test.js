import React from 'react';
import moment from 'moment';
import CustomDateTimePicker from '../CustomDateTimePicker';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import DateTimePickerData from '../../../AppData/DateTimePickerData';
Enzyme.configure({ adapter: new Adapter() });

describe('<CustomDateTimePicker />', function() {
    let enzymeWrapper;
    beforeEach(() => {
        enzymeWrapper = mount(<CustomDateTimePicker data={DateTimePickerData} />);
    });

    it('Date Time picker div', () => {
        expect(enzymeWrapper.find('div').length).toBe(4);
    });

    it('identify that div contains input', () => {
        expect(enzymeWrapper.find('div').childAt(1).type()).toBe('input');
    });

    it('should verify event handler to be called on onChange', () => {
        enzymeWrapper.find('.date_time_picker_wrapper span').simulate('Click');
    });

    it('event handler to be called on onChange', () => {
        const event = { target: { value: '2018-09-28 09:30:00' } };
        enzymeWrapper.find('input').simulate('change', event);
        expect(CustomDateTimePicker.onChange).toHaveBeenCalled;
    });

    it('renders without crashing', () => {
        let props = {
            currentDay: moment('2018-09-28 09:30:00').format('MMM Do YYYY h:mm:ss a')
        };
        const tree = renderer.create(<CustomDateTimePicker {...props} />).toJSON();
        expect(tree).toMatchSnapshot();
    });

    it('should verify event handler to be called on onBlur', () => {
        const event = { target: { value: 'press enter' } };
        enzymeWrapper.find('input').simulate('onBlur', event);
        expect(CustomDateTimePicker.onBlur).toHaveBeenCalled;
    });

    it('should call compoentwillreceive props function', () => {
        const DateTimeData = DateTimePickerData;
        DateTimeData.value = '2018-09-28 09:30:00';
        enzymeWrapper.setProps({ data: DateTimeData });
    });
});
