import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import moment from 'moment';
import Icon from 'vf-ent-ws-svgicons';
import DateTime from 'react-datetime';
import 'react-datetime/css/react-datetime.css';
import './CustomDateTimePicker.css';
import { constStyles, defaultData } from './CustomDateTimePickerDefData-Props';

export default class CustomDateTime extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      selectedValue: ''
    };
    this.futureDateDisabled = new Date();
    this.textInput = React.createRef();
    this.onChange = this.onChange.bind(this);
    this.calendarClick = this.calendarClick.bind(this);
  }

  calendarClick() {
    this.textInput.current.focus();
  }

  onChange(data) {
    this.setState({ selectedValue: data });
    this.state.data.onChange != undefined &&
      this.state.data.onChange({
        value: moment(data).format(this.state.dateTimeFormat),
        id: this.state.data.data.id
      });
  }

  componentWillMount() {
    this.getStateProps(this.props.data);
  }

  componentWillReceiveProps(nextProps) {
    this.getStateProps(nextProps.data);
  }

  getStateProps(props) {
    const dateTimeFormat = props.data.timeFormat
      ? `${props.data.dateFormat} ${props.data.timeFormat}`
      : props.data.dateFormat;
    let selectedValue = props.data.value || new Date();
    if (moment(selectedValue).format(dateTimeFormat) === 'Invalid date') {
      selectedValue = new Date();
    }
    this.setState({
      selectedValue: moment(selectedValue).format(dateTimeFormat),
      dateTimeFormat: dateTimeFormat,
      timeFormat: props.data.timeFormat || false,
      data: props
    });
  }

  disableFutureDate = (d) => {
    const futureDateDisabled = moment().subtract();
    return d.isBefore(futureDateDisabled);
  };

  renderInput = (props) => {
    return (
      <React.Fragment>
        <input {...props} ref={this.textInput} />
        <span className={constStyles.icon} onClick={this.calendarClick}>
          <Icon name={constStyles.icon_name} />
        </span>
      </React.Fragment>
    );
  };

  render() {
    return (
      <div className={constStyles.wrapper} id={defaultData.id} name={defaultData.name}>
        <DateTime
          value={this.state.selectedValue}
          onChange={this.onChange}
          inputProps={{ placeholder: this.state.data.data.placeholder }}
          isValidDate={this.disableFutureDate}
          locale={this.state.data.data.locale}
          renderInput={this.renderInput}
          timeFormat={this.state.data.data.timeFormat}
          dateFormat={this.state.data.data.dateFormat}
          closeOnSelect
          timeConstraints={{ minutes: { step: this.state.data.data.timeConstraints.minutes.step } }}
        />
      </div>
    );
  }
}

CustomDateTime.propTypes = {
  data: PropTypes.shape({
    name: PropTypes.string,
    id: PropTypes.string.isRequired,
    title: PropTypes.string,
    placeholder: PropTypes.string,
    value: PropTypes.string,
    locale: PropTypes.string.isRequired,
    dateFormat: PropTypes.string.isRequired,
    timeFormat: PropTypes.oneOfType[(PropTypes.string, PropTypes.bool)],
    onChange: PropTypes.func.isRequired
  }).isRequired
};

CustomDateTime.defaultProps = {
  data: defaultData
};
