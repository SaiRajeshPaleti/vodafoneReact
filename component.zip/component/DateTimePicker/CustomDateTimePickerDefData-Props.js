export const constStyles = {
	icon_name: 'calendar',
	wrapper: 'date_time_picker_wrapper',
	icon: 'sprite__icon date-icon'
};
export const defaultData = {
	name: 'dateTimePicker',
	id: 'date_time_picker',
	title: 'Date Time',
	placeholder: 'Enter Date Time',
	locale: 'en-US',
	value: '28/05/2018 13:20',
	before: 0,
	after: 0,
	format: 'DD/MM/YYYY hh:mm A',
	dateFormat: 'DD/MM/YYYY',
	timeConstraints: {
		minutes: {
			min: 0,
			max: 59,
			step: 5
		}
	},
	onChange: (data) => {
		console.log('Date Time is ' + data.value);
		console.log('Id is ' + data.id);
	}
};
