import React, { Component } from 'react';
import './Dial.css';
import SVGCompElement from 'vf-ent-ws-svg';
import PropTypes from 'prop-types';
import { constData, defaultData } from './DialDefProps';

const Dial = (props) => {
  constData.components[constData.text1].style ='stroke: ' + props.data.values.circleColor;
  constData.components[constData.text1].text = props.data.values.text1;
  constData.components[constData.text2].text = props.data.values.text2;
  constData.components[constData.text3].text = props.data.values.text3; 
  constData.components[constData.path].strokedasharray = props.data.values.completionPercentage + ', 100'; 

  const tooltip = props.data.tooltip ? props.data.tooltip : '';

  return (
			<span title={tooltip}>
				<svg viewBox={constData.svgDimension} className={props.data.values.circleStyle} onClick={props.data.action}>
					{constData.components.map((component, index) => SVGCompElement(component))}
				</svg>
			</span>
  )
}

Dial.propTypes = {
	data: PropTypes.shape({
    values: PropTypes.shape({ 
      text1: PropTypes.string,
      text2: PropTypes.string,
      text3: PropTypes.string,
      completionPercentage: PropTypes.string,
      type: PropTypes.string.isRequired,
      circleStyle: PropTypes.string.isRequired
    }).isRequired,
    action: PropTypes.func,
    tooltip: PropTypes.string
	}).isRequired
};

Dial.defaultProps = {
	data: defaultData
};


export default Dial;
