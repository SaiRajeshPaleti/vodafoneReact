export const constStyles = {
	gridItem: 'p-0 grid__item grid__item--gutter grid__item--md-1/1 grid__item--1/2 form-small--bottom',
	label: 'dblock',
	spanLabel: 'js-form-label form__label hover-labels',
	referenceSpan: 'f-normal',
	optionalSpan: 'optional',
	input: 'form__input input-focus',
	maximumChar: 'dropdown-messgaes m-0',
	helperLabel: 'helperLabel'
};

export const constData = {
	propsProperty: 'onChange',
	eventProperty: 'value'
};

export const defaultData = {
	placeholder: 'This is sample text',
	name: 'sample_name',
	maxLength: 100,
	helperText: ''
};
