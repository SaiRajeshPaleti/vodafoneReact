import React from 'react';
import renderer from 'react-test-renderer';
import TextField from '../textFieldComponent';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import textFieldData from '../../../AppData/textFieldData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<TextField />', function () {
			let props, enzymeWrapper;
			

			beforeEach(() => {
					props = textFieldData;
					enzymeWrapper = shallow( <TextField textField = {
							props
						}
						/>);
					});

				it('Text field  contains one div', () => {
					expect(enzymeWrapper.find('div').length).toBe(1);
				});

				it('identify that div contains input', () => {
					expect(enzymeWrapper.find('label').childAt(1).type()).toBe('input');
				});

				it('event handler to be called on onChange', () => {
					const event = {target: { value: "text"}};
					enzymeWrapper.find('input').simulate('change',event);
					expect(TextField.onChange).toHaveBeenCalled;						
				});

				it('should verify event handler to be called on onKeyDown',() => {
					const event = {target: { value: "press enter"}};
					enzymeWrapper.find('input').simulate('keyDown',event);
					expect(TextField.onKeyPress).toHaveBeenCalled;
								
					
				});
				it('should call compoentwillreceive props function',() => {
					const nextProps = { data : {
						disabled: "true"
					}						
					}
					enzymeWrapper.instance().componentWillReceiveProps(nextProps);
					expect(TextField.componentWillReceiveProps).toHaveBeenCalled;

				});
				it('should call compoentwillreceive props function',() => {
					const event = {target: { value: "press enter"}};
					enzymeWrapper.instance().handleKeyPress(event);
					expect(TextField.handleKeyPress).toHaveBeenCalled;
				});
			});