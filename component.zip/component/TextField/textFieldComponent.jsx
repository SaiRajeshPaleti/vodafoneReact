import React, { PureComponent } from 'react';
import { constStyles, constData, defaultData } from './textFieldDefData-Props';
import PropTypes from 'prop-types';
import './textField.css';
import Label from 'vf-ent-ws-label';
import BaseComponent from 'vf-ent-ws-utilities';

class TextField extends BaseComponent {
	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
		this.handleKeyPress = this.handleKeyPress.bind(this);
		this.applicableClass = props.data.className ? props.data.className : constStyles.input;
	}

	componentWillMount() {
		this.checkForOptionalProps(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.checkForOptionalProps(nextProps);
	}

	checkForOptionalProps(props) {
		this.disabled = props.data.disabled ? 'disabled' : '';
		this.LabelComponent = props.data.label ? <Label data={props.data.label} /> : '';
		this.setState({
			value: props.data.value ? props.data.value : ''
		});
	}
	handleKeyPress(event) {
		console.log('handleKeyPress called ', event.key);
		if (this.props.data.keyCode && this.props.data.keyCode === event.key) {
			this.delegateHandler('onKeyDown', event, constData.eventProperty);
			console.log('delegateHandler called ', event.key);
		}
	}

	handleChange(event) {
		this.setState({
			value: event.target.value
		});
		this.delegateHandler(constData.propsProperty, event, constData.eventProperty);
	}

	render() {
		return (
			<div>
				<input
					id={this.props.data.id}
					onChange={this.handleChange}
					type="text"
					name={this.props.data.name}
					className={this.applicableClass}
					onBlur={this.props.data.onBlur}
					onKeyPress={this.handleKeyPress}
					maxLength={this.props.data.maxLength}
					title={this.props.data.title}
					value={this.state.value}
					placeholder={this.props.data.placeholder}
					disabled={this.disabled}
				/>
				{this.LabelComponent}
			</div>
		);
	}
}

TextField.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string.isRequired,
		onChange: PropTypes.func,
		name: PropTypes.string.isRequired,
		onBlur: PropTypes.func,
		maxLength: PropTypes.number.isRequired,
		title: PropTypes.string,
		value: PropTypes.oneOfType([ PropTypes.string, PropTypes.number ]),
		placeholder: PropTypes.string,
		label_helper: PropTypes.shape({
			labelname: PropTypes.string.isRequired,
			type: PropTypes.string.isRequired,
			fontSizeType: PropTypes.string
		}),
		onChange: PropTypes.func.apply,
		disabled: PropTypes.string
	}).isRequired
};

TextField.defaultProps = { data: defaultData };

export default TextField;
