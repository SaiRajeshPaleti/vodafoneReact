import React from 'react';
import DropDownFilter from '../DropDownFilter';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import DropDownFilterData from '../../../AppData/DropDownFilterData';
Enzyme.configure({ adapter: new Adapter() });

global.console = {
  warn: jest.fn(),
  log: jest.fn(),
  error: jest.fn()
}

describe('<DropDownFilter />', function() {
  let enzymeWrapper;
  const data = {
    placeholder: 'Select a Value', 
    values: ['Hello World'],
    onClick: (data) => {
      console.log('Selected one is: ', data);
    }
  };

	beforeEach(() => {
		enzymeWrapper = mount(<DropDownFilter data={DropDownFilterData} />);
    });

    it('Only one container is rendered', () => {
		expect(enzymeWrapper.find('.drop-down-filter-container').length).toBe(1);
    });

    it('Only one input is rendered', () => {
      expect(enzymeWrapper.find('input').length).toBe(1);
    });
    
    it('All parts are rendered', () => {
      expect(enzymeWrapper.find('.drop-down-filter-container').children().length).toBe(4);
    });

    it('Dropdown button test', () => {
      const dropDown = enzymeWrapper.find('.drop-down-chevron-container');
      dropDown.simulate('click');
      enzymeWrapper.update();
      expect(enzymeWrapper.find('.drop-down-list').length).toBe(1);
    });

    it('Rendered all the list items', () => {
      const listNum = DropDownFilterData.values.length;
      const dropDown = enzymeWrapper.find('.drop-down-chevron');
      dropDown.simulate('click');
      enzymeWrapper.update();
      expect(enzymeWrapper.find('.drop-down-item').length).toBe(listNum);
    });

    it('Check that the filter works', () => {
      const textBox = enzymeWrapper.find('.drop-down-search');
      textBox.simulate('change', { target: { value: '1' } })
      expect(enzymeWrapper.find('.drop-down-item').length).toBe(2);
    });
    it('Drop down when user clicks on the text box', () => {
      const dropDown = enzymeWrapper.find('.drop-down-search');
      dropDown.simulate('click');
      enzymeWrapper.update();
      expect(enzymeWrapper.find('.drop-down-list').length).toBe(1);
    });
    it('Cancel button resets the dropdown', () => {
      const textBox = enzymeWrapper.find('.drop-down-search');
      textBox.simulate('change', { target: { value: 'i l' } })
      const reset = enzymeWrapper.find('.drop-down-cancel');
      reset.simulate('click')
      enzymeWrapper.update();
      expect(enzymeWrapper.find('.drop-down-item-container').length).toBe(DropDownFilterData.values.length);
    });
    it('Cancel button resets the search box', () => {
      const textBox = enzymeWrapper.find('.drop-down-search');
      textBox.simulate('change', { target: { value: '1' } });
      const reset = enzymeWrapper.find('.drop-down-cancel');
      reset.simulate('click');
      enzymeWrapper.update();
      let value = textBox.props().value;
      expect(value.length).toBe(0);
    });
    it('Applies the underline to unknown text', () => {
      const textBox = enzymeWrapper.find('.drop-down-search');
      textBox.simulate('change', { target: { value: 'i l' } });
      expect(enzymeWrapper.find('.drop-down-in-array').length).toBe(1);
    });
    it('Clicking a dropdown item', () => {
      let wrapper = mount(<DropDownFilter data={data} />);
      const chevron = wrapper.find('.drop-down-chevron-container');
      chevron.simulate('click');
      const dropDown = wrapper.find('.drop-down-item');
      dropDown.simulate('click');
      expect(wrapper.find('.drop-down-item').length).toBe(0);
    });
    it('Checking the default on click function works for clicking', () => {
      let wrapper = mount(<DropDownFilter data={data} />);
      const chevron = wrapper.find('.drop-down-chevron-container');
      chevron.simulate('click');
      const dropDown = wrapper.find('.drop-down-item');
      dropDown.simulate('click');
      expect(global.console.log).toHaveBeenCalledWith("Selected one is: ", 'Hello World');
    });
    it('Checking the default on click function works for typing', () => {
      let wrapper = mount(<DropDownFilter data={data} />);
      const textBox = wrapper.find('.drop-down-search');
      textBox.simulate('change', { target: { value: 'Hello World' } });
      expect(global.console.log).toHaveBeenCalledWith("Selected one is: ", 'Hello World');
    });
    it('Does the title render', () => {
      expect(enzymeWrapper.find('.vf-label-common').length).toBe(2);
    });
    it('Does the help text render', () => {
      expect(enzymeWrapper.find('.vf-label-light').length).toBe(1);
    });
});