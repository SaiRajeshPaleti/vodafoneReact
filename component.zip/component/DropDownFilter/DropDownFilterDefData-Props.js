export const defaultStyles = {
    container: 'drop-down-filter-container',
    searchContainer: 'drop-down-container',
    textBox: 'drop-down-search',
    chevron: 'drop-down-chevron',
    flipChevron: 'drop-down-chevron-flipped',
    chevronContainer: 'drop-down-chevron-container',
    cancel: 'drop-down-cancel',
    dropDownItemContainer: 'drop-down-item-container',
    dropDownItem: 'drop-down-item',
    dropDownList: 'drop-down-list',
    inArray: 'drop-down-in-array',
    cancelContainer: 'drop-down-cancel-container',
};
