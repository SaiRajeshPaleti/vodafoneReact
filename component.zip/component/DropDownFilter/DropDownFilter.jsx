import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import './DropDownFilter.css';
import Label from 'vf-ent-ws-label';
import { defaultStyles } from './DropDownFilterDefData-Props';
class DropDownFilter extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			selected: '',
			dropped: false,
			cancelActive: false
		}
	}

	componentWillMount() {
		this.updateStateInfo(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.updateStateInfo(nextProps);
	}

	updateStateInfo = (props) => {
		this.helpText = props.data.helpText ? <Label data={props.data.helpText} /> : '';
		this.title = props.data.title ? <Label data={props.data.title} /> : '';
		this.setState({
			data: props.data.values.sort(),
			selected: props.data.default && props.data.values.indexOf(props.data.default) > -1 ? props.data.default : '',
			cancelActive: props.data.default ? true : false 
		});
	};

	updateSearchBox=(event)=>{
		let value = event.target.value;
		this.setState({
			selected: value,
			dropped: true,
			cancelActive: true
		});
		this.updateDropDownItems(value);
		if (this.state.data.indexOf(value) > -1){
			this.props.data.onClick(value);
		}
	}
	
	updateDropDownItems=(value)=>{
		var updatedList = this.props.data.values;
    	updatedList = updatedList.filter(function(item){
      		return item.toLowerCase().search(
				value.toLowerCase()) !== -1;
		});
		let newData = {
			data: updatedList, 
			dropped: !(this.state.data.length === 0) || (value.length === 0),
			cancelActive: !(value.length === 0)
		};
		this.setState(newData);
	}

	dropDownOnFocus = () => {
		this.setState({
			dropped: true
		});
	}

	toggleSelected = (value) => {
		this.setState({
			cancelActive: true,
			selected: value,
		}, this.toggleDropDown());
		this.props.data.onClick(value);
	}

	toggleDropDown = () => {
		if (this.state.data.length !== 0){
			this.setState(previousState => {
				return{dropped: !previousState.dropped}
			});
		}
		
	}

	resetSearchBox = () => {
		this.setState({
			selected: '',
			dropped: true,
			data: this.props.data.values.sort(),
			cancelActive: false
		});
	}

	inArray(){
		return (this.state.selected === '') ? true : this.state.data.indexOf(this.state.selected) > -1
	}

	render(){
		return(
			<div className={`${defaultStyles.container} ${this.state.dropped ? defaultStyles.droppedActive : null}`}>
				{this.title}
				<SearchBox {...this.state}{...this.props}
					update={this.updateSearchBox}
					validate={this.inArray()}
					focus={this.dropDownOnFocus}
					reset={this.resetSearchBox}
					toggle={this.toggleDropDown}/>
				<DropDown
					data={this.state.dropped ? this.state.data : []}
					toggleSelected={this.toggleSelected}/>
				{this.helpText}
			</div>
		)
	}
}
const SearchBox = (props) => {
	return(
		<div className={`${defaultStyles.searchContainer} ${props.dropped ? defaultStyles.dropped : null}` }>
			<input placeholder={props.data.placeholder} type='text' value={props.selected} onChange={props.update} 
			className={`${defaultStyles.textBox} ${props.validate ? null : defaultStyles.inArray}`}
			onClick={props.focus}/>
			<div className={defaultStyles.cancelContainer}>
				<span onClick={props.reset} className={defaultStyles.cancel}>
				{`${props.cancelActive ? 'x' : ''}`}
				</span>
			</div>
			<div className={defaultStyles.chevronContainer} onClick={props.toggle}>
				<div className={`${defaultStyles.chevron} ${props.dropped ? defaultStyles.flipChevron : null}`}/>
			</div>
		</div>
	)
}
const DropDown = (props) => {
	return(
		<div className={defaultStyles.dropDownList}>
			{props.data.map((data, index) => 
				<div key={index} 
				onClick={() => props.toggleSelected(data)}
				className={defaultStyles.dropDownItemContainer}>
					<span className={defaultStyles.dropDownItem}>{data}</span>
				</div>
			)}
		</div>
	)
}
DropDownFilter.propTypes = {
	data: PropTypes.shape({
		placeholder: PropTypes.string,
		onClick: PropTypes.func,
		title: PropTypes.shape({
			labelName: PropTypes.string,
			type: PropTypes.string
		}),
		helpText: PropTypes.shape({
			labelName: PropTypes.string,
			type: PropTypes.string
		}),
		default: PropTypes.number,
        data: PropTypes.arrayOf(PropTypes.string)
	}).isRequired
};

export default DropDownFilter;
