import { PureComponent } from 'react';

export default class UserInfoProvider extends PureComponent {
	constructor(props) {
		super(props);
		this.state = {
			userNotifier: this.props.userNotifier,
			isLoading: false,
			isError: false
		};
		console.log('At the constructor : ' + JSON.stringify(this.state));
	}

	handleUserInfo = (value) => {
		this.setState({
			isLoading: value.isLoading,
			isError: value.isError
		});
		console.log('Invoked with : ' + JSON.stringify(value));
		// If a callback is provided, the observed value would be sent back to the parent who is consuming this component.
		//Expectation is callback will be a function.
		this.props.callback && this.props.callback(value);
	};

	componentWillUnmount() {
		if (this.state.userNotifier != undefined) {
			this.state.userNotifier.unsubscribe(this.handleUserInfo);
		}
		console.log('Unmounted');
	}

	componentWillMount() {
		if (this.state.userNotifier != undefined) {
			this.handleUserInfo.id = this.props.id;
			this.state.userNotifier.subscribe(this.handleUserInfo);
		}
		console.log('Mounted');
	}

	render() {
		console.log('At the render : ' + JSON.stringify(this.state));
		if (this.state.isLoading) return window.getLoader();
		else if (this.state.isError) return window.getError();
		else return '';
	}
}
