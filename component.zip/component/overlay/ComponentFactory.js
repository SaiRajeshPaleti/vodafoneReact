import React from 'react';
import { getContent } from './ElementRegistry';
import ValidationHOC from 'vf-ent-ws-validation-hoc';

const ComponentFactory = (fieldData, clickHandler) => {
	const ComponentContent = getContent(fieldData.type);
	let renderComponent;

	if (fieldData.body.isMissing) {
		const HOCExtension = ValidationHOC(
			ComponentContent,
			{ data: fieldData.body },
			fieldData.body.id,
			fieldData.body.MissingText
		);
		renderComponent = <HOCExtension />;
	} else {
		renderComponent = (
			<ComponentContent
				key={fieldData.body.id}
				data={fieldData.body}
				onChange={(evt) => clickHandler(evt, fieldData.body.id)}
			/>
		);
	}

	return renderComponent;
};

export default ComponentFactory;
