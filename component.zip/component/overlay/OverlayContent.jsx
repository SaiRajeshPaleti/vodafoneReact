import React from 'react';
import ComponentFactory from './ComponentFactory';
import PropTypes from 'prop-types';

const OverlayContent = (props) => {
	return <React.Fragment>{ComponentFactory(props.data)}</React.Fragment>;
};

OverlayContent.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string,
		body: PropTypes.object
	}).isRequired
};

export default OverlayContent;
