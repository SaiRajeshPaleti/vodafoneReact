import React from 'react';
import renderer from 'react-test-renderer';
import overlayData from '../../../AppData/overlayData';
import overlayFormData from '../../../AppData/overlayFormData';
import Overlay from '../overlay';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import overlayStyles from '../overlayDefData-Props';
import Adapter from 'enzyme-adapter-react-16';
import { array } from 'prop-types';

Enzyme.configure({ adapter: new Adapter() });

describe('<Overlay/>', function() {
	let props, enzymeWrapper, modalviewHandler, closemodalHandler, delHandler, cancelHandler, ewrapper;
	props = {
		data: {
		show: true,
	index: 0,
	childList: [
		{
			id: 'Generic',
			name: 'Generic',
			type: 'Generic',
			text: 'Are you sure?',
			leftButton: 'cancelBtn',
			rightButton: 'deleteBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'You are about to permanently delete this message.'
					}
				},
				{
					type: 'Label',
					body: {
						id: 'label1',
						type: 'labelDefault',
						labelname: 'Do you want to continue?'
					}
				}
			]
		}
	],
	buttondata: {
		deleteBtn: {
			id: 'primary',
			name: 'Delete',
			type: 'primary',
			buttonType: 'button'
		},
		openModal: {
			id: 'primary',
			name: 'Open Modal Box',
			type: 'primary',
			buttonType: 'button'
		},

		cancelBtn: {
			id: 'secondary',
			name: 'Cancel',
			type: 'secondary',
			buttonType: 'reset'
		}
	},
	tooltip: 'Click Here to Close',

	deleteMethod: (value) => {
		console.log(value);
		}
	}
 }

	beforeEach(() => {
		props = overlayData;
		modalviewHandler = Overlay.modalView;
		closemodalHandler = Overlay.closeModal;
		delHandler = overlayData.deleteMethod;
		cancelHandler = overlayData.cancelMethod;
		//enzymeWrapper = mount(<Overlay overlayContent={overlayData} />);
		//enzymeWrapper = shallow(<Overlay overlayContent={overlayData} />);
		enzymeWrapper = shallow( <Overlay { ...props } />);
		ewrapper = mount(<Overlay overlayContent={overlayFormData} index="0" />);
	});

	it('Overlay main div', () => {
		expect(enzymeWrapper.find('.dialog--scrollable').length).toEqual(1);
	});

	it('event handler to be called on modal view', () => {
		const span = enzymeWrapper.find('#openModal').simulate('click');
		expect(Overlay.modalView).toHaveBeenCalled;
	});

	it('event handler to be called on close Modal', () => {
		const span = enzymeWrapper.find('.accordion__chevron').simulate('click');
		expect(Overlay.closeModal).toHaveBeenCalled;
	});

	it('event handler to be called on delete method', () => {
		const span = enzymeWrapper.find('.button--primary').simulate('click');
		expect(overlayData.deleteMethod).toHaveBeenCalled;
	});

	it('event handler to be called on close Modal', () => {
		const span = enzymeWrapper.find('.button--secondary').simulate('click');
		expect(overlayData.cancelMethod).toHaveBeenCalled;
	});

	it('checks the modal count', () => {
		expect(eWrapper.find('#openModal').length.toEqual(OverlayFormData.childList.length));
	});

	it('should cancelHandler function', () => {
		enzymeWrapper.instance().cancelHandler();
	}); 
	it('should closeModal function', () => {
		enzymeWrapper.instance().closeModal();
	}); 
	it('should closeModal function', () => {
		enzymeWrapper.instance().cancelMethod();
	});
	it('should clickHandler function', () => {
		enzymeWrapper.instance().clickHandler('click');
	});
	it('should rejectHandler function', () => {
		enzymeWrapper.instance().rejectHandler('Reject');
	});
	it('should render overlay component', () => {
		expect(enzymeWrapper).not.toBe(null);
	}); 
	it('should render componentWillReceiveProps component', () => {
		const nextProps = props;
		enzymeWrapper.instance().componentWillReceiveProps(nextProps);
	}); 
	it('should render Overlay component', () => {
		expect(enzymeWrapper).not.toBe(null);
	});
	it('Overlay Component should render div', () => {		 		     
        expect(enzymeWrapper.find('div').length).toBe(1);
	});
	it('Overlay Component should render setMissing', () => {		 		     
        enzymeWrapper.instance().setMissing(array);
	});

});
