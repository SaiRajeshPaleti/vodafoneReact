import TextArea from 'vf-ent-ws-textarea';
import DropdownComponent from 'vf-ent-ws-simple-dropdown';
import Label from 'vf-ent-ws-label';
import AlertMessage from 'vf-ent-ws-alert-message';
import TextField from 'vf-ent-ws-textfield';

const ElementRegistry = {
	TextArea: TextArea,
	Dropdown: DropdownComponent,
	Label: Label,
	Alert: AlertMessage,
	TextField: TextField
};

export function getContent(type) {
	return ElementRegistry[type];
}
