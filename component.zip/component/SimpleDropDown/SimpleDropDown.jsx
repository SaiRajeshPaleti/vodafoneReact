import React from 'react';
import { defaultStyles, defaultData, constData } from './SimpleDropDownDefData-Props';
import './SimpleDropDown.css';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

class DropdownComponent extends BaseComponent {
	constructor(props) {
		super(props);

		this.resetToDefault = this.resetToDefault.bind(this);
		this.dropDown = this.dropDown.bind(this);
		this.loadInit = this.loadInit.bind(this);
		this.loadContent = this.loadContent.bind(this);

		this.getDropDownList = this.getDropDownList.bind(this);
		this.hideContent = this.hideContent.bind(this);

		this.resetToDefault();
	}

	resetToDefault() {
		let textTodisplay = this.props.data.title;
		this.props.data.dropdownValues
			? this.props.data.dropdownValues.map((test) => {
					if (test.optionValue == this.props.data.value) textTodisplay = test.optionName;
				})
			: null;
		this.state = {
			arrowIcon: false,
			displayText: textTodisplay
		};
	}

	componentWillReceiveProps(nextProps) {
		let textToprint = this.props.data.title;
		nextProps.data.dropdownValues && nextProps.data.dropdownValues.map((test) => {
			if (test.optionValue == nextProps.data.value) textToprint = test.optionName;
		});
		this.setState({
			displayText: textToprint
		});
		this.loadInit();
	}

	dropDown() {
		this.setState({
			arrowIcon: !this.state.arrowIcon
		});
	}

	getDropDownList(label,value) {
		console.log(label, 'event');
		const event = {
			target: {
				id: this.props.data.id,
				value: {
					label:label,
					value:value
				}
			}
		};
		this.delegateHandler('onChange', event, 'value');
		this.setState({
			displayText: label,
			arrowIcon: !this.state.arrowIcon
		});
		// Updated for delegate handler
	}

	hideContent() {
		this.setState({ arrowIcon: false });
	}

	loadInit() {
		return (
			<DropInit
				data={this.props.data}
				text={this.state.displayText}
				arrowIcon={this.state.arrowIcon}
				dropDown={this.dropDown}
			/>
		);
	}

	loadContent() {
		if (this.state.arrowIcon) {
			return (
				!this.props.data.disabled && (
					<DropContent
						data={this.props.data}
						arrowIcon={this.state.arrowIcon}
						getDropDownList={this.getDropDownList}
						hideContent={this.hideContent}
					/>
				)
			);
		} else {
			return '';
		}
	}

	render() {
		return (
			<div id={this.props.data.id} name={this.props.data.name} className={defaultStyles.cusDropDown}>
				{this.loadInit()}
				{this.loadContent()}
			</div>
		);
	}
}

const DropInit = ({ data, arrowIcon, dropDown, text }) => (
	<div
		className={arrowIcon ? defaultStyles.activeCls : defaultStyles.inactiveCls}
		title={data.title}
		onClick={dropDown}
	>
		<div className={defaultStyles.heading}>
			<span>{text}</span>
		</div>
		<span className={defaultStyles.Sprite}>
			<Icon name={defaultStyles.iconName} />
		</span>
	</div>
);

const DropContent = ({ data, hideContent, arrowIcon, getDropDownList }) => (
	<div className={arrowIcon ? defaultStyles.activeRelativeCls : defaultStyles.display_none} onClick={hideContent}>
		<ul className={defaultStyles.listRest}>
			{data.dropdownValues ? (
				data.dropdownValues.map((dropDownData, index) => (
					<li key={index} onClick={() => getDropDownList(dropDownData.optionName,dropDownData.optionValue)}>
						{dropDownData.optionName}
					</li>
				))
			) : (
				''
			)}
		</ul>
	</div>
);

DropdownComponent.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		name: PropTypes.string,
		clickTxt: PropTypes.string,
		title: PropTypes.string,
		dropdownValues: PropTypes.arrayOf(
			PropTypes.shape({
				optionName: PropTypes.string.isRequired,
				optionValue: PropTypes.string
			})
		),
		onChange: PropTypes.func
	})
};

export default DropdownComponent;
