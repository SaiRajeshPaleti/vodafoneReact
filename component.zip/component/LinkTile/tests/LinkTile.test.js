import React from 'react';
import LinkTile from '../LinkTile';
//import renderer from 'react-test-render';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import LinkTileData from '../../../AppData/LinkTileData';
Enzyme.configure({ adapter: new Adapter() });

global.console = {
    log: jest.fn(),
    error: jest.fn()
} 

describe('<LinkTile />', function() {
    let props, enzymeWrapper;

    beforeEach(() => {
        props = LinkTileData;
        enzymeWrapper = mount(<LinkTile data={props.tileData[0]} />);
    });

    it('Link tile must contain positioning div', () => {
        expect(enzymeWrapper.exists('.link-tile-position')).toEqual(true);
    });
    it('Link tile has been passed a function and executes it on click', () => {
        const tile = enzymeWrapper.find('.link-tile');
        tile.simulate('click');
        enzymeWrapper.update();
        expect(global.console.log).toHaveBeenCalled();
    });
    it('Link tile must contain wrapper div for icon', () => {
        expect(enzymeWrapper.exists('.link-tile-icon')).toEqual(true);
    });
    it('Link tile to render big circle component as first element of icon', () => {
        expect(enzymeWrapper.exists('.lt-circle-icon')).toEqual(true);
    });
    it('Link tile to render small circle component as second element of icon', () => {
        expect(enzymeWrapper.exists('.lt-small-circle-icon')).toEqual(true);
    });
    it('Link tile to render type of link component as third element of icon', () => {
        expect(enzymeWrapper.exists('.lt-type-icon')).toEqual(true);
    });
    it('Link tile to render + as fourth and final element of the icon', () => {
        expect(enzymeWrapper.exists('.lt-small-circle-content')).toEqual(true);
    });
    it('Link tile to render arrow icon', () => {
        expect(enzymeWrapper.exists('.link-tile-arrow')).toEqual(true);
    });
    it('Link tile must contain div for text element', () => {
        expect(enzymeWrapper.exists('.link-tile-text-box')).toEqual(true);
    });
    it('Link tile must have a title and description, with the correct parts highlighted', () => {
        expect(enzymeWrapper.exists('.link-tile-title')).toEqual(true);
        expect(enzymeWrapper.exists('.link-tile-description')).toEqual(true);
        expect(enzymeWrapper.find('.link-tile-highlight-string').length).toBe(4);
    });
});