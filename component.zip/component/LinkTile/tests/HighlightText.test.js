import React from 'react';
import HighlightText from '../HighlightText';
import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
Enzyme.configure({ adapter: new Adapter() });

global.console = {
    error: jest.fn()
} 

describe('<HighlightText />', function() {
    let noSearch, emptySearch, simpleSearch, multiplesSearch, letterSearch, symbolSearch, spaceSearch, halfWordSearch, variableSearch;
    let noWrapper, emptyWrapper, simpleWrapper, multiplesWrapper, letterWrapper, symbolWrapper, spaceWrapper, halfWordWrapper, variableWrapper;
    const testVar = 'test';

    beforeEach(() => {
        noSearch = {
            fullString: 'This is a test string'
        };
        emptySearch = {
            fullString: 'This is a test string',
            searchString: ''
        };
        simpleSearch = {
            fullString: 'This is a test string',
            searchString: 'test'
        };
        multiplesSearch = {
            fullString: 'This is a test string with two instances of the test search word',
            searchString: 'test'
        };
        letterSearch = {
            fullString: 'This is a test string',
            searchString: 's'
        };
        symbolSearch = {
            fullString: 'This is a test string!!!! (with exclamation marks)',
            searchString: '!!!'
        };
        spaceSearch = {
            fullString: 'This is a test string',
            searchString: 'is a test'
        };
        halfWordSearch = {
            fullString: 'This is a test string',
            searchString: 'str'
        };
        variableSearch = {
            fullString: 'This is a test string',
            searchString: `${testVar} str`
        }
        noWrapper = shallow(<HighlightText data={noSearch} />);
        emptyWrapper = shallow(<HighlightText data={emptySearch} />);
        simpleWrapper = shallow(<HighlightText data={simpleSearch} />);
        multiplesWrapper = shallow(<HighlightText data={multiplesSearch} />);
        letterWrapper = shallow(<HighlightText data={letterSearch} />);
        symbolWrapper = shallow(<HighlightText data={symbolSearch} />);
        spaceWrapper = shallow(<HighlightText data={spaceSearch} />);
        halfWordWrapper = shallow(<HighlightText data={halfWordSearch} />);
        variableWrapper = shallow(<HighlightText data={variableSearch} />);
    });
    it ('Function should return full string without anything highlighted when searchString is not present', () => {
        expect(noWrapper.html()).toEqual(
            '<span><span>This is a test string</span></span>');
    });
    it ('Function should return full string without anything highlighted when the search string is empty', () => {
        expect(emptyWrapper.html()).toEqual(
            '<span><span>This is a test string</span></span>');
    });
    it ('Function should return string with single highlighted search word', () => {
        expect(simpleWrapper.html()).toEqual(
            '<span><span>This is a <span class="link-tile-highlight-string">test</span>' + 
            ' string<span class="link-tile-highlight-string"></span></span></span>');
    });
    it ('Function should return string with two highlighted search words', () => {
        expect(multiplesWrapper.html()).toEqual(
            '<span><span>This is a <span class="link-tile-highlight-string">test</span>' + 
            ' string with two instances of the <span class="link-tile-highlight-string">test' + 
            '</span> search word<span class="link-tile-highlight-string"></span></span></span>');
    });
    it ('Function should return string with highlighted search letters', () => {
        expect(letterWrapper.html()).toEqual(
            '<span><span>Thi<span class="link-tile-highlight-string">s</span>' + 
            ' i<span class="link-tile-highlight-string">s</span> a te' + 
            '<span class="link-tile-highlight-string">s</span>t ' + 
            '<span class="link-tile-highlight-string">s</span>tring' + 
            '<span class="link-tile-highlight-string"></span></span></span>');
    });
    it ('Function should return string with highlighted symbols', () => {
        expect(symbolWrapper.html()).toEqual(
            '<span><span>This is a test string<span class="link-tile-highlight-string">' + 
            '!!!</span>! (with exclamation marks)<span class="link-tile-highlight-string">' + 
            '</span></span></span>');
    });
    it ('Function should return string properly when search string contains spaces', () => {
        expect(spaceWrapper.html()).toEqual(
            '<span><span>This <span class="link-tile-highlight-string">is a test</span>' + 
            ' string<span class="link-tile-highlight-string"></span></span></span>');
    });
    it ('Function should return string highlighting only half of a word', () => {
        expect(halfWordWrapper.html()).toEqual(
            '<span><span>This is a test <span class="link-tile-highlight-string">str' + 
            '</span>ing<span class="link-tile-highlight-string"></span></span></span>');
    });
    it ('Function should work with a string variable passed in', () => {
        expect(variableWrapper.html()).toEqual(
            '<span><span>This is a <span class="link-tile-highlight-string">test str' + 
            '</span>ing<span class="link-tile-highlight-string"></span></span></span>');
    });
});