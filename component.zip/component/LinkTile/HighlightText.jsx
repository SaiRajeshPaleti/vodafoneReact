import React from 'react';
import PropTypes from 'prop-types';
import { constStyles } from './HighlightTextDefProps';

const highlightText = (props) => {
    let searchTermLocations;

    const getSearchTermLocations = (loc) => {
        return searchTermLocations[loc];
    }

    const getSearchTermLocationsArray = () => {
        return searchTermLocations;
    }

    const setSearchTermLocations  = (arr) => {
        searchTermLocations = arr;
    }

    const addToSearchTermLocations = (str) => {
        searchTermLocations.push(str);
    }

    const searchStringLength = () => {
        return props.data.searchString.length;
    }

    const isStringPresent = (fullString, searchString) => {
        const lowerCaseString = fullString.toLowerCase();
        let lowerCaseSearch = null;
        if (searchString != null && searchString != '')
            lowerCaseSearch = searchString.toLowerCase();

        if (lowerCaseSearch!= null && lowerCaseString.includes(lowerCaseSearch)) {
            return searchStringIsPresent(lowerCaseString, lowerCaseSearch);
        } else {
            return noSearchStringPresent(fullString);
        }
    }

    const noSearchStringPresent = (fullString) => {
        return (
            <span>
                {fullString}
            </span>
        )
    }

    const searchStringIsPresent = (lowerCaseString, lowerCaseSearch) => {  
        setSearchTermLocations([lowerCaseString.indexOf(lowerCaseSearch)]);

        return findLocationsOfSearchString(lowerCaseString, lowerCaseSearch);
    }

    const findLocationsOfSearchString = (lowerCaseString, lowerCaseSearch) => {
        let highestIndexLocation = getSearchTermLocations(0) + searchStringLength();
        if (lowerCaseString.lastIndexOf(lowerCaseSearch) != "-1") {
            let nextHighest;
            while(highestIndexLocation < lowerCaseString.lastIndexOf(lowerCaseSearch)) {
                nextHighest = lowerCaseString.indexOf(lowerCaseSearch, highestIndexLocation);
                addToSearchTermLocations(nextHighest);
                highestIndexLocation = nextHighest + searchStringLength();
            }
        }

        addToSearchTermLocations(lowerCaseString.length);
        return splitFullString();
    }

    const splitFullString = () => {
        let fullString = props.data.fullString;
        let splitStringArray = []; 
        let prevIndexPos = 0; 
        let j = 0;

        for (let i = 0; i < getSearchTermLocationsArray().length ; i++) {
            splitStringArray[j] = 
                fullString.slice(prevIndexPos, getSearchTermLocations(i));
            j++;
            splitStringArray[j] = 
                fullString.slice(getSearchTermLocations(i), 
                getSearchTermLocations(i) + searchStringLength());
            j++;
            prevIndexPos = getSearchTermLocations(i) + searchStringLength();
        }

        addToSearchTermLocations(
            fullString.slice(
                getSearchTermLocations(getSearchTermLocationsArray().length - 2) +
                searchStringLength()
            )
        );

        return createArrayToReturn(splitStringArray);
    }

    const createArrayToReturn = (splitStringArray) => {
        const returnArray = [];
        for (let i = 0; i < splitStringArray.length; i += 2 ) {
            returnArray.push(splitStringArray[i], <span className={constStyles.highlight}>{splitStringArray[i + 1]}</span>);
        }

        return returnHighlightedText(returnArray);
    }

    const returnHighlightedText = (returnArray) => {
        return (
            <span>
                {returnArray.map((item) => (item))}
            </span>
        )
    }

    return (
        <span>
            {isStringPresent(props.data.fullString, props.data.searchString)}
        </span>
    )
}

highlightText.propTypes = {
    data: PropTypes.shape({
        fullString: PropTypes.string.isRequired,
        searchString: PropTypes.string.isRequired
    }).isRequired
};

export default highlightText;