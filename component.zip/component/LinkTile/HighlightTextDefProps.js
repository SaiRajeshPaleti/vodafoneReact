export const defaultProps = {
    fullString: 'This is a test string',
    searchString: 'test'
}

export const constStyles = {
	highlight: 'link-tile-highlight-string'
};