import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import { constStyles , defaultProps } from './LinkTileDefProps';
import highlightText from './HighlightText';
import './LinkTile.css';

const linkTile = (props) => {
    const titleData = {
        data: {
            searchString: props.data.highlightText,
            fullString: props.data.title
        }
    };
    const descriptionData = {
        data: {
            searchString: props.data.highlightText,
            fullString: props.data.description
        }
    };

    return (
        <div className={constStyles.position}>
            <div className={constStyles.linkTile} onClick={() => props.data.onClick(props.data.id, props.data.title)}>
                <div className={constStyles.icon}>
                    
                    <span className={constStyles.linkTypeIcon}>
                        <Icon name={props.data.icon}/>
                    </span>

                    <div className={constStyles.circleIcon} />

                    <div className={constStyles.smallCircleIcon}>
                        <span className={constStyles.smallCircleContent}>
                            +
                        </span>
                    </div>
                </div>
                
                <span className={constStyles.arrow} />

                <div className={constStyles.text}>
                    <div className={constStyles.title}>
                        {highlightText(titleData)}
                    </div>
                    <div className={constStyles.description}>
                        {highlightText(descriptionData)}
                    </div>
                </div>
            </div>
        </div>
    )
};

linkTile.propTypes = {
    data: PropTypes.shape({
        id: PropTypes.string.isRequired,
        title: PropTypes.string.isRequired,
        description: PropTypes.string.isRequired,
        icon: PropTypes.oneOf(
            'warning', 
            'settings',
            'icon-shopping-trolley', 
            'icon-report', 
            'icon-reports', 
            'sms',
            'icon-data'
        ).isRequired,
        onClick: PropTypes.func.isRequired,
        highlightText: PropTypes.string
    }).isRequired
};

linkTile.defaultProps = { data: defaultProps };

export default linkTile;