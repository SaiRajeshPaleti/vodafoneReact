export const defaultProps = {
	id: 'linktile1',
	title: 'Default title',
	description: 'Default description',
	icon: 'settings',
	onClick: (id, title) => {
		console.log('Clicked by ' + id + ' with the title ' + title)
	},
	highlightText: 'default'
}

export const constStyles = {
	linkTile: 'link-tile',
	title: 'link-tile-title',
	description: 'link-tile-description',
	arrow: 'link-tile-arrow',
	linkTypeIcon: 'lt-type-icon',
	circleIcon: 'lt-circle-icon',
	smallCircleIcon: 'lt-small-circle-icon',
	smallCircleContent: 'lt-small-circle-content',
	linkTilePositioning: 'lt-positioning',
	linkTileFont: 'lt-font',
	icon: 'link-tile-icon',
	text: 'link-tile-text-box',
	position: 'link-tile-position',
	redArrowIcon: 'chevron-right-red',
	highlightString: 'link-tile-highlight-string'
};