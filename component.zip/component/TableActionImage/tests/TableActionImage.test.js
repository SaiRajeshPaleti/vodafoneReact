import React from 'react';
import renderer from 'react-test-renderer';

import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import TableActionImage from '../TableActionImage';
import TableImageData from '../../../AppData/TableImageData';
import SlideComponent from '../SlideComponent';

Enzyme.configure({ adapter: new Adapter() });

console.log(TableActionImage, 'TableActionImage');

describe('<TableActionImage  />', function() {
	let props, enzymeWrapper, enzymeWrapperSlide, enzymeWrapperComponent, enzymeWrapperDatatype2, enzymeWrapperComp;

	beforeEach(() => {
		props = TableImageData;
		enzymeWrapper = shallow(<TableActionImage data={TableImageData[0]} />);
		enzymeWrapperDatatype2 = mount(<TableActionImage data={TableImageData[1]} />);
		enzymeWrapperSlide = shallow(<SlideComponent data={TableImageData[0]} />);
	});

	// console.log(TableImageData, "enzymeWrapperComponent")

	it('should render the Component', () => {
		expect(
			enzymeWrapper.containsMatchingElement(
				<Component
					controlType={TableImageData.controlType}
					ActionData={TableImageData.ActionData}
					actionHandler={TableImageData.actionHandler}
					rowData={TableImageData.rowData}
				/>
			)
		).toEqual(true);
	});
	it('should render the DataType2 Component', () => {
		expect(
			enzymeWrapperDatatype2.containsMatchingElement(
				<Component
					controlType={TableImageDataType2.controlType}
					ActionData={TableImageDataType2.ActionData}
					actionHandler={TableImageDataType2.actionHandler}
					rowData={TableImageDataType2.rowData}
				/>
			)
		).toEqual(true);
	});
	it('should render the SlideComponent', () => {
		const getClick = enzymeWrapperComponent.find('.floatIcon').simulate('click');
		expect(
			enzymeWrapperComponent.containsMatchingElement(
				<SlideComponent
					Data={TableImageData.ActionData}
					actionHandler={TableImageData.actionHandler}
					rowData={TableImageData.rowData}
				/>
			)
		).toEqual(true);
	});

	// //SlideComponent.JS Test Cases

	it('SlideComponent contains hoverItems ', () => {
		expect(enzymeWrapperSlide.find('.hoverItems').length);
	});

	it('Component contains floating_actions ', () => {
		expect(enzymeWrapperComponent.find('.floating_actions').length).toEqual(1);
	});

	it('SlideComponent contains sprite__icon', () => {
		expect(enzymeWrapperSlide.find('.sprite__icon ').length).toEqual(1);
	});
	it('SlideComponent contains floatIcon ', () => {
		expect(enzymeWrapperComponent.find('.floatIcon').length).toEqual(1);
	});

	it('event handler to be called on  change', () => {
		const span = enzymeWrapperComponent.find(TableImageData.ActionData.imageType);

		span.simulate('click');
		expect(Component.handleClick).toHaveBeenCalled;
	});

	it('should find onChange Fn', () => {
		const mockedEvent = { target: { value: 'order', name: 'order' } };

		const getfucntion = enzymeWrapperComponent.instance().handleClick(mockedEvent);
		expect(TableImageData.actionHandler).toHaveBeenCalled;
	});

	it('invokeActionHandler needs to be called ', () => {
		const mockedEvent = 0;

		const getfucntionSlide = enzymeWrapperSlide.instance().invokeActionHandler(mockedEvent);
		expect(TableImageData.actionHandler).toHaveBeenCalled;
		// expect(TableImageData.actionHandler.value).toEqual(approveCharges)
	});

	it('invokeActionHandler needs to be called ', () => {
		const mockedEvent = 0;
		//  component.find('ul').first().children().map(child => child.childAt(0).text())

		const getfucntionSlideul = enzymeWrapperSlide
			.instance()
			.find(ul)
			.first()
			.children()
			.map((child) => child.childAt(0));
		getfucntionSlideul.simulate(click);
		expect(enzymeWrapperSlide.invokeActionHandler).toHaveBeenCalled;
	});

	it('should find onChange Fn', () => {
		const mockedEvent = { target: { value: 'order', name: 'order' } };

		const getfucntion = enzymeWrapperComponent.instance().handleClick(mockedEvent);
	});

	it('should find onChange Fn', () => {
		const mockedEvent = { target: { value: 'order', name: 'order' } };

		enzymeWrapperComp.instance().handleClick(mockedEvent);
		expect(TableImageDataType2.actionHandler).toHaveBeenCalled;

		let visible = enzymeWrapperComp.state().visible;
		let paramsObj = enzymeWrapperComp.state().paramsObj;
		setTimeout(() => {
			expect(visible).to.equal(0);

			expect(paramsObj).toEqual({ QuoteReferenceNumber: 'QuoteReferenceNumber' });
		}, 100);

		expect(TableImageDataType2.actionHandler).toHaveBeenCalled;

		expect(enzymeWrapperComp.checkParam).toHaveBeenCalled;

		//  expect(TableImageDataType2.actionHandler().value).length.toEqual(1);

		//expect(TableImageDataType2.actionHandler().param).toEqual(TableImageDataType2.ActionData.revalidateQuote)
	});

	it('Mock Function', () => {
		const mockedEvent = { target: { value: 'order', name: 'order' } };
		const mockCallback = jest.fn();
		enzymeWrapperComp.instance().handleClick(mockedEvent, mockCallback);
	});
	
	it('TableActionImage click handler event ', () => {
		const event = {target: { value: "Address"}};
		enzymeWrapperSlide.find('.borderClass').at(0).simulate('click',event);
		expect(enzymeWrapperSlide.onClick).toHaveBeenCalled;
	});
	
});
