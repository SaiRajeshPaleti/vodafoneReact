import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import ActionImageStyles from './TableActionDefData-Props';
import BaseComponent from 'vf-ent-ws-utilities';

class SlideComponent extends BaseComponent {
	constructor(props) {
		super(props);
		this.onClick = this.onClick.bind(this);
	}
	validateFunArgs(arg) {
		return arg;
	}
	onClick(index) {
		let paramsObj = {};
		this.props.data.ActionData.selectionData[index].params.map((param, i) => {
			paramsObj[param] = this.props.data.rowData[param];
			return param;
		});
		let actionMethod = this.props.data.ActionData.selectionData[index].ActionMethod;
		this.delegateHandler(
			ActionImageStyles.actions.onClick,
			{ methodName: actionMethod, params: paramsObj },
			this.validateFunArgs
		);
	}

	render() {
		return (
			<div className={ActionImageStyles.constStyles.floatItems}>
				<ul>
					{this.props.data.ActionData.selectionData.map((item, index) => (
						// <div className={ActionImageStyles.constStyles.borderClass}>
						<li
							className={ActionImageStyles.constStyles.borderClass}
							onClick={() => this.onClick(index)}
							key={index}
						>
							<a>{item.label} </a>
							<div className={ActionImageStyles.constStyles.floatingListIcons}>
								<span className={ActionImageStyles.constStyles.spriteIcon}>
									<Icon name={ActionImageStyles.constStyles.chevronRight} />
								</span>
							</div>
						</li>
						// </div>
					))}
				</ul>
			</div>
		);
	}
}
export default SlideComponent;
SlideComponent.propTypes = {
	data: PropTypes.shape({
		controlType: PropTypes.string.isRequired,
		isSelected: PropTypes.bool.isRequired,
		key: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		onClick: PropTypes.func.isRequired,
		rowData: PropTypes.arrayOf(PropTypes.string.isRequired).isRequired,
		ActionData: PropTypes.shape({
			ActionMethod: PropTypes.string,
			IconType: PropTypes.string.isRequired,
			actionToBePerformed: PropTypes.string.isRequired,
			imageType: PropTypes.string.isRequired,
			imagealt: PropTypes.string.isRequired,
			isChoiceAction: PropTypes.bool.isRequired,
			selectionData: PropTypes.arrayOf(
				PropTypes.shape({
					ActionMethod: PropTypes.string.isRequired,
					label: PropTypes.string.isRequired,
					params: PropTypes.arrayOf(PropTypes.string.isRequired).isRequired
				})
			).isRequired
		})
	})
};
