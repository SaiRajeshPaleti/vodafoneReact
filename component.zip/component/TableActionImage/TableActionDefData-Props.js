const ActionImageStyles = {
	constStyles: {
		filteringDropdown: 'filtering__dropdown dropdown customDropdown choose_columns',
		multiSelect: 'filtering__dropdown--button dropdown__button',
		dropdownHeading: 'dropdown__heading',
		dropdownChevron: 'icon dropdown dropdown__chevron',
		spriteIcon: 'sprite__icon',
		multiselectContainer:
			'multiselect-container dropdown-menu-new dropdown__panel dropdown__panel--column custom-menu-dp',
		linkClass: 'link',
		dropdownHeadingLight: 'dropdown__heading--light',
		w100: 'dropdown',
		floatingActions: 'floating_actions',
		refreshIcon: 'refresh__icon',
		floatItems: 'floatItems',
		floatingListIcons: 'floating-list-icons',
		chevronRight: 'chevron-right',
		borderClass: 'borderClass'
	},
	actions: {
		onClick: 'onClick'
	}
};
export default ActionImageStyles;
