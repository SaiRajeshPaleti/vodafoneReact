import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import './TableActionImage.css';
import CSSTransitionGroup from 'react-addons-css-transition-group';
import ActionImageStyles from './TableActionDefData-Props';
import SlideComponent from './SlideComponent';

class TableActionImage extends BaseComponent {
	constructor(props) {
		super(props);

		this.updateSlider = this.updateSlider.bind(this);
		this.sliderComponentClose = this.sliderComponentClose.bind(this);
		this.onClick = this.onClick.bind(this);
		this.state = {
			showSlider: false,
			paramsObj: {},
			sliderComponent: ''
		};
	}
	componentWillMount() {
		this.updateSlider(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.updateSlider(nextProps);
	}
	validateFunArgs(arg) {
		return arg;
	}
	updateSlider(props = this.props, status = false) {
		let paramsObj = {};
		if (!props.data.ActionData.isChoiceAction) {
			props.data.ActionData.params.map((param, index) => {
				paramsObj[param] = props.data.rowData[index];
				return param;
			});
			this.delegateHandler(ActionImageStyles.actions.onClick, paramsObj, this.validateFunArgs);
		}
		const isSelection = props.data.ActionData.isChoiceAction;
		this.setState({
			paramsObj: paramsObj,
			sliderComponent: isSelection && (
				<CSSTransitionGroup {...props.data.ActionData.transitionData}>
					{status && <SlideComponent data={props.data} />}
				</CSSTransitionGroup>
			),
			tooltip: props.data.tooltip ? props.data.tooltip : ''
		});
	}
	onClick(e) {
		this.setState({
			showSlider: !this.state.showSlider
		});
		this.updateSlider(this.props, !this.state.showSlider);
	}

	sliderComponentClose(e) {
		this.setState({
			showSlider: false
		});
		this.updateSlider(this.props, false);
	}

	render() {
		return (
			<div
				className={ActionImageStyles.constStyles.floatingActions}
				tabIndex="0"
				onBlur={this.sliderComponentClose}
			>
				<div className={this.props.data.ActionData.imageType} onClick={this.onClick}>
					<div className={ActionImageStyles.constStyles.refreshIcon}>
						<span className={ActionImageStyles.constStyles.spriteIcon} title={this.state.tooltip}>
							<Icon name={this.props.data.ActionData.IconType} />
						</span>
					</div>
					{this.state.sliderComponent}
				</div>
			</div>
		);
	}
}

export default TableActionImage;
TableActionImage.propTypes = {
	data: PropTypes.shape({
		controlType: PropTypes.string.isRequired,
		isSelected: PropTypes.bool.isRequired,
		key: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		onClick: PropTypes.func.isRequired,
		rowData: PropTypes.arrayOf(PropTypes.string.isRequired).isRequired,
		ActionData: PropTypes.shape({
			ActionMethod: PropTypes.string,
			IconType: PropTypes.string.isRequired,
			actionToBePerformed: PropTypes.string.isRequired,
			imageType: PropTypes.string.isRequired,
			imagealt: PropTypes.string.isRequired,
			isChoiceAction: PropTypes.bool.isRequired,
			params: PropTypes.arrayOf(PropTypes.string.isRequired)
		})
	})
};
