export default {
  border: 'border'
};
