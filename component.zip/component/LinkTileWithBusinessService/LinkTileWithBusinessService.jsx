import React from 'react';
import PropTypes from 'prop-types';
import './LinkTileWithBusinessService.css';
import constStyles from './LinkTileWithBusinessServiceDef-props';
import LinkTile from 'vf-ent-ws-link-tile';
import HighlightText from 'vf-ent-ws-link-tile/HighlightText';

const LinkTileWithBusinessService = (props) => {
  return (
    <div>
      {props.data.linkTile.map((list) => {
        const highlightedData = {
          searchString: list.highlightText,
          fullString: list.businessServicename
        };

        return (
          <div key={list.id}>
            <div className={list.businessServicename ? constStyles.border : ''}>
              <HighlightText data={highlightedData} />
            </div>

            {list.tileData.map((linktile) => {
              return <LinkTile key={linktile.id} data={linktile} />;
            })}
          </div>
        );
      })}
    </div>
  );
};

LinkTileWithBusinessService.propTypes = {
  data: PropTypes.shape({
    linkTile: PropTypes.arrayOf(
      PropTypes.shape({
        businessServicename: PropTypes.string.isRequired,
        highlightText: PropTypes.string.isRequired,
        tileData: PropTypes.arrayOf(
          PropTypes.shape({
            description: PropTypes.string.isRequired,
            highlightText: PropTypes.string.isRequired,
            icon: PropTypes.string.isRequired,
            onClick: PropTypes.func,
            id: PropTypes.string.isRequired,
            title: PropTypes.string.isRequired
          }).isRequired
        ).isRequired
      }).isRequired
    ).isRequired
  }).isRequired
};
export default LinkTileWithBusinessService;
