import React from 'react';
import renderer from 'react-test-renderer';
import CheckBox from '../checkBox';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<CheckBox />', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = {
			data:{
				id: '1',
				name: 'checkbox',
				tooltip: 'Click on CheckBox to select',
				displayValue: 'Check Box Text',
				value: 'check Box Value'
			}
		}

		enzymeWrapper = mount(< CheckBox { ...props }/>);
	});

	it('verifying number of divisions', () => {
		expect(enzymeWrapper.find('div').length).toBe(1);
	});
	it('verifying input field', () => {
		expect(enzymeWrapper.find('div').childAt(0).type()).toBe('input');
	});
	it('CheckBox Component simulate change event', () => {
		const event = {data : {id:'1',value:true}};
		let check = enzymeWrapper.find('input').at(0);
		check.simulate('change',event);
		
	});
	it('life cycle method to be called when props value changes',() => {
		let nextProps = props;
		expect(enzymeWrapper.instance().componentWillReceiveProps(nextProps)).toHaveBeenCalled;
	});
	it('CheckBox Component simulate change event and verifies the condition', () => {
		const event = {data : {id:'1',value:true}};
		let check = enzymeWrapper.find('input').at(0);
		check.simulate('change',event);
		expect(enzymeWrapper.state().checked).toBe('checked');
		const checked = enzymeWrapper.state().checked;
		expect(checked).toBe('checked');
		
	});
	it('state value changing', () => {
		const checked = enzymeWrapper.state().checked;
		expect(checked.length).toBe(0);
	});
});
