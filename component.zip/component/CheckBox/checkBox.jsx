import React from 'react';
import { constStyles, constData, defaultData } from './checkBoxDefData-Props';
import './checkBox.css';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class CheckBox extends BaseComponent {
	constructor(props) {
		super(props);
		let checked;
		this.inputMyRef = React.createRef();
		if (props.data.value === 'true') {
			checked = 'checked';
		} else {
			checked = '';
		}

		this.state = {
			checked,
			disabled: props.data.disabled
		};
	}

	componentDidMount() {
		if (this.props.data.value) {
			this.inputMyRef.current.value = this.props.data.value;
		}
	}
	componentWillReceiveProps(nextprops) {
		let checked;
		if (nextprops.data.value) {
			if (nextprops.data.value === 'true') {
				checked = 'checked';
			} else {
				checked = '';
			}
			this.inputMyRef.current.value = nextprops.data.value;
		}
		this.setState({
			checked,
			disabled: nextprops.data.disabled
		});
	}
	onChange(event) {
		if (this.state.disabled != true) {
			if (this.state.checked === 'checked') {
				this.inputMyRef.current.value = 'false';
				this.setState({ checked: '' });
			} else {
				this.inputMyRef.current.value = 'true';
				this.setState({ checked: 'checked' });
			}
			this.delegateHandler(constData.onChangeProperty, event, constData.checked);
		}
	}
	render() {
		const isDisabled = this.props.data.disabled ? { disabled: 'true' } : '';
		return (
			<div className={constStyles.checkBoxClass}>
				<input
					type={constData.inputType}
					name={this.props.data.name + '_checkbox'}
					className={constStyles.boxClass}
					id={this.props.data.id + '_checkbox'}
					onChange={(event) => this.onChange(event)}
					checked={this.state.checked}
					title={this.props.data.tooltip}
					{...isDisabled}
				/>
				<p htmlFor={this.props.data.checkBoxId} className={constStyles.checkBoxTextClass}>
					{this.props.data.displayValue}
				</p>
				<input name={this.props.data.name} id={this.props.data.id} type="hidden" ref={this.inputMyRef} />
			</div>
		);
	}
}

CheckBox.propTypes = {
	data: PropTypes.shape({
		name: PropTypes.string.isRequired,
		id: PropTypes.string.isRequired,
		checked: PropTypes.bool,
		tooltip: PropTypes.string,
		displayValue: PropTypes.string,
		onChange: PropTypes.func.isRequired
	}).isRequired
};
CheckBox.defaultProps = {
	data: defaultData
};

export default CheckBox;
