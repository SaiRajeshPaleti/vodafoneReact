import React from 'react';
import './AlertMessages.css';
import { constStyles, defaultData } from './AlertDefData-Props';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

export default class AlertMessage extends BaseComponent {
	
	componentWillMount() {
		let messageData = this.props.data;
		this.ClassStyle = this.classStyle(messageData.type, messageData.arrowRequired, messageData.lightBackground);
		this.mainClass = this.mainClass(messageData);
	}

	classStyle = (type, arrowRequired, backGround) => {
		let classStyle = constStyles.class[type];
		arrowRequired ? (classStyle = `${classStyle} ${constStyles.class[constStyles.arrowStyle]}`) : classStyle;
		backGround ? (classStyle = `${classStyle} ${constStyles.class[constStyles.bgStyle]}`) : classStyle;
		return classStyle;
	};

	mainClass = (data) => {
		let mainClass = data.isValidate ? `${constStyles.class.mainClass} ${constStyles.isVaidate}` : constStyles.class.mainClass;
		return mainClass;
	}

	render() {
		const messageData = this.props.data;
		return (
			<div id={messageData.id} name={messageData.name} className={this.mainClass}>
				<div className={this.ClassStyle}>
					<span className={constStyles.data.alertIcon}>
						<Icon name={constStyles.icon[messageData.type]} />
					</span>
					<h1>{messageData.messageTitle}</h1>
					<p>{messageData.messageBody}</p>
				</div>
			</div>
		);
	}
}

AlertMessage.propTypes = {
	data: PropTypes.shape({
		name: PropTypes.string,
		id: PropTypes.string.isRequired,
		type: PropTypes.oneOf(Object.keys(constStyles.class)).isRequired,
		lightBackground: PropTypes.boolean,
		arrowRequired: PropTypes.boolean,
		messageTitle: PropTypes.string.isRequired,
		messageBody: PropTypes.string.isRequired
	})
};

AlertMessage.defaultProps = {
	data: defaultData
};
