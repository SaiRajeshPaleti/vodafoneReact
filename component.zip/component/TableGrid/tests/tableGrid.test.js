import React from 'react';
import TableGrid from '../TableGridComponent';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import tableGrid from '../../../AppData/TableGridData';
import Adapter from 'enzyme-adapter-react-16';
import CheckBox from '../../CheckBox/checkBox';

Enzyme.configure({
    adapter: new Adapter()
});

describe('<TableGrid />', function() {
    let props, enzymeWrapper;

    beforeEach(() => {
        props = tableGrid;
        enzymeWrapper = mount(<TableGrid data={props} />);
    });

    it('Should trigger componentWillRecieveProps', () => {
        const newProps = {
            ...tableGrid
        };
        enzymeWrapper.setProps({ data: newProps });
    });
    it('Table Grid contains  div', () => {
        expect(enzymeWrapper.find('.table').length).toEqual(1);
    });

    it('Table Grid contains a table', () => {
        expect(enzymeWrapper.find('.table__table').length).toEqual(1);
    });
    it('Table Grid contains a table rows', () => {
        expect(enzymeWrapper.find('.table__table').childAt(1).length).toEqual(1);
    });
    it('Verifying table row elements', () => {
        const data = enzymeWrapper.find('.table__body').first().find('tr').map((column) => column.text());
        expect(data.length).toEqual(5);
    });
    it('Verifying table column elements', () => {
        const data = enzymeWrapper.find('.table__head').first().find('th').map((column) => column.text());
        expect(data.length).toEqual(7);
    });
    it('Table Grid contains  TableHead Component', () => {
        expect(enzymeWrapper.find('TableHead').length).toBe(1);
    });
    it('Table Grid contains  Table Head Row Component', () => {
        expect(enzymeWrapper.find('.table__header-row').length).toBe(1);
    });
    it('Table Grid contains  UPArrow', () => {
        expect(enzymeWrapper.find('UpArrowSvg'));
    });
    it('Table Grid contains  DownArrow', () => {
        expect(enzymeWrapper.find('DownArrowSvg'));
    });

    it('Simulates UpArrowClick', () => {
        enzymeWrapper.find('.table__chevron--up').map((column) => {
            column.simulate('click');
            expect(enzymeWrapper.instance().ascendingSortHandler).toHaveBeenCalled;
        });
    });

    it('Simulates UpArrowClick', () => {
        enzymeWrapper.find('.table__chevron--down').map((column) => {
            column.simulate('click');
            expect(enzymeWrapper.instance().desendingSortHandler).toHaveBeenCalled;
        });
    });
    it('event handler to be called on down Arrow Click', () => {
        const span = enzymeWrapper.find('.table__chevron--down').at(0);
        enzymeWrapper.simulate('click');
        expect(TableGrid.desendingSortHandler).toHaveBeenCalled;
        expect(props.tabledata.sort()).toHaveBeenCalled;
    });

    it('event handler to be called on up Arrow Click', () => {
        const span = enzymeWrapper.find('.table__chevron--up').at(0);
        enzymeWrapper.simulate('click');
        expect(TableGrid.ascendingSortHandler).toHaveBeenCalled;
        expect(props.tabledata.sort()).toHaveBeenCalled;
    });
    it('Sholud trigger check all', () => {
        const checkboxEl = enzymeWrapper.find('.label_box').first().find('.check');
        console.log('checkbox ele-----------', checkboxEl.length);
        checkboxEl.simulate('change');
    });

    it('Table contains Single Check all check box', () => {
        expect(enzymeWrapper.find('.label_box').first().find('.check').length).toBe(1);
    });

    it('checking the status of checkall value after updating the state', () => {
        let span = enzymeWrapper.find('.label_box').first().find('.check');
        span.simulate('click');
        expect(enzymeWrapper.state().checkAll).toEqual(false);
        span.simulate('click');
        expect(enzymeWrapper.state().checkAll).toEqual(false);
    });
    it('event handler to be called on Table Check Box change', () => {
        const span = enzymeWrapper
            .find('.js-row-check')
            .first()
            .find('.js-row-check')
            .map((column) => column.simulate('change'));
        expect(TableGrid.selectRow).toHaveBeenCalled;
    });
    it('checking the value after State is updated when we check table row', () => {
        let span = enzymeWrapper.find('.label_box').first().find('.check');
        span.simulate('click');
        expect(enzymeWrapper.state().checkAll).toEqual(false);
    });
    it(' checkIt event handler to be called on click of row ', () => {
        let span = enzymeWrapper.find('.label_box').first().find('.check');
        span.simulate('change');
        expect(enzymeWrapper.instance().checkIt).toHaveBeenCalled;
    });

    it('Table Grid contains  table data tag', () => {
        expect(enzymeWrapper.find('.table__row').first().find('td').length).toEqual(7);
    });
    it('Verifying table retuns in case of image ', () => {
        const data = props.columns.map((column) => {
            if (column.controlType === 'checkbox') {
                const data = enzymeWrapper.find('.table__header-row').first().find('th').map((column) => column.text());
                expect(data);
            } else if (column.controlType === 'image') {
                const data = enzymeWrapper.find('.table__header-row').first().find('th').map((column) => column.text());
                expect(data);
            }
        });
    });
    it('event handler to be called on upArrow Click', () => {
        const span = enzymeWrapper
            .find('.table__chevron--up')
            .first()
            .find('.table__chevron--up')
            .map((column) => column.simulate('click'));
        expect(TableGrid.ascendingSortHandler).toHaveBeenCalled;
    });

    it('event handler to be called on down Arrow Click', () => {
        const span = enzymeWrapper
            .find('.table__chevron--down')
            .first()
            .find('.table__chevron--down')
            .map((column) => column.simulate('click'));
        expect(TableGrid.desendingSortHandler).toHaveBeenCalled;
    });

    it('Verifying table contains any anchor tag', () => {
        const data = props.columns.map((column) => {
            if (column.key === 'reference') {
                const data = enzymeWrapper.find('.anchor').length;
                expect(data).toEqual(5);
            }
        });
    });
    it('Verifying method in anchor tag is called', () => {
        const data = props.columns.map((column) => {
            if (column.key === 'reference') {
                const anchorMethod = enzymeWrapper.find('.anchor').at(1);

                anchorMethod.simulate('click');
            }
        });
    });
    it('Verifying method in checkBox component is called', () => {
        const anchorMethod = enzymeWrapper.find('.check').at(1);

        anchorMethod.simulate('click');
    });
    it('should trigger  selectRow ',() => {
        const index = 1,
              checkedvalue = "";        
        expect(enzymeWrapper.instance().selectRow(index,checkedvalue)).toHaveBeenCalled;
    });
});
