import React from 'react';
import tableRowStyles from './TableGridDefData-Props';
import CheckBox from 'vf-ent-ws-checkbox';

const TableBody = (props) => {
  const rowData = props.data.tableRowData;
  return (
    <tr key={props.data.index} className={tableRowStyles.className.tableRowOddClass}>
      {props.data.columns.map((column, index) => {
        if (column.controlType === 'checkbox') {
          const checkBoxData = {
            id: props.data.id || index.toString(),
            name: 'index',
            checked: props.data.checked,
            value: props.data.checked,
            onChange: (event) => props.data.click(props.data.index, event.value)
          };
          return (
            <td key={index} className={tableRowStyles.className.tableCellClass}>
              <div className={tableRowStyles.className.tableCellLabel}>
                <CheckBox data={checkBoxData} />
              </div>
            </td>
          );
        } else {
          const linkClass = column.link
            ? {
                className: tableRowStyles.className.anchor,
                onClick: () => props.data.getSummary(rowData)
              }
            : {};
          const priorityClass =
            column.key === 'PriorityLabel'
              ? { className: `${rowData.PriorityLabel}${tableRowStyles.className.priority}` }
              : {};
          return (
            <td key={index} className={tableRowStyles.className.tableCellDataClass}>
              <div {...linkClass} {...priorityClass}>
                <span>{rowData[column.key]}</span>
                {rowData.lastUpdated &&
                column.key === 'lastUpdated' && (
                  <span className={tableRowStyles.className.dateAndTime}>{rowData.lastUpdatedTime}</span>
                )}
              </div>
            </td>
          );
        }
      })}
    </tr>
  );
};
export default TableBody;
