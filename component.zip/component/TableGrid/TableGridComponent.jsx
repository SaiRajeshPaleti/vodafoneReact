import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';
import './TableGrid.css';
import tableComponentStyles from './TableGridDefData-Props';
import TableHead from './TableHeadComponent';
import TableRow from './TableRow';

class TableGrid extends PureComponent {
  constructor(props) {
    super(props);
    const arr = [];
    this.props.data.tabledata.map((listItem, index) => {
      arr[index] = listItem.checked ? listItem.checked : false;

      return listItem;
    });
    this.state = {
      rowState: arr,
      sortinghighlight: {}
    };
    this.individualSelect = [];
    this.selectAllData = [];
    this.checkAll = this.checkAll.bind(this);
    this.selectRow = this.selectRow.bind(this);
    this.SortHandler = this.SortHandler.bind(this);
    this.loadHeader = this.loadHeader.bind(this);
    this.loadInit = this.loadInit.bind(this);
    this.handleSelections = this.handleSelections.bind(this);
  }
  componentWillMount() {
    this.componentLoad(this.props);
  }
  componentWillReceiveProps(nextProps) {
    this.componentLoad(nextProps);
  }

  componentLoad(data) {
    const arr = [];
    data.data.tabledata.map((listItem, index) => {
      arr[index] = listItem.checked ? listItem.checked : false;
      return listItem;
    });
    this.setState(
      {
        tableGridData: data.data.tabledata,
        rowState: arr,
        checkAll: false,
        isFlag: false,
        sortinghighlight: data.data.sortKey
      },
      () => {
        this.init = this.loadInit('', false, data);
      }
    );
    //this.init = this.loadInit('', false, data);
  }
  SortHandler(e, key, type) {
    const data = {
      key,
      type
    };
    this.setState(
      {
        sortinghighlight: data
      },
      () => {
        this.loadHeader('', '', this.state.sortinghighlight);
      }
    );

    this.props.data.sortHandler(data);
  }

  checkAll(data) {
    const rowState = [];
    const checkState = data.value;
    for (let i = 0; i < this.state.rowState.length; i++) {
      rowState[i] = checkState;
    }
    const isFlag = !this.state.isFlag;
    this.setState(
      {
        rowState: rowState,
        checkAll: checkState,
        isFlag: isFlag
      },
      () => {
        this.init = this.loadInit(rowState, this.state.isFlag);
        this.setState({
          isFlag: !this.state.isFlag
        });
        // this.handleSelections(rowState, checkState);
      }
    );

    this.props.data.selectedData(data);
  }
  handleSelections(rowState, value) {
    const rowStateData = JSON.parse(JSON.stringify(rowState));
    const selectIndividualRow = [];
    rowStateData.map((rowData, index) => {
      if (rowData === true && this.props.data.tabledata[index] !== undefined) {
        selectIndividualRow.push(this.props.data.tabledata[index]);
      }
      return rowData;
    });

    this.props.data.selectedData({ selectedItems: selectIndividualRow, value });
  }
  selectRow(index, checkedvalue) {
    const tableData = { ...this.state };
    const data = tableData.rowState;

    data[index] = checkedvalue;

    let checkState = tableData.checkAll;
    let status = true;
    data.map((row) => {
      if (row === false) {
        status = false;
      }
      return status;
    });
    if (checkState || status) {
      checkState = !checkState;
    }

    this.setState(
      (prevState) => ({
        checkAll: checkState,
        rowState: [ ...prevState.rowState, data ],
        isFlag: this.state.isFlag
      }),
      () => {
        this.init = this.loadInit(this.state.rowState, false);
      }
    );
    const selectedItem = this.props.data.uniqueColumn
      ? this.props.data.tabledata[index][this.props.data.uniqueColumn]
      : this.props.data.tabledata[index];
    this.props.data.selectedData({ id: selectedItem, value: checkedvalue });
    // this.handleSelections(data, checkedvalue);
  }

  loadHeader(tableData, value, columns, sortData) {
    const headerData = {
      rows: value,
      sortKey: sortData,
      columns: columns,
      checkAll: this.state.checkAll,
      checkAllMethod: this.checkAll,
      SortHandler: this.SortHandler,
      recordsPerPage: tableData.recordsPerPage,
      totalcount: tableData.totalcount,
      isAllSelected: tableData.isAllSelected,
      selectAllData: tableData.selectAllData
    };

    return <TableRowHeader data={headerData} />;
  }
  loadInit(selectAll, isFlag, props = this.props) {
    const rowData = {
      ImageDisplay: this.ImageDisplay,
      rowState: isFlag === true ? selectAll : this.state.rowState,
      tableData: props.data,
      loadHeader: this.loadHeader,
      selectRow: this.selectRow,
      sortKey: this.state.sortinghighlight
    };
    this.setState({
      isFlag: !this.state.isFlag
    });
    return <TableRowComponent data={rowData} />;
  }

  render() {
    return <div className={tableComponentStyles.className.mainDivClass}>{this.init}</div>;
  }
}
export const TableRowComponent = (props) => {
  const { tableData, rowState, loadHeader, selectRow, sortKey } = props.data;
  const links = [];
  const columns = tableData.columns.filter((label) => label.isSelected);
  columns.map((label) => {
    if (label.link === true) {
      return links.push(label.key);
    }
    return label;
  });

  const rows = tableData.tabledata.map((row, index) => {
    const tableRecord = {
      tableRowData: row,
      id: row.id ? row[row.id] : false,
      index: index,
      key: index,
      checked: rowState[index],
      click: selectRow,
      link: links,
      columns: columns,
      getSummary: tableData.getSummary
    };
    return <TableRow data={tableRecord} key={index} />;
  });

  return loadHeader(tableData, rows, columns, sortKey);
};
export const TableRowHeader = (props) => {
  const {
    rows,
    columns,
    checkAll,
    checkAllMethod,
    SortHandler,
    sortKey,
    recordsPerPage,
    totalcount,
    isAllSelected,
    selectAllData
  } = props.data;

  const headerTableData = {
    columns: columns,
    SortHandler: SortHandler,
    checkAll: checkAllMethod,
    checked: checkAll,
    sortKey: sortKey,
    recordsPerPage: recordsPerPage,
    totalcount: totalcount,
    isAllSelected: isAllSelected,
    selectAllData: selectAllData
  };
  return (
    <div
      id={tableComponentStyles.Ids.usermanagementDivClassId}
      className={tableComponentStyles.className.usermanagementDivClass}
    >
      <table className={tableComponentStyles.className.tableClass} id={tableComponentStyles.Ids.tableClassId}>
        <thead className={tableComponentStyles.className.tableHeadClass}>
          <tr className={tableComponentStyles.className.trClass}>
            <TableHead data={headerTableData} />
          </tr>
        </thead>

        <tbody className={tableComponentStyles.className.tableBodyClass}>{rows}</tbody>
      </table>
    </div>
  );
};

TableGrid.propTypes = {
  data: PropTypes.shape({
    tabledata: PropTypes.arrayOf(
      PropTypes.shape({
        assignedTo: PropTypes.string,
        customerRef: PropTypes.string,
        lastUpdatedOn: PropTypes.string,
        priority: PropTypes.string,
        refNumber: PropTypes.string,
        status: PropTypes.string,
        summary: PropTypes.string
      }).isRequired
    ),
    uniqueColumn: PropTypes.string,
    getSummary: PropTypes.func,
    sortHandler: PropTypes.func,
    columns: PropTypes.arrayOf(
      PropTypes.shape({
        name: PropTypes.string,
        key: PropTypes.string,
        type: PropTypes.string,
        controlType: PropTypes.string,
        isSelected: PropTypes.bool,
        sortable: PropTypes.bool,
        link: PropTypes.bool
      }).isRequired
    )
  })
};
export default TableGrid;
