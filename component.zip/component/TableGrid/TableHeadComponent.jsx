import React, { PureComponent } from 'react';
import tableHeadStyles from './TableGridDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import CheckBox from 'vf-ent-ws-checkbox';

class TableHead extends PureComponent {
  render() {
    const recordsPerPage = this.props.data.recordsPerPage;
    const totalRecordsCount = this.props.data.totalcount;
    const selectAllData = this.props.data.selectAllData;
    let selctallPopUpStatus = this.props.data.isAllSelected;

    const selectTotalRecordsCount = () => {
      selectAllData(!selctallPopUpStatus);
    };

    return this.props.data.columns.map((column, index) => {
      if (column.controlType === 'checkbox') {
        const checkBoxData = {
          id: column.key || index.toString(),
          name: tableHeadStyles.Data.checkBoxName,
          checked: column.checked,
          value: column.checked,
          onChange: this.props.data.checkAll
        };
        return (
          <th
            key={index}
            className={tableHeadStyles.className.thClass}
            rowSpan={tableHeadStyles.tableStyles.rowSpan}
            colSpan={tableHeadStyles.tableStyles.colSpan}
            aria-label={tableHeadStyles.className.arialLablelClass}
          >
            {column.name}
            <div className={tableHeadStyles.className.tableChevronsClass}>
              <div className={tableHeadStyles.className.labelClass}>
                <div className={tableHeadStyles.className.checkBoxTipsClass}>
                  <CheckBox data={checkBoxData} />

                  <div
                    id={tableHeadStyles.className.selectAllPopUp}
                    className={
                      column.checked ? (
                        tableHeadStyles.className.showCheckedPopUp
                      ) : (
                        tableHeadStyles.className.hideCheckedPopUp
                      )
                    }
                  >
                    {selctallPopUpStatus ? (
                      <div>
                        <span>
                          <b>{totalRecordsCount}</b> results selected.
                        </span>
                        <span onClick={selectTotalRecordsCount}>
                          <b>Deselect</b> <b>{totalRecordsCount}</b> results
                        </span>
                      </div>
                    ) : (
                      <div>
                        <span>
                          <b>{recordsPerPage}</b> results selected.
                        </span>
                        <span onClick={selectTotalRecordsCount}>
                          <b>Select all</b> <b>{totalRecordsCount}</b> results
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </th>
        );
      } else {
        const ASC = tableHeadStyles.sortingKey.ASC;
        const DSC = tableHeadStyles.sortingKey.DSC;
        const sortClass = this.props.data.sortKey;

        return (
          <th
            key={index}
            className={`${tableHeadStyles.className.tableHeadSortClass} ${column.customClass
              ? column.customClass
              : ''}`}
            aria-controls={tableHeadStyles.className.arialControlClass}
            rowSpan={tableHeadStyles.tableStyles.rowSpan}
            colSpan={tableHeadStyles.tableStyles.colSpan}
          >
            {column.name}
            {column.sortable ? (
              <div className={tableHeadStyles.className.tableChevronsClass} title={tableHeadStyles.Data.sortingTitle}>
                <span
                  onClick={(e) => this.props.data.SortHandler(e, column.key, ASC)}
                  className={
                    sortClass.type === 'ASC' && sortClass.key === column.key ? (
                      `${tableHeadStyles.className.paginationActiveClass} ${tableHeadStyles.className.upArrowIconClass}`
                    ) : (
                      tableHeadStyles.className.upArrowIconClass
                    )
                  }
                >
                  <Icon name={tableHeadStyles.className.upIcon} />
                </span>
                <span
                  onClick={(e) => this.props.data.SortHandler(e, column.key, DSC)}
                  className={
                    sortClass.type === 'DSC' && sortClass.key === column.key ? (
                      `${tableHeadStyles.className.paginationActiveClass} ${tableHeadStyles.className
                        .downArrowIconClass}`
                    ) : (
                      tableHeadStyles.className.downArrowIconClass
                    )
                  }
                >
                  <Icon name={tableHeadStyles.className.downIcon} />
                </span>
              </div>
            ) : (
              <div className={tableHeadStyles.className.tableChevronsClass} title={tableHeadStyles.Data.sortingTitle}>
                <span className={tableHeadStyles.className.upArrowIconClass} />
                <span className={tableHeadStyles.className.downArrowIconClass} />
              </div>
            )}
          </th>
        );
      }
    });
  }
}

export default TableHead;
