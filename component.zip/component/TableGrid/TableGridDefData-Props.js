const tableComponentStyles = {
  Data: {
    selectAll: 'Select all',
    checkBoxName: 'form-input-checkbox-1',
    sortingTitle: 'Sort ascending/descending',
    NumberOfSelectedRows: 20,
    ResultSelected: 'Result selected.',
    ResultSelectAll: 'Sellect all',
    SelectedResult: 240,
    Result: 'results',
    checkUncheckData: 'check/uncheck all',
    formCheckBoxName: 'form-input-checkbox-89314409999990348231',
    checkRow: 'Check Row 1'
  },
  className: {
    showCheckedPopUp: 'showCheckedPopUp',
    hideCheckedPopUp: 'hideCheckedPopUp',
    anchor: 'anchor',
    mainDivClass: 'table custom-table-data',
    usermanagementDivClass: 'dataTables_wrapper',
    tableClass: 'table__table table--striped dataTable',
    tableHeadClass: 'table__head',
    trClass: 'table__header-row',
    thClass: 'table__header table__cell table__check-row table__cell--noordering sorting__asc',
    arialLablelClass: 'Select all 20results selected.select all 240results Check/Uncheck all ',
    tableChevronsClass: 'table__chevrons',
    labelClass: 'form__row no-gutter--all',
    checkBoxTipsClass: 'checkBoxTips p-relative',
    checkBoxClass: 'form__input form__input--checkable  js-select-all custom-checkbox',
    tableHeadSortClass: 'table__header table__cell sorting',
    arialControlClass: 'DataTables_Table_0',
    upArrowIconClass: 'sprite__icon table__chevron table__chevron--up',
    downArrowIconClass: 'sprite__icon table__chevron table__chevron--down',
    tableBodyClass: 'table__body',
    tableRowOddClass: 'table__row',
    tableCellClass: 'table__cell align--center sorting_1',
    tableCellLabel: 'form__row no-gutter--all',
    tableCellCheckBoxClass: 'form__input form__input--checkable js-row-check custom-checkbox',
    tableCellSpanClass: 'js-form-label form__label form__label--checkable ',
    tableCellDataClass: 'table__cell',
    tableCellBooleanSVGtrue: 'table__cell_boolean_svg_true',
    tableCellBooleanSVGfalse: 'table__cell_boolean_svg_false',
    checkBoxResults: 'checkbox-results',
    checkUncheckClass: 'js-form-label form__label form__label--checkable visually-hidden',
    upIcon: 'chevron-up',
    downIcon: 'chevron-down',
    paginationActiveClass: 'active',
    priorityColor: {
      P1: 'P1Color priority-status',
      P2: 'P2Color priority-status',
      P3: 'P3Color priority-status',
      P4: 'P4Color priority-status'
    },
    priority: 'Color priority-status',
    dateAndTime: 'dateAndTime'
  },
  Ids: {
    usermanagementDivClassId: 'DataTables_Table_0_wrapper',
    tableClassId: 'DataTables_Table_0',
    selectAllPopUp: 'selectAllPopUp'
  },
  tableStyles: {
    rowSpan: 1,
    colSpan: 1
  },
  sortingKey: {
    ASC: 'ASC',
    DSC: 'DSC'
  }
};
export default tableComponentStyles;
