export const constStyles = {
	orderConfirmSection: 'order_confirm_section bg_black',
	orderConfirm: 'order_confirm',
	orderInfo: 'order_info',
	orderClose: 'order_close',
	iconClass: 'sprite__icon',
	displayNone: 'display_none'
};
