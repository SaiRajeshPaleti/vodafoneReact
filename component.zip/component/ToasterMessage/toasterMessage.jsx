import React, { PureComponent } from 'react';
import { constStyles } from './toasterMessageDefData-Props';
import './toasterMessage.css';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';
import Button from 'vf-ent-ws-button';

export default class ToasterMessage extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			showMessage: this.props.data.show
		};
		this.closeMessage = this.closeMessage.bind(this);
	}

	closeMessage() {
		this.setState({ showMessage: false });
	}
	componentWillReceiveProps(nextProps) {
		this.setState({ showMessage: true });
	}

	render() {
		return (
			<section className={this.state.showMessage ? constStyles.orderConfirmSection : constStyles.displayNone}>
				<div className={constStyles.orderConfirm}>
					<span className={constStyles.iconClass}>
						<Icon name={this.props.data.orderInfoIcon} />
					</span>
					<div className={constStyles.orderInfo}>
						<p>{this.props.data.orderConfirmTxt}</p>
						<div className="">
							<span>{this.props.data.orderReferenceTxt}</span>
							<span id="referenceNumber">{this.props.data.orderReferenceNumber}</span>
							<span>{this.props.data.orderDetailsTxt}</span>

							{this.props.data.buttondata && (
								<Button key={this.props.data.buttondata.type} data={this.props.data.buttondata} />
							)}
						</div>
					</div>
					<div className={constStyles.orderClose} onClick={this.closeMessage}>
						<span className={constStyles.iconClass}>
							<Icon name={this.props.data.closeIcon} />
						</span>
					</div>
				</div>
			</section>
		);
	}
}
