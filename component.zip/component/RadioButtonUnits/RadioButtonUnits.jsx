import React from 'react';

import PropTypes from 'prop-types';

import BaseComponent from 'vf-ent-ws-utilities';

import RadioButtonUnitsDefData from './RadioButtonUnitsDefData-Props';

import './RadioButtonUnits.css';

class RadioButtonUnits extends BaseComponent {
  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
    this.updateStateInfo = this.updateStateInfo.bind(this);
  }

  componentWillMount() {
    this.updateStateInfo(this.props);
  }

  componentWillReceiveProps(nextProps) {
    this.updateStateInfo(nextProps);
  }

  updateStateInfo(props) {
    this.setState({
      listOfRecords: props.data.timePeriod
    });
  }

  handleClick = (data, selectedIndex) => {
    const recordsList = [ ...this.state.listOfRecords ];

    recordsList.map((data, index) => {
      data.selected = selectedIndex === index ? true : false;

      return data;
    });

    this.setState({
      listOfRecords: recordsList
    });
    this.delegateHandler(RadioButtonUnitsDefData.actions.onClick, data, (data) => {
      return data;
    });
  };

  render() {
    console.log(this.props);
    return (
      <div className={RadioButtonUnitsDefData.constStyles.radioSectionWrapper}>
        {this.state.listOfRecords.map((data, index) => {
          return (
            <div
              key={index}
              className={`${RadioButtonUnitsDefData.constStyles.radioCircle} ${data.selected &&
                RadioButtonUnitsDefData.constStyles.radioCircleActive}`}
              onClick={() => this.handleClick(data, index)}
            >
              <span className={RadioButtonUnitsDefData.constStyles.radioCircleHeading}>{data.displayValue}</span>

              <span className={RadioButtonUnitsDefData.constStyles.radioCircleHeading}>{data.displayText}</span>
            </div>
          );
        })}
      </div>
    );
  }
}

RadioButtonUnits.propTypes = {
  data: PropTypes.shape({
    timePeriod: PropTypes.arrayOf(
      PropTypes.shape({
        displayValue: PropTypes.string,

        displayText: PropTypes.string
      }).isRequired
    ).isRequired,

    onClick: PropTypes.func.isRequired
  }).isRequired
};

export default RadioButtonUnits;
