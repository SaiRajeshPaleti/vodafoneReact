const RadioButttonConstData = {
    constStyles: {
        radioSectionWrapper: 'radioSectionWrapper',
        radioCircle: 'radio--circle',
        radioCircleActive: 'radio--circle--active',
        radioCircleHeading: 'radio--circle--heading'
    },
    actions: {
        onClick: 'onClick'
    }
};

export default RadioButttonConstData;
