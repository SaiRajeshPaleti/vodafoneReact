import React from 'react';
import RadioButtonUnits from '../RadioButtonUnits';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import RadioButtonUnitsData from '../../../AppData/RadioButtonUnitsData';

Enzyme.configure({
    adapter: new Adapter()
});

describe('<RadioButtonUnits />', function () {
    let props, enzymeWrapper;

    beforeEach(() => {
        props = RadioButtonUnitsData;
        enzymeWrapper = mount(<RadioButtonUnits data={props} />);
    });
    it('Text field  contains one div', () => {
        expect(enzymeWrapper.find('.radio--circle').length).toBe(3);
    });

    it('Handler testing', () => {
        const timeCircles = enzymeWrapper.find('.radio--circle');
        timeCircles.at(1).simulate('click');
        expect(enzymeWrapper.handleChange).toHaveBeenCalled;
    });

    it('Should trigger componentWillRecieveProps', () => {
        const radioBtnVarData = RadioButtonUnitsData;
        radioBtnVarData.timePeriod[0].displayValue = '21';
        enzymeWrapper.setProps({ data: radioBtnVarData });
    });

});
