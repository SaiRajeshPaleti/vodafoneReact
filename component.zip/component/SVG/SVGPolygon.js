import React from 'react';
import PropTypes from 'prop-types';

const SVGPolygon = (props) => (
	<polygon points={props.paths} stroke-linecap={props.strokelinecap} stroke-linejoin={props.strokelinejoin} />
);

SVGPolygon.propTypes = {
	paths: PropTypes.string,
    strokelinecap: PropTypes.string,
	strokelinejoin: PropTypes.string
};

export default SVGPolygon;
