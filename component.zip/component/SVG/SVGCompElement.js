import React from 'react';
import SVGElementRegistry from './SVGElementRegistry';

const SVGCompElement = (fieldData) => {
    const CustomComponent = SVGElementRegistry[fieldData.type];

    return <CustomComponent {...fieldData} />;
};

export default SVGCompElement;
