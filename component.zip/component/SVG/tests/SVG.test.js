import React from 'react';
import renderer from 'react-test-renderer';
import DialData from '../../../AppData/DialData';
import Dial from '../SVGDial';
import Icon from '../SVGIcon';
import SVGDialTest from '../SVGDialTest';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

import moment from 'moment';

Enzyme.configure({ adapter: new Adapter() });

describe('<Expired Dial />', function() {
	let enzymeWrapper, props, count, clickHandler;
	beforeEach(() => {
		let data = DialData.datas[0];
		enzymeWrapper = mount(<Dial data={data.data} action={data.action} />);
	});

	it('Expired Dial  path', () => {
		expect(enzymeWrapper.find('path').length).toBe(2);
	});

	it('Expired Dial  text', () => {
		expect(enzymeWrapper.find('text').length).toBe(3);
	});

	it('Expired Dial  circle', () => {
		expect(enzymeWrapper.find('circle').length).toBe(1);
	});
});

describe('<Expired Circle />', function() {
	let enzymeWrapper, props, count, clickHandler;
	beforeEach(() => {
		let data = DialData.datas[4];
		enzymeWrapper = mount(<Dial data={data.data} action={data.action} />);
	});

	it('Expired Circle  path', () => {
		expect(enzymeWrapper.find('path').length).toBe(1);
	});

	it('Expired Circle  text', () => {
		expect(enzymeWrapper.find('text').length).toBe(3);
	});

	it('Expired Circle  circle', () => {
		expect(enzymeWrapper.find('circle').length).toBe(0);
	});
});

describe('<SVGDialTest all dial components />', function() {
	let enzymeWrapper, props, count, clickHandler;
	beforeEach(() => {
		let data = DialData.datas[0];
		enzymeWrapper = mount(<SVGDialTest />);
	});

	it(' SVGDialTest  path', () => {
		expect(enzymeWrapper.find('path').length).toBe(9);
	});

	it(' SVGDialTest  text', () => {
		expect(enzymeWrapper.find('text').length).toBe(18);
	});

	it('SVGDialTest  circle', () => {
		expect(enzymeWrapper.find('circle').length).toBe(3);
	});
});

describe('<SVGIcon components />', function() {
	let enzymeWrapper, props, count, clickHandler;
	beforeEach(() => {
		enzymeWrapper = mount(<Icon icon="test1" />);
	});

	it(' Icon  path', () => {
		expect(enzymeWrapper.find('path').length).toBe(0);
	});

	it(' Icon  text', () => {
		expect(enzymeWrapper.find('text').length).toBe(0);
	});

	it('Icon  circle', () => {
		expect(enzymeWrapper.find('circle').length).toBe(2);
	});
	it(' Icon  line count', () => {
		expect(enzymeWrapper.find('line').length).toBe(1);
	});
});
