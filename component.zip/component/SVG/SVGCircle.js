import React from 'react';
import PropTypes from 'prop-types';

const SVGCircle = (props) => (
    <circle
        cx={props.cx}
        cy={props.cy}
        r={props.r}
        strokeLinecap={props.strokelinecap}
        className={props.class}
        style={props.style}
        strokeLinejoin={props.strokelinejoin}
    />
);

SVGCircle.propTypes = {
    cx: PropTypes.number,
    cy: PropTypes.number,
    r: PropTypes.number,
    class: PropTypes.string,
    style: PropTypes.string,
    strokelinecap: PropTypes.string,
    strokelinejoin: PropTypes.string
};

export default SVGCircle;
