import SVGLine from './SVGLine';
import SVGPolygon from './SVGPolygon';
import SVGCircle from './SVGCircle';
import SVGPath from './SVGPath';
import SVGText from './SVGText';

const SVGElementRegistry = {
	line: SVGLine,
	polygon: SVGPolygon,
	circle: SVGCircle,
	path: SVGPath,
	text: SVGText
};

export default SVGElementRegistry;
