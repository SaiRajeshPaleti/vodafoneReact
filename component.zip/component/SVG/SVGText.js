import React from 'react';
import PropTypes from 'prop-types';

const SVGText = (props) => (
	<text x={props.x} y={props.y} className={props.class}>
		{props.text}
	</text>
);

SVGText.propTypes = {
	x: PropTypes.number,
	y: PropTypes.number,
	class: PropTypes.string
};

export default SVGText;
