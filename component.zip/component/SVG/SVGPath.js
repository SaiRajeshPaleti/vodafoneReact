import React from 'react';
import PropTypes from 'prop-types';

const SVGPath = (props) => <path d={props.paths} className={props.class} strokeDasharray={props.strokedasharray} />;

SVGPath.propTypes = {
    paths: PropTypes.string,
    class: PropTypes.string,
    strokedasharray: PropTypes.string
};

export default SVGPath;
