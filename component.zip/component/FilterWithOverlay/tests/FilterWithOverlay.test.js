import React from 'react';
import FilterWithOverlayData from '../../../AppData/FilterWithOverlayData';
import FilterWithOverlay from '../FilterWithOverlay';
import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import StartDatePicker from '../FilterWithOverlay';
import TimePeriod  from '../FilterWithOverlay';
Enzyme.configure({ adapter: new Adapter() });

describe('<FilterWithOverlay/>', function() {
    let props, enzymeWrapper;

    props = {
        data: {
            clearFilter: () => {
                console.log('clear Filter');
            },
            onClick: (a) => {
                console.log(a);
            },
            tooltip: 'Click here to open the filter criteria',
            filterText: 'Filters',
            clearFilterText: 'Clear filters',
            PriorityBox: {
                Heading: 'Priority',
                DropDown: {
                    id: 'priorityDropdownButton',
                    name: 'priorityDropdownButton',
                    dropDownButtonType: 'checkbox',
                    clickTxt: 'View all types',
                    title: 'Click Here',
                    checkedElements: (e) => { },
                    dropdownButtonValues: [
                        {
                            id: 'P1',
                            name: 'P1',
                            displayValue: 'P1'
                        },
                        {
                            id: 'P2',
                            name: 'P2',
                            displayValue: 'P2'
                        },
                        {
                            id: 'P3',
                            name: 'P3',
                            displayValue: 'P3'
                        },
                        {
                            id: 'P4',
                            name: 'P4',
                            displayValue: 'P4'
                        }
                    ]
                }
            },
            StatusBox: {
                Heading: 'Status',
                DropDown: {
                    id: 'statusDropdownButton',
                    name: 'statusDropdownButton',
                    dropDownButtonType: 'checkbox',
                    clickTxt: 'View all statuses',
                    title: 'Click Here',
                    checkedElements: (e) => { },
                    dropdownButtonValues: [
                        {
                            id: '1',
                            name: 'New',
                            displayValue: 'New'
                        },
                        {
                            id: '2',
                            name: 'InProgress',
                            displayValue: 'In progress'
                        },
                        {
                            id: '3',
                            name: 'Resolved',
                            displayValue: 'Resolved'
                        },
                        {
                            id: '4',
                            name: 'AwaitingCustomerInput',
                            displayValue: 'Awaiting customer input'
                        }
                    ]
                }
            },
            EscalationBox: {
                Heading: 'Escalation',
                DropDown: {
                    id: 'escalationDropdownButton',
                    name: 'escalationDropdownButton',
                    dropDownButtonType: 'checkbox',
                    clickTxt: 'View all',
                    title: 'Click Here',
                    checkedElements: (e) => { },
                    dropdownButtonValues: [
                        {
                            id: 'L1',
                            name: 'L1',
                            displayValue: 'L1'
                        },
                        {
                            id: 'L2',
                            name: 'L2',
                            displayValue: 'L2'
                        },
                        {
                            id: 'L3',
                            name: 'L3',
                            displayValue: 'L3'
                        },
                        {
                            id: 'L4',
                            name: 'L4',
                            displayValue: 'L4'
                        }
                    ]
                }
            },
            startDatePicker: {
                Title: 'Date Raised From',
                data: {
                    name: 'startDatePicker',
                    id: 'start_date_picker',
                    title: 'StartDate',
                    componentType: 'SimpleDate',
                    inputId: 'startpicker',
                    locale: 'en',
                    format: 'DD MMM YYYY',
                    after: 0
                }
            },

            endDatePicker: {
                Title: 'Date Raised To',
                data: {
                    name: 'endDatePicker',
                    id: 'end_date_picker',
                    title: 'EndDate',

                    componentType: 'SimpleDate',
                    inputId: 'endpicker',

                    locale: 'en',
                    format: 'DD MMM YYYY',
                    after: 0
                }
            },
            buttonData: {
                id: 'primary',
                name: 'Apply filter',
                type: 'primary',
                buttonType: 'button'
            },
            alertData: {
                type: 'info',
                name: 'info',
                id: 'l_w',
                lightBackground: true,
                arrowRequired: false,
                messageTitle: 'Invalid Date',
                messageBody: 'From date cannot be greater than to date'
            },
            timePeriodOptions: {
                timePeriod: [
                    {
                        displayValue: '24',
                        displayText: 'Hours'
                    },
                    {
                        displayValue: '7',
                        displayText: 'Days'
                    },
                    {
                        displayValue: '1',
                        displayText: 'Month'
                    }
                ]
            }
        }
    }

    beforeEach(() => {
        enzymeWrapper = shallow(<FilterWithOverlay { ...props } />);
    });

    it('should render Overlay component', () => {
		expect(enzymeWrapper).not.toBe(null);
    });
    
	it('Overlay Component should render div', () => {		 		     
        expect(enzymeWrapper.find('div').length).toEqual(14);// .toBe(1);
	});

    it('Filter contains  main div', () => {
        expect(enzymeWrapper.find('.filters').length).toEqual(1);
    });

    it('Filter Button contains anchor', () => {
        expect(enzymeWrapper.find('a').length).toEqual(1);
    });

    it('event handler to be called on anchor ', () => {
        const click = enzymeWrapper.find('.actions__reset');

        click.simulate('click');

        expect(enzymeWrapper.instance().expandFilter).toHaveBeenCalled;
    });

    it('Filter contains 3 dropdowns', () => {
        expect(enzymeWrapper.find('.filter__count').length).toEqual(1);
        
    });

    it('event handler to be called on click of radio variant', () => {
        const props ={
            data:{
                displayValue:'',
                displayText:'',
                selected:1
            }
        }
        expect(enzymeWrapper.instance().captureTimeVariant(props)).toHaveBeenCalled;
       
    });

    it('event handler to be called on click of filter button', () => {
        enzymeWrapper.instance().applyFilter();
     });

     it('invoke captureSelectedValues with priority dropDownType ', () => {
         let dropdownButtonValues = {dropDownType : 'priority', Filters:{length:8}};
        enzymeWrapper.instance().captureSelectedValues(dropdownButtonValues);
     });

     it('invoke captureSelectedValues with status dropDownType', () => {
        let dropdownButtonValues = {dropDownType : 'status',  Filters:{length:6}};
       enzymeWrapper.instance().captureSelectedValues(dropdownButtonValues);
    });

    it('invoke captureSelectedValues with escalation dropDownType', () => {
        let dropdownButtonValues = {dropDownType :  'escalation' ,  Filters:{length:10} };
       enzymeWrapper.instance().captureSelectedValues(dropdownButtonValues);
    });

    it('invoke getDate with from value', () => {
        let e ={ target:{value:'test'}};
        enzymeWrapper.instance().getDate(e,'from');
     });

     it('invoke getDate with to value', () => {
        let e ={ target:{value:'test'}};
        enzymeWrapper.instance().getDate(e,'to');
     });


    it('Should render viewing component', () => {
        enzymeWrapper.setState({
            showStatusViewingLabel: true,

            showPriorityViewingLabel: true,
            showEscalationViewingLabel: true
        });

        if (enzymeWrapper.instance().state.showStatusViewingLabel.length) {
            expect(enzymeWrapper.find('.filter-text').length).toEqual(3);
        }
    });

    it('Find close icon', () => {
        expect(enzymeWrapper.find('.pull--right').length).toEqual(1);
    });

    it('Function in  close icon', () => {
        let startPicker = enzymeWrapper.find('.pull--right');
        startPicker.simulate('click');
        expect(enzymeWrapper.instance().expandFilter).toHaveBeenCalled;
    });

    it('Filter label test', () => {
        expect(enzymeWrapper.find('.filter-title').text()).toEqual('Filter Results');
    });

      it('Filter label test', () => {
        expect(enzymeWrapper.find('.filter-title').text()).toEqual('Filter Results');
    });

    it('event handler to be called on click of radio variant', () => {
        enzymeWrapper.instance().captureTimeVariant(props);
    });


});

describe('<StartDatePicker/>', function () {
    let enzymeWrapper;
    let props = {
        data: {
            startDatePicker: {
                Title: 'Date Raised From',
                data: {
                    name: 'startDatePicker',
                    id: 'start_date_picker',
                    title: 'StartDate',
                    componentType: 'SimpleDate',
                    inputId: 'startpicker',
                    locale: 'en',
                    format: 'DD MMM YYYY',
                    after: 0,
                    value:1536085800000
                }
                // onChange: (e) => {
                //     console.log(e);
                // }
            },

            endDatePicker: {
                Title: 'Date Raised To',
                data: {
                    name: 'endDatePicker',
                    id: 'end_date_picker',
                    title: 'EndDate',
                    componentType: 'SimpleDate',
                    inputId: 'endpicker',
                    locale: 'en',
                    format: 'DD MMM YYYY',
                    after: 0,
                    value:1536085800000
                }
            },
            timePeriodOptions: {
                timePeriod: [
                    {
                        displayValue: '24',
                        displayText: 'Hours'
                    },
                    {
                        displayValue: '7',
                        displayText: 'Days'
                    },
                    {
                        displayValue: '1',
                        displayText: 'Month'
                    }
                ],
                onClick:()=>{}
            },
            onChange: () => { }
        }
    };
    beforeEach(() => {
        enzymeWrapper = shallow(<StartDatePicker {...props} />);
    });

    it('check for StartDatePicker component', () => {
        expect(enzymeWrapper).not.toBe(null);
    });

    it('check for div', () =>{
        expect(enzymeWrapper.find('div').length).toBe(14);
    });

});


describe('<TimePeriod />', function () {
    let enzymeWrapper;
    let props = {
        data: {
            startDatePicker: {
                Title: 'Date Raised From',
                data: {
                    name: 'startDatePicker',
                    id: 'start_date_picker',
                    title: 'StartDate',
                    componentType: 'SimpleDate',
                    inputId: 'startpicker',
                    locale: 'en',
                    format: 'DD MMM YYYY',
                    after: 0,
                    value:1536085800000
                }
                // onChange: (e) => {
                //     console.log(e);
                // }
            },

            endDatePicker: {
                Title: 'Date Raised To',
                data: {
                    name: 'endDatePicker',
                    id: 'end_date_picker',
                    title: 'EndDate',
                    componentType: 'SimpleDate',
                    inputId: 'endpicker',
                    locale: 'en',
                    format: 'DD MMM YYYY',
                    after: 0,
                    value:1536085800000
                }
            },
            timePeriodOptions: {
                timePeriod: [
                    {
                        displayValue: '24',
                        displayText: 'Hours'
                    },
                    {
                        displayValue: '7',
                        displayText: 'Days'
                    },
                    {
                        displayValue: '1',
                        displayText: 'Month'
                    }
                ],
                onClick:()=>{}
            },
            onChange: () => { }
        }
    };
    beforeEach(() => {
        enzymeWrapper = shallow(<TimePeriod  {...props} />);
    });

    it('check for StartDatePicker component', () => {
        expect(enzymeWrapper).not.toBe(null);
    });

});