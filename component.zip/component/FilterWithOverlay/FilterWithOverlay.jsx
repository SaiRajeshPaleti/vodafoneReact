import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import AlertMessage from 'vf-ent-ws-alert-message';

import CustomDateTime from 'vf-ent-ws-date-time-picker';


import Icon from 'vf-ent-ws-svgicons';
import Button from 'vf-ent-ws-button';
import './FilterWithValue.css';
import { defaultStyles, constData } from './FilterWithOverlayDefData-Props';
import DropDownWithViewingLabel from 'vf-ent-ws-dropdown-button-with-label';
import RadioButtonUnits from 'vf-ent-ws-radio-button-units';

class FilterWithOverlay extends BaseComponent {
  constructor(props) {
    super(props);
    const endDate = new Date();
    // Set it to one month ago
    const startDate = new Date(endDate.setDate(endDate.getDate() - 30));
    this.state = {
      expandFlag: true,
      filterCount: 0,
      priorityFilterCount: 0,
      statusFilterCount: 0,
      escalationFilterCount: 0,
      radioFilterCount: 0,

      containerFlag: false,
      expandClass: '',
      dateRaisedFrom: startDate,
      dateRaisedTo: new Date()
    };

    this.expandFilter = this.expandFilter.bind(this);
    this.getDate = this.getDate.bind(this);

    this.captureSelectedValues = this.captureSelectedValues.bind(this);
    this.applyFilter = this.applyFilter.bind(this);
    this.captureTimeVariant = this.captureTimeVariant.bind(this);
    this.countFilters = this.countFilters.bind(this);
  }
  componentWillMount() {
    this.invokeComponents(this.props.data);
  }
  componentWillReceiveProps(nextProps) {
    this.setState({
      SelectedPriorityFilters: nextProps.data.SelectedPriorityFilters,
      SelectedStatusFilters: nextProps.data.SelectedStatusFilters,
      SelectedEscalationFilters: nextProps.data.SelectedEscalationFilters
    });

    this.invokeComponents(nextProps.data);
  }
  invokeComponents(data) {
    const updatedData = data;
    const endDate = new Date();
    let expandFilterClass = '';
    // Set it to one month ago

    const startDate = new Date(endDate.setDate(endDate.getDate() - 30));
    updatedData.startDatePicker.data.value = updatedData.startDatePicker.data.value
      ? updatedData.startDatePicker.data.value
      : startDate.toDateString();
    updatedData.endDatePicker.data.value = updatedData.endDatePicker.data.value
      ? updatedData.endDatePicker.data.value
      : new Date().toDateString();
    const PriorityBox = data.PriorityBox;
    const StatusBox = data.StatusBox;
    const EscalationBox = data.EscalationBox;
    const timePeriod = data.timePeriodOptions;
    let priorityFilter = [];
    let EscalationFilter = [];
    let StatusFilter = [];
    let radioFilterCount = 0;
    PriorityBox.DropDown.dropdownButtonValues.map((list) => {
      if (list.value) {
        priorityFilter.push(list);
      }
    });
    EscalationBox.DropDown.dropdownButtonValues.map((list) => {
      if (list.value) {
        EscalationFilter.push(list);
      }
    });

    StatusBox.DropDown.dropdownButtonValues.map((list) => {
      if (list.value) {
        StatusFilter.push(list);
      }
    });

    timePeriod.timePeriod.map((list) => {
      if (list.selected) {
        radioFilterCount = 1;
      }
    });
    let filterCount = priorityFilter.length + EscalationFilter.length + StatusFilter.length + radioFilterCount;
    const startDateProps = {
      ...updatedData.startDatePicker,
      onChange: (e) => this.getDate(e, constData.startDatePickerFlag)
    };
    const endDateProps = {
      ...updatedData.endDatePicker,

      onChange: (e) => this.getDate(e, constData.endDatePickerFlag)
    };
    updatedData.timePeriodOptions.onClick = this.captureTimeVariant;
    const timePeriodData = {
      ...updatedData.timePeriodOptions
    };
    expandFilterClass = data.closeFilter ? '' : this.state.expandClass;
    this.setState(
      {
        expandClass: expandFilterClass,
        expandFlag: true,
        dropDownData: updatedData,
        StartdateProps: startDateProps,
        EnddateProps: endDateProps,
        DateTimeProps: timePeriodData,
        priorityFilterCount: priorityFilter.length,
        statusFilterCount: StatusFilter.length,
        escalationFilterCount: EscalationFilter.length,
        radioFilterCount: radioFilterCount
        //  filterCount: filterCount
      },
      () => {
        this.countFilters();
      }
    );
  }

  countFilters() {
    this.setState({
      filterCount:
        this.state.priorityFilterCount +
        this.state.statusFilterCount +
        this.state.escalationFilterCount +
        this.state.radioFilterCount
    });
  }

  expandFilter() {
    this.setState({
      expandFlag: !this.state.expandFlag,
      expandClass: this.state.expandFlag ? defaultStyles.dropDownOpen : ''
    });
  }
  getDate(e, value) {
    const temp = JSON.parse(JSON.stringify(this.state.DateTimeProps));

    temp.timePeriod.map((list) => {
      list.selected = false;
      return list;
    });
    temp.onClick = this.captureTimeVariant;

    if (value === constData.startDatePickerFlag) {
      let newStartDateProps = this.state.StartdateProps;
      newStartDateProps.data.value = e.value;
      this.setState(
        {
          StartdateProps: newStartDateProps,
          DateTimeProps: temp,
          radioFilterCount: 0,
          selectedTimeVariant: ''
        },
        () => {
          this.countFilters();
        }
      );
    }
    if (value === constData.endDatePickerFlag) {
      let newEndDateProps = this.state.EnddateProps;
      newEndDateProps.data.value = e.value;
      this.setState(
        {
          EnddateProps: newEndDateProps,
          DateTimeProps: temp,
          radioFilterCount: 0,
          selectedTimeVariant: ''
        },
        () => {
          this.countFilters();
        }
      );
    }
  }

  captureSelectedValues(dropDownData) {
    if (dropDownData.dropDownType === constData.StatusDropdownType) {
      this.setState(
        {
          SelectedStatusFilters: dropDownData.Filters,
          statusFilterCount: dropDownData.Filters.length
        },
        () => {
          this.countFilters();
        }
      );
    }
    if (dropDownData.dropDownType === constData.PriorityDropdownType) {
      this.setState(
        {
          SelectedPriorityFilters: dropDownData.Filters,
          priorityFilterCount: dropDownData.Filters.length
        },
        () => {
          this.countFilters();
        }
      );
    }
    if (dropDownData.dropDownType === constData.EscalationDropdownType) {
      this.setState(
        {
          SelectedEscalationFilters: dropDownData.Filters,
          escalationFilterCount: dropDownData.Filters.length
        },
        () => {
          this.countFilters();
        }
      );
    }
  }

  captureTimeVariant(data) {
    let endDate = new Date();
    let startDate = new Date();
    if (data.displayValue === '24') {
      startDate = new Date(endDate.setDate(endDate.getDate() - 1));
    } else if (data.displayValue === '7') {
      startDate = new Date(endDate.setDate(endDate.getDate() - 7));
    } else if (data.displayValue === '1') {
      startDate = new Date(endDate.setDate(endDate.getDate() - 30));
    }
    let newStartDateProps = this.state.StartdateProps;
    let newEndDateProps = this.state.EnddateProps;
    newStartDateProps.data.value = startDate.toDateString();
    newEndDateProps.data.value = new Date().toDateString();
    const temp = JSON.parse(JSON.stringify(this.state.DateTimeProps));
    temp.timePeriod.map((radio) => {
      if (radio.displayValue === data.displayValue) {
        radio = data;
      }
      return radio;
    });

    this.setState(
      {
        StartdateProps: newStartDateProps,
        EnddateProps: newEndDateProps,
        selectedTimeVariant: data.displayValue + data.displayText,
        radioFilterCount: data.selected ? 1 : 0,
        DateTimeProps: { ...temp, onClick: this.captureTimeVariant }
      },
      () => {
        this.countFilters();
      }
    );
  }
  applyFilter() {
    const filter = {
      PriorityFilters: this.state.SelectedPriorityFilters,
      StatusFilters: this.state.SelectedStatusFilters,
      EscalationFilters: this.state.SelectedEscalationFilters,
      dateRaisedFrom: this.state.StartdateProps.data.value,
      dateRaisedTo: this.state.EnddateProps.data.value,
      timeVariant: this.state.selectedTimeVariant
    };
    this.delegateHandler('onClick', filter, (filter) => {
      return filter;
    });

    this.setState({
      warningRequired: Date.parse(this.state.StartdateProps.data.value) > Date.parse(this.state.EnddateProps.data.value)
    });

    if (!(Date.parse(this.state.StartdateProps.data.value) > Date.parse(this.state.EnddateProps.data.value))) {
      this.expandFilter();
    }
  }

  render() {
    const buttonData = { ...this.state.dropDownData.buttonData, onClick: this.applyFilter };
    const PriorityDropDownData = {
      ...this.state.dropDownData.PriorityBox,
      handler: this.captureSelectedValues,
      dropdownType: constData.PriorityDropdownType
    };
    const StatusDropDownData = {
      ...this.state.dropDownData.StatusBox,
      handler: this.captureSelectedValues,
      dropdownType: constData.StatusDropdownType
    };
    const EscalationDropDownData = {
      ...this.state.dropDownData.EscalationBox,
      handler: this.captureSelectedValues,
      dropdownType: constData.EscalationDropdownType
    };
    return (
      <div className={`${defaultStyles.filterWrapper} ${this.state.expandClass}`}>
        <div className={defaultStyles.filters}>
          <div className={defaultStyles.actionShop}>
            <div className={defaultStyles.actionItemSpace}>
              <span
                className={defaultStyles.actionCustomMargin}
                title={this.state.dropDownData.tooltip}
                onClick={this.expandFilter}
              >
                <span className={defaultStyles.caption}>
                  <span className={defaultStyles.captionText}>
                    <span className={defaultStyles.filterCount}>{this.state.filterCount}</span>
                    <span>{this.state.dropDownData.filterText}</span>
                  </span>
                  <span className={defaultStyles.captionMedia}>
                    <Icon name={constData.chevronIcon} />
                  </span>
                </span>
              </span>
            </div>
            <div className={defaultStyles.actionsItem} onClick={this.state.dropDownData.clearFilter}>
              <a className={defaultStyles.actionsReset}>{this.state.dropDownData.clearFilterText}</a>
            </div>
          </div>
          <div className={defaultStyles.dropDownfilter}>
            <div className={defaultStyles.filteringForm}>
              <form className={defaultStyles.formSmall}>
                <div className={defaultStyles.spring}>
                  <fieldset className={defaultStyles.filteringContent}>
                    {this.state.warningRequired && <AlertMessage data={this.state.dropDownData.alertData} />}
                    <div>
                      <div className={defaultStyles.filterHeading}>
                        <p>
                          <span className={defaultStyles.filterTitle}>Filter Results</span>
                        </p>
                      </div>
                      <div className={defaultStyles.pullRightIconLarge} onClick={this.expandFilter}>
                        <Icon name={constData.IconClose} />
                      </div>
                    </div>
                    <div className={defaultStyles.gridGutter}>
                      <DropDownWithViewingLabel data={PriorityDropDownData} />

                      <DropDownWithViewingLabel data={StatusDropDownData} />

                      <div className={defaultStyles.gridItemForm}>
                        <label className={defaultStyles.formRow}>
                          <span className={defaultStyles.formRow}>Time period</span>
                          <RadioButtonUnits data={this.state.DateTimeProps} />
                        </label>
                      </div>
                      <StartDatePicker data={this.state.StartdateProps} />

                      <StartDatePicker data={this.state.EnddateProps} />
                      <DropDownWithViewingLabel data={EscalationDropDownData} />
                      <div className={defaultStyles.gridItemForm}>
                        <p className={defaultStyles.mzero}>
                          <span className='notecolor'>{this.state.dropDownData.noteLabel}</span>:
                          <span>{this.state.dropDownData.noteText}</span>
                        </p>
                      </div>
                      <div className={defaultStyles.applyFilter}>
                        <Button data={buttonData} />
                      </div>
                    </div>
                    <div className={defaultStyles.filterOptionContent} />
                  </fieldset>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const StartDatePicker = (data) => {
  return (
    <div className={defaultStyles.gridItemForm}>
      <label className={defaultStyles.formRow}>
        <span className={defaultStyles.jsFormLabel}>{data.data.Title}</span>
      </label>

      <CustomDateTime data={data.data} />
    </div>
  );
};

export default FilterWithOverlay;
const priorityDropDownShape = PropTypes.shape({
  id: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  dropDownButtonType: PropTypes.string.isRequired,
  clickTxt: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  checkedElements: PropTypes.func,
  dropdownButtonValues: PropTypes.arrayOf(
    PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      displayValue: PropTypes.string.isRequired
    }).isRequired
  ).isRequired
});

const startDatePickerShape = PropTypes.shape({
  Title: PropTypes.string.isRequired,
  data: PropTypes.shape({
    name: PropTypes.string.isRequired,
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    componentType: PropTypes.string.isRequired,
    inputId: PropTypes.string.isRequired,
    locale: PropTypes.string.isRequired,
    dateFormat: PropTypes.string.isRequired,
    timeFormat: PropTypes.bool.isRequired,
    timeConstraints: PropTypes.instanceOf(Object),
    disabledFrom: PropTypes.oneOfType([ PropTypes.string, PropTypes.number, PropTypes.instanceOf(Date) ])
  }).isRequired
});
FilterWithOverlay.propTypes = {
  data: PropTypes.shape({
    clearFilter: PropTypes.func,
    PriorityBox: PropTypes.shape({
      Heading: PropTypes.string.isRequired,
      DropDown: priorityDropDownShape.isRequired
    }).isRequired,
    StatusBox: PropTypes.shape({
      Heading: PropTypes.string.isRequired,
      DropDown: priorityDropDownShape.isRequired
    }).isRequired,
    EscalationBox: PropTypes.shape({
      Heading: PropTypes.string.isRequired,
      DropDown: priorityDropDownShape.isRequired
    }).isRequired,
    startDatePicker: startDatePickerShape.isRequired,
    endDatePicker: startDatePickerShape.isRequired,
    buttonData: PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      type: PropTypes.string.isRequired,
      buttonType: PropTypes.string.isRequired
    }).isRequired,
    alertData: PropTypes.shape({
      type: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      id: PropTypes.string.isRequired,
      lightBackground: PropTypes.bool.isRequired,
      arrowRequired: PropTypes.bool.isRequired,
      messageTitle: PropTypes.string.isRequired,
      messageBody: PropTypes.string.isRequired
    }).isRequired,
    timePeriodOptions: PropTypes.shape({
      timePeriod: PropTypes.arrayOf(
        PropTypes.shape({
          displayValue: PropTypes.string.isRequired,
          displayText: PropTypes.string.isRequired,
          selected: PropTypes.bool.isRequired
        }).isRequired
      ).isRequired
    }).isRequired
  }).isRequired
};
