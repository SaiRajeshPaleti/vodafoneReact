import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import './Refresh.css';
import { defaultStyles, actions } from './RefreshDefData-Props';

class Refresh extends BaseComponent {
	constructor(props) {
		super(props);
		this.onRefresh = this.onRefresh.bind(this);
	}
	componentWillMount() {
		this.loadRefresh(this.props.data);
	}
	componentWillReceiveProps(nextProps) {
		this.loadRefresh(nextProps.data);
	}
	onRefresh(e) {
		this.loadRefresh({ ...this.props.data, date: new Date() });
		this.delegateHandler(actions.onClick, e, (e) => {
			return e;
		});
	}
	loadRefresh(props) {
		const monthNames = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ];
		const dformat = `${[ props.date.getDate(), monthNames[props.date.getMonth()], props.date.getFullYear() ].join(
			' '
		)} ${[ props.date.getHours(), (props.date.getMinutes() < 10 ? '0' : '') + props.date.getMinutes() ].join(':')}`;

		this.setState({
			data: props,
			time: dformat
		});
	}

	render() {
		return (
			<h1 className={defaultStyles.heading}>
				<span className={defaultStyles.refreshText} title={this.state.data.title}>
					{`${this.state.data.displayText} ${this.state.time}`}
					<span id={this.state.data.id} onClick={this.onRefresh}>
						<Icon name={defaultStyles.syncIcon} />
					</span>
				</span>
			</h1>
		);
	}
}
Refresh.propTypes = {
	data: PropTypes.shape({
		date: PropTypes.oneOfType([ PropTypes.string, PropTypes.instanceOf(Date), PropTypes.number ]),
		displayText: PropTypes.string.isRequired,
		title: PropTypes.string.isRequired,
		onClick: PropTypes.func.isRequired
	}).isRequired
};
export default Refresh;
