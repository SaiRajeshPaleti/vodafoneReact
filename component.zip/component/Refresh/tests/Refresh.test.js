import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Refresh from '../Refresh';
import RefreshData from '../../../AppData/RefreshData';
Enzyme.configure({ adapter: new Adapter() });
describe('<Refresh />', function() {
    let enzymeWrapper;

    beforeEach(() => {
        enzymeWrapper = shallow(<Refresh data={RefreshData} />);
    });

    it('Refresh Component contains  H1', () => {
        expect(enzymeWrapper.find('h1').length).toEqual(1);
    });
    it('Refresh Component contains span', () => {
        expect(enzymeWrapper.find('.refresh-text').length).toEqual(1);
    });
    it('Refresh Component contains span', () => {
        let span = enzymeWrapper.find('#a');
        // let childSpan = span.find('span');
        span.simulate('click');
        expect(enzymeWrapper.instance().onRefresh).toHaveBeenCalled;
    });
    it('Should trigger componentWillRecieveProps', () => {
        const newProps = {
            ...RefreshData
        };
        enzymeWrapper.setProps({ data: newProps });
    });
});
