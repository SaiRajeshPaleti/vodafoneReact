export const defaultStyles = {
	heading: 'heading heading--light heading--5 no-gutter--all index__heading m-b-20 m-t-10',
	refreshText: 'refresh-text',
	syncIcon: 'sync'
};
export const actions = {
	onClick: 'onClick'
};
