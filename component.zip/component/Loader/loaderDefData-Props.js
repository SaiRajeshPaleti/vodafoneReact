export const constStyles = {
	loaderClass: 'loader',
	spriteCls: 'sprite__icon'
	//labelClass: 'labelLoader'
};
