import React, { PureComponent } from 'react';
import { constStyles } from './loaderDefData-Props';
import './loader.css';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

export default class Loader extends BaseComponent {
	render() {
		return (
			<div className={constStyles.loaderClass}>
				<div class={constStyles.spriteCls}>
					<Icon name={this.props.data.loaderIcon} />
					<div>{this.props.data.loaderText}</div>
				</div>
				
			</div>
		);
	}
}
