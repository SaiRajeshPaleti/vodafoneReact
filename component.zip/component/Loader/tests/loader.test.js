import Loader from '../loaderComponent';
import { shallow } from 'enzyme';

import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import React from 'react';
Enzyme.configure({ adapter: new Adapter() });

describe('<Loader/>', function() {
	let props = {};
	const wrapper = shallow(<Loader Loader={props} />);
	it('Loader  contains one div', () => {
		expect(wrapper.find('div').length).toBe(1);
	});
});
