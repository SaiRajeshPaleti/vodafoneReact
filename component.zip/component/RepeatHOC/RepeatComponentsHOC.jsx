import React, { PureComponent } from 'react';
import RepeatHOCRegistry from './RepeatHOCRegistry';
import { populateValuesAndMethodsInMetaData, setFieldValue, evaluateCriteria } from './RepeatHOCUtilities';
class RepeatComponentsHOC extends PureComponent {
	constructor(props) {
		super(props);
		this.state = {};
		window.updateFieldInRepeatHOC = this.updateFieldInRepeatHOC.bind(this);
		this.updateField = this.updateField.bind(this);
	}
	componentDidMount() {
		this.updateMetaData(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.updateMetaData(nextProps);
	}

	updateMetaData(props) {
		let componentList = props.data.componentList;
		const noOfSolutions = props.data.metaData.length;
		if (noOfSolutions > 1) {
			if (componentList[0].props.data.header && componentList[0].props.data.header.headerData) {
				componentList[0].props.data.header.headerData.deleteFlag = true;
			}
		}
		let fieldList = [];
		props.data.metaData.map((metaDataProps) => {
			console.log(JSON.stringify(metaDataProps));
			let uniqueReference = metaDataProps.uniqueReference;
			let fields = JSON.parse(JSON.stringify(componentList));
			populateValuesAndMethodsInMetaData(fields, undefined, undefined, metaDataProps);
			if (uniqueReference !== undefined) {
				this.appendUniqueReference(fields, uniqueReference);
			}
			fieldList = fieldList.concat(fields);
		});
		this.setState({
			fieldList
		});
	}
	updateFieldInRepeatHOC(fieldName, componentId, relativePath, value) {
		this.updateField(componentId, fieldName, value, relativePath, this.state.fieldList, {}, {});
	}
	updateField(componentId, fieldName, value, relativePath, pageData, parent, superParent) {
		Object.keys(pageData).forEach((key) => {
			if (key === 'id') {
				if (componentId === pageData[key]) {
					setFieldValue(superParent, fieldName, value, relativePath);
				}
			} else if (pageData[key] !== null && (typeof pageData[key] === 'object' || Array.isArray(pageData[key]))) {
				this.updateField(componentId, fieldName, value, relativePath, pageData[key], pageData, parent);
			}
		});
	}
	appendUniqueReference(field, uniqueReference) {
		Object.keys(field).forEach((key) => {
			if (key === 'id') {
				field[key] = field[key] + '_' + uniqueReference;
			} else if (field[key] !== null && (typeof field[key] === 'object' || Array.isArray(field[key]))) {
				this.appendUniqueReference(field[key], uniqueReference);
			}
		});
	}

	render() {
		let components =
			this.state && this.state.fieldList
				? this.state.fieldList.map((field, index) => {
						if (field.criteria) {
							let isValid = evaluateCriteria(field.criteria, this.props.formData);
							console.log('isValid   ', isValid);
							if (!isValid) {
								return false;
							}
						}
						let Component = RepeatHOCRegistry[field.componentType];
						return <Component key={index} {...field.props} />;
					})
				: false;
		return <div>{components}</div>;
	}
}
export default RepeatComponentsHOC;
