import moment from 'moment';	
	
	export const populateValuesAndMethodsInMetaData=(pageData, searchItems, data, formData)=> {
		Object.keys(pageData).forEach((key) => {
			if (key === 'id') {
				if (searchItems && data) {
					let index = searchItems.indexOf(pageData[key]);
					if (index > -1) {
						if (data[pageData[key]]) {
							if (typeof data[pageData[key]] === 'object') {
								pageData['value'] = data[pageData[key]].value;
							} else {
								pageData['value'] = data[pageData[key]];
							}
						}
						searchItems.splice(index, 1);
					}
				}
			} else if (key.indexOf('CreateHandler') > -1) {
				let params = pageData[key].split('|');
				if (window[params[0]]) {
					pageData[params[1]] = window[params[0]];
				}
			} else if (key.indexOf('apiData') > -1 && pageData[key]) {
				if (pageData[key].indexOf('@QueryList') > -1 || pageData[key].indexOf('@Query') > -1) {
					let dataObj = getValueFromCache(key, pageData);
					if (pageData[key].indexOf('@QueryList') > -1) {
						let keyArray = pageData[key].split('|');
						let queryObjArray = keyArray[0].split('.');
						if (queryObjArray[1]) {
							if(!pageData[queryObjArray[1]] || pageData[queryObjArray[1]]===''|| JSON.stringify(pageData[queryObjArray[1]])===JSON.stringify([])){
								pageData[queryObjArray[1]] = dataObj;
							}
						} else {
							if(!pageData['dropdownValues'] || pageData['dropdownValues']===''|| JSON.stringify(pageData['dropdownValues'])===JSON.stringify([])){
								pageData['dropdownValues'] = dataObj;
							}
						}
					} else if (pageData[key].indexOf('@Query') > -1) {
						let keyArray = pageData[key].split('|');
						let queryObjArray = keyArray[0].split('.');
						if (queryObjArray[1]) {
							if(!pageData[queryObjArray[1]] || pageData[queryObjArray[1]]===''){
								pageData[queryObjArray[1]] = dataObj;
							}
						} else {
							if(!pageData['value'] || pageData['value']===''){
								pageData['value'] = dataObj;
							}
						}
					}
				} else if (pageData[key].indexOf('@SessionStorage') > -1) {
					let keyArray = pageData[key].split('|');
					let queryObjArray = keyArray[0].split('.');
					let dataObj = getValueFromSession(keyArray, pageData);
					if (queryObjArray[1]) {
						pageData[queryObjArray[1]] = dataObj;
					} else {
						pageData['value'] = dataObj;
					}
				} else if (pageData[key].indexOf('@FormData') > -1) {
					if (formData) {
						let keyArray = pageData[key].split('|');
						let queryObjArray = keyArray[0].split('.');
						let tempFormData = JSON.parse(JSON.stringify(formData));
						let dataObj = getValueFromForm(keyArray[1], tempFormData);
						if (queryObjArray[1]) {
							pageData[queryObjArray[1]] = dataObj;
						} else {
							pageData['value'] = dataObj;
						}
					}
				} else if (pageData[key].indexOf('@Eval') > -1) {
					let keyArray = pageData[key].split('|');
					if (keyArray.length > 1) {
						let value = evaluateValue(keyArray[1]);
						let queryObjArray = keyArray[0].split('.');
						if (queryObjArray[1]) {
							pageData[queryObjArray[1]] = value;
						}
					}
				}
			} else if (pageData[key] !== null && (typeof pageData[key] === 'object' || Array.isArray(pageData[key]))) {
				populateValuesAndMethodsInMetaData(pageData[key], searchItems, data, formData);
			}
		});
	}
	const evaluateValue=(key) =>{
		let value;
		switch (key) {
			case 'CurrentDate': {
				value = moment(new Date()).format('DD MMM YYYY');
				break;
			}
			default: {
				break;
			}
		}
		return value;
	}
	const getValueFromForm=(key, formData) =>{
		let outputValue;
		if (formData) {
			let keyArray = key.split('.');
			if (keyArray) {
				for (let i = 0; i < keyArray.length; i++) {
					outputValue = formData[keyArray[i]];
					if (outputValue) {
						formData = outputValue;
					} else {
						return;
					}
				}
			}
		}
		return outputValue;
	}
	const getValueFromSession=(keyArray, pageData)=> {
		let outputValue;
		let sessionValue = sessionStorage.getItem(keyArray[1]);
		let sessionObj;
		if (sessionValue) {
			sessionObj = JSON.parse(sessionValue);
		}
		if (keyArray[2]) {
			outputValue = getValueFromObject(JSON.parse(JSON.stringify(sessionObj)), keyArray[2].split('.'));
		}
		return outputValue;
	}
	
	const getListFromObject=(data, paramsArray, flatten) =>{
		let keys = paramsArray[0].split('.');
		let output = {};
		let outputArray = [];
		for (let i = 2; i < keys.length; i++) {
			let value = getValueFromObject(data, paramsArray[i].split('.'));
			if (Array.isArray(value)) {
				value.map((val, index) => {
					let obj = outputArray[index];
					if (!obj) {
						obj = {};
					}
					obj[keys[i]] = val;
					outputArray[index] = obj;
				});
			} else {
				output[keys[i]] = value;
			}
		}
		if (outputArray.length > 0) {
			flatten = true;
			return outputArray;
		} else {
			flatten = false;
			return output;
		}
	}
	const getValueFromObject=(data, objArray) =>{
		let outputValue;
		for (let i = 0; i < objArray.length; i++) {
			if (Array.isArray(data)) {
				objArray.splice(0, i);
				return data.map((dataObj) => getValueFromObject(dataObj, objArray));
			} else {
				outputValue = data[objArray[i]];
				data = outputValue;
			}
		}
		return outputValue;
	}

	
	const getValueFromCache=(key, pageData)=> {
		let outputValue;
		let cachedData = window.getCachedData();
		let apiDatas = cachedData.cacheQuery.apiData;

		if (apiDatas) {
			apiDatas.map((apiData) => {
				var valueArray = pageData[key].split('|');
				if (apiData.name === valueArray[1]) {
					let data = apiData.data;
					if (valueArray[0].indexOf('@QueryList') > -1) {
						/*outputValue= data.map((obj)=>({
						  optionName:  obj[valueArray[2]],
						  optionValue:obj[valueArray[3]]
					  }));*/
						let flatten = false;
						if (Array.isArray(data)) {
							outputValue = [];
							data.map((obj) => {
								let output = getListFromObject(
									JSON.parse(JSON.stringify(obj)),
									valueArray,
									flatten
								);
								if (Array.isArray(output)) {
									outputValue = [ ...outputValue, ...output ];
								} else {
									outputValue = [ ...outputValue, output ];
								}
							});
						} else {
							outputValue = getListFromObject(JSON.parse(JSON.stringify(data)), valueArray);
						}
					} else if (valueArray[0].indexOf('@Query') > -1) {
						if (Array.isArray(data)) {
							outputValue = getValueFromObject(
								JSON.parse(JSON.stringify(data[0])),
								valueArray[2].split('.')
							);
						} else {
							outputValue = getValueFromObject(
								JSON.parse(JSON.stringify(data)),
								valueArray[2].split('.')
							);
						}
					}
				}
			});
		}
		return outputValue;
	}
	export const setFieldValue=(superParent, fieldName, value, relativePath)=> {
		let object = superParent;
		if(JSON.stringify(relativePath)!==JSON.stringify('')){
			let fieldStructure = relativePath.split('.');
			fieldStructure.map((key) => {
				object = object[key];
			});
		}
		object[fieldName] = value;
	}
	export const evaluateCriteria=(criteria, data)=> {
		if (criteria.condition === 'AND' || criteria.condition === 'OR') {
			let result1 = evaluateCriteria(criteria.leftOperand, data);
			let result2 = evaluateCriteria(criteria.rightOperand, data);

			let result = criteria.condition === 'OR' ? result1 || result2 : result1 && result2;

			return result;
		} else {
			let leftOperandValue = getValueFromMetaData(data, criteria.leftOperand);
			if (leftOperandValue) {
				if (criteria.condition === 'EQUAL') {
					return leftOperandValue === criteria.rightOperand;
				} else if (criteria.condition === 'GREATERTHAN') {
					return leftOperandValue > criteria.rightOperand;
				} else if (criteria.condition === 'LESSTHAN') {
					return leftOperandValue < criteria.rightOperand;
				} else if (criteria.condition === 'CONTAINS') {
					return leftOperandValue.indexOf(criteria.rightOperand) > -1;
				} else if (criteria.condition === 'NOTEQUAL') {
					return leftOperandValue !== criteria.rightOperand;
				}
			} else {
				if (criteria.condition === 'NOTEQUAL') {
					return leftOperandValue !== criteria.rightOperand;
				} else {
					return false;
				}
			}
		}
	}
	export const getValueFromMetaData=(formData, searchItem)=> {
		let value;
		Object.keys(formData).forEach((key) => {
			if (key === searchItem) {
				if (formData[key] !== null && typeof formData[searchItem] === 'object') {
					value = formData[searchItem].value;
				} else {
					value = formData[searchItem];
				}
			} else if (formData[key] !== null && (typeof formData[key] === 'object' || Array.isArray(formData[key]))) {
				let returnedValue = getValueFromMetaData(formData[key], searchItem);
				if (returnedValue) {
					value = returnedValue;
				}
			}
		});
		return value;
	}