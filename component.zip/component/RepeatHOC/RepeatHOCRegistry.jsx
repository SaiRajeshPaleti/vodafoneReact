import SummaryServiceSite from 'vf-ent-ws-summary-serviceSite';

const RepeatHOCRegistry = {
	SummaryServiceSite,
};
export default RepeatHOCRegistry;
