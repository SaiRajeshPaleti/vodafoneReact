const filterStyle = {
	constStyles: {
		overflowclass: 'filter__overflow',
		filterOverflow: 'filter__overflow filter__overflow--shift',
		activeoverflowclass: 'filter__overflow--shift',
		button: 'actions__filter',
		activebutton: 'actions__filter--active',
		mainDivClass: 'filters',
		actionDivClass: 'actions actions--shop',
		actionDivItemClass: 'actions__item actions__filter--space',
		rotate: 'rotate',
		// buttonClass:"actions__filter",
		captionClass: 'caption',
		captionTextClass: 'caption__text',
		filterCount: 'filter__count',
		captionMediaClass: 'caption__media sprite__icon',
		filterIconClass: 'IconsFonts icon accordion__chevron',
		actionItemsClass: 'actions__item',
		clearFilterClass: 'actions__reset no-gutter--top',
		active: 'active',
		filter: 'filter__filters filter__filters--filled filter__filters--filled--alt',
		filterActionClass: 'filter__actions',
		filtercloseClass: 'filter__close',
		filtercloseTitle: 'filter__title',
		filterApply: 'filter__apply',
		filterText: 'Filters',
		spriteIcon: 'sprite__icon'
	},
	constData: {
		buttons: {
			clear: {
				id: 'filterButton',
				name: 'Clear filters',
				type: 'tertiary',
				buttonType: 'button'
			},
			applyFilter: {
				id: 'applyFilterButton',
				name: 'Apply',
				type: 'primary',
				isDisabled: true,
				buttonType: 'button'
			}
		},
		clearFilters: 'Clear filters',
		chevron: 'chevron-down',
		close: 'close'
	},
	actions: {
		applyFilter: 'applyFilter'
	}
};
export default filterStyle;
