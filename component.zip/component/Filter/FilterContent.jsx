import React from 'react';
import filterStyle from './filterDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import Button from 'vf-ent-ws-button';
import Accordion from 'vf-ent-ws-accordion';
export const FilterContent = (props) => {
	return (
		!props.data.clear && (
			<div className={filterStyle.constStyles.filter}>
				<div>
					<div className={filterStyle.constStyles.filterActionClass}>
						<div className={filterStyle.constStyles.filtercloseClass}>
							<span className={filterStyle.constStyles.spriteIcon} onClick={props.data.onClick}>
								<Icon name={filterStyle.constData.close} />
							</span>
						</div>
					</div>
					{props.data.filterDropdownData.map((filterData, index) => (
						<Accordion data={filterData} key={index} />
					))}
					<div className={filterStyle.constStyles.filterApply}>
						<Button data={props.data.applyButtonData} />
					</div>
				</div>
			</div>
		)
	);
};
export default FilterContent;
