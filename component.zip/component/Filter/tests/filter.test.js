import React from 'react';
import renderer from 'react-test-renderer';
import Filter from '../FilterComponent';
import {
    shallow,
    mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import FilterData from '../../../AppData/FilterData';
Enzyme.configure({
	adapter: new Adapter()
});

describe('<Filter />', function () {

    let enzymeWrapper;
    beforeEach(() => {
        enzymeWrapper = mount( < Filter  data = { FilterData }/>); 
    });
    

    it('it should call compoenent will mount before render',() => {
        expect( enzymeWrapper.instance().componentWillMount() ).toHaveBeenCalled;       
    });

    it('should render the content',() => {
        expect( enzymeWrapper.find('a').length).toBe(2);
    });

    it('should call onclick event',() => {
        expect(enzymeWrapper.instance().toggleFilter()).toHaveBeenCalled;
        enzymeWrapper.setState({ 
            active :"",
            clear: false
         });
    });

    it('should call componentWillReceiveProps',() => { 
        const data =   FilterData ;
        expect(enzymeWrapper.instance().componentWillReceiveProps(data.filterDropdownData)).toHaveBeenCalled;        
    });

    it('should call selectFilterItem ',() => {
        const mockData = FilterData.filterDropdownData[0].content.contentData[0];
        const event = {target: { value: "text given"}};
        expect(enzymeWrapper.instance().selectFilterItem(mockData,event)).toHaveBeenCalled;
    }); 
    
});