import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import './filter.css';
import filterStyle from './filterDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import FilterContent from './FilterContent';

class Filter extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			clear: false,
			active: this.props.data.isFilterOpen,
			selectedCount: 0,
			selectedItems: {},
			filterArwCls: filterStyle.constStyles.captionMediaClass,
			filterContentCls: filterStyle.constStyles.overflowclass,
			filterHeadCls: filterStyle.constStyles.button,
			filterDropdownData: this.props.data.filterDropdownData,
			clearFilterCls: filterStyle.constStyles.clearFilterClass
		};
		this.formatAccordionData = this.formatAccordionData.bind(this);
		this.selectFilterItem = this.selectFilterItem.bind(this);
		this.applyFilter = this.applyFilter.bind(this);

		this.toggleFilter = this.toggleFilter.bind(this);
		this.clearfilter = this.clearfilter.bind(this);
	}
	componentWillMount() {
		this.formatAccordionData(this.props);
	}
	componentWillReceiveProps(nextProps) {
		this.formatAccordionData(nextProps);
	}
	formatAccordionData(props) {
		const filterProps = props.data.filterDropdownData;
		const data = [];
		var flag = false;
		const items = { ...this.state.selectedItems };
		filterProps.map((filterData) => {
			const accordionData = { ...filterData };
			accordionData.content.contentData.map((radioData) => {
				radioData.onChange = (event) => this.selectFilterItem(radioData, event);
				if (radioData.checked == true) {
					flag = true;
					accordionData.alwaysExpanded = true;
					//this.toggleFilter();
					this.setState({
						clearFilterCls: `${filterStyle.constStyles.clearFilterClass} ${filterStyle.constStyles.active}`
					});
					items[radioData.name] = radioData;
				}
				return radioData;
			});
			data.push(accordionData);
			return filterData;
		});

		this.value = [];
		var v = JSON.parse(JSON.stringify(filterProps));
		v.map((filterData) => {
			const accordionData = { ...filterData };
			accordionData.content.contentData.map((radioData) => {
				radioData.onChange = (event) => this.selectFilterItem(radioData, event);
				delete radioData.checked;
				return radioData;
			});
			this.value.push(accordionData);
			return filterData;
		});

		this.value.map((arr) => {
			arr.content.contentData.map((obj) => {
				delete obj.checked;
			});
		});
		this.setFilterClass(this.state.active);
		this.setState({
			filterDropdownData: data,
			selectedItems: items,
			active: props.data.isFilterOpen,
			applyButtonData: {
				...filterStyle.constData.buttons.applyFilter,
				isDisabled: Object.keys(this.state.selectedItems).length === 0,
				onClick: this.applyFilter
			},
			selectedCount: this.props.data.selectedCount
		});
	}
	selectFilterItem(selectedItem, event) {
		const items = { ...this.state.selectedItems };
		items[selectedItem.name] = selectedItem;
		this.setState({
			selectedItems: items,
			applyButtonData: {
				...this.state.applyButtonData,
				isDisabled: Object.keys(items).length === 0
			},
			clearFilterCls: `${filterStyle.constStyles.clearFilterClass} ${filterStyle.constStyles.active}`
		});
		this.setState({
			filterDropdownData: this.value
		});
	}
	toggleFilter() {
		this.setState({
			active: !this.state.active,
			clear: false,
			applyButtonData: {
				...filterStyle.constData.buttons.applyFilter,
				isDisabled: Object.keys(this.state.selectedItems).length === 0,
				onClick: this.applyFilter
			}
		});
		this.setFilterClass(!this.state.active);
		this.props.data.openFilter != undefined && this.props.data.openFilter();
	}
	setFilterClass(active) {
		const filterHeadCls = `${filterStyle.constStyles.button} ${active && filterStyle.constStyles.activebutton}`;
		this.setState({
			filterArwCls: !active
				? filterStyle.constStyles.captionMediaClass
				: `${filterStyle.constStyles.captionMediaClass} ${filterStyle.constStyles.rotate}`,
			filterContentCls: active ? filterStyle.constStyles.filterOverflow : filterStyle.constStyles.overflowclass,
			filterHeadCls
		});
	}
	applyFilter() {
		this.setState({
			selectedCount: Object.keys(this.state.selectedItems).length
		});
		this.delegateHandler(filterStyle.actions.applyFilter, this.state.selectedItems, (args) => {
			return args;
		});
		this.toggleFilter();
		this.setFilterClass(false);
		console.log(this.selectedCount);
	}

	clearfilter() {
		this.setState({
			active: false,
			clear: true,
			selectedItems: {},
			selectedCount: 0,
			clearFilterCls: filterStyle.constStyles.clearFilterClass,
			filterDropdownData: this.value
		});

		this.state.selectedCount > 0 &&
			this.delegateHandler(filterStyle.actions.applyFilter, {}, (args) => {
				return args;
			});
		this.setFilterClass(false);
		this.props.data.clearFilter != undefined && this.props.data.clearFilter();
	}

	render() {
		const contentData = {
			onClick: this.toggleFilter,
			filterDropdownData: this.state.filterDropdownData,
			applyButtonData: this.state.applyButtonData,
			clear: this.state.clear
		};
		return (
			<div className={filterStyle.constStyles.mainDivClass}>
				<div className={filterStyle.constStyles.actionDivClass}>
					<div className={filterStyle.constStyles.actionDivItemClass}>
						<a
							className={this.state.filterHeadCls}
							onClick={this.toggleFilter}
							title={this.props.data.tooltip}
						>
							<span className={filterStyle.constStyles.captionClass}>
								<span className={filterStyle.constStyles.captionTextClass}>
									<span className={filterStyle.constStyles.filterCount}>
										{this.state.selectedCount}
									</span>
									<span>{filterStyle.constStyles.filterText}</span>
								</span>
								<span className={this.state.filterArwCls}>
									<Icon name={filterStyle.constData.chevron} />
								</span>
							</span>
						</a>
					</div>
					<div className={filterStyle.constStyles.actionItemsClass}>
						<a className={this.state.clearFilterCls} onClick={this.clearfilter}>
							{filterStyle.constData.clearFilters}
						</a>
					</div>
				</div>

				<div className={this.state.filterContentCls}>
					<FilterContent data={contentData} />
				</div>
			</div>
		);
	}
}
Filter.propTypes = {
	data: PropTypes.shape({
		tooltip: PropTypes.string,
		applyFilter: PropTypes.func.isRequired,
		filterDropdownData: PropTypes.arrayOf(
			PropTypes.shape({
				header: PropTypes.shape({
					type: PropTypes.string.isRequired,
					headerData: PropTypes.shape({
						title: PropTypes.string.isRequired
					}).isRequired
				}).isRequired,
				content: PropTypes.shape({
					type: PropTypes.string.isRequired,
					contentData: PropTypes.arrayOf(
						PropTypes.shape({
							id: PropTypes.string.isRequired,
							name: PropTypes.string.isRequired,
							tooltip: PropTypes.string.isRequired,
							displayValue: PropTypes.string.isRequired
						}).isRequired
					)
				}).isRequired
			})
		)
	})
};

export default Filter;
