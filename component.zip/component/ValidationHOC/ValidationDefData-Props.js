export const constStyle = {
    wrapper: 'valid-hoc-wrapper'    
}

export const defaultData = {
    type: 'warning',
    name: 'warning',
    id: 'l_w_wa',
    lightBackground: true,
    arrowRequired: true,
    isValidate: true,
    messageBody: 'This is a mandotary field'
};