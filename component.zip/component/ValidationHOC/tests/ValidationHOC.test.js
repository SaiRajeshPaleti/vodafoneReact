import React from 'react';
import renderer from 'react-test-renderer';
import  ValidationHOC  from '../ValidationHOC';
import  HOC  from '../ValidationHOC';
import {
    mount,
    shallow

} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({
    adapter: new Adapter()
});

describe('<ValidationHOC />', function () {
    let props, enzymeWrapper,PassedComponent;

    beforeEach(() => {   
        const NewComponent = ValidationHOC(PassedComponent) ;          
        enzymeWrapper = shallow (< NewComponent content = { false }  />);
    });
    it('should render the div', () => {        
        expect(enzymeWrapper).not.toBe(null);      

    });
});