import React, { PureComponent } from 'react';
import AlertMessage from 'vf-ent-ws-alert-message';
import {defaultData, constStyle} from './ValidationDefData-Props';

const ValidationHOC = (PassedComponent, props, key= + new Date(), content) => {

	const HOC = () => {

			let alertData  = Object.assign({}, defaultData); ;
			if(content){
				alertData.messageBody = content;
			}
			return (
				<div className={constStyle.wrapper}>
					<AlertMessage data={alertData} />
					<PassedComponent key={key} {...props} />
				</div>
			);
	}

	return HOC;
};

export default ValidationHOC;
