export const IconTitleData = {
  iconName: 'icon-report',
  title: 'Devices',
  type: 'icon',
  src: ''
};
export const ClassNames = {
  listHolder: 'list-holder',
  linkElement: 'link-element'
};
