// import React from 'react';
// import PropTypes from 'prop-types';
// import IconWithTitle from 'vf-ent-ws-icon-with-title';
// import './AttachmentsList.css';
// import { IconTitleData, ClassNames } from './AttachmentsDefData-Props';

// const formatData = (listItem) => {
//   const defaultData = JSON.parse(JSON.stringify(IconTitleData));
//   return {
//     ...defaultData,
//     title: listItem.name
//   };
// };
// export const AttachmentsList = (props) => {
//   return (
//     <div className={ClassNames.listHolder}>
//       {props.data.list.map((listItem, index) => {
//         return (
//           <a href={listItem.url} className={ClassNames.linkElement} key={index}>
//             <IconWithTitle data={formatData(listItem)} />
//           </a>
//         );
//       })}
//     </div>
//   );
// };

// AttachmentsList.propTypes = {
//   data: PropTypes.shape({
//     id: PropTypes.string.isRequired,
//     list: PropTypes.arrayOf(
//       PropTypes.shape({
//         name: PropTypes.string.isRequired,
//         url: PropTypes.string.isRequired
//       }).isRequired
//     ).isRequired
//   }).isRequired
// };

// AttachmentsList.defaultProps = { data: IconTitleData };

// export default AttachmentsList;
