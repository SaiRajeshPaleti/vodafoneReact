export const constStyles = {
	items: 'hoverItems',
	displayNone: 'display_none',
	dot1: 'dot dot1',
	dot2: 'dot dot2',
	dot3: 'dot dot3',
	iconClass: 'sprite__icon',
	overview: 'floatNav-O',
	navSection: 'floatingNavSection',
	Nav: 'floatingNav',
	clear: 'clear_all',
	floatIcon: 'floatIcon',
	search: 'floatNav-S'
};
export const constData = {
	onClick: 'onClick',
	value: 'name'
};
export const defaultData = {
	id: 'float1',
	name: 'floatIcon',
	iconPrimary: 'more-android',
	hoverTitle: 'Do some Action',
	hoverIcons: [
		{
			id: '1',
			name: 'overView',
			hoverTitle: 'Overview',
			iconName: 'arrow-up',
			onClick: () => {}
		},
		{
			id: '2',
			name: 'search',
			hoverTitle: 'Search',
			iconName: 'search',
			onClick: () => {}
		}
	],
	onClick: () => {}
};
