import React from 'react';
import { constStyles, defaultData } from './FloatNavdefData-Props';
import './floatingNav.css';
import Icon from 'vf-ent-ws-svgicons';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class FloatNav extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			hovering: false
		};

		this.MouseEnter = this.handleMouseEnter.bind(this);
		this.MouseLeave = this.handleMouseLeave.bind(this);
		this.divClass = '';
		this.ulClass = constStyles.displayNone;
	}

	handleMouseEnter() {
		this.setState({ hovering: true });
		this.divClass = constStyles.items;
		this.ulClass = '';
	}
	handleMouseLeave() {
		this.setState({ hovering: false });
		this.ulClass = constStyles.displayNone;
	}

	renderOnHover = () => {
		return this.props.data.hoverIcons.map((icon, index) => {
			const E = {
				target: {
					id: icon.id,
					value: icon.name
				}
			};
			return (
				<li key={index}>
					<a>
						<span
							className={constStyles.iconClass}
							title={icon.hoverTitle}
							onClick={(e) => icon.onClick(E)}
						>
							<Icon name={icon.iconName} />
						</span>
					</a>
				</li>
			);
		});
	};

	componentWillMount() {
		this.childIcons = this.renderOnHover();
	}

	render() {
		return (
			<div>
				<div className={constStyles.navSection}>
					<div className={constStyles.Nav} onMouseEnter={this.MouseEnter} onMouseLeave={this.MouseLeave}>
						<div className={this.divClass}>
							<ul className={this.ulClass}>{this.childIcons}</ul>
						</div>
						<div className={constStyles.floatIcon}>
							<span
								className={constStyles.iconClass}
								title={this.props.data.hoverTitle}
								onClick={() => this.props.data.onClick()}
							>
								<Icon name={this.props.data.iconPrimary} />
							</span>
						</div>
					</div>
				</div>
			</div>
		);
	}
}

FloatNav.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		iconPrimary: PropTypes.string.isRequired,
		hoverTitle: PropTypes.string,
		hoverIcons: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				hoverTitle: PropTypes.string,
				iconName: PropTypes.string.isRequired,
				onClick: PropTypes.func
			})
		).isRequired,
		onClick: PropTypes.func
	}).isRequired
};

FloatNav.defaultProps = {
	data: defaultData
};

export default FloatNav;
