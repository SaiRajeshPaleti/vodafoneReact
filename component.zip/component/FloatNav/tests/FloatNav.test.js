import React from 'react';
import renderer from 'react-test-renderer';
//import App from '../App';
import FloatNav from '../FloatNav';
import FloatNavData from '../../../AppData/FloatNavData';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';

import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });
function setup() {
	let props;
	const enzymeWrapper = shallow(<FloatNav />);
	return { enzymeWrapper, props };
}

describe('components', function() {
	describe('<FloatNav/>', function() {
		let props, enzymeWrapper, mouseEnter, mouseLeave;

		beforeEach(() => {
			props = FloatNavData;
			mouseEnter = FloatNav.handleMouseEnter;
			mouseLeave = FloatNav.handleMouseLeave;
			enzymeWrapper = mount(<FloatNav FloatNavItems={FloatNavData} />);
		});
		it('overview text', () => {
			console.log(enzymeWrapper.find('.floatNav-O').text());
			expect(enzymeWrapper.find('.floatNav-O').text()).toEqual('Overview');
		});

		it('overview Icon test', () => {
			expect(enzymeWrapper.find('.floatNav-S').text()).toEqual('Search');
		});

		it('search Icon test', () => {
			expect(enzymeWrapper.find('.searchIcon').text()).toEqual('p');
		});

		it('event handler to be called on mouseenter', () => {
			let floatNav = enzymeWrapper.find('.floatingNav');
			floatNav.simulate('change');
			expect(FloatNav.handleMouseEnter).toHaveBeenCalled;
		});

		it('event handler to be called on mouseleave', () => {
			let floatNav = enzymeWrapper.find('.floatingNav');
			floatNav.simulate('change');
			expect(FloatNav.handleMouseLeave).toHaveBeenCalled;
		});

		it('set state on mouse enter method', () => {
			enzymeWrapper.setState({ props }, () => {
				enzymeWrapper.instance().handleMouseEnter();
				const userState = enzymeWrapper.state('props');
				expect(userState.handleMouseEnter).toHaveBeenCalled;
			});
		});

		it('set state on mouse leave method', () => {
			enzymeWrapper.setState({ props }, () => {
				enzymeWrapper.instance().handleMouseLeave();
				const userState = enzymeWrapper.state('props');
				expect(userState.handleMouseLeave).toHaveBeenCalled;
			});
		});
	});
});
