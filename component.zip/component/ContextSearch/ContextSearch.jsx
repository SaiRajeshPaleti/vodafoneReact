import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import TextField from 'vf-ent-ws-textfield';

import SelectDropDown from 'vf-ent-ws-select-dropdown';
import Button from 'vf-ent-ws-button';

import './ContextSearch.css';
import { defaultStyles, constData } from './ContextSearchDefData-props';

class ContextSearch extends BaseComponent {
  constructor(props) {
    super(props);

    this.loadDropDown = this.loadDropDown.bind(this);
    this.getSelectedOption = this.getSelectedOption.bind(this);
    this.getTextData = this.getTextData.bind(this);
    this.searchData = this.searchData.bind(this);
    this.invokeComponent = this.invokeComponent.bind(this);
  }
  componentWillMount() {
    this.invokeComponent(this.props);
  }
  componentWillReceiveProps(nextProps) {
    this.invokeComponent(nextProps);
  }
  invokeComponent(props) {
    this.setState(
      {
        data: props.data,
        selectedDropdownValue: props.data.selectedvalue
          ? props.data.selectedvalue
          : props.data.contentSearch.defaultValue,
        selectedText: props.data.textSearch.textData.value
      },
      () => {
        this.contextSearchDropdown = this.loadDropDown();
        this.loadTextSearch(props.data.textSearch.textData.value);
      }
    );
  }

  getSelectedOption(e) {
    const Data = this.state.data;

    if (e.value === Data.contentSearch.restrict) {
      Data.textSearch.textData.format = '';
    } else Data.textSearch.textData.format = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
    this.setState({
      selectedDropdownValue: e.value,
      data: Data
    });
    this.loadTextSearch();
  }
  getTextData(e) {
    this.setState({
      selectedText: e.value
    });

    this.loadTextSearch(e.value);
  }
  readData(data) {
    return data;
  }

  searchData(e) {
    const Data = this.state.data;
    const selectedText = this.state.selectedText;
    if (selectedText && selectedText.length > Data.textSearch.searchCriteriaLength)
      this.delegateHandler(
        constData.propsProperty,
        { selectedText: this.state.selectedText, selectedOption: this.state.selectedDropdownValue },
        this.readData
      );
  }

  loadDropDown() {
    const dropDrownData = {
      data: this.state.data.contentSearch,
      selectedvalue: this.state.data.selectedvalue,
      onChange: this.getSelectedOption
    };
    return <ContextSearchDropdown data={dropDrownData} />;
  }
  loadTextSearch(val) {
    let textsrcdata = this.state.data.textSearch;

    textsrcdata = {
      ...textsrcdata,
      textData: {
        ...textsrcdata.textData,
        value: val ? val : ''
      }
    };
    let isDisabled = textsrcdata.textData.value.length > textsrcdata.searchCriteriaLength ? false : true;
    let buttonProps = { ...textsrcdata.buttonData, isDisabled, onClick: this.searchData };
    this.setState({
      textFieldData: {
        ...textsrcdata.textData,
        onChange: this.getTextData,
        onKeyUp: this.searchData
      },
      buttonData: buttonProps
    });
  }
  render() {
    return (
      <div className={defaultStyles.searchOrderFilterCol}>
        <div className={defaultStyles.searchOrderFilter}>
          <div className={defaultStyles.gridItemFormSmallBottom}>{this.contextSearchDropdown}</div>
          <div className={defaultStyles.positionRelativeSearch}>
            <TextField data={this.state.textFieldData} />
            <Button data={this.state.buttonData} />
          </div>
        </div>
        {this.state.data.searchNote && (
          <p className={defaultStyles.searchLabel}>
            <span className={defaultStyles.searctText}>{this.state.data.searchNote}</span>
          </p>
        )}
      </div>
    );
  }
}

const ContextSearchDropdown = (props) => {
  const { data, selectedvalue, onChange } = props.data;
  const dropdownData = {
    ...data,
    selectedvalue,
    onChange
  };
  return <SelectDropDown data={dropdownData} />;
};

ContextSearch.propTypes = {
  data: PropTypes.shape({
    contentSearch: PropTypes.shape({
      dropdown: PropTypes.arrayOf(
        PropTypes.shape({
          itemName: PropTypes.string.isRequired,
          itemValue: PropTypes.string.isRequired
        }).isRequired
      ).isRequired,
      selectBoxId: PropTypes.string.isRequired,
      selectBoxName: PropTypes.string.isRequired
    }).isRequired,
    textSearch: PropTypes.shape({
      searchCriteriaLength: PropTypes.number.isRequired,
      buttonData: PropTypes.shape({
        location: PropTypes.string.isRequired,
        id: PropTypes.string.isRequired,
        buttonType: PropTypes.string.isRequired,
        type: PropTypes.string.isRequired,
        name: PropTypes.string,
        isIcon: PropTypes.bool
      }).isRequired,
      textData: PropTypes.shape({
        id: PropTypes.string.isRequired,
        maxLength: PropTypes.number.isRequired,
        name: PropTypes.string.isRequired,
        placeholder: PropTypes.string.isRequired
      }).isRequired
    }).isRequired
  }).isRequired
};
export default ContextSearch;
