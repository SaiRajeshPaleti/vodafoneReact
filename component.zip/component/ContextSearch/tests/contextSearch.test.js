import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ContextSearch from '../ContextSearch';
import ContextSearchData from '../../../AppData/ContextSearchData';

Enzyme.configure({ adapter: new Adapter() });

describe('<ContextSearch/>', function() {
    let enzymeWrapper, props, count, clickHandler;
    beforeEach(() => {
        enzymeWrapper = mount(<ContextSearch data={ContextSearchData} />);
    });

    it('Context Search contains main div', () => {
        expect(enzymeWrapper.find('.search_order_filter_col').length).toEqual(1);
    });
    it('Context Search contains a dropdown', () => {
        expect(enzymeWrapper.find('.form__select_cr').length).toEqual(1);
    });

    it('Context Search contains a textbox', () => {
        expect(enzymeWrapper.find('.form__input').length).toEqual(1);
    });
    it('Context Search contains a search button', () => {
        expect(enzymeWrapper.find('.button').length).toEqual(1);
    });

    it('event handler to be called on change of select box', () => {
        let dropdown = enzymeWrapper.find('.form__select_cr');
        dropdown.simulate('change');

        expect(enzymeWrapper.instance().getSelectedOption).toHaveBeenCalled;
    });

    it('event handler to be called on change of textbox', () => {
        let textbox = enzymeWrapper.find('.form__input');
        textbox.simulate('change');

        expect(enzymeWrapper.instance().getTextData).toHaveBeenCalled;
    });
    it('event handler to be called on click of search button', () => {
        let searchButton = enzymeWrapper.find('.button');
        searchButton.simulate('click');

        expect(enzymeWrapper.instance().searchData).toHaveBeenCalled;
    });
    it('Should trigger componentWillRecieveProps', () => {
        const newProps = {
            ...ContextSearchData
        };
        enzymeWrapper.setProps({ data: newProps });
    });
});
