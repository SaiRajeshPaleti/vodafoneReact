export const defaultStyles = {
  chevronIcon: 'chevron-down',
  searchIcon: 'search',
  searchOrderFilterCol: 'search_order_filter_col',
  searchOrderFilter: 'search_order_filter',
  gridItemFormSmallBottom: 'grid__item form-small--bottom search-grid',
  positiveRelativeDblock: 'position_relative dblock',
  formInputForm: 'form-input form__input--selectable',
  formSelect: 'form__select_cr',
  chevronSearch: 'chevron-search-custom',
  positionRelativeSearch: 'position_relative search_input',
  searchIconFontsButtonSecondary: 'search_icon IconsFonts button button--secondary search-but',
  searchLabel: 'p-0 m-0',
  searctText: 'searct-text'
};
export const constData = {
  propsProperty: 'onClick'
};
