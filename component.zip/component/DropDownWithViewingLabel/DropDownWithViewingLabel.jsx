import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import DropDownButtons from 'vf-ent-ws-dropdown-button';
import { defaultStyles } from './DropDownWithViewinLabelDefData-Props';
class DropDownWithViewingLabel extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      viewingData: []
    };
    this.dropDownHandler = this.dropDownHandler.bind(this);
  }
  componentWillMount() {
    this.loadData(this.props.data);
  }
  componentWillReceiveProps(nextProps) {
    this.loadData(nextProps.data);
  }

  loadData(data) {
    this.setState({
      dropDownWithLabelData: data
    });
    const Filters = [];
    data.DropDown.dropdownButtonValues.map((list) => {
      if (list.value) {
        Filters.push(list.displayValue);
      }
    });
    this.setState({
      showViewingLabel: true,
      viewingData: Filters
    });
  }

  dropDownHandler(e) {
    const Filters = [];
    const listItems = this.state.dropDownWithLabelData.DropDown.dropdownButtonValues;
    listItems.map((list) => {
      if (e) {
        if (e.id.includes(list.id)) {
          list.value = e.value;
        }
      }
      if (list.value) {
        Filters.push(list.displayValue);
      }
      return list;
    });
    const dropDownType = this.state.dropDownWithLabelData.dropdownType;
    const handlerData = { e: e, Filters: Filters, dropDownType: dropDownType };

    this.setState({
      showViewingLabel: true,
      viewingData: Filters
    });
    this.delegateHandler('handler', handlerData, () => {
      return handlerData;
    });
  }

  render() {
    return (
      <div className={defaultStyles.gridItemForm}>
        <div>
          <label className={defaultStyles.formRow}>
            <span className={defaultStyles.jsFormLabel}>{this.state.dropDownWithLabelData.Heading} </span>
          </label>
          <DropDownButtons data={this.state.dropDownWithLabelData.DropDown} handler={this.dropDownHandler} />
        </div>

        <ViewingLabel data={this.state.viewingData} />
      </div>
    );
  }
}

export default DropDownWithViewingLabel;
const ViewingLabel = (props) => {
  return (
    props.data.length > 0 && (
      <div className={defaultStyles.filterText}>
        <p>
          <span className={defaultStyles.noteLabel}>Viewing </span>
          <span className={defaultStyles.noteDesc}>
            {props.data.map((label, index) => {
              return <span key={index}>{(index ? ', ' : '') + label}</span>;
            })}
          </span>
        </p>
      </div>
    )
  );
};
DropDownWithViewingLabel.propTypes = PropTypes.shape({
  DropDown: PropTypes.shape({
    clickTxt: PropTypes.string.isRequired,
    dropDownButtonType: PropTypes.string.isRequired,
    dropdownButtonValues: PropTypes.arrayOf(
      PropTypes.shape({
        displayValue: PropTypes.string.isRequired,
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired
      }).isRequired
    ).isRequired,
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired
  }).isRequired,
  Heading: PropTypes.string.isRequired
}).isRequired;
