import React from 'react';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import renderer from 'react-test-renderer';
Enzyme.configure({ adapter: new Adapter() });
import DropDownWithViewingLabel from '../DropDownWithViewingLabel';
import DropDownWithViewingLabelData from '../../../AppData/DropDownWithViewingLabelData';

describe('<DropDownWithViewingLabel/>', function() {
    let props, enzymeWrapper;

    beforeEach(() => {
        enzymeWrapper = mount(<DropDownWithViewingLabel data={DropDownWithViewingLabelData} />);
    });

    it('Filter contains  main div', () => {
        expect(enzymeWrapper.find('.grid__item').length).toEqual(1);
    });
    it('Filter Button contains DropDown', () => {
        expect(enzymeWrapper.find('.dropdown__heading').length).toEqual(1);
    });
    // it('DropDown contains Viewing Label', () => {
    //     expect(enzymeWrapper.find('.filter-text').length).toEqual(1);
    // });

    it('event handler to be called on change of priority select box', () => {
        let dropdown = enzymeWrapper.find('.filtering__dropdown');

        dropdown.simulate('change');

        expect(enzymeWrapper.instance().dropDownHandler).toHaveBeenCalled;
        // enzymeWrapper.instance().dropDownHandler();
        // // component.instance().onSubmit();

        // expect(enzymeWrapper.instance().loadViewingLabel).toHaveBeenCalled;
    });

    it('loadViewingLabel to be called', () => {
        enzymeWrapper.instance().dropDownHandler();
        // // component.instance().onSubmit();
        const listItems = DropDownWithViewingLabelData.DropDown.dropdownButtonValues;
        expect(enzymeWrapper.instance().loadViewingLabel).toHaveBeenCalled;
    });

    it('Should trigger componentWillRecieveProps', () => {
        const newProps = {
            ...DropDownWithViewingLabelData
        };
        enzymeWrapper.setProps({ data: newProps });
    });
});
