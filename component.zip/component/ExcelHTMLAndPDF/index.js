import { createExcel } from './createExcel';
import { generateHtml, generatePDF } from './createPdfandHTML';
import { convertJSONToObject } from './requestMapGenerator';

export const createExcelFunction = createExcel;

export const generateHtmlFunction = generateHtml;

export const generatePDFFunction = generatePDF;

export const convertJSONToObjectFunction = convertJSONToObject;


