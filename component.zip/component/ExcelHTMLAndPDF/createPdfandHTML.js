const { commonDictLookup } = require('./constants');
const Constants = commonDictLookup['Constants'];


const Freemarker = require('freemarker');
const fs = require('fs');
const pdf = require('html-pdf');
const freemarker = new Freemarker();
const options = { format: Constants.OPTIONS };

export const generateHtml= (payloadMap, fileName,templatePath) => {
   // let html = fs.readFileSync(templatePath, 'utf8');
  fs.readFile(templatePath, function (err, html) {
        freemarker.render(html, payloadMap, function (err, result) {
            if (err) {
                throw new Error(err);
            }
            fs.writeFile(fileName, result, function (err) {
                if (err) console.log(err);
            });
        });
    });
}

export const generatePDF = (payloadMap, fileName,templatePath) => {    
     fs.readFile(templatePath, function (err, html) {
        freemarker.render(html, payloadMap, function (err, result) {
            if (err) {
                throw new Error(err);
            }
            pdf.create(result, options).toFile(fileName, function (err, res) {
                if (err) return console.log(err);
            });
        });
    });
}
