const Constants = {
    EXCELEXT: '.xlsx',
	PDFEXT: '.PDF',
	HTMLEXT: '.html',
	OPTIONS: 'Letter',
    PLACEHOLDER: '$',    
    STRING: 'string',    
	EMPTY: ''
}
const commonDictLookup = {
	Constants: Constants
};
module.exports = { commonDictLookup,Constants };