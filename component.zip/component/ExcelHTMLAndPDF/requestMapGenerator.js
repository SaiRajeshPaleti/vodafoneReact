const { commonDictLookup } = require('./constants');
const Constants = commonDictLookup['Constants'];

const payloadMap = {};

export const convertJSONToObject = (payloadData) => {
    for (let section of Object.keys(payloadData)) {
        if (typeof payloadData[section] === Constants.STRING) {
            if (section != 'label' && section != 'value') {
                payloadMap[section] = payloadData[section];
            }
        }
        else {
            for (let key of Object.keys(payloadData[section])) {
                if (typeof payloadData[section][key] === Constants.STRING ||
                    typeof payloadData[section][key] === '') {
                    if (key == 'value') {
                        payloadMap[section] = payloadData[section][key];
                    }
                }
                else if (!Array.isArray(payloadData[section][key])) {
                    convertJSONToObject(payloadData[section][key]);
                }
            }
        }
    }
    return payloadMap;
}