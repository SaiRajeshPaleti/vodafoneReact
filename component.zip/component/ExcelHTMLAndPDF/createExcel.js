const { commonDictLookup } = require('./constants');
const Constants = commonDictLookup['Constants'];


export const createExcel =  (payloadMap, filename,template) => {
    const Excel = require('exceljs');
    const wb = new Excel.Workbook();
    wb.xlsx.readFile(template + Constants.EXCELEXT).then(function () {
        wb.eachSheet(function (worksheet, sheetId) {
            worksheet.eachRow(function (row, rowNumber) {
               let currRow = worksheet.getRow(rowNumber);
                row.eachCell(function (cell, colNumber) {
                 let currVal = currRow.getCell(colNumber).value;
                    let tempVal = currVal.replace(Constants.PLACEHOLDER, Constants.EMPTY);
                    if (tempVal != null && payloadMap[tempVal] != null) {
                        currRow.getCell(colNumber).value = payloadMap[tempVal];
                    }
                    else if (currVal.indexOf(Constants.PLACEHOLDER) > -1) {
                        currRow.getCell(colNumber).value = Constants.EMPTY;
                    }
                });
            });
        });
        wb.xlsx.writeFile(filename);
    });
}