import React from 'react';
import './GenericSearch.css';
import PropTypes from 'prop-types';
import { defaultStyle, defaultData } from './GenericSearchDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import TextField from '../TextField/textFieldComponent';
import BaseComponent from 'vf-ent-ws-utilities';

class GenericSearch extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      search: ''
    };
    this.searchData = this.searchData.bind(this);
    this.clearInput = this.clearInput.bind(this);
  }

  componentWillMount() {
    this.icon = this.iconFn(defaultStyle.search);
  }
  componentWillUpdate() {
    this.close = this.iconFn(defaultStyle.close);
  }
  searchData(event) {
    this.setState({ search: event.value });
  }
  clearInput() {
    this.setState({ search: '' });
  }
  iconFn = (param) => {
    return <IconButton data={defaultStyle[param]} click={this.clearInput} />;
  };

  render() {
    let textVal = {
      ...this.props.data.textField,
      value: this.state.search,
      onChange: this.searchData
    };
    return (
      <div className={defaultStyle.gridItem}>
        <TextField data={textVal} />
        {this.state.search && this.close}
        {!this.state.search && this.icon}
      </div>
    );
  }
}

const IconButton = (props) => (
  <span className={defaultStyle.iconClass} onClick={props.click}>
    <Icon name={props.data} />
  </span>
);

GenericSearch.propTypes = {
  data: PropTypes.shape({
    onChangeHandler: PropTypes.func.isRequired,
    clearIconFont: PropTypes.string.isRequired,
    searchIconFont: PropTypes.string.isRequired,
    textField: PropTypes.shape({
      id: PropTypes.string.isRequired,
      name: PropTypes.string.isRequired,
      title: PropTypes.string.isRequired,
      placeholder: PropTypes.string.isRequired,
      maxLength: PropTypes.number.isRequired,
      onChange: PropTypes.func.isRequired
    }),
    buttonWithIconData: PropTypes.arrayOf(
      PropTypes.shape({
        location: PropTypes.string.isRequired,
        id: PropTypes.string.isRequired,
        name: PropTypes.string.isRequired,
        type: PropTypes.string.isRequired,
        buttonType: PropTypes.string.isRequired,
        isIcon: PropTypes.bool.isRequired
      })
    )
  }).isRequired
};
GenericSearch.defaultProps = {
  data: defaultData
};
export default GenericSearch;
