import React from 'react';
import renderer from 'react-test-renderer';
import GenericSearch from '../GenericSearch';
import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import GenericSearchData from '../../../AppData/GenericSearchData';
Enzyme.configure({ adapter: new Adapter() });

describe('<GenericSearch />', function() {
	let props, enzymeWrapper;
	const onSearchMock = jest.fn();
	const clearInput = jest.fn();
	// const event = {

	//     target: { value: 'the-value' }
	//   };

	beforeEach(() => {
		props = GenericSearchData;
		enzymeWrapper = shallow(<GenericSearch GenericSearchItems={props} />);
	});

	it('should render GenericSearch component', () => {
		expect(enzymeWrapper.find('.grid__item').length).toBe(1);
	});

	it('identify that div contains input', () => {
		expect(enzymeWrapper.find('input').type()).toBe('input');
	});

	it('Verifies that element contains child div element', () => {
		expect(enzymeWrapper.childAt(1).find('div').length).toBe(1);
	});

	it('event handler to be called on onChange', () => {
		let elem = enzymeWrapper.find('input');

		elem.simulate('change', { target: { value: 'some value' } });

		expect(onSearchMock).toBeCalled;
	});
	it('event handler to be called on ', () => {
		//let elem = enzymeWrapper.childAt(1);
		//enzymeWrapper.simulate('focus');
		enzymeWrapper.simulate('click');

		//   expect(onSearchMock).toBeCalled;
		expect(enzymeWrapper.state('search')).toBe('');
	});

	it('event handler to be called on bttton click', () => {
		let button = enzymeWrapper.childAt(1);
		button.simulate('click');
		expect(clearInput).toHaveBeenCalled;
	});

	it('event handler to be called on clear input', () => {
		enzymeWrapper.setState({ props }, () => {
			enzymeWrapper.instance().clearInput();
			const userState = enzymeWrapper.state('props');
			expect(userState.clearInput).toHaveBeenCalled;
		});
	});
});
