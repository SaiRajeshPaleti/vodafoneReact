import React from 'react';
import { constStyles, defaultData, constData } from './SwitchDefData-Props';
import PropTypes from 'prop-types';
import './switchbutton.css';
import BaseComponent from 'vf-ent-ws-utilities';

class Switch extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			status: props.data.status,
			disabled:props.data.disabled
		};
		this.handleOnClick = this.handleOnClick.bind(this);
	}


	componentWillReceiveProps(nextProps) {
		this.setState({
			status: nextProps.data.status,
			disabled:nextProps.data.disabled
		});
	}
	dataPassing(obj) {
		return {
			id: obj.id,
			value: obj.value
		};
	}

	handleOnClick() {
		if(this.state.disabled!==true){
			this.setState(
				{
					status: !this.state.status
				},
				() => {
					const switchEventData = {
						id: this.props.data.id,
						value: this.state.status
					};
					this.delegateHandler(constData.propsProperty, switchEventData, this.dataPassing);
				}
			);
		}
	}

	render() {
		return (
			<div
				id={this.props.data.id}
				className={this.props.data.mainClass ? this.props.data.mainClass : constStyles.mainCls}
			>
				<label className={constStyles.switchOnOff}>
					<span
						name={this.props.data.name}
						className={this.state.status ? constStyles.switchActive : constStyles.switchInActive}
						onClick={this.handleOnClick}
					/>
				</label>
			</div>
		);
	}
}

Switch.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		mainClass: PropTypes.string,
		name: PropTypes.string.isRequired
	}).isRequired
};

Switch.defaultProps = { data: defaultData };

export default Switch;
