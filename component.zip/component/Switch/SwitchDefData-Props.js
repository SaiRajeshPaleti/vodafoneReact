export const constStyles = {
	mainCls: 'grid__item grid__item--gutter grid__item--sm-1/1 grid__item--1/3 ',
	switchOnOff: 'switch_onoff',
	switchActive: 'fa fa-toggle-on active',
	switchInActive: 'fa fa-toggle-on inactive'
};

export const constData = {
	propsProperty: 'onClick',
	eventProperty: 'value'
};

export const defaultData = {
	id: 'sample_switch',
	status: false,
	name: 'switch',
	mainClass: '',
	onClick: (data) => {
		console.log("button status: ", data);
	}
}

export default constStyles;