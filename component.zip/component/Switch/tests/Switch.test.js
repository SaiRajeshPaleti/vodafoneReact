import React from 'react';
import renderer from 'react-test-renderer';
import switchData from '../../../AppData/SwitchData';
import Switch from '../Switch';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import SwitchComponentData from '../SwitchDefData-Props';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<Switch/>', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = switchData;

		enzymeWrapper = shallow(<Switch SwitchComponentData={props} />);
	});

	it('Switch Component main div', () => {
		expect(enzymeWrapper.find('.switch_onoff').length).toEqual(1);
	});
	it('event handler to be called on change', () => {
		const span = enzymeWrapper.find('.switch_onoff').simulate('click');
		expect(Switch.toggleSwitch).toHaveBeenCalled;
	});
	it('event handler to be called on check All change3', () => {
		enzymeWrapper.setState({ props }, () => {
			enzymeWrapper.instance().toggleSwitch();
			const userState = enzymeWrapper.state('props');
			expect(userState.toggleSwitch).toHaveBeenCalled;
		});
	});
	it('Switch functional component', () => {
		enzymeWrapper.instance().componentWillReceiveProps(props);
	});
	// it('Switch functional', () => {
	//  	enzymeWrapper.instance().dataPassing(String);
	//  });
	 it('Switch instance handleonclick', () => {
		enzymeWrapper.instance().handleOnClick();
	});

	it('checking the status of select value after updating the state', () => {
		let span = enzymeWrapper.find('.switch_onoff');
		span.simulate('click');
		expect(enzymeWrapper.state().checkAll).toEqual(false);
		span.simulate('click');
		expect(enzymeWrapper.state().checkAll).toEqual(true);
	});
});
