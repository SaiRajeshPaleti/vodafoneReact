import React from 'react';
import { constStyles, defaultData, constData } from './priorityCardsDefData-Props';
import './prioritycards.css';
import Icon from 'vf-ent-ws-svgicons';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class priorityCardsSVG extends BaseComponent {
	componentWillMount() {
		this.content = this.contentBody(this.props.data);
		// }
		// componentDidMount() {
		const nextprops = this.props;
		//if (nextprops.data.enableDefaultSelection) {
		this.debugLog('received componentDidMount props  ::' + JSON.stringify(nextprops));
		this.active =
			nextprops.data.activeTabs && nextprops.data.currentCard === nextprops.data.name
				? constStyles.tabsCls
				: null;
		this.content = this.contentBody(nextprops.data);
		this.debugLog('active inside priprt card didmount:: ' + this.active);
		//}
	}

	componentWillReceiveProps(nextprops) {
		this.active =
			nextprops.data.activeTabs && nextprops.data.currentCard === nextprops.data.name
				? constStyles.tabsCls
				: null;
		this.content = this.contentBody(nextprops.data);
	}

	contentBody = (cardData) => {
		return (
			<React.Fragment>
				<div className={constStyles.svgClass}>
					<Icon className={constStyles.iconClass} name={cardData[constData.svg]} />
				</div>
				<div className={constStyles.divContentClass}>
					<p>{cardData[constData.descC42]}</p>
				</div>
				<div className={constStyles.divContentClass}>
					<p>{cardData[constData.descC43]}</p>
				</div>
			</React.Fragment>
		);
	};
	onClick(e) {}
	render() {
		const E = { target: { id: this.props.data.id, value: this.props.data.name } };
		this.debugLog('value of E ::' + JSON.stringify(E));
		return (
			<div
				className={this.active}
				name={this.props.data.name}
				id={this.props.data.id}
				onClick={(e) => {
					this.delegateHandler(constData.onClick, E, constData.value);
				}}
			>
				<div className={constStyles.svg}>{this.content}</div>
			</div>
		);
	}
}

priorityCardsSVG.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		id: PropTypes.string.isRequired,
		url: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		description1: PropTypes.string,
		description2: PropTypes.string,
		onClick: PropTypes.func.isRequired
	}).isRequired
};

priorityCardsSVG.defaultPops = {
	data: defaultData.card4
};

export default priorityCardsSVG;
