import React from 'react';
import { constStyles, constData, defaultData } from './priorityCardsDefData-Props';
import './prioritycards.css';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class PriorityCardsSelect extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = { circleClass: '' };
		this.selectFunction = this.selectFunction.bind(this);
	}

	selectFunction() {
		if (this.state.circleClass === '')
			this.setState({
				circleClass: `${constStyles.circleSelectClass}`
			});
		else this.setState({ circleClass: '' });
		this.props.data.onClick();
	}

	render() {
		const cardData = this.props.data;
		return (
			<div
				onClick={this.selectFunction}
				name={this.props.data.name}
				id={this.props.data.id}
				className={constStyles.select}
			>
				<div className={`${constStyles.svgClass} ${this.state.circleClass}`}>
					<div className={constStyles.divContentClass}>
						<p>{cardData[constData.selectField]}</p>
					</div>
				</div>
				<div>{constData.descField}</div>
			</div>
		);
	}
}

PriorityCardsSelect.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		speed: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		id: PropTypes.string.isRequired,
		onClick: PropTypes.func.isRequired
	}).isRequired
};

PriorityCardsSelect.defaultProps = {
	data: defaultData.card5
};

export default PriorityCardsSelect;
