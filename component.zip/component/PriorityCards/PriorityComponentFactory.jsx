import React from 'react';
import { getContent } from './PriorityElementRegistry';

const PriorityComponentFactory = (cardData) => {
	const ComponentContent = getContent(cardData.type);
	return <ComponentContent data={cardData} />;
};
export default PriorityComponentFactory;
