import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsComponentList from '../priorityCardsComponentList';

Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCardsComponentList />', function () {
    let props, enzymeWrapper;

    props={
        data:{
            dataList: {
                heading: 'Template One',
                name: 'Ethernet Interconnect',
                url: 'http://www.vodafone.co.uk/',
                item1: true,
                item2: true,
                item3: true,
                item4: false
            },
            card7_mapping: {
                item1: {
                    label: 'Customer And Billing Details',
                    key: 'CustomerAndBillingDetails'
                },
                item2: {
                    label: 'Site A Details',
                    key: 'SiteADetails'
                },
                item3: {
                    label: 'Site B Details',
                    key: 'SiteBDetails'
                },
                item4: {
                    label: 'Service Details',
                    key: 'ServiceDetails'
                }
            }
        }
    };

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsComponentList {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

});