import React from 'react';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PriorityCardsComponentIconText from '../PriorityCardsComponentIconText';

Enzyme.configure({ adapter: new Adapter() });

describe('<PriorityCardsComponentIconText />', function () {
    let props, enzymeWrapper;

    props={
        data:{
            noteList: [ 
                { text: 'test notes', date: '12 May 2018' },
                 { text: 'test notes', date: '12 May 2018' }
                 ]
        }
    }

    beforeEach(() => {
        enzymeWrapper = mount (<PriorityCardsComponentIconText {...props} />);

    });

    it('check for rendering', ()=>{
        expect(enzymeWrapper).not.toBe(null);
    });

});