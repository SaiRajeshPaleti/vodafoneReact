import React from 'react';
import Icon from 'vf-ent-ws-svgicons';
import { constStyles } from './priorityCardsDefData-Props';
import PropTypes from 'prop-types';
import { defaultData } from './priorityCardsDefData-Props';
import BaseComponent from 'vf-ent-ws-utilities';

class priorityCardsComponentList extends BaseComponent {
	constructor(props) {
		super(props);
		this.setCardData = this.setCardData.bind(this);
	}
	componentWillMount() {
		this.setCardData(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.setCardData(nextProps);
	}

	setCardData(props) {
		this.commonCardBody = Object.keys(props.data.card7_mapping).map((key, index) => {
			const isActive = this.isTaskCompleted(key);
			return (
				<li key={index}>
					<span className={isActive ? 'bg-true' : 'bg-false'}>
						{isActive ? (
							<Icon name={constStyles.tickClass} />
						) : (
							<span className={constStyles.emptyCircle} />
						)}
					</span>
					<span>{props.data.card7_mapping[key].label}</span>
				</li>
			);
		});
	}

	isTaskCompleted = (key) => {
		return this.props.data.dataList[key];
	};

	render() {
		const onClick = this.props.data.dataList.onClick != undefined ? this.props.data.dataList.onClick : () => {};
		return (
			<div className={constStyles.listClass}>
				<h2 onClick={onClick}>
					<a href={this.props.data.dataList.url}>{this.props.data.dataList.heading}</a>
				</h2>
				<h3>{this.props.data.dataList.name}</h3>
				<ul>{this.commonCardBody}</ul>
			</div>
		);
	}
}

priorityCardsComponentList.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string,
		datList: PropTypes.shape({
			heading: PropTypes.string,
			name: PropTypes.string,
			url: PropTypes.url,
			item1: PropTypes.bool,
			item2: PropTypes.bool,
			item3: PropTypes.bool,
			item4: PropTypes.bool
		}),
		card7_mapping: PropTypes.shape({
			item1: PropTypes.shape({
				label: PropTypes.string,
				key: PropTypes.string
			}),
			item2: PropTypes.shape({
				label: PropTypes.string,
				key: PropTypes.string
			}),
			item3: PropTypes.shape({
				label: PropTypes.string,
				key: PropTypes.string
			}),
			item4: PropTypes.shape({
				label: PropTypes.string,
				key: PropTypes.string
			})
		})
	}).isRequired
};

priorityCardsComponentList.defaultPops = {
	data: defaultData.card7
};

export default priorityCardsComponentList;
