import React from 'react';
import StepTracker from 'vf-ent-ws-step-tracker';
import { constStyles, defaultData } from './priorityCardsDefData-Props';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class priorityCardsFullSteps extends BaseComponent {
	constructor(props) {
		super(props);
		this.setCardData = this.setCardData.bind(this);
	}
	componentWillMount() {
		this.setCardData(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.setCardData(nextProps);
	}

	setCardData(props) {
		let commonOrderDetails = props.data.order_details.map((data, index) => {
			return (
				<div className="card-right-data" key={index}>
					<span>{data.name}:</span>
					<span className="card-right-value">{data.value}</span>
				</div>
			);
		});
		this.setState({ commonOrderDetails });
	}

	getStepTrackerActiveID(data, name) {
		let result = data.filter((obj) => {
			return obj.name === name;
		});
		if (!result[0]) return 1;
		return parseInt(result[0].id);
	}

	setStepTrackerData(trackerData) {
		const active_id = this.getStepTrackerActiveID(trackerData.data, trackerData.currentActive);
		trackerData.data.map((obj, index) => {
			let id = parseInt(obj.id);
			if (active_id > id) {
				obj.isComplete = true;
				obj.isActive = false;
			} else if (active_id === id) {
				obj.isComplete = false;
				obj.isActive = true;
			} else {
				obj.isComplete = false;
				obj.isActive = false;
			}
		});
		return trackerData;
	}

	render() {
		const cardData = this.props.data;
		const cardType = this.props.data.type;
		return (
			<div>
				<div className={`${constStyles.fullClass} ${cardType}`}>
					<div className={constStyles.fullClassHead}>
						<span>{cardData.title}</span>
						<span>{cardData.date_value ? cardData.date_value : ''}</span>
						<div className={constStyles.clearClass} />
					</div>
					<div className={constStyles.fullClassOD}>
						<div className={constStyles.fullClassL}>
							<div>
								<p>{cardData.address}</p>
							</div>
							<div>
								<h6>{cardData.date_data ? cardData.date_data.heading : ''}</h6>
								<h3>{cardData.date_data ? cardData.date_data.value : ''}</h3>
							</div>
						</div>
						<div id={cardType} className={constStyles.fullClassL}>
							<div>
								<h6 className={constStyles.marginReset}>
									{cardData.product_data ? `${cardData.product_data.heading} :` : ''}
								</h6>
								<h3>{cardData.product_data ? cardData.product_data.value : ''}</h3>
							</div>
							<div>
								<h6>{cardData.order_ref ? `${cardData.order_ref.heading} :` : ''}</h6>
								<h3>{cardData.order_ref ? cardData.order_ref.value : ''}</h3>
							</div>
						</div>
						<div className={constStyles.fullClassR}>{this.state.commonOrderDetails}</div>
					</div>
					<div className={constStyles.fullClassStep}>
						<h2>{cardData.step_tracker_title}:</h2>
						<div>
							<StepTracker data={this.setStepTrackerData(this.props.data.stepTrackerData)} />
						</div>
					</div>
				</div>
			</div>
		);
	}
}

priorityCardsFullSteps.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		title: PropTypes.string.isRequired,
		address: PropTypes.string.isRequired,
		step_tracker_title: PropTypes.string.isRequired,
		date_data: PropTypes.shape({
			heading: PropTypes.string.isRequired,
			value: PropTypes.string.isRequired
		}),
		order_details: PropTypes.arrayOf(
			PropTypes.shape({
				name: PropTypes.string.isRequired,
				description: PropTypes.string.isRequired
			})
		),
		trackerType: PropTypes.string.isRequired,
		stepTrackerData: PropTypes.shape({
			steptrackerlabel: PropTypes.arrayOf(
				PropTypes.shape({
					name: PropTypes.string.isRequired,
					stepNo: PropTypes.string.isRequired,
					isComplete: PropTypes.bool.isRequired,
					isActive: PropTypes.bool.isRequired
				})
			),
			orderTrackerData: PropTypes.arrayOf(
				PropTypes.shape({
					name: PropTypes.string.isRequired,
					isComplete: PropTypes.bool.isRequired,
					isActive: PropTypes.bool.isRequired,
					icon: PropTypes.string.isRequired
				})
			),
			stepImplementation: PropTypes.func
		})
	}).isRequired
};

priorityCardsFullSteps.defaultProps = {
	data: defaultData.card6
};

export default priorityCardsFullSteps;
