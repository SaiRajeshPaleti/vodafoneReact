import React from 'react';
import Icon from 'vf-ent-ws-svgicons';

export default (props) => {
	return (
	props.data.noteList.map((note, index)=>(
	<div>
		<div className="pcIT">
			<div className="pcIcon">
				<span>
					<Icon name={props.data.iconName} />
				</span>
			</div>
			<div className="pcDesc">
				<span>{note.text}</span>
			</div>
			<div className="pcText">
				<span>{note.date}</span>
			</div>
			<div style={{ clear: 'both', float: 'none' }} />
		</div>
		<br/>
		<br/>
		</div>
		))
	);
};
