import React from 'react';
import { constStyles, defaultData } from './priorityCardsDefData-Props';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';

class priorityCardsFullTitle extends BaseComponent {
	constructor(props) {
		super(props);
		this.setCardData = this.setCardData.bind(this);
		this.setCardData(props);
		this.state = {
			commonAddressBody: this.commonAddressBody,
			commonCardFooter: this.commonCardFooter
		};
	}

	componentWillReceiveProps(nextProps) {
		this.setCardData(nextProps);
		this.setState({
			commonAddressBody: this.commonAddressBody,
			commonCardFooter: this.commonCardFooter
		});
	}

	setCardData(props) {
		this.commonAddressBody = props.data.content.body.map((data, index) => {
			return (
				<div className={constStyles.priorityCardRow}>
					<div key={index} className={constStyles.PriorityCardContent}>
						<strong>{data.name}</strong>
						<address>{data.description}</address>
					</div>
				</div>
			);
		});
		this.commonCardFooter =
			props.data.content.dataFooter.length > 0 &&
			props.data.content.dataFooter.map((data, index) => {
				return (
					<div key={index}>
						<span>{data.name}</span>
						<span>{data.description}</span>
					</div>
				);
			});
	}

	render() {
		const cardData = this.props.data;
		return (
			<div className={constStyles.card_section}>
				<div className={`${constStyles.fullClass} ${cardData.type} ${cardData.className}`}>
					<div className={constStyles.fullClassHead}>
						{cardData.displayIcon && (
							<span className={constStyles.svgClassDelete} onClick={() => cardData.onClick(cardData.id)}>
								<Icon className={constStyles.iconClass} name={constStyles.svgClassDelete} />
							</span>
						)}
						<span>{cardData.title}</span>
						<span>{cardData.additional_title}</span>
					</div>
					<div className={constStyles.fullClassAdr}>{this.state.commonAddressBody}</div>
				</div>
				{this.commonCardFooter && <div className={constStyles.fullClassFt}>{this.state.commonCardFooter}</div>}
			</div>
		);
	}
}

priorityCardsFullTitle.propTypes = {
	data: PropTypes.shape({
		title: PropTypes.string.isRequired,
		additional_title: PropTypes.string,
		type: PropTypes.string.isRequired,
		content: PropTypes.shape({
			body: PropTypes.arrayOf(
				PropTypes.shape({
					name: PropTypes.string.isRequired,
					description: PropTypes.string.isRequired
				})
			),
			dataFooter: PropTypes.arrayOf(
				PropTypes.shape({
					name: PropTypes.string.isRequired,
					description: PropTypes.string.isRequired
				})
			)
		})
	}).isRequired
};

priorityCardsFullTitle.defaultProps = {
	data: defaultData.card3
};

export default priorityCardsFullTitle;
