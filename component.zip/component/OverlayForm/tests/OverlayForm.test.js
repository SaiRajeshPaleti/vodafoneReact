import React from 'react';
import OverlayForm from '../OverlayForm';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import OverlayFormData from '../../../AppData/OverlayFormData';

Enzyme.configure({ adapter: new Adapter() });

describe('Ancillary Overlay', function() {
	let enzymeWrapper;

	beforeEach(() => {
		enzymeWrapper = mount(<OverlayForm overlayContent={OverlayFormData} />);
	});

	it('checks the modal count', () => {
		expect(enzymeWrapper.find('#openModal').length).toEqual(OverlayFormData.childList.length);
	});

	it('checks if value is mapped', () => {
		expect(enzymeWrapper.find('.spring').length).toBeGreaterThan(0);
	});
});
