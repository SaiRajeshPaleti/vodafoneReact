export const defaultData = {
	show: true,
	index: 0,
	childList: [
		{
			type: 'Generic',
			text: 'Are you sure?',
			leftButton: 'cancelBtn',
			rightButton: 'deleteBtn',
			leftHandler: () => {},
			rightHandler: () => {},
			data: [
				{
					type: 'StaticText',
					body: {
						className: 'nextLine',
						data: 'You are about to permanently delete this message.'
					}
				}
			]
		}
	],
	buttondata: {
		deleteBtn: {
			id: 'primary',
			name: 'Delete',
			type: 'primary',
			buttonType: 'button'
		},

		cancelBtn: {
			id: 'secondary',
			name: 'Cancel',
			type: 'secondary',
			buttonType: 'reset'
		}
	},
	tooltip: 'Click Here to Close'
};
