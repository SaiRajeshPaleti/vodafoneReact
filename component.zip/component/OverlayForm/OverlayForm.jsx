import React from 'react';
import Overlay from 'vf-ent-ws-overlay';
import PropTypes from 'prop-types';
import { defaultData } from './OverlayFormDefData-Props';
import BaseComponent from 'vf-ent-ws-utilities';

class OverlayForm extends BaseComponent {
	render() {
		return (
			<div>
				{this.props.data.childList.map((content, index) => {
					return <Child key={index} data={this.props.data} index={index} />;
				})}
			</div>
		);
	}
}

class Child extends BaseComponent {
	constructor(props) {
		super(props);
		this.flag = this.flag.bind(this);
		this.state = { show: false };
	}
	flag = () => {
		this.setState({ show: !this.state.show });
	};
	render() {
		return (
			<React.Fragment>
				<div onClick={this.flag}> {this.props.data.childList[this.props.index].type} </div>
				<Overlay
					index={this.props.index}
					data={Object.assign({}, this.props.data, {
						show: this.state.show,
						index: this.props.index
					})}
				/>
			</React.Fragment>
		);
	}
}

OverlayForm.propTypes = {
	data: PropTypes.shape({
		show: PropTypes.bool.isRequired,
		index: PropTypes.number,
		childList: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string,
				name: PropTypes.string,
				type: PropTypes.string.isRequired,
				text: PropTypes.string.isRequired,
				leftButton: PropTypes.string.isRequired,
				rightButton: PropTypes.string.isRequired,
				leftHandler: PropTypes.func,
				rightHandler: PropTypes.func,
				data: PropTypes.arrayOf(
					PropTypes.shape({
						type: PropTypes.string.isRequired,
						body: PropTypes.shape({
							className: PropTypes.string,
							data: PropTypes.string
						})
					})
				)
			})
		),
		buttondata: PropTypes.shape({
			deleteBtn: PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				type: PropTypes.string.isRequired,
				buttonType: PropTypes.string.isRequired
			}),

			cancelBtn: PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				type: PropTypes.string.isRequired,
				buttonType: PropTypes.string.isRequired
			})
		}),
		tooltip: PropTypes.string
	})
};

OverlayForm.defaultProps = {
	data: defaultData
};

export default OverlayForm;
