import React, { PureComponent } from 'react';
import { constStyles } from './noServiceDefData-Props';
import './noService.css';
import Icon from 'vf-ent-ws-svgicons';

export default class NoService extends PureComponent {
	render() {
		return (
			<div className={constStyles.noService}>
				<span class={constStyles.iconClass}>
					<Icon name={this.props.data.noCountIcon} />
				</span>
				<div class={constStyles.noServiceText}>
					<div>{this.props.data.noRecordsTxt}</div>
				</div>
			</div>
		);
	}
}
