export const constStyles = {
	iconClass: 'sprite__icon',
	noService: 'noService',
	noServiceText: 'noServiceText'
};
