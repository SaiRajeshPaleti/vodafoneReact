export const defaultStyles = {
	cusDropDown: 'filtering__dropdown dropdown customDropdown mob_excel_dropdown',
	inactiveCls: 'filtering__dropdown--button dropdown__button dropdown__button',
	activeCls: 'filtering__dropdown--button dropdown__button dropdown__button active',
	heading: 'dropdown__heading f__left',
	headlingLight: 'dropdown__heading--light',
	Sprite: 'sprite__icon down_arrow',
	activeRelativeCls: 'dropdown__panel p__relative display_block',
	listRest: 'list list--reset p-l-20',
	display_none: 'display_none',
	test: 'test',
	liTest: 'litest',
	iconName: 'chevron-down'
};

export const constData = {
	dropDownContentType: {
		radioType: 'radio',
		checkType: 'checkbox'
	}
};

export const defaultData = {
	id: 'dropdownButton',
	name: 'dropdownButton',
	dropDownButtonType: 'checkbox',
	clickTxt: 'Click me',
	title: 'Click Here',
	checkedElements: () => {
		//console.log(e);
	},
	dropdownButtonValues: [
		{
			id: 'check1',
			name: 'checkbox',
			tooltip: 'Click on CheckBox to select',
			displayValue: 'Sample 1'
		},
		{
			id: 'check2',
			name: 'checkbox',
			tooltip: 'Click on CheckBox to select',
			displayValue: 'Sample 2'
		}
	]
};
