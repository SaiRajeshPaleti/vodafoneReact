import React, { PureComponent } from 'react';
import { defaultStyles, defaultData, constData } from './DropDownButtonDefData-Props';
import './DropDownButton.css';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import RadioButton from 'vf-ent-ws-radiobutton';
import CheckBox from 'vf-ent-ws-checkbox';
import BaseComponent from 'vf-ent-ws-utilities';

class DropDownButtons extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			arrowIcon: true
		};
		this.dropDown = this.dropDown.bind(this);
		this.checkFn = this.checkFn.bind(this);
		this.loadInit = this.loadInit.bind(this);
		this.loadContent = this.loadContent.bind(this);
		this.returnValue = new Array(this.props.data.dropdownButtonValues.length);
		this.returnValue.fill(false);
	}
	componentWillMount() {
		this.init = this.loadInit();
	}
	componentWillUpdate() {
		this.content = this.loadContent();
	}

	dropDown() {
		this.setState({ arrowIcon: !this.state.arrowIcon });
	}

	checkFn(e) {
		this.returnValue[e.id - 1] = e.value;
		this.props.data.checkedElements(this.returnValue);
	}

	loadInit() {
		return <DropInit data={this.props.data} arrowIcon={this.state.arrowIcon} dropDown={this.dropDown} />;
	}
	loadContent() {
		return <DropContent data={this.props.data} arrowIcon={this.state.arrowIcon} checkFn={this.checkFn} />;
	}

	render() {
		return (
			<div id={this.props.data.id} name={this.props.data.name} className={defaultStyles.cusDropDown}>
				{this.init}
				{this.content}
			</div>
		);
	}
}

const DropInit = ({ data, arrowIcon, dropDown }) => (
	<div
		className={arrowIcon ? defaultStyles.activeCls : defaultStyles.inactiveCls}
		title={data.title}
		onClick={dropDown}
	>
		<div className={defaultStyles.heading}>
			<span>{data.clickTxt}</span>
		</div>
		<span className={defaultStyles.Sprite}>
			<Icon name={defaultStyles.iconName} />
		</span>
	</div>
);

const DropContent = ({ data, arrowIcon, checkFn }) => (
	<div className={arrowIcon ? defaultStyles.activeRelativeCls : defaultStyles.display_none}>
		<ul className={defaultStyles.listRest}>
			{data.dropdownButtonValues.map((dropDownData) => (
				<li key={dropDownData.id}>
					{data.dropDownButtonType === constData.dropDownContentType.radioType ? (
						<RadioButton data={Object.assign({}, dropDownData, { onChange: checkFn })} />
					) : data.dropDownButtonType === constData.dropDownContentType.checkType ? (
						<CheckBox data={Object.assign({}, dropDownData, { onChange: checkFn })} />
					) : (
						''
					)}
				</li>
			))}
		</ul>
	</div>
);

DropDownButtons.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		name: PropTypes.string,
		dropDownButtonType: PropTypes.string,
		clickTxt: PropTypes.string,
		title: PropTypes.string,
		checkedElements: PropTypes.func,
		dropdownButtonValues: PropTypes.arrayOf(
			PropTypes.shape({
				name: PropTypes.string.isRequired,
				id: PropTypes.string.isRequired,
				checked: PropTypes.bool,
				tooltip: PropTypes.string,
				displayValue: PropTypes.string
			})
		)
	})
};

DropDownButtons.defaultProps = {
	data: defaultData
};

export default DropDownButtons;
