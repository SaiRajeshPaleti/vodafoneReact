import React from 'react';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import TextArea from './../TextArea'
import TextAreaComponent from './../textAreaComponent';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<TextAreaComponent />', function () {
			let props, enzymeWrapper;
			props = {
				data: {
					id: 'textarea1',
					name: 'Description',
					rows: 5,
					label: 'Notes',
					//maxLength: 20,
					//value: 'sss',
					title: 'Please enter the description',
					placeholder: 'Enter Some Text',
					label_header_left: {
						labelname: 'Notes',
						isRequired: true,
						type: 'labelDefault',
						isInline: true,
						fontSizeType: 'lg'
					},
					label_header_right: {
						labelname: '',
						type: 'labelDefault',
						isInline: true,
						fontSizeType: 'lg'
					},
					label_helper: {
						labelname: 'You can enter  +, (), /, space and – special characters',
						type: 'labelDefault',
						fontSizeType: 'sm'
					},
					onChange: (value) => console.log('teaxtarea value:', value)
				},
				value: 12,
				onDataChange: () => {
					console.log('test');
				}
			};

		beforeEach(() => {
				enzymeWrapper = shallow( <TextAreaComponent { ...props }
					/>);
				});

			it('should render TextArea component', () => {
				expect(enzymeWrapper).not.toBe(null);
			}); 
			it('should render componentWillReceiveProps component', () => {
				enzymeWrapper.instance().componentWillReceiveProps(props);
			}); 
			it('should render handleChange component', () => {
				const event = {
					target: {
						value: 'click'
					}
				}
				enzymeWrapper.instance().handleChange(event);
			}); 

});

describe('<TextArea />', function () {
	let props, enzymeWrapper;
	props = {
		data: {
			id: 'textarea1',
			name: 'Description',
			rows: 5,
			label: 'Notes',
			//maxLength: 20,
			//value: 'sss',
			title: 'Please enter the description',
			placeholder: 'Enter Some Text',
			label_header_left: {
				labelname: 'Notes',
				isRequired: true,
				type: 'labelDefault',
				isInline: true,
				fontSizeType: 'lg'
			},
			label_header_right: {
				labelname: '',
				type: 'labelDefault',
				isInline: true,
				fontSizeType: 'lg'
			},
			label_helper: {
				labelname: 'You can enter  +, (), /, space and – special characters',
				type: 'labelDefault',
				fontSizeType: 'sm'
			},
			onChange: (value) => console.log('teaxtarea value:', value)
		},
		value: 12,
		onDataChange: () => {
			console.log('test');
		}
	};

	beforeEach(() => {
		enzymeWrapper = shallow( <TextArea { ...props }
			/>);
		});

	it('should render TextArea component', () => {
		expect(enzymeWrapper).not.toBe(null);
	});
});