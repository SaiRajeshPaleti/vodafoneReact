import React from 'react';
import PropTypes from 'prop-types';
import { constStyles } from './textAreaDefData-Props';

const TextArea = (props) => {
	return (
		<div>
			<textarea
				id={props.data.id}
				title={props.data.title}
				name={props.data.name}
				className={constStyles.textAreaClass}
				rows={props.data.rows}
				value={props.value}
				maxLength={props.data.maxLength}
				onChange={props.onDataChange}
				placeholder={props.data.placeholder}
			/>
		</div>
	);
};

TextArea.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string.isRequired,
		title: PropTypes.string,
		name: PropTypes.string,
		placeholder: PropTypes.string,
		rows: PropTypes.number,
		maxLength: PropTypes.number
	})
};

export default TextArea;
