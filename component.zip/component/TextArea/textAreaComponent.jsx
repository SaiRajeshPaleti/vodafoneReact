import React from 'react';
import './textarea.css';
import { constStyles, constData, defaultData } from './textAreaDefData-Props';
import PropTypes from 'prop-types';
import TextArea from './textArea';
import Label from 'vf-ent-ws-label';
import BaseComponent from 'vf-ent-ws-utilities';

class TextAreaComponent extends BaseComponent {
	constructor(props) {
		super(props);
		this.handleChange = this.handleChange.bind(this);
	}

	componentWillMount() {
		this.checkForOptionalProps(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.checkForOptionalProps(nextProps);
	}

	checkForOptionalProps(props) {
		this.LabelComponent = props.data.label_helper ? <Label data={this.props.data.label_helper} /> : '';

		this.setState({
			charLength: props.data.value ? props.data.maxLength - props.data.value.length : props.data.maxLength,
			value: props.data.value ? props.data.value : ''
		});
	}

	handleChange(event) {
		this.setState({
			charLength: this.props.data.maxLength && this.props.data.maxLength - event.target.value.length,
			value: event.target.value
		});
		this.delegateHandler(constData.propsProperty, event, constData.eventProperty);
	}

	render() {
		return (
			<div>
				<div className={constStyles.divClass}>
					<div className={constStyles.labelClass}>
						<span className={constStyles.labelTxtClass}>
							<Label data={this.props.data.label_header_left} />
						</span>
						<span className={constStyles.maxLengthSpanClass}>
							{this.state.charLength}
							{constStyles.spacing}
							<Label data={this.props.data.label_header_right} />
						</span>
					</div>
					<TextArea onDataChange={this.handleChange} value={this.state.value} {...this.props} />
					{this.LabelComponent}
				</div>
			</div>
		);
	}
}

TextAreaComponent.defaultProps = {
	data: defaultData
};

TextAreaComponent.propTypes = {
	data: PropTypes.shape({
		label_header_left: PropTypes.shape({
			labelname: PropTypes.string.isRequired,
			type: PropTypes.string.isRequired,
			isInline: PropTypes.bool.isRequired,
			fontSizeType: PropTypes.string
		}).isRequired,
		label_header_right: PropTypes.shape({
			labelname: PropTypes.string.isRequired,
			type: PropTypes.string.isRequired,
			isInline: PropTypes.bool.isRequired,
			fontSizeType: PropTypes.string
		}).isRequired,
		label_helper: PropTypes.shape({
			labelname: PropTypes.string.isRequired,
			type: PropTypes.string.isRequired,
			fontSizeType: PropTypes.string
		}),
		maxLength: PropTypes.number,
		value: PropTypes.oneOfType([ PropTypes.string, PropTypes.number ]),
		onChange: PropTypes.func
	})
};

export default TextAreaComponent;
