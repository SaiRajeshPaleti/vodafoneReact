export const constStyles = {
	textAreaId: 'comment',
	// divClass:"p-0 grid__item grid__item--gutter grid__item--md-1/1 grid__item--1/2 form-small--bottom",
	labelClass: 'dblock',
	labelTxtClass: 'hover-labels d-block',
	maxLengthSpanClass: 'characters-left',
	textAreaClass: 'form-control description-height',
	helperLabel: 'helperLabel',
	spacing: ' '
};

export const constData = {
	propsProperty: 'onChange',
	eventProperty: 'value'
};

export const defaultData = {
	id: 'textarea',
	name: 'Description',
	rows: 5,
	label: 'Notes',
	maxLength: 4000,
	title: 'Please enter the description',
	placeholder: 'This is sample text',
	label_helper: {
		labelname: 'You can enter  +, (), /, space and – special characters',
		type: 'labelDefault',
		fontSizeType: 'sm'
	},
	label_header_left: {
		labelname: 'Notes',
		type: 'labelDefault',
		isInline: true,
		fontSizeType: 'lg'
	},
	label_header_right: {
		labelname: 'characters left',
		type: 'labelDefault',
		isInline: true,
		fontSizeType: 'lg'
	}
}