export const constBtnStyles = {
	globalButtons: 'global_buttons',
	primary: 'button button--primary',
	secondary: 'button button--secondary',
	tertiary: 'button button--tertiary',
	buttonActive:'button button--tertiary selected_active',
	transparent: 'button button--transparent',
	tabbedActive: 'button button--tertiary button--secondary',
	btnInside: 'button-inside'
};

export const constBtnIconStyle = {
	right: {
		btnClass: 'button button--primary',
		spanClass: 'sprite__icon chevron-right-arrow',
		btnIcon: 'chevron-right'
	},
	left: {
		btnClass: 'button button--secondary',
		spanClass: 'sprite__icon chevron-left-arrow',
		btnIcon: 'chevron-left'
	},
	lefttick: {
		btnClass: 'button button--secondary',
		spanClass: 'sprite__icon chevron-left-arrow',
		btnIcon: 'tick'
	}
};
export const constData = {
	propsProperty: 'onClick',
	eventProperty: ''
};

export const defaultData = {
	id: 'primary',
	name: 'Primary button',
	type: 'primary',
	buttonType: 'button',
	onClick: () => {
		console.log('clicked');
	}
};
