import React from 'react';
import Button from '../button';
import renderer from 'react-test-renderer';
import {
	shallow,
	mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ButtonData from '../../../AppData/buttonData';
Enzyme.configure({
	adapter: new Adapter()
});

describe('<Button/>', function () {
			let props, enzymeWrapper;

			beforeAll(() => {
					props = ButtonData;
					enzymeWrapper = shallow( < Button data = {
							props[0]
						}
						/>);
					});

				it('Button Component contains  div', () => {
					expect(enzymeWrapper.find('button').length).toBe(1);
				});

				// it('identify that div contains button', () => {
				// 	expect(enzymeWrapper.find('div').childAt(0).type()).toBe('button');
				// });

				it('event handler to be called on clicking button', () => {
					let button = enzymeWrapper.find('button');
					button.simulate('click');
					expect(props.onClick).toHaveBeenCalled;
				});

				it('lifecyle method to be invoked when props value changes', () => {
					enzymeWrapper.instance().componentWillReceiveProps(props);
				});

				it('method to be invoked to check the values', () => {
					enzymeWrapper.instance().checkDirection('right','right');
				});

				it('method to be invoked to return a button with icon', () => {
					enzymeWrapper.instance().buttonWithIcon(props.data);
				});

				it('method to be invoked to return button style', () => {
					enzymeWrapper.instance().buttonWithIcon('right');
				});

			});