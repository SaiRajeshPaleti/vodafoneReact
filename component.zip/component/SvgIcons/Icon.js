import React from 'react';
import Icons from './icons.svg';
import './svg.css';

const Icon = (props) => (
	<svg key={Math.random()} className={`icon icon-${props.name}`}>
		<use xlinkHref={`${Icons}#${props.name}`} />
		{console.log(`${Icons}#${props.name}`)}
	</svg>
);

export default Icon;
