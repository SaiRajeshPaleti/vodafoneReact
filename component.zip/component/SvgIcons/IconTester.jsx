import React, { PureComponent } from 'react';
import iconDefaultData from '../../AppData/iconsData';
import Icon from 'vf-ent-ws-svgicons';
//import Icon from '../SVG/SVGIcon';
// import Icon from '../SvgIcons/Icon';

class IconTester extends PureComponent {
	render() {
		// console.log("this.state.fieldsData inside render --"+JSON.stringify(this.state))
		return <div>{iconDefaultData.data.map((data, index) => <Icon {...data} />)}</div>;
	}
}

export default IconTester;
