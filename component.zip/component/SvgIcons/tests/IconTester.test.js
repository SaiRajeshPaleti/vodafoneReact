import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import IconTester from '../IconTester'
import iconsData from '../../../AppData/iconsData';
Enzyme.configure({ adapter: new Adapter() });

describe('<IconTester />', function () {
	const props = iconsData;
	let wrapper;
	beforeEach(() => {
		wrapper = mount(
			<IconTester data ={iconsData}/>
		);
	});
	
	it('IconTester functional component', () => {
		wrapper.instance().componentWillReceiveProps(props);
	});

	it('IconTester click handler event ', () => {
		let headclick = wrapper.find('.accordion__heading').simulate('click');
		expect(IconTester.toggleClick).toHaveBeenCalled;
	});
	
});
