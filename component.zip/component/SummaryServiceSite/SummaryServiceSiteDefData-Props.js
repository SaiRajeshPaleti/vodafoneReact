export const constStyles = {
	containerDiv: 'wholesale_ipvpn_panel',
	head: 'panel_head',
	content: 'panel_state',
	col: 'panel',
	col_bg: 'panel_bg',
	col_actions: 'panel_actions',
	delete_icon_name: 'icon-delete',
	delete_icon: 'sprite__icon delete display_block',
	edit_icon_name: 'edit',
	edit_icon: 'sprite__icon edit'
};
