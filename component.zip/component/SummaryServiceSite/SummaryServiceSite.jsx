import React from 'react';
import './SummaryServiceSite.css';
import { constStyles } from './SummaryServiceSiteDefData-Props';
//import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
//import Icon from './../SvgIcons/Icon';
import BaseComponent from 'vf-ent-ws-utilities';

export default class SummaryServiceSite extends BaseComponent {
	constructor(props) {
		super(props);
		this.onDeleteClick = this.onDeleteClick.bind(this);
		this.onEditClick = this.onEditClick.bind(this);
	}

	componentWillMount() {
		console.log(this.props);
	}

	componentWillReceiveProps(nextProps) {}
	onDeleteClick(params) {
		console.log('params', params);
		this.props.data.deleteSite(this.props.data.id);
	}
	onEditClick() {
		this.props.data.editSite(this.props.data.id);
	}

	render() {
		const serviceSiteData = this.props.data;
		return (
			<div className={constStyles.containerDiv}>
				<div className={constStyles.col}>
					<p className={constStyles.head}>{serviceSiteData.bearerSpeed.title}</p>
					<p className={constStyles.content}>{serviceSiteData.bearerSpeed.speed}</p>
				</div>
				<div className={constStyles.col}>
					<p className={constStyles.head}>{serviceSiteData.accessType.title}</p>
					<p className={constStyles.content}>{serviceSiteData.accessType.type}</p>
				</div>
				<div className={`${constStyles.col} ${constStyles.col_bg}`}>
					<p className={constStyles.head}>{serviceSiteData.siteAddress.title}</p>
					<p className={constStyles.content}>{serviceSiteData.siteAddress.address}</p>
				</div>
				<div className={`${constStyles.col} ${constStyles.col_actions}`}>
					<p className={constStyles.delete_icon} onClick={this.onDeleteClick}>
						<Icon name={constStyles.delete_icon_name} />
					</p>
					<p className={constStyles.edit_icon} onClick={this.onEditClick}>
						<Icon name={constStyles.edit_icon_name} />
					</p>
				</div>
			</div>
		);
	}
}
