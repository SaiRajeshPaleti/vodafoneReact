import React from 'react';
import { constStyles } from './LabelDefData-Props';

export const CommonLabel = (props) => {
	const fontClass = props.data.fontSizeType ? constStyles.textSize[props.data.fontSizeType] : '';
	const helperFontClass = props.helperFontClass ? props.helperFontClass : '';
	const applicableClass = props.data.className ? props.data.styling : `${props.styling} ${fontClass} ${helperFontClass}`;
	const isRequired = props.data.isRequired ? <span className={constStyles.labelRequired}>*</span> : '';
	const isInline = props.data.isInline ? constStyles.labelInlineTrue : constStyles.labelInlineFalse;

	return (
		<div style={{ display: isInline }} className={props.wrapperStyling}>
			<label id={props.data.id} htmlFor={props.data.htmlFor} className={applicableClass}>
				{props.data.labelname}

				{isRequired}
			</label>
		</div>
	);
};

export const LabelDefault = (props) => {
	const styling = constStyles.labelCommon;
	return <CommonLabel styling={styling} {...props} />;
};

export const LabelHelperLightXS = (props) => {
	const styling = `${constStyles.labelCommon} ${constStyles.labelLight}`;
	return <CommonLabel helperFontClass={ constStyles.textSize["xs"]} styling={styling} {...props} />;
};

export const LabelHelperLightSM = (props) => {
	const styling = `${constStyles.labelCommon} ${constStyles.labelLight}`;
	return <CommonLabel helperFontClass={ constStyles.textSize["sm"]} styling={styling} {...props} />;
};

export const LabelHelperDarkXS = (props) => {
	const styling = constStyles.labelCommon;
	return <CommonLabel helperFontClass={ constStyles.textSize["xs"]} styling={styling} {...props} />;
};

export const LabelHelperDarkSM = (props) => {
	const styling = constStyles.labelCommon;
	return <CommonLabel helperFontClass={ constStyles.textSize["sm"]} styling={styling} {...props} />;
};

export const LabelCenter = (props) => {
	const styling = constStyles.labelCommon;
	const wrapperStyling = constStyles.labelCenter;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelRight = (props) => {
	const styling = constStyles.labelCommon;
	const wrapperStyling = constStyles.labelRight;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelRequiredDefault = (props) => {
	const styling = constStyles.labelCommon;
	return (
		<div>
			<CommonLabel styling={styling} {...props} />
		</div>
	);
};

export const LabelRequiredCenter = (props) => {
	const styling = constStyles.labelCommon;
	const wrapperStyling = constStyles.labelCenter;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelRequiredRight = (props) => {
	const styling = constStyles.labelCommon;
	const wrapperStyling = constStyles.labelRight;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelHeadingDefault = (props) => {
	const styling = constStyles.labelHeading;
	const wrapperStyling = constStyles.labelBorder;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelHeadingCenter = (props) => {
	const styling = constStyles.labelHeading;
	const wrapperStyling = `${constStyles.labelBorder} " " ${constStyles.labelCenter}`;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};
export const LineNoMargin = (props) => {
	const styling = constStyles.labelHeading;
	const wrapperStyling = `${constStyles.labelBorderNoPadding}`;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelHeadingRight = (props) => {
	const styling = constStyles.labelHeading;
	const wrapperStyling = `${constStyles.labelBorder} " " ${constStyles.labelRight}`;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelHeadingNBDefault = (props) => {
	const styling = constStyles.labelHeading;
	return (
		<div>
			<CommonLabel styling={styling} {...props} />
		</div>
	);
};

export const LabelHeadingNBCenter = (props) => {
	const styling = constStyles.labelHeading;
	const wrapperStyling = constStyles.labelCenter;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

export const LabelHeadingNBRight = (props) => {
	const styling = constStyles.labelHeading;
	const wrapperStyling = constStyles.labelRight;
	return (
		<div>
			<CommonLabel wrapperStyling={wrapperStyling} styling={styling} {...props} />
		</div>
	);
};

