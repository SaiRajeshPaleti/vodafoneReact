import React from 'react';
import { getContent } from './LabelRegistry';

const LabelComponentFactory = (labelData) => {
	const ComponentContent = getContent(labelData.type);
	return <ComponentContent data={labelData} />;
};
export default LabelComponentFactory;
