export const constStyles = {
    labelCommon: 'vf-label-common',
    labelLight: 'vf-label-light',
    labelCenter: 'vf-label-center',
    labelRight: 'vf-label-right',
    labelRequired: 'vf-label-required',
    labelHeading: 'vf-label-common vf-heading',
    labelBorder: 'vf-heading-border vf-label-padding',
	labelBorderNoPadding: 'vf-heading-border',
    labelInlineTrue: 'inline-block',
    labelInlineFalse: 'block',
    labelTypes: ['labelHelperLightXS', 'labelHelperLightSM', 'labelHelperDarkXS', 'labelHelperDarkSM', 'labelDefault', 'labelCenter', 'labelRight', 'labelRequiredDefault', 'labelRequiredCenter', 'labelRequiredRight', 'labelHeadingDefault', 'labelHeadingCenter',  'labelHeadingRight'],
    textSize: {
        xs: 'vf-label-xs',
        sm: 'vf-label-sm',
        md: 'vf-label-md',
        lg: 'vf-label-lg',
        xl: 'vf-label-sm'
    }
};
export const defaultData = {
    id: 'label1',
    type: 'labelDefault',
    htmlFor: 'sample',
    labelname: 'Sample Name'
};
