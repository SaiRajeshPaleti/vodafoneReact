import React from 'react';
import paginationStyles from './PaginationDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

export default class Content extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			leftArrowClass: '',
			rightArrowClass: ''
		};
	}
	componentWillMount() {
		var c;
		this.props.data.currentPage > 1 ? (c = 1) : (c = 0);
		this.setClassName(this.props, c);
	}
	setClassName(props, status) {
		const leftArrowClass =
			props.data.currentPage <= 1
				? paginationStyles.constStyles.linkDisabaled
				: paginationStyles.constStyles.paginationLink;
		const rightArrowClass =
			props.data.currentPage >= props.data.totalPages
				? paginationStyles.constStyles.linkDisabaled
				: paginationStyles.constStyles.paginationLink;
		const prevPageClick = this.props.data.prevPageClick;

		this.setState({
			leftArrowClass,
			rightArrowClass,
			prevPageClick: status === 1 ? prevPageClick : () => {}
		});
	}
	componentWillReceiveProps(nextProps) {
		var c;
		nextProps.data.currentPage > 1 ? (c = 1) : (c = 0);
		this.setClassName(nextProps, c);
	}

	render() {
		const { constData, defaultStyles, constStyles } = paginationStyles;
		return (
			<React.Fragment>
				<a className={this.state.leftArrowClass}>
					<span className={constStyles.hiddenCls}>{constData.previous_page}</span>
					<span className={defaultStyles.Iconclass} onClick={this.state.prevPageClick}>
						<Icon name={defaultStyles.left_icon} />
					</span>
				</a>
				<p className={constStyles.paginationInfo}>
					<input
						type="text"
						className={constStyles.currPagination}
						value={this.props.data.currentPage}
						onChange={(event) => this.delegateHandler(constData.onChange, event, constData.value)}
					/>

					<span className={constStyles.paginationOf}>{constData.of_text}</span>
					<span>{this.props.data.totalPages}</span>
				</p>
				<a className={this.state.rightArrowClass}>
					<span className={constStyles.hiddenCls}>{constData.next_page}</span>
					<span className={defaultStyles.Iconclass} onClick={this.props.data.nextPageClick}>
						<Icon name={defaultStyles.right_icon} />
					</span>
				</a>
			</React.Fragment>
		);
	}
}

Content.propTypes = {
	data: PropTypes.shape({
		nextPageClick: PropTypes.func.isRequired,
		prevPageClick: PropTypes.func.isRequired,
		currentPage: PropTypes.oneOfType[(String, Number)],
		onChange: PropTypes.func.isRequired,
		totalPages: PropTypes.number.isRequired
	}).isRequired
};
