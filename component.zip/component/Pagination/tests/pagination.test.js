import React from 'react';
import renderer from 'react-test-renderer';
import Pagination from '../Pagination';
import {
	shallow,
	mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import PaginationData from '../../../AppData/PaginationData';
Enzyme.configure({
	adapter: new Adapter()
});

describe('<Pagination />', function () {
			let props, enzymeWrapper;

			beforeEach(() => {

					enzymeWrapper = mount( < Pagination data = { PaginationData } />) 
			});

				it('should render the component', () => {
					expect(enzymeWrapper.find('nav').length).toBe(1);
				 }); 

				it('should render content component',() => {
					expect(enzymeWrapper.find('content')).toBeDefined;
				});

				it('should call nextPageClick handler',() => {
					const mockedEvent = { target: {} }							
					expect(enzymeWrapper.instance().nextPageClick(mockedEvent)).toHaveBeenCalled;		

				});
				it('should call prevPageClick handler',() => {
					const mockedEvent = { target: {} }							
					expect(enzymeWrapper.instance().prevPageClick(mockedEvent)).toHaveBeenCalled;		

				});
				it('should call onChange handler',() => {
					const mockedEvent = { target: {} }							
					expect(enzymeWrapper.instance().onChange(mockedEvent)).toHaveBeenCalled;		

				});
});