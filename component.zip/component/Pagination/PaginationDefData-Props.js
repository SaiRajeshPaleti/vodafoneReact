const paginationStyles = {
	constData: {
		previous_page: 'Previous page',
		of_text: 'of',
		next_page: 'Next page',
		onChange: 'onChange',
		value: 'value',
		getCurrentPage: 'getCurrentPage',
		nextPageClick: 'nextPageClick'
	},
	defaultStyles: {
		Iconclass: 'sprite__icon',
		left_icon: 'chevron-left',
		right_icon: 'chevron-right'
	},
	constStyles: {
		mainCls: 'search__section search__section--pagination',
		componentCls: 'js-component-component component__component',
		pagination: 'pagination',
		springCls: 'spring',
		paginationLink: 'pagination__link',
		linkDisabaled: 'pagination__link pagination__link--disabled',
		hiddenCls: 'visually-hidden',
		paginationInfo: 'no-gutter--top no-gutter--bottom pagination__info',
		currPagination: 'pagination__current',
		paginationOf: 'pagination__of'
	}
};

export default paginationStyles;
