import React from 'react';
import paginationStyles from './PaginationDefData-Props';
import './Pagination.css';
import PropTypes from 'prop-types';
import Content from './Content';
import BaseComponent from 'vf-ent-ws-utilities';

class Pagination extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			currentPage: this.props.data.pagenumber,
			totalNoPages: this.props.data.totalPages
		};
		this.prevPageClick = this.prevPageClick.bind(this);
		this.nextPageClick = this.nextPageClick.bind(this);
		this.onChange = this.onChange.bind(this);
		this.sendData = this.sendData.bind(this);
	}

	nextPageClick(event) {
		let paginationData = { ...this.state };
		let currPage = paginationData.currentPage;
		let totalPages = paginationData.totalNoPages;
		if (currPage >= 0 && currPage < totalPages) {
			currPage++;
			this.delegateHandler(paginationStyles.constData.getCurrentPage, currPage, this.sendData);
			this.setState({ currentPage: currPage });
		}
	}

	prevPageClick(event) {
		let paginationPrevData = { ...this.state };
		let currPagePrev = paginationPrevData.currentPage;
		let totalPages = paginationPrevData.totalNoPages;
		if (currPagePrev <= totalPages && currPagePrev >= 2) {
			currPagePrev = currPagePrev - 1;
			this.delegateHandler(paginationStyles.constData.getCurrentPage, currPagePrev, this.sendData);
			this.setState({ currentPage: currPagePrev });
		}
	}
	onChange(event) {
		this.delegateHandler(paginationStyles.constData.getCurrentPage, event.value, this.sendData);
		this.setState({ currentPage: event.value });
	}
	sendData(event) {
		return event;
	}
	render() {
		const PaginationData = {
			prevPageClick: this.prevPageClick,
			nextPageClick: this.nextPageClick,
			currentPage: this.state.currentPage,
			onChange: this.onChange,
			totalPages: this.state.totalNoPages
		};
		return (
			<div>
				<nav className={paginationStyles.constStyles.mainCls}>
					<div className={paginationStyles.constStyles.componentCls}>
						<div className={paginationStyles.constStyles.pagination}>
							<div className={paginationStyles.constStyles.springCls} />
							<Content data={PaginationData} />
						</div>
					</div>
				</nav>
			</div>
		);
	}
}

Pagination.propTypes = {
	data: PropTypes.shape({
		pagenumber: PropTypes.number.isRequired,
		totalPages: PropTypes.number.isRequired,
		getPaginationData: PropTypes.func
	}).isRequired
};

export default Pagination;
