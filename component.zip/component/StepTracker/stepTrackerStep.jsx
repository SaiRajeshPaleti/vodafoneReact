import React from 'react';
import './stepTracker.css';
import { constStyles } from './stepTrackerDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';
class StepTrackerStep extends BaseComponent{
	constructor(props) {
		super(props);
		let showLabel=props.tracker.isActive;
		this.state = { showLabel };
		this.handleMouseEnter = this.handleMouseEnter.bind(this);
		this.handleMouseLeave = this.handleMouseLeave.bind(this);
	}
	handleMouseEnter(e){
		this.setState({ showLabel:true });
	}
	handleMouseLeave(e){
		if(!this.props.tracker.isActive){
			let showLabel=false;
			this.setState({ showLabel});
		}

	}
	render() {
		let props=this.props;
		return (
			<div
				onClick={() => props.clickStep(props.index, props.tracker)}
				className={
					props.tracker.isComplete ? (
						constStyles.stepDone
					) : (
						`${props.tracker.isActive ? constStyles.activeStep : constStyles.untouchedStep}`
					)
				}
			>
				<div className={constStyles.stepperContainer}
				onMouseEnter={this.handleMouseEnter}
				onMouseLeave={this.handleMouseLeave}>
					{this.state.showLabel ? props.tracker.name : null}
					<div className={constStyles.circle}>
						<span className={props.tracker.isComplete ? constStyles.spriteIcon : null}>
							{props.tracker.isComplete ? <Icon name={constStyles.completeStepIcon} /> : props.tracker.stepNo}
						</span>
					</div>
				</div>
			</div>
		);
	}
};
export default StepTrackerStep;
export const StepTrackerLine = (props) => {
	return (
		<React.Fragment>
			{props.trackerType === 'stepTracker' ? (
				<div className={constStyles.lineWrapper}>
					<div className={constStyles.line} />
				</div>
			) : (
				''
			)}
		</React.Fragment>
	);
};
