import StepTrackerStep from './stepTrackerStep';
import StepTrackerOrderStep from './stepTrackerOrderStep';
const StepRegistry = {
	stepTracker: StepTrackerStep,
	orderTracker: StepTrackerOrderStep
};
export function getContent(type) {
	return StepRegistry[type];
}
