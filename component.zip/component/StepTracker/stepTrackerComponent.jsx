import React from 'react';
import './stepTracker.css';
import { constStyles, constData, defaultData } from './stepTrackerDefData-Props';
import PropTypes from 'prop-types';
import { StepTrackerLine } from './stepTrackerStep';

import StepComponentFactory from './StepComponentFactory';
import BaseComponent from 'vf-ent-ws-utilities';

class StepTracker extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = { childComponents: [] };
		this.clickStep = this.clickStep.bind(this);
	}
	dataPassing(obj) {
		return obj;
	}

	clickStep(index, step) {
		const stepClickData = {
			index: index,
			id: step.id,
			value: step.name
		};
		this.delegateHandler(constData.onClickProperty, stepClickData, this.dataPassing);
	}

	componentDidMount() {
		this.resetData(this.props.data);
	}

	resetData(data) {
		let components = [];
		data.data.map((tracker, index) =>
			components.push(StepComponentFactory(index, tracker, this.clickStep, data.type))
		);
		this.setState({ childComponents: components });
	}

	componentWillReceiveProps(nextProps) {
		this.resetData(nextProps.data);
	}

	render() {
		return (
			<div className={constStyles[this.props.data.type]}>
				<div className={constStyles.supportingText}>{this.state.childComponents}</div>
				<StepTrackerLine trackerType={this.props.data.type} />
			</div>
		);
	}
}
StepTracker.propTypes = PropTypes.oneOf([
	PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		type: PropTypes.string.isRequired,
		data: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				isComplete: PropTypes.bool.isRequired,
				isActive: PropTypes.bool.isRequired,
				stepNo: PropTypes.string.isRequired
			}).isRequired
		).isRequired
	}),
	PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		type: PropTypes.string.isRequired,
		data: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				isComplete: PropTypes.bool.isRequired,
				isActive: PropTypes.bool.isRequired,
				icon: PropTypes.string
			}).isRequired
		).isRequired
	}).isRequired
]).isRequired;

// StepTracker.defaultProps = {
// 	data: defaultData
// };
export default StepTracker;
