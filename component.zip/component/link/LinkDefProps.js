export const constStyles = {
	bodylinkAStyle: 'link link--body',
	darkbglinkAStyle: 'link link--dark',
	darkbgbodylinkAStyle: 'link link--body link--body--dark',
	stdlinkAStyle: 'link'
};
export const defaultData = {
	id: 'link',
	name: 'linkToClick',
	linkType: 'bodylink' /*stdlink  or bodylink or darkbglink  or darkbgbodylink or dark-bg*/,
	url: '#',
	label: 'link text'
};
