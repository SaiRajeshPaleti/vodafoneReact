import React from 'react';
import Link from '../Link';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import LinkData from '../../../AppData/LinkData';
Enzyme.configure({ adapter: new Adapter() });

describe('<Link />', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = LinkData;
		enzymeWrapper = shallow(<Link data={props} />);
	});

	it('Link  contains one div', () => {
		expect(enzymeWrapper.find('div').length).toBe(1);
	});
	it('identify that div contains 1 p tags', () => {
		expect(enzymeWrapper.find('p').length).toBe(1);
	});
	it('identify that p does not contain dark-bg class', () => {
		expect(enzymeWrapper.find('p').hasClass('dark-bg')).toEqual(false);
	});
	it('identify that div contains 1 a tags', () => {
		expect(enzymeWrapper.find('a').length).toBe(1);
	});
	it('identify that a contains link class', () => {
		expect(enzymeWrapper.find('a').hasClass('link')).toEqual(true);
	});
	it('identify that a contains text', () => {
		expect(enzymeWrapper.find('.link').text()).toEqual('This is link text');
	});

	it('crate link instance for functional', () => {
		enzymeWrapper.instance().dataPassing(String);
	});
	
});
