import React from 'react';
import { constStyles, defaultData } from './LinkDefProps';
import './link.css';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

class Link extends BaseComponent {
	classToBeAdded() {
		this.classToAdded = constStyles[`${this.props.data.linkType}AStyle`];
	}
	componentWillMount() {
		this.classToBeAdded();
	}
	dataPassing(obj) {
		return {
			id: obj.id,
			value: obj.value
		};
	}
	render() {
		return (
			<div>
				<p>
					<a
						className={this.classToAdded}
						onClick={() =>
							this.delegateHandler(
								'onClick',
								{ id: this.props.data.id, value: this.props.data.href },
								this.dataPassing
							)}
					>
						{this.props.data.label}
					</a>
				</p>
			</div>
		);
	}
}
Link.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string,
		name: PropTypes.string,
		linkType: PropTypes.string,
		href: PropTypes.string,
		label: PropTypes.string
	}).isRequired
};
Link.defaultProps = {
	data: defaultData
};
export default Link;
