import React from 'react';
import { constStyles } from './ResultsCountDefData-Props';
import './ResultsCount.css';
import BaseComponent from 'vf-ent-ws-utilities';

class ResultsCount extends BaseComponent {
	constructor() {
		super();
	}

	render() {
		return (
			<div className={constStyles.gridItem}>
				<div className={constStyles.paginationInfo}>
					{
						<p>
							<span className={constStyles.reg}>{this.props.data.labels.label1}</span>
							<span className={constStyles.bold}>
								{this.props.data.pageIndex * this.props.data.noOfResultsPerPage + 1}-{this.props.data.pageIndex * this.props.data.noOfResultsPerPage + this.props.data.noOfResults}
							</span>
							{/* <span className={constStyles.reg}>{this.props.data.labels.label2}</span> */}
							{/* <span className={constStyles.bold}>{this.props.data.totalNumberOfResults}</span> */}
							<span className={constStyles.reg}>{this.props.data.labels.label3}</span>
						</p>
					}
				</div>
			</div>
		);
	}
}
export default ResultsCount;
