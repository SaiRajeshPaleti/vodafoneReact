import React from 'react';
import renderer from 'react-test-renderer';
import AdvancedGenericSearch from '../AdvancedGenericSearch';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import advancedGenericSearchdata from '../../../AppData/advancedGenericSearchdata';
import advancedSearchData from '../../../AppData/advancedSearchData';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('components', function() {
	describe('<AdvancedGenericSearch />', function() {
		let props, enzymeWrapper;
		let event = {target: { value: "text"}};

		beforeEach(() => {
			props = {
				onChangeHandler: function toggleIcon() {}
			};
			enzymeWrapper = mount(
				<AdvancedGenericSearch
					data={advancedGenericSearchdata}
					advancedSearchComponentData={advancedSearchData.advancedSearchComponentData}
					submitHandler={advancedSearchData.onSubmitHandler}
					searchMethod={advancedGenericSearchdata.searchMethod}
				/>
			);
		});

		it('Advance Generic search contains main Div', () => {
			expect(enzymeWrapper.find('.advancesearch_main').length).toBe(1);
		});
		it('event handler to be called on onChange', () => {			
			enzymeWrapper.find('SearchBox').simulate('change',event);
			expect(enzymeWrapper.onChange).toHaveBeenCalled;	
									
		});

		it('onchange should verify below condition when value is not null',() => {
			const eleng = event.target.value;
			expect(eleng).not.toBe(null);
			expect(eleng.length).toBeGreaterThan(2);
			enzymeWrapper.setState({ 
				input: event.target.value, 
				disabled: false 
			});
			expect(enzymeWrapper.setState).toHaveBeenCalled;
		});
		
		it('Advance Generic search should call enterpress ', () => {			
			enzymeWrapper.find('SearchBox').simulate('keypress', {key: 'Enter'});
			expect(enzymeWrapper.enterPress).toHaveBeenCalled;
							
		});

		it('event handler to be called on handleAdvancedSearchClick', () => {
			let searchInput = enzymeWrapper.find('.search-down');
			searchInput.simulate('click');
			expect(AdvancedGenericSearch.handleAdvancedSearchClick).toHaveBeenCalled;
		});

		it('event handler to be called on on Clear button', () => {
			let clearData = enzymeWrapper.find('.adv-clear-search-change-request');
			clearData.simulate('click');
			expect(AdvancedGenericSearch.clearData).toHaveBeenCalled;
		});

		it('event handler to be called on on Clear button', () => {
			let buttonClick = enzymeWrapper.find('.submitClass');
			buttonClick.simulate('onclick');
			expect(AdvancedGenericSearch.search).toHaveBeenCalled;
		});

		
        it('Search will be called', () => {
            expect(enzymeWrapper.instance().searchFn()).toHaveBeenCalled;
	 });
	 
	 it('toggleIcon will be called', () => {
		expect(enzymeWrapper.instance().toggleIcon()).toHaveBeenCalled;
 });
	 it('should find onChange Fn', () => {
		const mockedEvent = { target: {"value":"orange","name":"orange"} }

		expect(enzymeWrapper.instance().onChange(mockedEvent)).toHaveBeenCalled;
	});
	});
});
