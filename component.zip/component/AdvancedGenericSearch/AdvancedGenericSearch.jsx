import React from 'react';
import { constStyles } from './AdvancedGenericSearchDefData-Props';
import PropTypes from 'prop-types';
import './AdvancedGenericSearch.css';
import AdvancedSearch from 'vf-ent-ws-advanced-search';
import CSSTransitionGroup from 'react-addons-css-transition-group';
import Icon from 'vf-ent-ws-svgicons';
import TextField from 'vf-ent-ws-textfield';

import BaseComponent from 'vf-ent-ws-utilities';
class AdvancedGenericSearch extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			arrowEve: false,
			input: this.props.data.textFieldData.value,
			disabled: true,
			visible: false
		};
		this.toggleIcon = this.toggleIcon.bind(this);
		this.onChange = this.onChange.bind(this);
		this.clearData = this.clearData.bind(this);
		this.searchFn = this.searchFn.bind(this);
		this.enterPress = this.enterPress.bind(this);
		this.handleAdvancedSearchClick = this.handleAdvancedSearchClick.bind(this);
	}
	toggleIcon() {
		this.setState({ arrowEve: !this.state.arrowEve });
	}
	enterPress(event) {
		const value = this.state.input;
		if (value && value.length > 2) {
			this.searchFn();
		}
	}

	searchFn() {
		let key = this.props.data.searchFieldId;
		let value = this.state.input;
		if (value && value.length > 2) {
			this.setState({ input: value, disabled: false });
		} else {
			this.setState({ input: value, disabled: true });
		}
		let criteria = {};
		criteria[key] = value;
		if (value && value.length > 2) this.props.data.searchMethod(criteria);
	}
	onChange(event) {
		let value = event.value;
		if (value && value.length > 2) {
			this.setState({ input: value, disabled: false });
		} else {
			this.setState({ input: value, disabled: true });
		}
	}
	clearData() {
		this.setState({ input: '', disabled: true });
		this.props.data.clearSearch != undefined && this.props.data.clearSearch();
	}
	handleAdvancedSearchClick() {
		this.setState({ visible: !this.state.visible });
	}
	renderAdvancedSearch(props, state = this.state) {
		return (
			<AdvanceSearchBox
				data={props.data}
				visible={state.visible}
				advancedSearchComponentData={props.data.advancedSearchComponentData}
				submitHandler={props.data.submitHandler}
				handleAdvancedSearchClick={this.handleAdvancedSearchClick}
			/>
		);
	}
	componentWillUpdate(nextProps, nextState) {
		this.search = this.renderAdvancedSearch(nextProps, nextState);
	}

	render() {
		return (
			<div className={constStyles.advancesearchMainClass}>
				<div className={constStyles.searchFilterClass}>
					<SearchBox
						data={this.props.data}
						onChange={this.onChange}
						onSearch={this.searchFn}
						onKeyDown={this.enterPress}
						tabIndex="0"
						keyCode="Enter"
						handleAdvancedSearchClick={this.handleAdvancedSearchClick}
						state={this.state}
					/>
					{this.search}
				</div>
				<div className={constStyles.advClearSearch} onClick={this.clearData}>
					<span>{this.props.data.clear}</span>
				</div>
			</div>
		);
	}
}
const SearchBox = (props) => {
	let textFieldData = {
		...props.data.textFieldData,
		value: props.state.input,
		onChange: props.onChange,
		keyCode: props.keyCode,
		onKeyDown: props.onKeyDown
	};
	return (
		<div className={constStyles.searchFilterClass}>
			<div className={constStyles.categorySearch}>
				<div className={constStyles.searchInput}>
					<TextField data={textFieldData} />
					<div className={constStyles.chevronCustom} onClick={props.handleAdvancedSearchClick}>
						<span className={constStyles.spriteIcon} title={props.data.tooltip}>
							<Icon name={constStyles.downIcon} />
						</span>
					</div>
				</div>
				<div
					className={props.state.disabled ? constStyles.disabled : constStyles.submitClass}
					onClick={props.onSearch}
				>
					<span
						className={constStyles.spriteIcon}
						title={!props.state.disabled ? props.data.searchTooltip : ''}
					>
						<Icon name={constStyles.searchIcon} />
					</span>
				</div>
			</div>
			<span className={constStyles.searchText}>{props.data.helpText}</span>
		</div>
	);
};
const AdvanceSearchBox = (props) => {
	return (
		<CSSTransitionGroup
			transitionName="slide"
			transitionAppear={true}
			transitionAppearTimeout={1000}
			transitionEnterTimeout={1000}
			transitionLeaveTimeout={300}
		>
			{props.visible ? (
				<AdvancedSearch
					data={Object.assign({
						...props.data.advancedSearchComponentData,
						clearFn: props.data.clearFn,
						closeTooltip: props.data.closeTooltip,
						getClickAdvanceSearch: props.handleAdvancedSearchClick
					})}
				/>
			) : null}
		</CSSTransitionGroup>
	);
};
AdvancedGenericSearch.propTypes = {
	data: PropTypes.shape({
		id: PropTypes.string.isRequired,
		name: PropTypes.string.isRequired,
		textFieldData: PropTypes.object.isRequired,
		searchMethod: PropTypes.func.isRequired,
		advancedSearchComponentData: PropTypes.array.isRequired,
		submitHandler: PropTypes.func.isRequired
	})
};
export default AdvancedGenericSearch;
