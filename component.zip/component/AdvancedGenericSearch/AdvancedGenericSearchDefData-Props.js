export const constStyles = {
	advancesearchMainClass: 'advancesearch_main',
	searchFilterClass: 'search_order_filter_col',
	categorySearch: 'search_order_filter category_seacrh',
	searchInput: 'search_input',
	crInput: 'search-input search-cr-input',
	chevronCustom: 'search-down',
	spriteIcon: 'sprite__icon',
	icon: 'icon',
	downIcon: 'chevron-down',
	searchIcon: 'search',
	submitClass: 'search-but',
	disabled: 'search-but-disabled',
	searchText: 'searct-text',
	advClearSearch: 'adv-clear-search-change-request',
	clearLabel: 'Clear Search'
};
