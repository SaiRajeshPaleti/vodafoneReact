import React from 'react';
import RadioButton from '../RadioButton';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import Data from './../../../AppData/RadioButtonData';
Enzyme.configure({ adapter: new Adapter() });

describe('<Radio/>', function() {
	let props, enzymeWrapper, datalength;

	beforeAll(() => {
		props = Data;
		enzymeWrapper = shallow(<RadioButton data={props} />);
	});

	it('Radio Component contains  div', () => {
		expect(enzymeWrapper.find('div').length).toEqual(1);
	});

	it('Radio Component contains  input', () => {
		let span = enzymeWrapper.find('input');
		span.simulate('change');
		expect(span.onChange).toHaveBeenCalled;
	});
});
