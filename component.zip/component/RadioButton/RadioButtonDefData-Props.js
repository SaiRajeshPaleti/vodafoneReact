export const constStyles = {
	labelClass: 'radiolabel'
};
export const constData = {
	inputType: 'radio',
	onChangeProperty: 'onChange',
	checked: 'checked'
};

export const defaultData = {
	onChange: function onChange(val) {
		//Method Implementation goes here
		//console.log(' I am in Radio Button data function');
	},
	id: '1',
	name: 'radio',
	tooltip: 'click here to select',
	displayValue: 'Order Something'
};
