import React from 'react';
import './RadioButton.css';
import { constStyles, constData, defaultData } from './RadioButtonDefData-Props';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';

export default class RadioButton extends BaseComponent {
	constructor(props) {
		super(props);
		this.onChange=this.onChange.bind(this)
	}
	onChange(event){
		if(this.props.data.disabled!==true){
			this.delegateHandler(constData.onChangeProperty, event, constData.checked)
		}
	}
	render() {
		return (
			<div className={constStyles.labelClass}>
				<span title={this.props.data.tooltip}>
					<input
						id={this.props.data.id}
						type={constData.inputType}
						name={this.props.data.name}
						checked={this.props.data.checked}
						onChange={this.onChange}
					/>
				</span>
				{this.props.data.displayValue}
			</div>
		);
	}
}

RadioButton.propTypes = {
	data: PropTypes.shape({
		name: PropTypes.string.isRequired,
		id: PropTypes.string.isRequired,
		checked: PropTypes.bool,
		tooltip: PropTypes.string,
		displayValue: PropTypes.string,
		onChange: PropTypes.func.isRequired
	}).isRequired
};
RadioButton.defaultProps = {
	data: defaultData
};
