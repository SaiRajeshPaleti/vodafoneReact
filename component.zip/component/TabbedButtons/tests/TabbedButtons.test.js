import React from 'react';
import renderer from 'react-test-renderer';
import TabbedButtons from '../TabbedButtons';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<TabbedButtons/>', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = {
			data :{
				activeButton: 'ad',		
				value: "Address",
				buttons: [{
						id: 'ad',
						label: 'Additional Details'
					},
					{
						id: 'rc',
						label: 'Request closure'
					},
					{
						id: 're',
						label: 'Request escalation'
					}
				],
				onClick: (dataPassed) => console.log('Button ID', dataPassed)
			
			}
		
		};
		enzymeWrapper = mount( <TabbedButtons { ...props}/>);
	});

	it('Button Component contains  div', () => {
		expect(enzymeWrapper.find('ButtonSection').length).toBe(1);
	});

	it('method to be called on clicking on Tab', () => {
		let Tabbs = enzymeWrapper.find('.request_selection_btns').childAt(1);
		Tabbs.simulate('click');
		expect(props.method).toHaveBeenCalled;
	});

	// it('Verifies that Additional details tab is active', () => {
	// 	expect(enzymeWrapper.find('.request_selection_btns').childAt(0).hasClass('button--secondary')).toEqual(false);
	// });

	it('method to be invoked for getting data', () => {
		enzymeWrapper.instance().dataPassing('a');
	});

	it('event handler to be called on  clicking button', () => {
		const event = {target: { value: "Address"}};
		enzymeWrapper.find('.request_selection_btns').simulate('click',event);
	
	});
	
	it('method to be called to set the active button state', () => {
		const event = {target: { 
			value: true,
			id: 5
	    }};
		enzymeWrapper.find('.request_selection_btns').simulate('click',event);		
		expect(enzymeWrapper.instance().handleButtonClick(event)).toHaveBeenCalled;
		enzymeWrapper.setState({activeButton:'event.target.id'});
	});

	it('should call componentDidMount when mounting',() => {
		expect(enzymeWrapper.instance().componentDidMount()).toHaveBeenCalled;
	});	

	it('should call componentWillReceiveProps when mounting',() => {		
		 enzymeWrapper.instance().componentWillReceiveProps(props);		 
	});	
});
