import React from 'react';
import { constStyles, defaultData, constData } from './TabbedButtonsDefProps';
import PropTypes from 'prop-types';
import './TabbedButtons.css';
import Label from 'vf-ent-ws-label';
import Buttons from 'vf-ent-ws-button';
import BaseComponent from 'vf-ent-ws-utilities';

class TabbedButtons extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			activeButton: props.data.activeButton
		};
		this.handleButtonClick = this.handleButtonClick.bind(this);
		this.inputMyRef = React.createRef();
		this.applicableClass = props.data.className ? props.data.className : constStyles.selectionBlockClass;
	}

	componentWillMount() {
		this.checkForUpdatedProps(this.props);
	}
	componentDidMount() {
		if (this.props.data.value) {
			this.inputMyRef.current.value = this.props.data.value;
		}
	}
	componentWillReceiveProps(nextProps) {
		this.inputMyRef.current.value = nextProps.data.value;
		this.checkForUpdatedProps(nextProps);
	}

	checkForUpdatedProps(props) {
		const labelProps = {
			id: props.data.label_id,
			styling: constStyles.helperLabel,
			labelname: props.data.helperText
		};
		this.LabelComponent = props.data.label_helper ? <Label data={labelProps} /> : '';
		this.setState({ activeButton: props.data.value });
	}

	dataPassing(id) {
		return {
			id: id,
			value: true
		};
	}

	handleButtonClick(target) {
		this.inputMyRef.current.value = target.id;
		this.setState({ activeButton: target.id }, () => {
			this.delegateHandler(constData.propsProperty, this.state.activeButton, this.dataPassing);
		});
	}

	render() {
		return (
			
			<div className={this.applicableClass} id={this.props.data.id}>
				<div className={constStyles.buttonListParentClass}>
					<div className={constStyles.buttonListClass}>
						<ButtonSection
							buttons={this.props.data.buttons}
							buttonType="button"
							onClick={this.handleButtonClick}
							activeId={this.state.activeButton}
						/>
						<div>{this.LabelComponent}</div>
					</div>
				</div>
				<input name={this.props.data.name} type="hidden" ref={this.inputMyRef} />
			</div>
		);
	}
}

const ButtonSection = (props) => {
	const buttonHtml = props.buttons.map((tabButton, i) => {
		let buttonProps = {
			id: tabButton.id,
			name: tabButton.label,
			buttonType: props.buttonType,
			type: props.activeId === tabButton.id ? constStyles.activeClass : constStyles.inActiveClass,
			onClick: props.onClick
		};

		return <Buttons key={i} data={buttonProps} />;
	});

	return buttonHtml;
};

TabbedButtons.defaultProps = {
	data: defaultData
};

TabbedButtons.propTypes = {
	data: PropTypes.shape({
		activeButton: PropTypes.string.isRequired,
		buttons: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string.isRequired,
				label: PropTypes.string.isRequired
			})
		)
	})
};

export default TabbedButtons;
