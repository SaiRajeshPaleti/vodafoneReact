export const constStyles = {
	selectionBlockClass: 'request_selection_block',
	buttonListParentClass: 'request_selection_btns_parent',
	buttonListClass: 'request_selection_btns',
	buttonTertiaryClass: 'button button--tertiary',
	buttonSecondaryClass: 'button--secondary',
	activeClass: 'tabbedActive',
	inActiveClass: 'tertiary',
	helperLabel: 'helperLabel'
};

export const constData = {
	propsProperty: 'onClick'
};

export const defaultData = {
	activeButton: 'vf-btn-active',
	buttons: [{
			id: 'vf-btn1',
			label: 'Sample Button 1'
		},
		{
			id: 'vf-btn2',
			label: 'Sample Button 2'
		},
		{
			id: 'vf-btn3',
			label: 'Sample Button 3'
		}
	]
};