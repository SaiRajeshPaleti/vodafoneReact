export const constStyles = {
	listView: 'list_view',
	activeToggle: 'activeToggle',
	toggleSection: 'toggleSection'
};
