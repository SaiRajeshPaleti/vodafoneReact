import React from 'react';
import Icon from 'vf-ent-ws-svgicons';
import './ListToggle.css';
import { constStyles } from './ListToggleDefData-Props';
import PropTypes from 'prop-types';

const ListToggleComponent = (props) => {
	return (
		<div className={constStyles.toggleSection}>
			{props.data.icons.map((data, index) => {
				return (
					<span
						key={index}
						className={`${constStyles.listView} ${data.selected && constStyles.activeToggle}`}
						onClick={() => props.data.onClick(data, index)}
					>
						<Icon name={data.name} />
					</span>
				);
			})}
		</div>
	);
};

ListToggleComponent.propTypes = {
	data: PropTypes.shape({
		icons: PropTypes.arrayOf(
			PropTypes.shape({
				name: PropTypes.string,
				title: PropTypes.string,
				isIcon: PropTypes.bool,
				selected: PropTypes.bool,
				view: PropTypes.string
			})
		).isRequired,
		onClick: PropTypes.func.isRequired,
		currentView: PropTypes.string
	})
};

export default ListToggleComponent;
