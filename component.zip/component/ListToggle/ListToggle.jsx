import React from 'react';
import './ListToggle.css';
import ListToggleComponent from './ListToggleComponent';
import BaseComponent from 'vf-ent-ws-utilities';
import PropTypes from 'prop-types';

class ListToggle extends BaseComponent {
    constructor(props) {
        super(props);
        this.state = {
            data: {
                icons: this.props.data.Icons,
                currentView: this.props.data.Icons[0].view,
                onClick: this.iconSelected
            }
        };
        this.iconSelected = this.iconSelected.bind(this);
    }

    componentWillMount() {
        console.log('Current View', this.state.data.currentView);
    }

    iconSelected = (data, selectedIndex) => {
        const iconsList = [...this.state.data.icons];
        iconsList.map((data, index) => {
            return data.selected = selectedIndex === index ? true : false;
        })
        this.setState(
            {
                data: {
                    icons: iconsList,
                    currentView: iconsList[selectedIndex].view,
                    onClick: this.iconSelected
                }
            });
        this.props.data.onClick(data.name, data.view);
    }

    render() {
        return (
            <ListToggleComponent data={this.state.data} />
        );
    }
}



ListToggle.propTypes = {
    data: PropTypes.shape({

        Icons: PropTypes.arrayOf(
            PropTypes.shape({
                name: PropTypes.string,
                title: PropTypes.string,
                isIcon: PropTypes.bool,
                selected: PropTypes.bool,
                view: PropTypes.string
            })
        ).isRequired,
        onClick: PropTypes.func,
        currentView: PropTypes.string
    })
}
export default ListToggle;