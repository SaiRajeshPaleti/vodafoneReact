import React from 'react';
import ListToggleComponent from '../ListToggleComponent';
import ListToggle from '../ListToggle';


import {
	shallow, mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ListToggleData from '../../../AppData/ListToggleData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<ListToggle />', function () {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = ListToggleData;
		enzymeWrapper = mount(<ListToggle data={
			props
		}

		/>);
	});
	//	console.log('data..in test', enzymeWrapper);
	it('Text field  contains one div', () => {
		expect(enzymeWrapper.find('div').length).toBe(1);
	});

	it('Handler testing', () => {
		const icons = enzymeWrapper.find('.list_view');
		console.log('icons infos', icons);
		expect(icons.length).toBe(2);
		icons.at(1).simulate('click');
		expect(props.iconSelected).toHaveBeenCalled;

	});

});