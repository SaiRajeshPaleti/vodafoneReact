import React from 'react';
import BaseComponent from 'vf-ent-ws-utilities';
import './EscalationTimeline.css';
import { constStyles } from './EscalationTimelineDefProps';
import PropTypes from 'prop-types';

class EscalationTimeline extends BaseComponent {
    constructor(props) {
        super(props);
        this.state = {
            stage: 0
        };
        this.handleChange = this.handleChange.bind(this);
    }

    componentWillMount() {
        this.updateStateInfo(this.props);
    }

    componentWillReceiveProps(nextProps) {
        this.updateStateInfo(nextProps);
    }

    updateStateInfo = (props) => {
        this.setState({
            data: props.data
        });
    };

    handleChange(index) {
        this.setState({ stage: index });
    }

    render() {
        return (
            <div className={constStyles.container}>
                <div className={constStyles.headerSection}>
                    <Timeline {...this.state} handleChange={this.handleChange} />
                    {/* <Line data={this.state.data} /> */}
                    <Titles {...this.state} />
                </div>
                <TableData stage={Number(this.state.stage)} data={this.state.data} />
            </div>
        );
    }
}

const Timeline = (props) => {
    let lastElement = props.data[props.data.length - 1];
    return (
        <div className={constStyles.timeline}>
            {props.data.map((data, index) => (
                <div key={index} className={constStyles.stageContainer}>
                    <div
                        className={`${data.color ? constStyles.radioColor : ''}
                        ${props.stage === index ? constStyles.radioChecked : ''} 
                        ${constStyles.radioCircles}`}
                        onClick={() => props.handleChange(index)}
                    >
                        <span>{data.text}</span>
                    </div>
                    <div className={constStyles.line} />
                    <div
                        className={`${props.data.length > 5 ? '' : constStyles.arrow} ${lastElement.color
                            ? constStyles.arrowColour
                            : ''}`}
                    />
                    {/* <div
                        className={`${lastElement.color && props.data.length <= 5 && props.data.length - 1 === index
                            ? constStyles.lineColour
                            : null}`}
                    /> */}
                </div>
            ))}
        </div>
    );
};

// const Line = (props) => {
//     let lastElement = props.data[props.data.length - 1];
//     return (
//         <div className={constStyles.lineContainer}>
//             <div className={constStyles.line} /> */}
//             <div
//                 className={`${props.data.length > 5 ? null : constStyles.arrow} ${lastElement.color
//                     ? constStyles.arrowColour
//                     : null}`}
//             />
//         </div>
//     );
// };

const Titles = (props) => {
    return (
        <div className={constStyles.titleSection}>
            {props.data.map((data, index) => (
                <div key={index} className={constStyles.titleContainer}>
                    <div className={`${props.stage === index ? constStyles.pointer : null}`} />
                    <div
                        className={` ${constStyles.title} ${data.color ? constStyles.titleColour : null}`}
                        key={index}
                    >{`${props.stage === index ? data.title : ''}`}</div>
                </div>
            ))}
        </div>
    );
};

const TableData = (props) => {
    return (
        <div className={constStyles.tableContainer}>
            <table className={constStyles.table}>
                {props.data[props.stage].data.map((data, index) => (
                    <tbody key={index}>
                        <tr className={` ${data.hightlightTxt ? constStyles.highlightTxt : ''}`}>
                            <td>{data.date}</td>
                            <td className={constStyles.middleColumn}>{data.action}</td>
                            <td>{`${constStyles.reason}${data.reason}`}</td>
                        </tr>
                    </tbody>
                ))}
            </table>
        </div>
    );
};

EscalationTimeline.propTypes = {
    data: PropTypes.arrayOf(
        PropTypes.shape({
            title: PropTypes.float,
            text: PropTypes.string,
            data: PropTypes.arrayOf(
                PropTypes.shape({
                    date: PropTypes.string,
                    action: PropTypes.string,
                    reason: PropTypes.string
                }).isRequired
            ).isRequired
        }).isRequired
    ).isRequired
};

export default EscalationTimeline;
