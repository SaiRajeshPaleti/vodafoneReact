import React from 'react';
import EscalationTimeline from '../EscalationTimeline';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import EscalationTimelineData from '../../../AppData/EscalationTimelineData';
Enzyme.configure({ adapter: new Adapter() });

global.console = {
  warn: jest.fn(),
  log: jest.fn(),
  error: jest.fn()
}

describe('<EscalationTimeline />', function() {
  let enzymeWrapper;
  const data = [{
    title: 'Not escalated',
    text: 'L0',
    data:[
        {
            date: '12.15am 08 September 2017',
            action: 'Escalation requested',
            reason: 'Level 0'
        },
        {
            date: '12.15am 08 September 2017',
            action: 'Escalation requested',
            reason: 'Level 0'
        },
        {
            date: '12.15am 08 September 2017',
            action: 'Escalation requested',
            reason: 'Level 0'
        }
    ]
  }]

	beforeEach(() => {
		enzymeWrapper = mount(<EscalationTimeline data={EscalationTimelineData} />);
    });

    it('contains no p tags', () => {
		expect(enzymeWrapper.find('p').length).toBe(0);
    });

    it('Only one timeline is called', () => {
		expect(enzymeWrapper.find('Timeline').length).toBe(1);
    });

    it('Only one line is called', () => {
      expect(enzymeWrapper.find('Line').length).toBe(1);
    });

    it('Only one set of titles are called', () => {
      expect(enzymeWrapper.find('Titles').length).toBe(1);
    });
    it('Only one table is called', () => {
      expect(enzymeWrapper.find('TableData').length).toBe(1);
    });
    it('All parts are rendered', () => {
      expect(enzymeWrapper.find('.container').children().length).toBe(2);
    });
    it('Rendered all the radio buttons', () => {
      const buttonNum = EscalationTimelineData.length;
      expect(enzymeWrapper.find('.radioCircles').length).toBe(buttonNum);
    });
    it('Handler Testing', () => {
      const buttonNum = EscalationTimelineData.length -1;
      enzymeWrapper.find('.stageContainer').last().find('.radioCircles').simulate('click');
      enzymeWrapper.update();
      expect(enzymeWrapper.state().stage).toBe(buttonNum);
    });
});