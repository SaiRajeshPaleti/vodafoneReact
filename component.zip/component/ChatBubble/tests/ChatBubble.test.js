import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ChatBubble from '../ChatBubble';
import ChatBubbleData from '../../../AppData/ChatBubbleData';

Enzyme.configure({ adapter: new Adapter() });

describe('<ChatBubble Component />', function() {
	let props, enzymeWrapper;

	beforeEach(() => {
		props = ChatBubbleData;
		enzymeWrapper = mount(<ChatBubble data={props} />);
	});

	it('verifying number of divisions', () => {
		expect(enzymeWrapper.find('.comment-box-common').length).toBe(2);
	});
	it('verifying number of paragraphs', () => {
		expect(enzymeWrapper.find('.comment-box-common').first().find('p').length).toBe(3);
	});
	it('Fist paragraph contains text', () => {
		expect(enzymeWrapper.find('.chat--buble--heading').at(0).text()).toEqual('2018-09-14T09:34:35');
	});
	it('Paragraph contains text', () => {
		expect(enzymeWrapper.find('.chat--buble--heading').at(1).text()).toEqual('user');
	});
});
