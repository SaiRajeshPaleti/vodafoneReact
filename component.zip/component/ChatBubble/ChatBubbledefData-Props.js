export const constStyles = {
  chatBubbleMainWrapper: 'chat-bubble-main-wrapper',
  chatBubbleWrapper: 'chat-bubble-wrapper',
  commentBox: 'comment-box-common',
  commentBlock: 'comment-bubble-block',
  commentHeading: 'chat--buble--heading',
  commentText: 'chat--buble--heading chat--bubble--text',
  bubbleTailIcon: 'bubble'
};
