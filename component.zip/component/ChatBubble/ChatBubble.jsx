import React from 'react';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import { constStyles } from './ChatBubbledefData-Props';
import './ChatBubble.css';

const ChatBubble = (props) => {
  return (
    <div className={constStyles.chatBubbleMainWrapper}>
      {props.data.notes.map((noteItem, index) => {
        return (
          <div key={index} className={constStyles.chatBubbleWrapper}>
            <div className={`${constStyles.commentBox} ${noteItem.commentedBy === 'rest.esb' ? 'admin' : 'user'}`}>
              <div className={constStyles.commentBlock}>
                <p className={constStyles.commentHeading}>{noteItem.commentedWhen}</p>
                <p className={constStyles.commentHeading}>{noteItem.commentedBy === 'rest.esb' ? 'admin' : 'user'}</p>
                <div className={constStyles.commentText} dangerouslySetInnerHTML={{ __html: noteItem.content }} />
              </div>
              <Icon name={constStyles.bubbleTailIcon} />
            </div>
          </div>
        );
      })}
    </div>
  );
};
ChatBubble.propTypes = {
  data: PropTypes.shape({
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    notes: PropTypes.arrayOf(
      PropTypes.shape({
        commentedBy: PropTypes.string.isRequired,
        commentedWhen: PropTypes.string.isRequired,
        content: PropTypes.string.isRequired
      }).isRequired
    ).isRequired
  }).isRequired
};
export default ChatBubble;
