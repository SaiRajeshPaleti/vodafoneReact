import React from 'react';
import PropTypes from 'prop-types';
import ReactQuill from 'react-quill';
import BaseComponent from 'vf-ent-ws-utilities';
import Label from 'vf-ent-ws-label';
import 'react-quill/dist/quill.snow.css'; // ES6
import './RichTextBox.css'; // ES6
import { constStyles, constData, defaultData } from './RichTextBoxDefData-Props';

class RichTextBox extends BaseComponent {
  constructor(props) {
    super(props);
    this.reactQuillRef = false;
    this.handleChange = this.handleChange.bind(this);
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.checkForOptionalProps = this.checkForOptionalProps.bind(this);
  }
  componentWillMount() {
    this.checkForOptionalProps(this.props);
  }
  componentWillReceiveProps(nextProps) {
    this.checkForOptionalProps(nextProps);
  }
  componentDidMount() {
    if (this.props.data.value && this.props.data.value.length > 0) {
      const editor = this.reactQuillRef.getEditor();
      const maxLength = this.props.data.maxLength ? parseInt(this.props.data.maxLength, 10) : 0;
      const lengthLeft = editor.getLength() === 1 ? maxLength : maxLength - editor.getLength() + 1;
      this.setState({
        lengthLeft: lengthLeft
      });
    }
  }
  checkForOptionalProps(props) {
    this.LabelComponent = props.data.label ? <Label data={props.data.label} /> : '';
    let lengthLeft = this.props.data.maxLength ? parseInt(this.props.data.maxLength, 10) : 0;
    const maxLength = props.data.maxLength ? parseInt(props.data.maxLength, 10) : 0;
    if (this.reactQuillRef) {
      const editor = this.reactQuillRef.getEditor();
      lengthLeft = editor.getLength() === 1 ? maxLength : maxLength - editor.getLength() + 1;
    }
    this.setState({
      value: props.data.value,
      maxLength: maxLength,
      lengthLeft: lengthLeft
    });
  }

  handleChange(value, delta, source, editor) {
    let id = this.props.data.id;
    const lengthLeft = editor.getLength() === 1 ? this.state.maxLength : this.state.maxLength - editor.getLength() + 1;

    this.setState({
      // value: this.state.maxLength && lengthLeft < 0 ? this.state.value : value,
      value: value,
      lengthLeft: this.state.maxLength > 0 ? lengthLeft : 0
    });
    // const editorContent = this.state.maxLength > 0 && lengthLeft > 0 ? value : this.state.value;

    this.delegateHandler(constData.onChange, { id, value, contentLength: editor.getLength() - 1 }, (data) => data);
  }

  handleKeyDown(e) {
    if (this.state.maxLength > 0 && this.state.lengthLeft === 0 && e.keyCode !== 8 && e.keyCode !== 46) {
      e.preventDefault();
    }
  }
  render() {
    return (
      <div className={constStyles.richWrapper}>
        <div className={constStyles.labelContainer}>
          <div className={constStyles.labelContainerRow}>
            <div className={constStyles.labelContainerCell}>
              <BoxTitle data={{ title: this.props.data.title }} />
            </div>
            <div className={constStyles.labelContainerCell}>
              <Textright data={{ lengthLeft: this.state.lengthLeft, maxLength: this.state.maxLength }} />
            </div>
          </div>
        </div>
        <ReactQuill
          ref={(el) => {
            this.reactQuillRef = el;
          }}
          name={this.props.data.name}
          id={this.props.data.id}
          placeholder={this.props.data.placeholder}
          value={this.state.value}
          modules={constData.configModules}
          onChange={this.handleChange}
          onKeyDown={this.handleKeyDown}
        />
        {this.LabelComponent}
      </div>
    );
  }
}
export const Textright = (props) => {
  const contentLength = {
    ...constData.labelData,
    labelname: `${props.data.lengthLeft} Characters`
  };
  return props.data.maxLength > 0 ? (
    <div className={props.data.lengthLeft < 0 && constStyles.maxLengthError}>
      <Label data={contentLength} />
    </div>
  ) : (
    ''
  );
};
export const BoxTitle = (props) => {
  const content = {
    ...constData.titleData,
    labelname: props.data.title
  };
  return props.data.title && props.data.title.length > 0 ? <Label data={content} /> : '';
};

RichTextBox.propTypes = {
  data: PropTypes.shape({
    id: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    name: PropTypes.string.isRequired,
    maxLength: PropTypes.oneOfType([ PropTypes.string, PropTypes.number ]),
    title: PropTypes.string,
    value: PropTypes.oneOfType([ PropTypes.string, PropTypes.number ]),
    placeholder: PropTypes.string,
    disabled: PropTypes.string
  }).isRequired
};
RichTextBox.defaultData = defaultData;
export default RichTextBox;
