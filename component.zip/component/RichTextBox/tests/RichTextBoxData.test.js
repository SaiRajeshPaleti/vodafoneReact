import React from 'react';
import RichTexBox, { BoxTitle, Textright } from '../RichTextBox';
import Enzyme, { shallow, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import RichTextBoxData from '../../../AppData/RichTextBoxData';

Enzyme.configure({
    adapter: new Adapter()
});

describe('<RichTexBox />', function() {
    let wrapper;
    let props = {
        data: {
            id: 'richtextbox',
            name: 'richtextbox',
            maxLength: '10',
            title: 'Please add any steps taken to resolve the issue',
            placeholder: 'Tell a story',
            // value: '<p>1234567</p>',
            onChange: (data) => {},
            value: 10,
            label: {
                id: 'buildingNumber',
                type: 'labelRequiredDefault',
                htmlFor: '',
                labelname: 'Building Number',
                isRequired: false
            },
            disabled: 'disable test',
            configModules: {
                toolbar: [ [ 'bold', 'italic', 'underline' ], [ 'link' ] ]
            }
        }
    };

    beforeEach(() => {
        wrapper = shallow(<RichTexBox {...props} data={RichTextBoxData} />);
    });

    it('Should render container wrapper', () => {
        expect(wrapper.find('.rich-wrapper').length).toBe(1);
    });
    it('Should render title', () => {
        const labelEl = mount(<BoxTitle data={{ title: RichTextBoxData.title }} />);
        expect(labelEl.find('#richboxTitle').length).toBe(1);
    });
    it('Should render characters left label', () => {
        const labelEl = mount(<Textright data={{ lengthLeft: 10, maxLength: 20 }} />);
        expect(labelEl.find('#charactersText').length).toBe(1);
    });
    it('Should call compoentwillreceive props function', () => {
        const nextProps = { ...RichTextBoxData, value: '<p>new text</p>' };
        wrapper.setProps({ data: nextProps });
    });

    it('should verify event handler to be called on onKeyDown', () => {
        const event = { target: { value: 'press enter' } };
        wrapper.find('#richtextbox').simulate('keyDown', event);
        expect(RichTexBox.onKeyPress).toHaveBeenCalled;
    });

    it('check for componentWillMount invocation', () => {
        expect(wrapper.instance().componentWillMount());
    });

    it('check for componentWillReceiveProps invocation', () => {
        expect(wrapper.instance().componentWillReceiveProps(props));
    });

    it('check for componentDidMount invocation', () => {
        expect(wrapper.instance().componentDidMount());
    });

    it('check for checkForOptionalProps invocation', () => {
        expect(wrapper.instance().checkForOptionalProps(props));
    });

    it('check for handleKeyDown invocation', () => {
        expect(wrapper.instance().handleKeyDown({ keyCode: 13 }));
    });

    it('event handler to be called on onChange', () => {
        let value, delta, source, editor;
        value = <p>add</p>;
        delta = {};
        source = 'user';
        editor = { getLength: () => {} };
        expect(wrapper.instance().handleChange(value, delta, source, editor)).toHaveBeenCalled;
    });
});

// describe('<BoxTitle/>', function() {
//     let wrapper;
//     let props = {
//         data: {
//             title: 'Please add any steps taken to resolve the issue'
//         }
//     };
//     beforeEach(() => {
//         wrapper = shallow(<BoxTitle {...props} />);
//     });

//     it('check for BoxTitle component', () => {
//         expect(wrapper).not.toBe(null);
//     });
// });

// describe('<Textright/>', function() {
//     let wrapper;
//     let props = {
//         data: {
//             lengthLeft: 10,
//             maxLength: 20
//         }
//     };
//     beforeEach(() => {
//         wrapper = shallow(<Textright {...props} />);
//     });

//     it('check for BoxTitle component', () => {
//         expect(wrapper).not.toBe(null);
//     });
// });
