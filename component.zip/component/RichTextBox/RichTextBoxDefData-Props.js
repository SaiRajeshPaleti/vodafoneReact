export const constStyles = {
  richWrapper: 'rich-wrapper',
  labelContainer: 'label-container',
  labelContainerRow: 'label-container-row',
  labelContainerCell: 'label-container-cell',
  maxLengthError: 'max-length-error'
};

export const constData = {
  onChange: 'onChange',
  labelData: {
    id: 'charactersText',
    type: 'labelRight',
    htmlFor: ''
  },
  titleData: {
    id: 'richboxTitle',
    type: 'labelDefault',
    htmlFor: ''
  },
  configModules: {
    toolbar: [ [ 'bold', 'italic', 'underline' ], [ 'link' ] ]
  }
};

export const defaultData = {
  id: 'richtextbox',
  name: 'richtextbox',
  maxLength: '10',
  title: 'Please add any steps taken to resolve the issue',
  placeholder: 'Tell a story',
  value: '<p>1234567</p>',
  onChange: (data) => {
    // console.log('text area data ', data);
  }
};
