export const defaultStyles = {
	tabsWhiteBg: 'tabs tabs_white_bg',
	tabNavCls: 'tabs__navigation tabs__navigation--overflow',
	prevIconCls: 'prev_arrow display_block',
	spriteIconCls: 'sprite__icon',
	chevronLeftIcon: 'chevron-left',
	chevronRightIcon: 'chevron-right',
	displayNone: 'display_none',
	nextIconCls: 'next_arrow',
	disableicon: 'sprite__icon disable_icon'
};
