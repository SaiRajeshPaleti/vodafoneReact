import React from 'react';

import PriorityCards from 'vf-ent-ws-priority-cards';
import BaseComponent from 'vf-ent-ws-utilities';

class ServiceSpeedOptions extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			serviceOption: false,
			currentOption: ''
		};
		this.serviceOptionSelector = this.serviceOptionSelector.bind(this);
	}

	serviceOptionSelector(event, currentOption) {
		const prevCard = this.state.currentOption;
		let isActive = this.state.serviceOption;
		isActive = !prevCard || prevCard === currentOption ? !isActive : isActive;
		this.setState({
			serviceOption: isActive,
			currentOption: currentOption
		});
	}

	render() {
		return (
			<div className="service_options_height">
				{this.props.data.map((card, index) => {
					return (
						<PriorityCards
							cardType="card5"
							key={index}
							PriorityCards={card}
							clickHandler={(evt) => this.serviceOptionSelector(evt, card.speed)}
							activeSelectors={this.state.serviceOption}
							currentSelector={this.state.currentOption}
						/>
					);
				})}
			</div>
		);
	}
}

export default ServiceSpeedOptions;
