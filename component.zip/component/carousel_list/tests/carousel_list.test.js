import React from 'react';
import CarouselList from '../carousel_list';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from "enzyme-adapter-react-16";

Enzyme.configure({ adapter: new Adapter() });

describe('<CarouselList/>', function () {
    let props, enzymeWrapper;

    props = {
        data: {
            type: 'ProductCarouselList',
            //enableDefaultSelection: true,
            //defaultSelectedProd: 'Ethernet Wireline',
            card4: [
                {
                    type: 'card4',
                    Id: 'w1',
                    url: 'EWL_interconnect',
                    name: 'Ethernet Wireline',
                    description: 'Interconnect',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w11',
                    url: 'EWL_pointtopoint',
                    name: 'Ethernet Wireless',
                    description: 'Point to Point',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w12',
                    url: 'EWL_MSPbearer',
                    name: 'Ethernet Wirelines',
                    description: 'Bearer',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w31',
                    url: 'EWL_interconnect',
                    name: 'Ethernet Publicline',
                    description: 'Interconnects',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w14',
                    url: 'EWL_interconnect',
                    name: 'Wholesale',
                    description: 'IPVPN',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w15',
                    url: 'EWL_MSPbearer',
                    name: 'Retail',
                    description: 'IPVPNS',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w16',
                    url: 'EWL_interconnect',
                    name: 'Wholesale privateline',
                    description: 'IPVPN point',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w17',
                    url: 'EWL_interconnect',
                    name: 'Wholesale publicline',
                    description: 'IPV point',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w18',
                    url: 'EWL_interconnect',
                    name: 'Entranet Wireline',
                    description: 'IP point',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w19',
                    url: 'EWL_interconnect',
                    name: 'Interconnects Wireline',
                    description: 'IN point',
                    onClick: () => {}
                },
                {
                    type: 'card4',
                    Id: 'w10',
                    url: 'EWL_interconnect',
                    name: 'Interconnects privateline',
                    description: 'INCN point',
                    onClick: () => {}
                }
            ],
            onClick: (e) => {
                console.log('selected card ' + JSON.stringify(e));
            },
            tooltip: 'Click here to access more products',
            displayCards: {
                minimumCards: 4,
                intialIndex: 0,
                singleStep: 1,
                multipleStpes: 4
            }
        }
    }

    beforeEach(() => {
        enzymeWrapper = mount(<CarouselList { ...props } />)
    })

    it('should render CarouselList component', () => {
		expect(enzymeWrapper).not.toBe(null);
    });

    it('Arrows  main div', () => {
        expect(enzymeWrapper.find('.next_arrow').length).toEqual(1);
    });

    it('event handler to be called on previous click', () => {
        const span =
            enzymeWrapper.find('.icon-chevron-left').at(0).simulate('click');
        expect(CarouselList.nextSlide).toHaveBeenCalled;
    });

    it('event handler to be called on previous click state check', () => {
        enzymeWrapper.setState({ props }, () => {
            enzymeWrapper.instance().nextSlide();
            const userState = enzymeWrapper.state('props');
            expect(userState.nextSlide).toHaveBeenCalled;
        });
    });

    it('event handler to be called on previous click state check', () => {
        enzymeWrapper.setState({ props }, () => {
            enzymeWrapper.instance().previousSlide();
            const userState = enzymeWrapper.state('props');
            expect(userState.previousSlide).toHaveBeenCalled;
        });
    });

    it('method to be invoked to get next slide', () => {
		enzymeWrapper.instance().nextSlide();
	});
    
    it('method to be invoked to get previous slide', () => {
        enzymeWrapper.instance().previousSlide();
    }); 

    it('identify that div contains 1 a tags', () => {
		expect(enzymeWrapper.find('Next').length).toBe(1);
	});

    it('identify that div contains 1 a tags', () => {
		expect(enzymeWrapper.find('Previous').length).toBe(1);
    });
});