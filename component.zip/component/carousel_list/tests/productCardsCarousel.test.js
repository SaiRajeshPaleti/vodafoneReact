import React from 'react';
import CarouselContent from '../productCardsCarousel/carousel_content';
import renderer from 'react-test-renderer';
import {
	shallow,
	mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import productCardsData from '../../../AppData/productCardsData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<CarouselContent/>', function () {
            let enzymeWrapper;
           let props = {
               data:[
                    {
                        type: 'card4',
                        Id: 'w1',
                        url: 'EWL_interconnect',
                        name: 'Ethernet Wireline',
                        description: 'Interconnect',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w11',
                        url: 'EWL_pointtopoint',
                        name: 'Ethernet Wireless',
                        description: 'Point to Point',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w12',
                        url: 'EWL_MSPbearer',
                        name: 'Ethernet Wirelines',
                        description: 'Bearer',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w31',
                        url: 'EWL_interconnect',
                        name: 'Ethernet Publicline',
                        description: 'Interconnects',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w14',
                        url: 'EWL_interconnect',
                        name: 'Wholesale',
                        description: 'IPVPN',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w15',
                        url: 'EWL_MSPbearer',
                        name: 'Retail',
                        description: 'IPVPNS',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w16',
                        url: 'EWL_interconnect',
                        name: 'Wholesale privateline',
                        description: 'IPVPN point',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w17',
                        url: 'EWL_interconnect',
                        name: 'Wholesale publicline',
                        description: 'IPV point',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w18',
                        url: 'EWL_interconnect',
                        name: 'Entranet Wireline',
                        description: 'IP point',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w19',
                        url: 'EWL_interconnect',
                        name: 'Interconnects Wireline',
                        description: 'IN point',
                        onClick: () => {}
                    },
                    {
                        type: 'card4',
                        Id: 'w10',
                        url: 'EWL_interconnect',
                        name: 'Interconnects privateline',
                        description: 'INCN point',
                        onClick: () => {}
                    }
                ],
                defaultSelctedProd: true,
                clickHandler: (value) => {
                    console.log(value);
                }
           }
            beforeAll(() => {
                enzymeWrapper = mount( < CarouselContent {...props} />);
                });

            it('check for rendering', () => {
                expect(enzymeWrapper).not.toBe(null);
            });

            it('check for activeStatus invocation',()=>{
                const event ={target : {value : "text"}}
                expect(enzymeWrapper.instance().activeStatus(event));                    
            });

            it('check for PriorityCards invocation', () =>{
                expect(enzymeWrapper.find('PriorityCards').length).toBe(11);
            });
  });