import React from 'react';
import { shallow } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import ServiceSpeedOptions from './../serviceSpeedOptions/serviceSpeedOptions';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<ServiceSpeedOptions/>', function () {
	let serviceWrapper, props;
	props = {
		data:[
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '300',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '350',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '400',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '450',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '500',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '550',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '600',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '650',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '700',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '750',
                    onClick: () => {}
                },
                {
                    type: 'card5',
                    id: 's1',
                    name: 'card5',
                    speed: '800',
                    onClick: () => {}
                }
            ]
	};

	beforeAll(() => {
		serviceWrapper = shallow( < ServiceSpeedOptions {...props} /> );
	});

	it('should render ServiceSpeedOptions component', () => {
		expect(serviceWrapper).not.toBe(null);
    });
    
    it('should render serviceOptionSelector function', () => {
        serviceWrapper.instance().serviceOptionSelector('click', '300');
    });

});
