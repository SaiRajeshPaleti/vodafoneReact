import carouselContent from './productCardsCarousel/carousel_content';
import ServiceSpeedOptions from './serviceSpeedOptions/serviceSpeedOptions';

const carouselContents = {
	ProductCarouselList: carouselContent,
	ServiceSpeedsOptions: ServiceSpeedOptions
};

export function getCarouselContent(type) {
	return carouselContents[type];
}
