import React from 'react';
import { defaultStyles } from '../carousel_listDefData-Props';
import PropTypes from 'prop-types';
import PriorityCards from 'vf-ent-ws-priority-cards';
import BaseComponent from 'vf-ent-ws-utilities';

class CarouselContent extends BaseComponent {
	constructor(props) {
		super(props);
		if (this.props.defaultSelctedProd) {
			this.debugLog('default selected data ::::', this.props.defaultSelctedProd);
			this.state = {
				activeTab: true,
				currentCard: this.props.defaultSelctedProd,
				data: this.props.data
			};
		} else {
			this.state = {
				activeTab: false,
				currentCard: ' ',
				data: this.props.data
			};
		}
		this.activeStatus = this.activeStatus.bind(this);
		this.debugLog('current selected data ::::', this.state.currentCard);
	}

	componentWillReceiveProps(nextProps) {
		console.log('nextProps =', nextProps);
		const activeTab = nextProps.cardActiveStatus ? nextProps.cardActiveStatus : false;
		this.setState({
			activeTab,
			currentCard: nextProps.defaultSelctedProd,
			data: nextProps.data
		});
	}
	activeStatus(event) {
		const prevCard = this.state.currentCard;
		let isActive = this.state.activeTab;
		isActive = !prevCard === event.value ? !isActive : true;
		this.setState({
			activeTab: isActive,
			currentCard: event.value
		});

		isActive ? this.props.clickHandler(event.value) : '';
	}

	render() {
		return (
			<div>
				<div className={defaultStyles.tabsWhiteBg}>
					<div className={defaultStyles.tabNavCls}>
						{this.state.data.map((card, index) => {
							return (
								<PriorityCards
									key={index}
									data={Object.assign(
										{},
										card,
										{ onClick: this.activeStatus },
										{ activeTabs: this.state.activeTab },
										{ currentCard: this.state.currentCard }
									)}
								/>
							);
						})}
					</div>
				</div>
			</div>
		);
	}
}

CarouselContent.propTypes = {
	productCarousel: PropTypes.arrayOf(
		PropTypes.shape({
			type: PropTypes.string.isRequired,
			id: PropTypes.string.isRequired,
			url: PropTypes.string.isRequired,
			name: PropTypes.string.isRequired,
			description: PropTypes.string.isRequired,
			onClick: PropTypes.func.isRequired
		})
	),
	clickHandler: PropTypes.func.isRequired
};

export default CarouselContent;
