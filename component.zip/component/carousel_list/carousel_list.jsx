import React from 'react';
import './carousel_list.css';
import { defaultStyles } from './carousel_listDefData-Props';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import { getCarouselContent } from './carouselSelector';
import BaseComponent from 'vf-ent-ws-utilities';

class CarouselList extends BaseComponent {
	constructor(props) {
		super(props);
		const tempArr = this.props.data.card4.slice(
			this.props.data.displayCards.intialIndex,
			this.props.data.displayCards.minimumCards
		);
		this.state = {
			sliderContent: this.props.data.card4,
			startIndex: this.props.data.displayCards.intialIndex,
			endIndex: this.props.data.displayCards.minimumCards,
			tempArr: tempArr,
			cardActiveStatus: this.props.activeTab,
			defaultSelctedProd: this.props.data.defaultSelectedProd
		};
		this.nextSlide = this.nextSlide.bind(this);
		this.previousSlide = this.previousSlide.bind(this);
	}

	nextSlide() {
		let carouselArr = this.state.sliderContent;
		const totalElement = carouselArr.length;
		let firstIndex = this.state.startIndex + this.props.data.displayCards.singleStep;
		let lastIndex = this.state.endIndex + this.props.data.displayCards.singleStep;
		if (lastIndex > totalElement) {
			lastIndex = totalElement;
			firstIndex = lastIndex - this.props.data.displayCards.singleStep;
		}
		console.log('firstIndex = ', firstIndex, lastIndex, carouselArr);

		this.setState({
			tempArr: carouselArr.slice(firstIndex, lastIndex),
			startIndex: firstIndex,
			endIndex: lastIndex,
			cardActiveStatus: true,
			defaultSelctedProd: carouselArr[firstIndex].name
		});
		this.props.data.onClick && this.props.data.onClick(carouselArr[firstIndex].name);
	}

	previousSlide() {
		let carouselDataArr = this.state.sliderContent;
		let intialIndex = this.state.startIndex - this.props.data.displayCards.singleStep;
		let finalIndex = this.state.endIndex - this.props.data.displayCards.singleStep;
		if (intialIndex < 0) {
			intialIndex = 0;
			finalIndex = this.props.data.displayCards.singleStep;
		}
		this.setState({
			tempArr: carouselDataArr.slice(intialIndex, finalIndex),
			startIndex: intialIndex,
			endIndex: finalIndex,
			cardActiveStatus: true,
			defaultSelctedProd: carouselDataArr[intialIndex].name
		});
		this.props.data.onClick && this.props.data.onClick(carouselDataArr[intialIndex].name);
	}

	render() {
		const Carouseldata = getCarouselContent(this.props.data.type);

		return (
			<div className="product_select_list">
				<div className="default_carousel_list">
					<Previous
						data={this.props.data}
						sliderContent={this.state.sliderContent}
						startIndex={this.state.startIndex}
						previousSlide={this.previousSlide}
					/>
					<Carouseldata
						data={this.state.tempArr}
						cardActiveStatus={this.state.cardActiveStatus}
						defaultSelctedProd={this.state.defaultSelctedProd}
						clickHandler={this.props.data.onClick}
					/>
					<Next
						data={this.props.data}
						sliderContent={this.state.sliderContent}
						endIndex={this.state.endIndex}
						nextSlide={this.nextSlide}
					/>
				</div>
			</div>
		);
	}
}

const Previous = (props) => (
	<div
		className={
			props.sliderContent.length <= props.data.displayCards.minimumCards ? (
				defaultStyles.displayNone
			) : (
				defaultStyles.prevIconCls
			)
		}
	>
		<span
			className={
				props.startIndex === props.data.displayCards.intialIndex ? (
					defaultStyles.disableicon
				) : (
					defaultStyles.spriteIconCls
				)
			}
			onClick={props.startIndex === props.data.displayCards.intialIndex ? null : props.previousSlide}
		>
			{console.log('is Previous disabled:::', props.startIndex === props.data.displayCards.intialIndex)}
			<Icon name={defaultStyles.chevronLeftIcon} />
		</span>
	</div>
);

const Next = (props) => (
	<div
		className={
			props.sliderContent.length <= props.data.displayCards.minimumCards ? (
				defaultStyles.displayNone
			) : (
				defaultStyles.nextIconCls
			)
		}
	>
		<span
			// className={defaultStyles.spriteIconCls}
			className={
				props.sliderContent.length === props.endIndex ? defaultStyles.disableicon : defaultStyles.spriteIconCls
			}
			onClick={props.sliderContent.length === props.endIndex ? null : props.nextSlide}
			title={props.data.tooltip ? props.data.tooltip : ''}
		>
			{console.log('is Next disabled:::', props.sliderContent.length === props.endIndex)}
			<Icon name={defaultStyles.chevronLeftIcon} />
		</span>
	</div>
);

CarouselList.propTypes = {
	data: PropTypes.shape({
		type: PropTypes.string.isRequired,
		card4: PropTypes.arrayOf(
			PropTypes.shape({
				type: PropTypes.string.isRequired,
				id: PropTypes.string.isRequired,
				url: PropTypes.string.isRequired,
				name: PropTypes.string.isRequired,
				description: PropTypes.string.isRequired,
				onClick: PropTypes.func.isRequired
			})
		),
		tooltip: PropTypes.string.isRequired,
		displayCards: PropTypes.shape({
			minimumCards: PropTypes.number.isRequired,
			intialIndex: PropTypes.number.isRequired,
			singleStep: PropTypes.number.isRequired,
			multipleStpes: PropTypes.number.isRequired
		}),
		onClick: PropTypes.func.isRequired
	})
};

export default CarouselList;
