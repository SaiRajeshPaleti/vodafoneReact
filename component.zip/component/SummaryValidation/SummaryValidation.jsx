import React from 'react';
import './SummaryValidation.css';
import { constStyles, defaultData } from './SummaryValidationDefData-Props';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

export default class SummaryValidation extends BaseComponent {
	constructor(props) {
		super(props);
		this.navigateToElement = this.navigateToElement.bind(this);
	}

	componentWillMount() {
		this.setListOfErrors(this.props);
	}

	componentWillReceiveProps(nextProps) {
		this.setListOfErrors(nextProps);
	}

	setListOfErrors(props) {
		this.listOfErrors = props.data.messageBody.map((data, index) => {
			return (
				<li key={index} onClick={() => this.navigateToElement(data.id)}>
					{data.label}
				</li>
			);
		});
	}

	navigateToElement(elemID, containerID) {
		const elementID = document.getElementById(elemID);
		if (containerID) {
			document.querySelector(containerID + constStyles.accHead).click();
		}
		if (elementID) {
			//	elementID.scrollIntoView({ behavior: 'instant', block: 'center' });
			elementID.scrollIntoView(false);
			window.scrollBy(0, window.innerHeight / 2);
		}
	}

	render() {
		const messageData = this.props.data;
		return (
			<div id={messageData.id} name={messageData.name} className={constStyles.class.mainClass}>
				<div className={constStyles.class}>
					<span className={constStyles.alertIcon}>
						<Icon name={constStyles.icon} />
					</span>
					<h1>{messageData.messageTitle}:</h1>
					<ol className={constStyles.validationErrors}>{this.listOfErrors}</ol>
				</div>
			</div>
		);
	}
}

SummaryValidation.propTypes = {
	data: PropTypes.shape({
		messageTitle: PropTypes.string.isRequired,
		messageContent: PropTypes.arrayOf(
			PropTypes.shape({
				id: PropTypes.string.isRequired,
				title: PropTypes.string.isRequired
			})
		).isRequired
	})
};
