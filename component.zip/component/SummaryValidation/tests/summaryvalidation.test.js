import React from 'react';
import renderer from 'react-test-renderer';
import SummaryValidation from '../SummaryValidation';
import {
	shallow
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import SummaryValidationData from '../../../AppData/SummaryValidationData';

Enzyme.configure({
	adapter: new Adapter()
});

describe('<SummaryValidation />', function () {
            let props, enzymeWrapper;
            
 
			beforeEach(() => {
					props = SummaryValidationData;
					enzymeWrapper = shallow( <SummaryValidation data = { props } />);
					});

				it('Should render summaryvalidation component', () => {
					expect(enzymeWrapper.find('div').length).toBe(2);
				});

				it('Should have className for the message', () => {
					expect(enzymeWrapper.find('.alert_notifications_light').length).not.toBe(null)	;
				});

				it('should render message title', () => {
					expect(enzymeWrapper.find('h1').length).not.toBe(null);								
				});
				
				it('should show props',() => {
					enzymeWrapper.instance().componentWillReceiveProps(props);
				});
				it('should show instance details',() => {					
					enzymeWrapper.instance().navigateToElement('input1', true);
				});
				
			});