export const constStyles = {
	arrowStyle: 'arrowStyle',
	bgStyle: 'bgStyle',
	class: 'alert_notifications warning_msgs alert_notifications_light',
	validationErrors: 'error_list',
	icon: 'block',
	alertIcon: 'alert_notifications_icon sprite__icon',
	isVaidate: 'validate_msg',
	accHead: 'generic_form_accordion'
};
