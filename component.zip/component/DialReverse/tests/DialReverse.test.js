import React from 'react';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import DialReverse from '../../DialReverse/DialReverse';
import dialData from '../../../AppData/DialData';

Enzyme.configure({ adapter: new Adapter() });

describe('<Dial test cases />', function() {
    let enzymeWrapper, props, clickHandler;
    props = dialData;

    props.map((dailRecord) => {
        beforeEach(() => {
            enzymeWrapper = mount(<DialReverse data={dailRecord} />);
        });
    });
    it('Dial contains div', () => {
        expect(enzymeWrapper.find('.dial-wrapper').length).toBe(1);
    });
    it('Span contains svg', () => {
        expect(enzymeWrapper.find('.dial-wrapper').first().find('svg').length).toBe(1);
    });
    it('SVG handler is called', () => {
        const svg = enzymeWrapper.find('svg');
        svg.simulate('click');
    });
});
