export const constDataVarient = {
    text_wrapper: 'text--wrapper',
    activeText: 'activeText',
    dialVarientFlag: true,
    dial_transform: 'rotate(-89.8 250 250)',
    dial__value: 'dial__value',
    dial__valuelabel: 'dial__value-label',
    dial_valuewrapper: 'dial__value-wrapper',
    dial_Dashboard: 'dial data-dials__dial dial--body dial--finn dial--full dial--dashboard progress-dial',
    dialWrapper: 'dial-wrapper',
    dial__indicator: 'dial_indicator',
    circle_bg_varient: 'circle-bg_varient',
    iconName: 'dial',
    svgDimension: '0 0 500 500',
    class: 'circular-chart green',
    circle: 1,
    initialPercentage: 100,
    totlaDegreeValue: 360,
    totalStrokePercentage: 306,
    totalStrokeValue: 20000,
    componentsVarient: [
        {
            cx: 250,
            cy: 250,
            r: 245,
            class: 'dial__circle-track',
            type: 'circle'
        },
        {
            cx: 250,
            cy: 250,
            r: 245,
            class: 'js-dial-circle dial_circle circle',
            id: 'dial__circle',
            type: 'circle'
        }
    ]
};

export const defaultDataVarient = {
    values: {
        text1: '25',
        text2: 'Priority1',
        text3: 'Expired',
        completionPercentage: '50',
        type: 'Dial',
        circleStyle: 'dial__svg'
    },
    action: function submitHandler() {
        console.log('clicked dial with unknown status ');
    },
    tooltip: 'Click here to get the filtered list view'
};
