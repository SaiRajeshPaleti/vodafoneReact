import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import './DialReverse.css';
import { constDataVarient, defaultDataVarient } from './DialReverseDefProps';

class DialReverse extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			percentage: constDataVarient.initialPercentage
		};
	}

	componentWillMount() {
		this.dailInfo(this.props, '', false);
	}
	componentWillReceiveProps(nextProps) {
		this.dailInfo(nextProps, '', false);
	}
	componentDidMount() {
		const completionPercentage =
			this.props.data.values.text1 / this.props.data.values.total * constDataVarient.initialPercentage;

		this.setState({
			percentage: completionPercentage
		});
		this.dailInfo(this.props, completionPercentage, true);
	}
	dailInfo(props, percentage, flag) {
		const dialData = {
			containerData: props.data,
			percentage: flag ? percentage : this.state.percentage
		};
		this.dailView = <Dail data={dialData} />;
	}
	render() {
		return <div className={constDataVarient.dialWrapper}>{this.dailView}</div>;
	}
}
const Dail = (props) => {
	const { containerData, percentage } = props.data;

	const deg = constDataVarient.totlaDegreeValue * percentage / constDataVarient.initialPercentage;
	let strokePercentage = constDataVarient.totalStrokePercentage * percentage / constDataVarient.initialPercentage;
	const styles = {
		transform: `rotate(${deg}deg)`
	};

	const strokeDashArray = {
		strokeDasharray: `${strokePercentage}% ${constDataVarient.totalStrokeValue}%`
	};
	strokePercentage = constDataVarient.totalStrokePercentage * percentage / constDataVarient.initialPercentage;

	const tooltip = containerData.tooltip;
	const arrowIconClass = constDataVarient.dial__indicator;
	const arrowIconTransform = styles;

	return (
		<div className={constDataVarient.dial_Dashboard} onClick={containerData.action}>
			<div className={constDataVarient.dial_valuewrapper} title={containerData.tooltip}>
				<div className={constDataVarient.dial__valuelabel}>{containerData.values.text1}</div>
				<div className={constDataVarient.text_wrapper}>
					<div className={constDataVarient.dial__value}>{containerData.values.text2}</div>
					<span className={constDataVarient.activeText}>{containerData.values.text3}</span>
				</div>
			</div>
			<span className={arrowIconClass} style={arrowIconTransform} />
			<svg className={containerData.values.circleStyle} viewBox={constDataVarient.svgDimension}>
				<circle
					className={constDataVarient.componentsVarient[0].class}
					cx={constDataVarient.componentsVarient[0].cx}
					cy={constDataVarient.componentsVarient[0].cy}
					r={constDataVarient.componentsVarient[0].r}
					transform={constDataVarient.dial_transform}
				/>
				<circle
					id={constDataVarient.componentsVarient[1].id}
					className={constDataVarient.componentsVarient[1].class}
					cx={constDataVarient.componentsVarient[1].cx}
					cy={constDataVarient.componentsVarient[1].cy}
					r={constDataVarient.componentsVarient[1].r}
					transform={constDataVarient.dial_transform}
					style={strokeDashArray}
				/>
			</svg>
		</div>
	);
};

DialReverse.propTypes = {
	data: PropTypes.shape({
		values: PropTypes.shape({
			text1: PropTypes.string,
			text2: PropTypes.string,
			text3: PropTypes.string,
			completionPercentage: PropTypes.string,
			type: PropTypes.string.isRequired,
			circleStyle: PropTypes.string.isRequired
		}).isRequired,
		action: PropTypes.func,
		tooltip: PropTypes.string
	}).isRequired
};

DialReverse.defaultProps = {
	data: defaultDataVarient
};

export default DialReverse;
