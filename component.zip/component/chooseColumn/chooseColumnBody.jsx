import React from 'react';
import Checkbox from 'vf-ent-ws-checkbox';
import Icon from 'vf-ent-ws-svgicons';
import { constStyle } from './chooseColumnDefData-Props';
import PropTypes from 'prop-types';

const chooseColumnBody = (props) => {

	let colVals = props.columns.map((column, index, i) => {
		if (column.controlType !== 'checkbox') {
            const checkBoxData  = {
				id: column.id,
				name: column.name,
                className: constStyle.inputForm,
                checked: column.isSelected,
                onChange: () => props.chooseColumnMethod(column)
            }
			return (
				<li key={index} index={index}>
					<div className={constStyle.labelCheckable}>
                        <Checkbox data={checkBoxData}/>
						<p className={constStyle.colText}>{column.name}</p>
						<div className={constStyle.priArrows}>
							<span className={constStyle.chevronUp} onClick={() => props.moveUp(column)}>
								<Icon name={constStyle.upIconVal} />
							</span>
							<span className={constStyle.chevronDown} onClick={() => props.moveDown(column)}>
								<Icon name={constStyle.downIconVal} />
							</span>
						</div>
					</div>
				</li>
			);
		} else {
			return "";
		}
	});
    return colVals;
    
}

chooseColumnBody.propTypes = {
    moveUp: PropTypes.func.isRequired,
	moveDown: PropTypes.func.isRequired,
	chooseColumnMethod: PropTypes.func.isRequired,
	columns: PropTypes.arrayOf(
		PropTypes.shape({
			id: PropTypes.string,
			name: PropTypes.string,
			type: PropTypes.string.isRequired,
			controlType: PropTypes.string,
			isSelected: PropTypes.bool.isRequired,
		}).isRequired
	)
};

export default chooseColumnBody;
