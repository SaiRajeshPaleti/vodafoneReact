import React, { PureComponent } from 'react';
import './chooseColumn.css';
import PropTypes from 'prop-types';
import { constStyle, defaultData } from './chooseColumnDefData-Props';
import ChooseColumnHead from './chooseColumnHead';
import ChooseColumnBody from './chooseColumnBody';
import Button from 'vf-ent-ws-button';
import BaseComponent from 'vf-ent-ws-utilities';

class ChooseColumn extends BaseComponent {
	constructor(props) {
		super(props);
		this.state = {
			columnView: false
		};
		this.viewColumn = this.viewColumn.bind(this);
	}

	componentWillMount(){
		this.generateChooseColumnBody(this.props);
	}

	componentWillReceiveProps(nextProps){
		this.generateChooseColumnBody(nextProps);
	}

	generateChooseColumnBody(props){
		this.chooseColumnBody = <ChooseColumnBody {...props.data} />;
	}

	viewColumn() {
		this.setState({ columnView: !this.state.columnView });
	}

	
	
	render() {
		return (
			<div className={constStyle.chooseColumns}>
				<ChooseColumnHead viewColumn={this.viewColumn}  {...this.props.data} />
				<ul className={this.state.columnView ? constStyle.dropdownMenu : constStyle.displayNone}>
					<div className={constStyle.defaultView}>
						<Button data={this.props.data.chooseColumnProps.defaultBtn} />
					</div>
					{this.chooseColumnBody}
				</ul>
			</div>
		);
	}
}

ChooseColumn.proptypes = {
	data: PropTypes.shape({
		defaultBtn: PropTypes.shape({
			id: PropTypes.string.isRequired,
			name: PropTypes.string.isRequired,
			type: PropTypes.string,
			buttonType: PropTypes.string.isRequired,
			onClick: PropTypes.func
		})
	})
};

ChooseColumn.defaultProps = {
	data: defaultData
};

export default ChooseColumn;
