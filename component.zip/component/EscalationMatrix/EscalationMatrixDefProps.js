export const constStyles = {
    container: 'escalation-matrix-container',
    matrixContainer: 'escalation-matrix-matrix-container',
    stageContainer: 'escalation-matrix-stage-container',
    stage: 'escalation-matrix-stage',
    stageText: 'escalation-matrix-stage-text',
    lineContainer: 'escalation-matrix-line-container',
    line: 'escalation-matrix-line',
    arrow: 'escalation-matrix-arrow',
    title: 'escalation-matrix-title',
    titleContainer: 'escalation-matrix-title-container',
}