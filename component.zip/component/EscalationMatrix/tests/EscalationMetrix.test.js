import React from 'react';
import EscalationMatrix from '../EscalationMatrix';
import renderer from 'react-test-renderer';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import EscalationMatrixData from '../../../AppData/EscalationMatrixData';
Enzyme.configure({ adapter: new Adapter() });

global.console = {
  warn: jest.fn(),
  log: jest.fn(),
  error: jest.fn()
}

describe('<EscalationMatrix />', function() {
  let enzymeWrapper;
	beforeEach(() => {
		enzymeWrapper = mount(<EscalationMatrix data={EscalationMatrixData} />);
    });

    it('Only one arrow is rendered', () => {
    let wrapper = shallow(<EscalationMatrix data={EscalationMatrixData} />);
		expect(wrapper.find('.escalation-matrix-arrow').length).toBe(1);
    });

    it('Only one matrix is called', () => {
		expect(enzymeWrapper.find('.escalation-matrix-matrix-container').length).toBe(1);
    });

    it('Only one line is called', () => {
      expect(enzymeWrapper.find('Line').length).toBe(1);
    });

    it('Only one set of titles are called', () => {
      expect(enzymeWrapper.find('.escalation-matrix-title').length).toBe(EscalationMatrixData.length);
    });
    it('All parts are rendered', () => {
      expect(enzymeWrapper.find('.escalation-matrix-container').children().length).toBe(1);
    });
});