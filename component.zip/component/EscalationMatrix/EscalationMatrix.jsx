import React from 'react';
import './EscalationMatrix.css';
import {constStyles} from './EscalationMatrixDefProps'
import PropTypes from 'prop-types';

const EscalationMatrix = (props) => {
    return(
        <div className={constStyles.container}>
            <div className={constStyles.matrixContainer}>
                {props.data.map((data) => (
                    <div className={constStyles.stageContainer} key={data.id}>
                        <div className={`${data.arrow ? constStyles.arrow : constStyles.stage}`}>
                            <span className={constStyles.stageText}>{data.text}</span>
                        </div>
                        <span className={constStyles.title}>{data.caption}</span>
                    </div>
                ))}
                <Line />
            </div>
        </div>
    )
}

const Line = () => {
    return(
        <div className={constStyles.lineContainer}>
            <div className={constStyles.line}/>
        </div>
    )
}

EscalationMatrix.propTypes = {
	data: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.float,
            text: PropTypes.string,
            caption: PropTypes.string,
            caption2: PropTypes.string
	    }).isRequired
    ).isRequired
};

export default EscalationMatrix;