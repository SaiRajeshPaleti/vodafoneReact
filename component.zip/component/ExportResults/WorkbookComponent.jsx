import React from 'react';
import { constStyles, constData } from './ExportResultsDefData-Props';
import ReactExport from 'react-data-export';
import PropTypes from 'prop-types';
import Icon from 'vf-ent-ws-svgicons';

const ExcelFile = ReactExport.ExcelFile;
const ExcelSheet = ReactExport.ExcelFile.ExcelSheet;

const WorkbookComponent = (props) => {
	let activeData = [];

	const calcActiveData = (data) =>
		data.map((obj) => {
			if (!obj.isSelected) {
				return;
			}
			let isUnchecked = false;
			let objCopy = Object.assign({}, obj);
			const uncheckedColumns = columnList(props.columns, false);
			if (uncheckedColumns.length === 0) {
				activeData.push(obj);
			} else {
				isUnchecked = true;
			}
			uncheckedColumns.map((column) => {
				if (objCopy.hasOwnProperty(column.key)) {
					delete objCopy[column.key];
				}
			});
			if (isUnchecked) activeData.push(objCopy);
		});

	const columnList = (arrOfObj, action) => {
		let arr = [];
		arrOfObj.map((data) => {
			if (data['isSelected'] === action) {
				arr.push(data);
			}
		});
		return arr;
	};

	calcActiveData(props.data);
	const listOfActiveColumns = columnList(props.columns, true);
	const columnArray = [];
	let dataList = [];
	let heading = listOfActiveColumns.map((obj) => {
		columnArray.push(obj.key.toLowerCase());
		return { value: obj.name, style: { fill: { patternType: 'solid', fgColor: { rgb: 'FFFF0000' } } } };
	});
	dataList.push(heading);
	JSON.parse(JSON.stringify(activeData)).map((obj) => {
		dataList.push(
			Object.entries(obj)
				.map((arr) => {
					if (columnArray.indexOf(arr[0].toLowerCase()) > -1) {
						return { value: arr[1], name: arr[0] };
					}
				})
				.sort(function(a, b) {
					return columnArray.indexOf(a.name.toLowerCase()) - columnArray.indexOf(b.name.toLowerCase());
				})
				.filter((item) => item)
		);
	});

	const multiDataSet = [
		{
			columns: [],
			ySteps: -1,
			data: dataList
		}
	];
	return activeData.length ? (
		<div>
			<ExcelFile
				filename={props.fileName.split('.')[0]}
				element={
					<span onClick={props.close} id="downloadWorkbook" className={constStyles.linkClass}>
						&nbsp; {constData.saveText}
						<Icon name="chevron-right" />
					</span>
				}
			>
				<ExcelSheet dataSet={multiDataSet} name={props.sheetName} />
			</ExcelFile>
		</div>
	) : (
		<span className={constStyles.optionDisabled}>
			Save as excel<Icon name="chevron-right" />
		</span>
	);
};

WorkbookComponent.propTypes = {
	data: PropTypes.arrayOf(PropTypes.object),
	columns: PropTypes.arrayOf(PropTypes.object),
	fileName: PropTypes.string.isRequired,
	sheetName: PropTypes.string.isRequired
};

export default WorkbookComponent;
