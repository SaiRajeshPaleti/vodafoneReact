import React from 'react';
import { constStyles } from './ExportResultsDefData-Props';
import Icon from 'vf-ent-ws-svgicons';
import PropTypes from 'prop-types';

const ExportResultsHead = (props) => {
	return (
		<div onClick={props.handleClick} className={constStyles.multiSelect}>
			<label className={constStyles.dropdownHeading}>
				<span className={constStyles.dropdownHeadingLight}>
					<strong>{props.label}</strong>
				</span>
			</label>
			<span className={constStyles.spriteIcon} title={props.tooltip}>
				<Icon name={constStyles.dropdownChevron} />
			</span>
		</div>
	);
};

ExportResultsHead.propTypes = {
	label: PropTypes.string.isRequired,
	tooltip: PropTypes.string
};

export default ExportResultsHead;
