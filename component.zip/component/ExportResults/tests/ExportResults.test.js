import React from 'react';
import ExportResults from '../ExportResults';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({
    adapter: new Adapter()
});

describe('<ExportResults/>', function () {
    let props, enzymeWrapper;

    props = {
        data: {
            data: [
                {
                    reference: 'VF_TOP_8822_196301_402',
                    summary: 'Ethernet-2ZSM',
                    status: 'completed',
                    assignedTo: 'Finance',
                    lastUpdated: '14-08-2018',
                    priority: 'low',
                    isSelected: false
                },
                {
                    reference: 'VF_TOP_8822_196301_403',
                    summary: 'Ethernet-3ZSM',
        
                    assignedTo: 'Finance',
                    lastUpdated: '15-08-2018',
                    priority: 'low',
                    status: 'completed',
                    isSelected: true
                }
            ],
            columns: [
                {
                    id: 'data2',
                    name: 'Reference',
                    key: 'reference',
                    type: 'string',
                    isSelected: true,
                    isDisabled: true,
                    sortable: false,
                    link: true
                },
                {
                    id: 'data3',
                    name: 'Summary',
                    key: 'summary',
                    type: 'string',
                    isSelected: true,
                    sortable: false,
                    link: 'false'
                },
                {
                    id: 'data4',
                    name: 'Status',
                    key: 'status',
                    type: 'string',
                    isSelected: true,
                    sortable: false,
                    link: 'false'
                },
                {
                    id: 'data5',
                    name: 'Assigned To',
                    key: 'assignedTo',
                    type: 'string',
                    isSelected: true,
                    sortable: false,
                    link: 'false'
                },
                {
                    id: 'data6',
                    name: 'Last Updated',
                    key: 'lastUpdated',
                    type: 'date',
                    isSelected: true,
                    sortable: false,
                    link: true
                },
                {
                    id: 'data7',
                    name: 'Priority',
                    key: 'priority',
                    type: 'string',
                    isSelected: true,
                    sortable: false,
                    link: 'false'
                }
            ],
            type: 'type2',
            fileName: 'Bulkquotelist.xlsx',
	        sheetName: 'Bulkquotes',
            label: 'Export results'
        }
    };

    beforeAll(() => {
        enzymeWrapper = mount( < ExportResults { ...props } />);
    });

    it('should render ExportResults component', () => {
		expect(enzymeWrapper).not.toBe(null);
    });
    
    it('should render handleCheckboxClick function', () => {
		enzymeWrapper.instance().handleCheckboxClick(props.data.columns[0]);
	});

    it('should render excludeHeadingColumn function', () => {
		enzymeWrapper.instance().excludeHeadingColumn(props);
    });
    
    it('should render handleClickOutside function', () => {
        const event = {
            target: 'test'
        };
		enzymeWrapper.instance().handleClickOutside(event);
	});

	it('should render handleClick function', () => {
		enzymeWrapper.instance().handleClick();
	});
});