import React from 'react';
import ExportResultsHead from '../ExportResultsHead';
import renderer from 'react-test-renderer';
import {
	shallow,
	mount
} from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
Enzyme.configure({
	adapter: new Adapter()
});
describe('<ExportResultsHead/>', function () {
    let props, enzymeWrapper;

    props={
        label: 'test',
        tooltip: 'tooltip test',
        handleClick: () => {
            console.log('test');
        }
    }

    beforeAll(() => {
            enzymeWrapper = shallow( < ExportResultsHead data = { props } />); });

            it('should render ExportResultsHead component', () => {
                expect(enzymeWrapper).not.toBe(null);
            });
    });