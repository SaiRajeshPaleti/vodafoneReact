import React from 'react';
import { constStyles, constData } from './ExportResultsDefData-Props';
import './ExportResults.css';
import PropTypes from 'prop-types';
import ExportResultsHead from './ExportResultsHead';
import WorkbookComponent from './WorkbookComponent';
import Checkbox from 'vf-ent-ws-checkbox';
import Icon from 'vf-ent-ws-svgicons';

class ExportResults extends React.Component {
	constructor(props) {
		super(props);
		this.state = {
			data: this.props.data.data,
			columns: this.excludeHeadingColumn(props),
			isExpanded: false
		};
		this.handleClick = this.handleClick.bind(this);
		this.generateType2Data = this.generateType2Data.bind(this);
		this.setWrapperRef = this.setWrapperRef.bind(this);
		this.handleClickOutside = this.handleClickOutside.bind(this);
		this.applicableClass = constStyles.closeExportResult;
	}

	componentDidMount() {
		document.addEventListener('mousedown', this.handleClickOutside);
	}

	componentWillReceiveProps(nextProps) {
		this.setState({
			data: nextProps.data.data,
			columns: this.excludeHeadingColumn(nextProps)
		});
		this.generateType2Data(nextProps.data);
	}

	componentWillUpdate(nextProps, nextState) {
		this.handleOpenClose(nextProps, nextState);
		this.generateType2Data(nextProps.data);
	}

	componentWillUnmount() {
		document.removeEventListener('mousedown', this.handleClickOutside);
	}

	excludeHeadingColumn(props) {
		const columns = JSON.parse(JSON.stringify(props.data.columns))
			.filter((col) => col.isSelected)
			.filter((col) => col.type !== 'control');
		return columns;
	}

	handleOpenClose(props, state = this.state) {
		this.applicableClass = `${constStyles.w100} ${state.isExpanded
			? constStyles.openExportResult
			: constStyles.closeExportResult}`;
	}

	handleClick() {
		this.setState({
			isExpanded: !this.state.isExpanded
		});
	}

	handleCheckboxClick(column) {
		column.isSelected = !column.isSelected;
		this.setState({
			columns: this.excludeHeadingColumn(this.props)
		});
	}

	generateType2Data(data) {
		this.type2Data =
			data.type === constData.type2 &&
			data.columns.map((column, index, i) => {
				let checkBoxData = {
					id: column.id,
					name: column.name,
					checked: column.isSelected,
					onChange: () => this.handleCheckboxClick(column),
					disabled: column.isDisabled
				};
				column.isSelected == true ? (checkBoxData.value = column.isSelected.toString()) : '';

				return (
					<li key={index}>
						<div className={constStyles.labelCheckable}>
							<Checkbox data={checkBoxData} />
							<p className={constStyles.colText}>{column.name}</p>
						</div>
					</li>
				);
			});
	}

	setWrapperRef(node) {
		this.wrapperRef = node;
	}
	handleClickOutside(event) {
		if (this.wrapperRef && !this.wrapperRef.contains(event.target)) {
			//this.handleClick();
			this.setState({ isExpanded: false });
		}
	}

	render() {
		return (
			<div ref={this.setWrapperRef} className={`${constStyles.filteringDropdown} ${this.props.data.type}`}>
				<div className={this.applicableClass}>
					<ExportResultsHead handleClick={this.handleClick} {...this.props.data} />
					<ul className={constStyles.multiselectContainer}>
						{this.props.data.otherExportsFlag ? (
							this.props.data.otherExports.map((e) => {
								return (
									<li className="exportClass " onClick={e.onClick}>
										{e.name}
										<Icon name="chevron-right" />
									</li>
								);
							})
						) : (
							<li>
								<WorkbookComponent
									data={this.state.data}
									columns={this.state.columns}
									close={this.handleClick}
									{...this.props.data}
								/>{' '}
							</li>
						)}
						{this.type2Data}
					</ul>
				</div>
			</div>
		);
	}
}

ExportResults.propTypes = {
	data: PropTypes.shape({
		data: PropTypes.arrayOf(Object)
	})
};

export default ExportResults;
