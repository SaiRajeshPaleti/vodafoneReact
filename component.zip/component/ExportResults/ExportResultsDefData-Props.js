export const constStyles = {
	filteringDropdown: 'filtering__dropdown dropdown customDropdown choose_columns',
	multiSelect: 'filtering__dropdown--button dropdown__button',
	dropdownHeading: 'dropdown__heading',
	dropdownChevron: 'chevron-down',
	spriteIcon: 'sprite__icon down__arrow',
	multiselectContainer:
		'multiselect-container dropdown-menu-new dropdown__panel dropdown__panel--column custom-menu-dp',
	linkClass: 'link',
	dropdownHeadingLight: 'dropdown__heading--light',
	w100: 'dropdown',
	labelCheckable: 'form__label--checkable filter__label exportResultInput',
	colText: 'columsText',
	openExportResult: 'openexportresults',
	closeExportResult: 'closeexportresults',
	optionDisabled: 'option_disabled'
};

export const constData = {
	saveText: 'Save as excel',
	type2: 'type2'
};
