export const defaultStyles = {
	chevronIcon: 'chevron-down',
	gridItemFormSmallBottom: 'grid__item form-small--bottom search-grid',
	positiveRelativeDblock: 'position_relative dblock',
	formInputForm: 'form-input form__input--selectable',
	formSelect: 'form__select_cr',
	chevronSearch: 'chevron-search-custom',
	arrow: 'arrow'
};
export const actions = {
	onChange: 'onChange'
};
export const staticData = {
	value: 'value'
};
