import React from 'react';
import PropTypes from 'prop-types';
import BaseComponent from 'vf-ent-ws-utilities';
import Icon from 'vf-ent-ws-svgicons';
import './SelectDropDown.css';
import { defaultStyles, actions, staticData } from './SelectDropDownDefData-Props';
class SelectDropDown extends BaseComponent {
  constructor(props) {
    super(props);
    this.getSelectedValue = this.getSelectedValue.bind(this);
    this.changeArrow = this.changeArrow.bind(this);
    this.state = { flag: true };
  }
  componentWillMount() {
    this.dropdown = this.loadDropDown(this.props.data);
  }
  componentWillReceiveProps(nextProps) {
    this.dropdown = this.loadDropDown(nextProps.data);
  }
  changeArrow() {
    this.setState({
      flag: !this.state.flag
    });
    this.dropdown = this.loadDropDown(this.props.data, this.state.flag);
  }
  getSelectedValue(e) {
    this.delegateHandler(actions.onChange, e, staticData.value);
  }
  loadDropDown(data, flag) {
    const dropData = {
      data: data,
      getSelectedOption: this.getSelectedValue,
      changeArrow: this.changeArrow,
      flag: flag
    };
    return <SelectBox data={dropData} />;
  }
  render() {
    return <div className={defaultStyles.positiveRelativeDblock}>{this.dropdown}</div>;
  }
}
const SelectBox = (props) => {
  const { data, getSelectedOption, changeArrow, flag } = props.data;
  const defaultData = data.selectedvalue ? data.selectedvalue : data.defaultValue;
  return (
    <div className={defaultStyles.formInputForm} onClick={changeArrow}>
      <select
        className={defaultStyles.formSelect}
        name={data.selectBoxName}
        id={data.selectBoxId}
        onChange={getSelectedOption}
      >
        {data.dropdown.map((item) => (
          <option
            key={item.itemValue}
            label={item.itemName}
            value={item.itemValue}
            selected={defaultData === item.itemName}
          >
            {item.itemName}
          </option>
        ))}
      </select>

      <div className={defaultStyles.chevronSearch}>
        <Icon name={defaultStyles.chevronIcon} />
      </div>
    </div>
  );
};
SelectDropDown.propTypes = {
  data: PropTypes.shape({
    dropdown: PropTypes.arrayOf(
      PropTypes.shape({
        itemName: PropTypes.string.isRequired,
        itemValue: PropTypes.string.isRequired
      }).isRequired
    ).isRequired,
    selectBoxId: PropTypes.string.isRequired,
    selectBoxName: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired
  }).isRequired
};
export default SelectDropDown;
