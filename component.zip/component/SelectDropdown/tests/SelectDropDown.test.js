import React from 'react';
import renderer from 'react-test-renderer';
import { mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import SelectDropDown from '../SelectDropDown';
import SelectDropDownData from '../../../AppData/SelectDropDownData';

Enzyme.configure({ adapter: new Adapter() });

describe('<SelectDropDown/>', function() {
    let enzymeWrapper, props, count, clickHandler;
    beforeEach(() => {
        enzymeWrapper = mount(<SelectDropDown data={SelectDropDownData} />);
    });

    it('Select DropDown contains a dropdown', () => {
        expect(enzymeWrapper.find('.form__select_cr').length).toEqual(1);
    });

    it('event handler to be called on change of select box', () => {
        let dropdown = enzymeWrapper.find('.form__select_cr');
        dropdown.simulate('change');

        expect(enzymeWrapper.instance().getSelectedOption).toHaveBeenCalled;
    });
});
