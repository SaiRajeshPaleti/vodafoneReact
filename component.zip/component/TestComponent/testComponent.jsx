import React, { PureComponent } from 'react';

import PropTypes from 'prop-types';
//import Label from 'vf-ent-ws-label';

import BaseComponent from 'vf-ent-ws-utilities';
import GenericSearch from '../../components_framework/GenericSearch/GenericSearch';
//import LinkTileWithBusinessService from 'vf-ent-ws-link-tile-business-service';
import LinkTileWithBusinessService from '../LinkTileWithBusinessService/LinkTileWithBusinessService';
import { constBtnIconStyle } from 'vf-ent-ws-button/buttonDefData-Props';
class TestComponent extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {};
    this.prepareData = this.prepareData.bind(this);
    this.check = this.check.bind(this);
  }

  componentWillMount() {
    this.prepareData(this.props.data);
  }

  componentWillReceiveProps(nextProps) {
    this.prepareData(nextProps.data);
  }
  prepareData(data) {
    data.genericSearch.textField.onChange = this.check;
    this.setState({
      data: data,
      defaultData: data
    });
  }

  check(e) {
    console.log('Onchange');
    let tileStore = JSON.parse(JSON.stringify(this.state.defaultData));
    tileStore.genericSearch.textField.onChange = this.check;
    const matchedService = [];
    tileStore.linkTile.linkTile.map((list) => {
      const matchedData = [];
      const businessService = list.businessServicename;
      list.tileData.map((tile) => {
        const description = tile.description;
        const title = tile.title;

        if (
          e.value != '' &&
          (description.includes(e.value) || title.includes(e.value) || businessService.includes(e.value))
        ) {
          matchedData.push(tile);
        }
        return (tile.highlightText = e.value);
      });
      if (!businessService.includes(e.value) && matchedData.length === 0) {
        list.businessServicename = '';
      }
      matchedService.push(list);

      list.highlightText = e.value;
      list.tileData = matchedData;
    });

    tileStore.linkTile.linkTile = matchedService;
    console.log('Test', matchedService);
    this.setState({
      data: e.value === '' ? this.state.defaultData : tileStore
    });
  }

  render() {
    const genericSearchData = this.state.data.genericSearch;
    const linkTileData = this.state.data.linkTile;
    return (
      <div>
        <GenericSearch data={genericSearchData} />
        <LinkTileWithBusinessService data={linkTileData} />
      </div>
    );
  }
}
export default TestComponent;
