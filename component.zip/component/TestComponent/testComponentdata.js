export default {
  genericSearch: {
    onChangeHandler: function changeHandler() {
      //method implementation goes here
    },

    searchIconFont: 'p',
    clearIconFont: '3',

    textField: {
      id: 'search-snack-input',
      name: 'txt1',
      title: '',
      placeholder: 'Enter some text',
      maxLength: 40,
      onChange: (value) => console.log('input value:', value)
    },
    buttonWithIconData: [
      {
        location: 'right',
        id: 'rightIconButton',
        name: 'Right icon button',
        type: 'primary',
        buttonType: 'button',
        isIcon: true
      }
    ]
  },
  linkTile: {
    linkTile: [
      {
        businessServicename: 'Ethernet VPN',
        highlightText: 'e',
        id: 1,
        tileData: [
          {
            id: 'linktile1',
            title: 'Raise incident',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'warning',
            onClick: (id, title) => {
              console.log('Clicked by ' + id + ' with the title ' + title);
            },
            highlightText: 'raise inci'
          },
          {
            id: 'linktile2',
            title: 'Raise service request',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'settings',
            onClick: (id, title) => {
              console.log('Clicked by ' + id + ' with the title ' + title);
            },
            highlightText: 'raise'
          },
          {
            id: 'linktile3',
            title: 'Raise order',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'icon-shopping-trolley',
            onClick: (id, title) => {
              console.log('Clicked by ', id);
            },
            highlightText: 'raise'
          }
        ]
      },
      {
        businessServicename: 'Ethernet ',
        highlightText: 'e',
        id: 2,
        tileData: [
          {
            id: 'linktile4',
            title: 'Raise incident',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'warning',
            onClick: (id, title) => {
              console.log('Clicked by ' + id + ' with the title ' + title);
            },
            highlightText: 'raise inci'
          },
          {
            id: 'linktile5',
            title: 'Raise service request',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'settings',
            onClick: (id, title) => {
              console.log('Clicked by ' + id + ' with the title ' + title);
            },
            highlightText: 'raise'
          },
          {
            id: 'linktile6',
            title: 'Raise order',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'icon-shopping-trolley',
            onClick: (id, title) => {
              console.log('Clicked by ', id);
            },
            highlightText: 'raise'
          }
        ]
      },
      {
        businessServicename: 'VPN',
        highlightText: 'e',
        id: 3,
        tileData: [
          {
            id: 'linktile7',
            title: 'Raise incident',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'warning',
            onClick: (id, title) => {
              console.log('Clicked by ' + id + ' with the title ' + title);
            },
            highlightText: 'raise inci'
          },
          {
            id: 'linktile8',
            title: 'Raise service request',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'settings',
            onClick: (id, title) => {
              console.log('Clicked by ' + id + ' with the title ' + title);
            },
            highlightText: 'raise'
          },
          {
            id: 'linktile9',
            title: 'Raise order',
            description: 'Allows you to raise an issue with your Business Service',
            icon: 'icon-shopping-trolley',
            onClick: (id, title) => {
              console.log('Clicked by ', id);
            },
            highlightText: 'raise'
          }
        ]
      }
    ]
  }
};
