import React, { PureComponent } from 'react';

export default class BaseComponent extends PureComponent {
	constructor(props) {
		super(props);
		if (this.constructor === BaseComponent) {
			throw new TypeError('Abstract class "BaseComponent" cannot be instantiated directly.');
		}
		this.delegateHandler = this.delegateHandler.bind(this);
	}

	/*
    * This handler would decide whether or not the parent function needs to be invoked. 
    * Parameters:
    * propertyName : the name of the property that you want to be searched within the props data object that correlates to the parent function
    * event : the DOM event object that triggered the DOM event
    * args : This can be of 2 types
    *   1) this object can hold a name of a property that you want to search within the event object passed above; Using this you can define *which data value you want to send back to the parent; Using this approach a data object consisting of the id of the component that triggered the change and the changed value will be sent back to the parent
    * 
    *   2) A function which accepts the event object passed above and should return a data object that would be passed back to the parent function; Using this approach, the responsibility lies with the function itself to send a proper data object that a parent can use
    * 
    * Returns:
    * This function would not return any value to the caller 
    */
	delegateHandler(propertyName, event, args) {
		if (
			this.props.data &&
			this.props.data.hasOwnProperty(propertyName) &&
			this.props.data[propertyName] instanceof Function
		) {
			console.log('fn passed');
			let response =this.props.data[propertyName](
				args instanceof Function
					? args(event)
					: Object.assign({}, { id: event.target.id, value: event.target[args] })
			);
			return response;
		} else {
			console.log('fn not passed');
		}
	}
	debugLog(...data) {
		if (window.LogInfo) {
			window.LogInfo(...data);
		} else {
			console.log(...data);
		}
	}
}
