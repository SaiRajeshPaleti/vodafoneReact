import React from 'react';
import ComponetFactory from './ComponentFactory';
import { defaultStyles } from './AdvancedSearchDefData-Props';
import DateRangeComponent from './DateRangeComponent';

const FormElement = (fieldData, handler, isRange) => {
	if (isRange) {
		return <DateRangeComponent data={fieldData} handler={handler} />;
	} else {
		return <div className={defaultStyles.className.advrow}>{ComponetFactory(fieldData, handler, isRange)}</div>;
	}
};
export default FormElement;
