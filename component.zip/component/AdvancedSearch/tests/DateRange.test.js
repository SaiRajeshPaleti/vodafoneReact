import React from 'react';
import renderer from 'react-test-renderer';
import DateRangeComponent from '../DateRangeComponent';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';

Enzyme.configure({ adapter: new Adapter() });

describe('<DateRangeComponent />', function() {
	let enzymeWrapper, props, count, clickHandler;
	props = {
		data :{
			rangeAttributes: [
				{
					data: {
						name: 'name',
						title: 'StartDate',
						id: 'date_picker',
						searchAttribute: 'StartDate',
						componentType: 'SimpleDate',
						inputId: 'cove-200',
						placeholder: 'Start Date',
						value: '',
						locale: 'en',
						format: 'DD MMM YYYY',
						before: 0,
						after: 10
					},
					searchAttribute: 'StartDate',
					componentType: 'SimpleDate'
				},
				{
					data: {
						name: 'datePicker',
						id: 'date_picker',
						title: 'EndDate',
						searchAttribute: 'EndDate',
						componentType: 'SimpleDate',
						inputId: 'cove-200',
						placeholder: 'Enter date',
						value: '',
						locale: 'en',
						format: 'DD MMM YYYY'
						// before: 45,
						// after: 0
					},
					searchAttribute: 'EndDate',
					componentType: 'SimpleDate'
				}
			]
		}
	}
	beforeEach(() => {		
		enzymeWrapper = mount(
			<DateRangeComponent { ...props } />
		);
	});

	it('should render DateRange', () => {
		
    });
    
});