import React from 'react';
import renderer from 'react-test-renderer';
import AdvancedSearch from '../AdvancedSearch';
import { shallow, mount } from 'enzyme';
import Enzyme from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import advancedSearchData from '../../../AppData/advancedSearchData';
//import advancedSearchTestData from '../../../AppData/advancedSearchTestData';
//import advancedSearchRangeData from '../../../AppData/advancedSearchRangeData';
import FormElement from '../AdvancedFormElement';
import moment from 'moment';

Enzyme.configure({ adapter: new Adapter() });

describe('<AdvancedSearch />', function() {
	
	let enzymeWrapper, count, clickHandler;
	let props = {
		data:{
			submitHandler: () => {
				//console.log('search query  ' + ' <<url>>' + '<<Default criteria>> ' + JSON.stringify(searchCriteria));
			},
			criteria: { QuoteReferenceNo: '123', StartDate: '2018-08-28T13:26:09.927Z' },
			clearFn: () => {
				//console.log('Cleared!');
			},
			closeTooltip: 'Click here to close the advanced search criteria view',
			getClickAdvanceSearch: ()=>{},			
			name: "datePicker", 
			id: "date_picker", 
			title: "EndDate", 
			searchAttribute: "EndDate", 
			componentType: "SimpleDate"
		}
	};
	beforeEach(() => {
		//console.log('props are in testcase',props);		
		enzymeWrapper = shallow(
			// <AdvancedSearch
			// 	// advancedSearchComponentData={props.advancedSearchComponentData}
			// 	// submitHandler={props.onSubmitHandler}
			// 	{ ...props }
			// />
			<AdvancedSearch data={advancedSearchData} />
		);
	});

	// it('AdvancedSearch contains  div', () => {
	// });

	it('should render AdvancedSearch component', () => {
		expect(enzymeWrapper).not.toBe(null);
	});
	it('AdvancedSearch Component should render div', () => {		 		     
        expect(enzymeWrapper.find('div').length).toEqual(13);
	});

	it('AdvancedSearch contains table', () => {
		expect(enzymeWrapper.find('table').length).toBe(0);
	});
	it('Verifying button main Div ', () => {
		expect(enzymeWrapper.find('button').length).toBe(0);
	});
	it('Verifying onClear ', () => {
		//const userState = enzymeWrapper.state('data');
		enzymeWrapper.instance().onClear();
		//enzymeWrapper.instance().reset();
		//console.log('state--->',wrapper.state());
		//enzymeWrapper.setState({disableFlag:true})
		
	});
	it('Verifying onSubmit ', () => {
		enzymeWrapper.instance().onSubmit();
	});
	it('Verifying attributeValue() ', () => {
		let attrProps={
			e : {
				id: "cove=301", value: "a"
			},
			compType:"Text"

		}
		enzymeWrapper.instance().attributeValue(attrProps);
	});
	it('Verifying forceUpdate() ', () => {
		enzymeWrapper.instance().forceUpdate();
	});
	
	it('should render handler function', () => {
		//const e = {id: "cove=301", value: "someValue"}  //	//e={value:10}
		//const backendAttribute = "CustomerReferenceNo";
		const e = { target:{ value: 10 }}
		const backendAttribute = { target:{ value: 'CustomerReferenceNo' }}
		enzymeWrapper.instance().handler(e, backendAttribute);
	}); 
	 
	it('AdvancedSearch contains  input Component', () => {
		expect(enzymeWrapper.find('input').length).toBe(0);
	});

	it('event handler to be called on clicking submit', () => {
		let button = enzymeWrapper.find('#submitbtnid');
		button.simulate('click');
		expect(props.submitHandler).toHaveBeenCalled;
	});

	it('event handler to be called on clicking cancel', () => {
		let button = enzymeWrapper.find('#cancelbtnid');
		button.simulate('click');
		expect(props.submitHandler).toHaveBeenCalled;
	});

	// it('event handler called on search data', () => {
	// 	let input1 = enzymeWrapper.find('#cove-300');
	// 	let input2 = enzymeWrapper.find('#cove-301');
	// 	let input3 = enzymeWrapper.find('#cove-302');
	// 	input1.simulate('blur', { target: { value: 'Q' } });
	// 	input2.simulate('blur', { target: { value: 'PO' } });
	// 	input3.simulate('blur', { target: { value: 'UK' } });
	// 	expect(props.changeHandler).toHaveBeenCalled;
	// });

	// it('event handler called on date range search data', () => {
	// 	let startPicker = enzymeWrapper.find('#cove-303').first();
	// 	let endPicker = enzymeWrapper.find('#cove-304').first();
	// 	const DATE_EU_FORMAT = 'dd/mm/yyyy';
	// 	let newDate = null;
	// 	const props = {
	// 		data: {
	// 			value: '26/01/2018',
	// 			inputId: 'cove-303'
	// 		},
	// 		onChange: (stringEUDate) => {
	// 			newDate = stringEUDate;
	// 		}
	// 	};
	// 	//selected
	// 	startPicker.instance().props.onChange(moment());
	// 	endPicker.instance().props.onChange(moment());
	// 	expect(endPicker).toBe('27-09-12');
	// });


});

// describe('<AdvancedSearch with date range/>', function() {
// 	let enzymeWrapper, props, count, clickHandler;
// 	beforeEach(() => {
// 		clickHandler = AdvancedSearch.clickHandler;
// 		props = advancedSearchRangeData;
// 		enzymeWrapper = mount(
// 			<AdvancedSearch
// 				advancedSearchComponentData={props.advancedSearchComponentData}
// 				submitHandler={props.onSubmitHandler}
// 			/>
// 		);
// 	});

// 	it('AdvancedSearch with date range contains  div', () => {
// 		let props = advancedSearchData;
// 		let formElement = FormElement(props.advancedSearchComponentData[0], props.onSubmitHandler, true);

// 		expect(enzymeWrapper.find('div').length).toBe(27);
// 	});
// });

//Enzyme.configure({ adapter: new Adapter() });

// describe('<AdvancedSearch submit test/>', function() {
// 	let enzymeWrapper, props, count, clickHandler;
// 	beforeEach(() => {
// 		clickHandler = AdvancedSearch.clickHandler;
// 		props = advancedSearchTestData;
// 		enzymeWrapper = mount(
// 			<AdvancedSearch
// 				advancedSearchComponentData={props.advancedSearchComponentData}
// 				submitHandler={props.onSubmitHandler}
// 			/>
// 		);
// 	});

// 	it('AdvancedSearch submit', () => {
// 		let button = enzymeWrapper.find('#submitbtnid');
// 		button.simulate('click');
// 		expect(props.submitHandler).toHaveBeenCalled;
// 	});

// });
