import React from 'react';
import ComponetFactory from './ComponentFactory';
import BaseComponent from 'vf-ent-ws-utilities';

class DateRangeComponent extends BaseComponent {
	constructor(props) {
		super(props);
	}
	componentWillReceiveProps(nextProps) {}
	render() {
		return (
			<div>
				{this.props.data.rangeAttributes.map((advancedCompData, index) =>
					ComponetFactory(advancedCompData, this.props.data.onChange, true)
				)}
			</div>
		);
	}
}

export default DateRangeComponent;
