export const defaultStyles = {
	Data: {
		submitButton: {
			buttonType: 'button',
			id: 'submitbtnid',
			name: 'Search',
			type: 'primary'
		},
		clearButton: {
			buttonType: 'button',
			id: 'cancelbtnid',
			name: 'Clear',
			type: 'transparent'
		}
	},
	className: {
		buttonContainerClass: 'p-0 grid__item grid__item--gutter grid__item--md-1/1 grid__item--1/1',
		buttonAlignRight: 'buttons_right',
		buttonClear: 'btns_right_clear',
		advancedSearchContainerClass:
			'p-0 grid__item grid__item--gutter grid__item--md-1/1 grid__item--1/1 form-small--bottom',

		iconCloseClass: 'close_icon sprite__icon',
		CloseIcon: 'close',
		advanceSearchCompClass: 'advance_search_comp',
		advrow: 'adv_row',
		advDateRange: 'adv_date_range date_picker',
		inlBlock: 'inline-block'
	}
};
