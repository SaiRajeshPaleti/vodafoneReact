import React from 'react';
import { defaultStyles } from './AdvancedSearchDefData-Props';
import AdvancedSearchFormElementRegistry from './AdvancedSearchFormElementRegistry';

const ComponentFactory = (fieldData, handler, isRange) => {
	const CustomComponent = AdvancedSearchFormElementRegistry[fieldData.componentType];
	return (
		<div
			id={fieldData.componentType}
			className={isRange ? defaultStyles.className.advDateRange : defaultStyles.className.advrow}
		>
			{
				<CustomComponent
					data={Object.assign({}, fieldData, {
						onChange: fieldData.searchAttribute
							? (evt) => handler(evt, fieldData.searchAttribute, fieldData.value)
							: handler
					})}
				/>
			}
		</div>
	);
};
export default ComponentFactory;
