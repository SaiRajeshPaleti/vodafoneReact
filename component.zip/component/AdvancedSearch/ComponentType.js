export const componentType = {
	TEXTFIELD: 'Text',
	DATEPICKER: 'SimpleDate',
	DATERANGE: 'DateRange'
};
export default componentType;
