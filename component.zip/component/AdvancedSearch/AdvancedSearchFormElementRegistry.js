//import CustomDatePicker from '../DayPicker/CustomDayPicker';
import TextField from 'vf-ent-ws-textfield';
import DateRangeComponent from './DateRangeComponent';
import CustomDatePicker from 'vf-ent-ws-daypicker';
const AdvancedSearchFormElementRegistry = {
	Text: TextField,
	DateRange: DateRangeComponent,
	SimpleDate: CustomDatePicker
};
export default AdvancedSearchFormElementRegistry;
