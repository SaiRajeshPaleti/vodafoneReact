import React from 'react';
import Button from 'vf-ent-ws-button';
import { defaultStyles } from './AdvancedSearchDefData-Props';
import './AdvancedSearch.css';
import FormElement from './AdvancedFormElement';
import ComponentType from './ComponentType';
import moment from 'moment';
import Icon from 'vf-ent-ws-svgicons';
import BaseComponent from 'vf-ent-ws-utilities';

class AdvancedSearch extends BaseComponent {
	constructor(props) {
		super(props);
		//console.log('new component of advanced search created', props.data);
		this.resetValue = JSON.parse(JSON.stringify(props.data));
		this.newArray = JSON.parse(JSON.stringify(props.data));
		this.criteria = props.data.criteria != undefined ? props.data.criteria : {};
		this.recMainFn(this.newArray.advancedSearchComponentData);
		this.initialValue = JSON.stringify(props.data);
		this.state = {
			fieldsData: Object.assign([], this.newArray),
			disableFlag: true
		};
		this.handler = this.handler.bind(this);
		this.attributeValue = this.attributeValue.bind(this);
		this.onClear = this.onClear.bind(this);
		this.onSubmit = this.onSubmit.bind(this);
	}

	recMainFn(val) {
		var b = [];
		if (val.constructor == Array) {
			b = val;
			b.map((el) => {
				Object.values(el).map((sEl) => {
					if (typeof sEl != 'object') {
						this.recFn(el);
					} else {
						this.recMainFn(sEl);
					}
				});
			});
		} else if (val.constructor == Object) {
			b = Object.values(val);
			b.map((sEl) => {
				if (typeof sEl != 'object') {
					this.recFn(val);
				} else {
					this.recMainFn(sEl);
				}
			});
		}
	}
	recFn(obj) {
		if (obj.hasOwnProperty('id') && this.criteria[obj.searchAttribute] != undefined) {
			obj.value = this.criteria[obj.searchAttribute];
		}
	}

	handler(e, backendAttribute) {
		console.log(backendAttribute);
		let a = true;
		this.newFieldsData = this.state.fieldsData;

		let derivingUpdated = false;
		this.newFieldsData.advancedSearchComponentData.map((el) => {
			if (!el.hasOwnProperty('isRangeAttribute')) {
				if (e && e.id == el.id) {
					el.value = this.attributeValue(e, el.componentType);
					if (el.value.length > 2) {
						a = false;
					}
				} else if (el.value.length > 2) {
					a = false;
				}
			} else if (el.componentType == 'DateRange') {
				console.log('inside date range ', el.rangeValue);
				const rangeValue = el.rangeValue;
				let derivingDayFromToday = 0;
				el.rangeAttributes.map((dateEl) => {
					if (dateEl.searchAttribute == backendAttribute) {
						dateEl.data.value = moment(e).toISOString();
						if (dateEl.data.deriving) {
							derivingUpdated = true;
							derivingDayFromToday = moment(new Date()).diff(moment(e), 'days');
							// added below code to fix 1 day diffrence in moment day count
							var addedDate = moment().subtract(derivingDayFromToday, 'days');
							if (addedDate.format('YYYY-MM-DD') != moment(e).format('YYYY-MM-DD')) {
								derivingDayFromToday = derivingDayFromToday + 1;
							}
							// end of day count fix.
						}
						a = false;
					} else {
						if (dateEl.data.value != '' && dateEl.data.value != undefined) {
							a = false;
						}
						if (derivingUpdated && rangeValue > 0 && !dateEl.data.deriving) {
							dateEl.data.before = derivingDayFromToday;
							derivingUpdated = false;
							if (derivingDayFromToday - rangeValue > 0) {
								dateEl.data.value = moment()
									.subtract(derivingDayFromToday - rangeValue, 'days')
									.toISOString();
								dateEl.data.after = -1 * (derivingDayFromToday - rangeValue);
							} else {
								dateEl.data.value = moment().toISOString();
								dateEl.data.after = 0;
							}

							this.forceUpdate();
						}
					}
				});
			}
		});

		this.setState({ disableFlag: a });
	}

	attributeValue(e, compType) {
		switch (compType) {
			case ComponentType.TEXTFIELD:
				return e.value;
			case ComponentType.DATEPICKER:
				return e;
		}
	}
	onSubmit = () => {
		let searchElement = {};
		this.state.fieldsData.advancedSearchComponentData.map((advancedCompDataElement) => {
			if (advancedCompDataElement.isRangeAttribute) {
				advancedCompDataElement.rangeAttributes.map((rangeDataElement) => {
					if (rangeDataElement.data.value) {
						searchElement[rangeDataElement.data.searchAttribute] = rangeDataElement.data.value;
					}
				});
			} else {
				if (advancedCompDataElement.value)
					searchElement[advancedCompDataElement.searchAttribute] = advancedCompDataElement.value;
			}
		});
		this.props.data.submitHandler(searchElement);
	};

	onClear = () => {
		this.props.data.clearFn != undefined && this.props.data.clearFn();
		this.myFormRef.reset();
		const fieldsData = Object.assign({}, JSON.parse(JSON.stringify(this.resetValue)));

		let dateRange = fieldsData.advancedSearchComponentData.filter(
			(advData) => advData.componentType == 'DateRange'
		);

		if (
			dateRange &&
			dateRange[0].rangeAttributes &&
			dateRange[0].rangeAttributes.length > 1 &&
			dateRange[0].rangeAttributes[1].data.hasOwnProperty('defaultafter')
		) {
			dateRange[0].rangeAttributes[1].data.after = dateRange[0].rangeAttributes[1].data.defaultafter;
		}

		if (
			dateRange &&
			dateRange[0].rangeAttributes &&
			dateRange[0].rangeAttributes.length > 1 &&
			dateRange[0].rangeAttributes[1].data.hasOwnProperty('defaultbefore')
		) {
			dateRange[0].rangeAttributes[1].data.before = dateRange[0].rangeAttributes[1].data.defaultbefore;
		}

		console.log('fieldsData....', JSON.stringify(fieldsData));
		this.setState({ fieldsData });
		this.setState({ disableFlag: true });
	};

	render() {
		return (
			<div className={defaultStyles.className.advanceSearchCompClass}>
				<form ref={(el) => (this.myFormRef = el)}>
					<h1 className={defaultStyles.className.inlBlock}>Advanced search</h1>
					<span
						className={defaultStyles.className.iconCloseClass}
						onClick={this.props.data.getClickAdvanceSearch}
						title={this.props.data.closeTooltip ? this.props.data.closeTooltip : ''}
					>
						<Icon name={defaultStyles.className.CloseIcon} />
					</span>

					<div>
						{this.state.fieldsData.advancedSearchComponentData.map((advancedCompData, index) =>
							FormElement(advancedCompData, this.handler, false)
						)}
					</div>
					<div>
						<div className={defaultStyles.className.buttonAlignRight}>
							<div className={defaultStyles.className.buttonClear}>
								<Button
									data={Object.assign({}, defaultStyles.Data.clearButton, {
										onClick: () => this.onClear(this.resetFieldsData)
									})}
								/>
							</div>
							<Button
								data={Object.assign({}, defaultStyles.Data.submitButton, {
									onClick: this.onSubmit,
									isDisabled: this.state.disableFlag
								})}
							/>
						</div>
					</div>
				</form>
			</div>
		);
	}
}

export default AdvancedSearch;
